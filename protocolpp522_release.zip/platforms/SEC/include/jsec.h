#ifndef JSEC_H_
#define JSEC_H_

///
///\class jsec jsec.h "include/jsec.h"
///   
///\section SEC Security Encryption CoProcessor (SEC)
///
/// Class to create shared descriptors for the SEC/CAAM architecture found 
/// in the Freescale/NXP/Qualcomm QorIQ and Layerscape network processors
/// See the Security Reference Manual for the QorIQ processor desired for
/// shared descriptor layout of each protocol in the ENCAP and DECAP
/// directions
///
/// Also created job descriptors to process input and output data in
/// the SEC/CAAM architecture. Contains support for reading and writing
/// SG tables in the formats supported by SEC/CAAM
///
/// NOTE: Commands in the shared descriptor are big endian but inline
///       data may be little endian if the platform requires it such
///       as some of the ARM based Layerscape processors. Examples of
///       data that may be little endian are the IV, NONCE, SALT, and
///       INITCNT
///
/// <table>
/// <caption id="jsecconstants">\f$ IPsec\; cipher\; and\; authentication\; modes \f$</caption>
/// <tr><th>cipher<th>authentication
/// <tr><td>NULL_CIPHER <td>NULL_AUTH
/// <tr><td>DES_CBC <td>HMAC_MD5
/// <tr><td>3DES_CBC <td>HMAC_SHA1
/// <tr><td>AES_CBC <td>AES_XCBC_MAC
/// <tr><td>AES_CTR <td>AES_CMAC
/// <tr><td>AES_CCM <td>HMAC_SHA2_256
/// <tr><td>AES_GCM <td>HMAC_SHA2_384
/// <tr><td> <td>HMAC_SHA2_512
/// </table>
///
/// The methods and constructor for NXPs SEC(CAAM) support in Protocol++&reg; (ProtocolPP&reg;) are as follows
///\code
///
/// // Constructor for JSEC
/// jsec(sgt_t sgt, unsigned long seed);
///
///
/// // Return the properly formatted shared descriptor converted from the
/// // Protocol++ (ProtocolPP) security association and type
/// void get_shared(std::shared_ptr<ProtocolPP::jarray<uint8_t>>& shared,
///                 ProtocolPP::protocol_t type,
///                 std::shared_ptr<ProtocolPP::jsecass> security);
///
/// // Return a properly formatted job descriptor for SEC(CAAM)
/// // using the Protocol++(ProtocolPP) data
/// void get_desc(std::shared_ptr<ProtocolPP::jarray<uint8_t>>& desc,
///               uint64_t shareaddr,
///               unsigned int sharesize,
///               uint64_t inaddr,
///               unsigned int inlen,
///               bool insgf,
///               uint64_t outaddr,
///               unsigned int outlen,
///               bool outsgf);
///
/// // Read the scatter-gather table and return the data as a jarray
/// void read_sgt(uint8_t* sgtin,
///               std::shared_ptr<ProtocolPP::jarray<uint8_t>>& data); 
///\endcode
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Redistribution and use in source and binary forms, with or without modification, are
/// permitted provided that the following conditions are met:
///
/// * Redistributions of source code must retain the above copyright notice, this list of
///   conditions and the following disclaimer
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use requires a fee-based license obtainable at www.protocolpp.com
///
/// * Academic use requires written and notarized permission from John Peter and Sheila
///   Rocha Greninger
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
//
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The names of its contributors may not be used to endorse or promote products derived
/// from this software without specific prior written permission
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "assert.h"
#include "jprotocolpp.h"

namespace PlatformPP {

class jsec {

    public :

    //////////////////////////////////////////////////////
    /// Structure for scatter-gather tables in SEC/CAAM
    /// QorIQ or Layerscape processors
    /// @param chunksize - range of lengths to split the data into
    ///                    when creating a SG table, i.e., "256..1024"
    /// @param sgtsize - size of entries (either 8 or 16 for SEC/CAAM)
    /// @param bufpool - Buffer pool to use for memory
    /// @param offset - size of the offset into data buffers, i.e., "20..100"
    /// @param maxentries - maximum number of entries to read in a SG table
    //////////////////////////////////////////////////////
    struct sgt_t {             // range of lengths to split the data into when creating a SG table default="256..1024"
        std::string chunksize; // size of pointers in bytes (either 4 or 8 for SEC/CAAM default=8)
        unsigned int ptrsize;  // size of entires (either 8 or 16 for SEC/CAAM default=16)
        unsigned int sgtsize;  // buffer pool to use for memory (default=0xFF)
        uint8_t bufpool;       // size of the offset into data buffers default="0..255"
        std::string offset;    // endianess of the SEC/CAAM platform (default=BIG)
        ProtocolPP::endian_t endianess;    // maximum number of entries to read in a SG table
        unsigned int maxentries;

        sgt_t() : chunksize("256..1024"),
                  ptrsize(8),
                  sgtsize(16),
                  bufpool(0xFF),
                  offset("0..255"),
                  endianess(ProtocolPP::BIG),
                  maxentries(500) {}
    };

    //////////////////////////////////////////////////////
    /// Constructor for JSEC
    /// @param sgt - Structure of SG table for SEC/CAAM
    /// @param seed - Seed for random size generation for SG table construction
    //////////////////////////////////////////////////////
    jsec(sgt_t sgt, unsigned long seed);

    //////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////
    virtual ~jsec () {}

    //////////////////////////////////////////////////////
    /// Return the properly formatted shared descriptor
    /// for QorIQ or Layerscape processors
    /// @param shared - Byte pointer to shared descriptor
    /// @param type - protocol to request shared descriptor for
    /// @param security - security association to derive
    ///                   shared descriptor from
    //////////////////////////////////////////////////////
    void get_shared(std::shared_ptr<ProtocolPP::jarray<uint8_t>>& shared,
                    ProtocolPP::protocol_t type,
                    std::shared_ptr<ProtocolPP::jsecass> security);

    //////////////////////////////////////////////////////
    /// Return a properly formatted job descriptor
    /// @param desc - pointer to hold descriptor
    /// @param shareaddr - shared descriptor address
    /// @param sharesize - size of the shared descriptor
    /// @param inaddr - address of input data
    /// @param inlen - length of the input data
    /// @param insgf - flag for scattered input data (true for scattered)
    /// @param outaddr - address of output data
    /// @param outlen - length of the output data
    /// @param outsgf - flag for scattered output data (true for scattered)
    //////////////////////////////////////////////////////
    void get_desc(std::shared_ptr<ProtocolPP::jarray<uint8_t>>& desc,
                  uint64_t shareaddr,
                  unsigned int sharesize,
                  uint64_t inaddr,
                  unsigned int inlen,
                  bool insgf,
                  uint64_t outaddr,
                  unsigned int outlen,
                  bool outsgf);

    //////////////////////////////////////////////////////
    /// Read the scatter-gather table and return the data
    /// @param sgtin - pointer to SG table
    /// @param data - data from SG table
    //////////////////////////////////////////////////////
    void read_sgt(uint8_t* sgtin,
                  std::shared_ptr<ProtocolPP::jarray<uint8_t>>& data); 

    //////////////////////////////////////////////////////
    /// Encapsulate the data as a Blob suitable for SEC(CAAM). Due to the nature
    /// of the Blob Key Encryption Key (BKEK) and how it's constructed, this function
    /// is only really useful when testing SEC(CAAM) directly. The BKEK bits are
    /// not accessible once the design is in silicon. Furthermore, Blob construction
    /// is typically specific to the device such that only that type of device can
    /// create the Blob
    /// @param bkek - Blob key encryption key (BKEK)
    /// @param bkek_size - Length of the BKEK
    /// @param blobkey - Random Blob key
    /// @param blobkey_size - Length of the random Blob key
    /// @param blob_data - Data to enacapsulate as the Blob
    /// @param blob_data_size - Length of Blob data
    /// @param blob - Correctly sized pointer to hold encapsulated Blob
    //////////////////////////////////////////////////////
    void blob_encap(uint8_t* bkek,
                    unsigned int bkek_size,
                    uint8_t* blobkey,
                    unsigned int blobkey_size,
                    uint8_t* blob_data,
                    unsigned int blob_data_size,
                    uint8_t* blob);

    //////////////////////////////////////////////////////
    /// Decapsulate the data as a Blob suitable for SEC(CAAM). Due to the nature
    /// of the Blob Key Encryption Key (BKEK) and how it's constructed, this function
    /// is only really useful when testing SEC(CAAM) directly. The BKEK bits are
    /// not accessible once the design is in silicon. Furthermore, Blob construction
    /// is typically specific to the device such that only that type of device can
    /// create the Blob
    /// @param bkek - Blob key encryption key (BKEK)
    /// @param bkek_size - Length of the BKEK
    /// @param blob - Encapsulated Blob data
    /// @param blob_size - Size of the Blob data
    /// @param blob_data - correctly sized pointer to hold plaintext Blob data
    //////////////////////////////////////////////////////
    void blob_decap(uint8_t* bkek,
                    unsigned int bkek_size,
                    uint8_t* blob,
                    unsigned int blob_size,
                    uint8_t* blob_data);

    private :

    // don't use these
    jsec() = delete;
    jsec(jsec& rhs) = delete;
    jsec(const jsec& rhs) = delete;

    // sgt type and random number generator
    sgt_t m_sgt;
    std::shared_ptr<ProtocolPP::jrand> m_rand;
};

}

#endif // JSEC_H_
