#ifndef JCRC_H
#define JCRC_H

///
///\class jcrc jcrc.h "include/jcrc.h"
///
///\section CRCS Cyclic Redundacy Check (CRC)
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jcrc
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jintegrity
///
/// <B>For Additional Documentation:</B>
/// @see jarray
/// @see jcrc
/// @see jmodes
/// @see jintegrity
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <cstring>
#include <iostream>
#include "EnumString.h"
#include "jenum.h"

namespace ProtocolPP {

class jcrc {

public:

    //////////////////////////////////////////////////////////////////////
    /// Interface for CRC calculation
    ///
    /// @param auth - CRC type(CRC5, CRC7, CRC8, CRC11, CRC12, CRC16, CRC16_CCITT, CRC24, CRC32_IETF, CRC32_IEEE, CRC_POLY)
    /// @param poly - Polynomial for CRC calculation
    /// @param polylen - Polynomial length for CRC calculation
    /// @param zeroinit - Use all zero initial value for CRC
    /// @param swapin - Swap input data for CRC value
    /// @param swapout - Swap output data for CRC value
    /// @param compout - Complement final result
    //////////////////////////////////////////////////////////////////////
    jcrc(auth_t auth,
         uint32_t poly,
         unsigned int polylen=0,
         bool zeroinit=false,
         bool swapin=true,
         bool swapout=true,
         bool compout=true);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jcrc() {}

    //////////////////////////////////////////////////////////////////////
    /// Calculates the CRC for the input data, stays in intermediate state
    /// until result() is called at which time swapout and comput are applied
    ///
    /// @param input - Input data to process
    /// @param length - Data length
    //////////////////////////////////////////////////////////////////////
    void ProcessData(const uint8_t* input, unsigned int length);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the CRC value
    ///
    /// @param crc - CRC calculated value
    //////////////////////////////////////////////////////////////////////
    void result(uint8_t* crc);

    //////////////////////////////////////////////////////////////////////
    /// Size of the result
    ///
    /// @return size of the CRC
    //////////////////////////////////////////////////////////////////////
    unsigned int result_size();

private:

    // don't allow these
    jcrc() = delete;
    jcrc(jcrc& rhs) = delete;
    jcrc(const jcrc& rhs) = delete;

    // internal variables
    auth_t m_auth;
    uint8_t m_table[256];
    uint32_t m_poly;
    uint32_t m_mask;
    uint32_t m_crc;
    unsigned int m_polylen;
    bool m_zeroinit;
    bool m_swapin;
    bool m_swapout;
    bool m_compout;
    bool m_usetable;
};

}

#endif //JCRC_H
