#ifndef JCONFIDENTSA_H
#define JCONFIDENTSA_H

///
///\class jconfidentsa jconfidentsa.h "include/jconfidentsa.h"
///
/// @see jmodes for encryption modes of operation
///
///\section DESCSA Data Encryption Standard (DES)
///
/// <B>Description</B>
/// 
/// For brevity, the following description omits the exact transformations and permutations which specify the algorithm;
/// for reference, the details can be found in DES supplementary material
///
/// DES is the archetypal block cipher—an algorithm that takes a fixed-length string of plaintext bits and transforms it
/// through a series of complicated operations into another ciphertext bitstring of the same length. In the case of DES,
/// the block size is 64 bits. DES also uses a key to customize the transformation, so that decryption can supposedly only
/// be performed by those who know the particular key used to encrypt. The key ostensibly consists of 64 bits; however,
/// only 56 of these are actually used by the algorithm. Eight bits are used solely for checking parity, and are thereafter
/// discarded. Hence the effective key length is 56 bits 
///
/// The key is nominally stored or transmitted as 8 bytes, each with odd parity. According to ANSI X3.92-1981 (Now, known
/// as ANSI INCITS 92-1981), section 3.5: 
///
/// One bit in each 8-bit byte of the KEY may be utilized for error detection in key generation, distribution, and storage.
/// Bits 8, 16,..., 64 are for use in ensuring that each byte is of odd parity 
///
/// Like other block ciphers, DES by itself is not a secure means of encryption, but must instead be used in a mode of operation.
/// FIPS-81 specifies several modes for use with DES. Further comments on the usage of DES are contained in FIPS-74. Decryption
/// uses the same structure as encryption, but with the keys used in reverse order. (This has the advantage that the same
/// hardware or software can be used in both directions 
///
/// <B>Overall structure</B>
/// 
/// The algorithm's overall structure is shown in the figure below: there are 16 identical stages of processing, termed rounds.
/// There is also an initial and final permutation, termed IP and FP, which are inverses (IP "undoes" the action of FP, and
/// vice versa). IP and FP have no cryptographic significance, but were included in order to facilitate loading blocks in and
/// out of mid-1970s 8-bit based hardware 
///
/// Before the main rounds, the block is divided into two 32-bit halves and processed alternately; this criss-crossing is known
/// as the Feistel scheme. The Feistel structure ensures that decryption and encryption are very similar processes—the only
/// difference is that the subkeys are applied in the reverse order when decrypting. The rest of the algorithm is identical.
/// This greatly simplifies implementation, particularly in hardware, as there is no need for separate encryption and decryption
/// algorithms 
///
/// The \f$ \oplus \f$ symbol denotes the exclusive-OR (XOR) operation. The F-function scrambles half a block together with
/// some of the key. The output from the F-function is then combined with the other half of the block, and the halves are
/// swapped before the next round. After the final round, the halves are swapped; this is a feature of the Feistel structure
/// which makes encryption and decryption similar processes 
///
///\image html DES-main-network50.png
///\image latex DES-main-network50.eps "DES Main Network" width=5cm
///
/// <B>The Feistel (F) function</B>
///
/// The F-function, depicted in the figure below, operates on half a block (32 bits) at a time and consists of four stages: 
///
/// 1. Expansion: the 32-bit half-block is expanded to 48 bits using the expansion permutation, denoted E in the diagram,
///    by duplicating half of the bits. The output consists of eight 6-bit (8 * 6 = 48 bits) pieces, each containing a copy
///    of 4 corresponding input bits, plus a copy of the immediately adjacent bit from each of the input pieces to either side
///
/// 2. Key mixing: the result is combined with a subkey using an XOR operation. Sixteen 48-bit subkeys—one for each round—are
///    derived from the main key using the key schedule (described below)
///
/// 3. Substitution: after mixing in the subkey, the block is divided into eight 6-bit pieces before processing by the S-boxes,
///    or substitution boxes. Each of the eight S-boxes replaces its six input bits with four output bits according to a
///    non-linear transformation, provided in the form of a lookup table. The S-boxes provide the core of the security of
///    DES—without them, the cipher would be linear, and trivially breakable
///
/// 4. Permutation: finally, the 32 outputs from the S-boxes are rearranged according to a fixed permutation, the P-box. This
///    is designed so that, after permutation, the bits from the output of each S-box in this round are spread across four
///    different S-boxes in the next round
///
/// The alternation of substitution from the S-boxes, and permutation of bits from the P-box and E-expansion provides so-called
/// "confusion and diffusion" respectively, a concept identified by Claude Shannon in the 1940s as a necessary condition for
/// a secure yet practical cipher
///
///\image html DES_Feistel25.png
///\image latex DES_Feistel25.eps "DES Feistel Network" width=10cm
///
/// <B>Key schedule</B>
/// 
/// The figure below illustrates the key schedule for encryption—the algorithm which generates the subkeys. Initially,
/// 56 bits of the key are selected from the initial 64 by Permuted Choice 1 (PC-1)—the remaining eight bits are either
/// discarded or used as parity check bits. The 56 bits are then divided into two 28-bit halves; each half is thereafter treated
/// separately. In successive rounds, both halves are rotated left by one or two bits (specified for each round), and then 48
/// subkey bits are selected by Permuted Choice 2 (PC-2)—24 bits from the left half, and 24 from the right. The rotations
/// (denoted by "<<<" in the diagram) mean that a different set of bits is used in each subkey; each bit is used in approximately
/// 14 out of the 16 subkeys
///
/// The key schedule for decryption is similar—the subkeys are in reverse order compared to encryption. Apart from that change,
/// the process is the same as for encryption. The same 28 bits are passed to all rotation boxes
/// 
///\image html DES-key-schedule.png
///\image latex DES-key-schedule.eps "DES Key Schedule" width=10cm
/// 
/// <B>Security and cryptanalysis</B>
///
/// Although more information has been published on the cryptanalysis of DES than any other block cipher, the most practical
/// attack to date is still a brute-force approach. Various minor cryptanalytic properties are known, and three theoretical
/// attacks are possible which, while having a theoretical complexity less than a brute-force attack, require an unrealistic
/// number of known or chosen plaintexts to carry out, and are not a concern in practice
///
/// <B>Brute-force attack</B>
///
/// For any cipher, the most basic method of attack is brute force—trying every possible key in turn. The length of the key
/// determines the number of possible keys, and hence the feasibility of this approach. For DES, questions were raised about
/// the adequacy of its key size early on, even before it was adopted as a standard, and it was the small key size, rather than
/// theoretical cryptanalysis, which dictated a need for a replacement algorithm. As a result of discussions involving external
/// consultants including the NSA, the key size was reduced from 128 bits to 56 bits to fit on a single chip
///  
/// The EFF's US$250,000 DES cracking machine contained 1,856 custom chips and could brute-force a DES key in a matter of
/// days—the photo shows a DES Cracker circuit board fitted with several Deep Crack chips
///
/// In academia, various proposals for a DES-cracking machine were advanced. In 1977, Diffie and Hellman proposed a machine costing
/// an estimated US$20 million which could find a DES key in a single day.[1][31] By 1993, Wiener had proposed a key-search machine
/// costing US$1 million which would find a key within 7 hours. However, none of these early proposals were ever implemented—or, at
/// least, no implementations were publicly acknowledged. The vulnerability of DES was practically demonstrated in the late 1990s. In
/// 1997, RSA Security sponsored a series of contests, offering a $10,000 prize to the first team that broke a message encrypted with
/// DES for the contest. That contest was won by the DESCHALL Project, led by Rocke Verser, Matt Curtin, and Justin Dolske, using idle
/// cycles of thousands of computers across the Internet. The feasibility of cracking DES quickly was demonstrated in 1998 when a custom
/// DES-cracker was built by the Electronic Frontier Foundation (EFF), a cyberspace civil rights group, at the cost of approximately
/// US$250,000 (see EFF DES cracker). Their motivation was to show that DES was breakable in practice as well as in theory: "There are
/// many people who will not believe a truth until they can see it with their own eyes. Showing them a physical machine that can crack
/// DES in a few days is the only way to convince some people that they really cannot trust their security to DES." The machine brute-forced
/// a key in a little more than 2 days' worth of searching
///
/// The next confirmed DES cracker was the COPACOBANA machine built in 2006 by teams of the Universities of Bochum and Kiel, both
/// in Germany. Unlike the EFF machine, COPACOBANA consists of commercially available, reconfigurable integrated circuits. 120 of
/// these field-programmable gate arrays (FPGAs) of type XILINX Spartan-3 1000 run in parallel. They are grouped in 20 DIMM modules,
/// each containing 6 FPGAs. The use of reconfigurable hardware makes the machine applicable to other code breaking tasks as well. One
/// of the more interesting aspects of COPACOBANA is its cost factor. One machine can be built for approximately $10,000. The cost
/// decrease by roughly a factor of 25 over the EFF machine is an example of the continuous improvement of digital hardware—see Moore's
/// law. Adjusting for inflation over 8 years yields an even higher improvement of about 30x. Since 2007, SciEngines GmbH, a spin-off
/// company of the two project partners of COPACOBANA has enhanced and developed successors of COPACOBANA. In 2008 their COPACOBANA
/// RIVYERA reduced the time to break DES to less than one day, using 128 Spartan-3 5000's. SciEngines RIVYERA held the record in
/// brute-force breaking DES, having utilized 128 Spartan-3 5000 FPGAs. Their 256 Spartan-6 LX150 model has further lowered this time 
///
/// In 2012, David Hulton and Moxie Marlinspike announced a system with 48 Xilinx Virtex-6 LX240T FPGAs, each FPGA containing 40 fully
/// pipelined DES cores running at 400 MHz, for a total capacity of 768 gigakeys/sec. The system can exhaustively search the entire
/// 56-bit DES key space in about 26 hours and this service is offered for a fee online
///
///\section AESCSA The Advanced Encryption Standard (AES)
///
/// Also known by its original name Rijndael is a specification for the encryption of electronic
/// data established by the U.S. National Institute of Standards and Technology (NIST) in 2001. 
/// AES is a subset of the Rijndael block cipher developed by two Belgian cryptographers, Vincent
/// Rijmen and Joan Daemen, who submitted a proposal to NIST during the AES selection process. Rijndael
/// is a family of ciphers with different key and block sizes 
///
/// For AES, NIST selected three members of the Rijndael family, each with a block size of 128 bits,
/// but three different key lengths: 128, 192 and 256 bits 
///
/// AES has been adopted by the U.S. government and is now used worldwide. It supersedes the Data
/// Encryption Standard (DES), which was published in 1977. The algorithm described by AES is a
/// symmetric-key algorithm, meaning the same key is used for both encrypting and decrypting the data 
///
/// In the United States, AES was announced by the NIST as U.S. FIPS PUB 197 (FIPS 197) on November 26,
/// 2001. This announcement followed a five-year standardization process in which fifteen competing
/// designs were presented and evaluated, before the Rijndael cipher was selected as the most suitable
/// (see Advanced Encryption Standard process for more details) 
///
/// AES became effective as a federal government standard on May 26, 2002, after approval by the
/// Secretary of Commerce. AES is included in the ISO/IEC 18033-3 standard. AES is available in many
/// different encryption packages, and is the first (and only) publicly accessible cipher approved by
/// the National Security Agency (NSA) for top secret information when used in an NSA approved
/// cryptographic module (see Security of AES, below)
///
/// <B>Description of the ciphers</B>
///
/// AES is based on a design principle known as a substitution–permutation network, and is efficient
/// in both software and hardware. Unlike its predecessor DES, AES does not use a Feistel network.
/// AES is a variant of Rijndael which has a fixed block size of 128 bits, and a key size of 128, 192,
/// or 256 bits. By contrast, Rijndael per se is specified with block and key sizes that may be any
/// multiple of 32 bits, with a minimum of 128 and a maximum of 256 bits 
///
/// AES operates on a 4 × 4 column-major order array of bytes, termed the state. Most AES calculations
/// are done in a particular finite field 
///
/// For instance, if there are 16 bytes, \f$ b_0, b_1,...,b_15,\f$ these bytes are represented as this
/// two-dimensional array: 
///
///\image html MajorBytesArray.png
///\image latex MajorBytesArray.eps "AES Major Bytes Array" width=2cm
///
/// The key size used for an AES cipher specifies the number of transformation rounds that convert the
/// input, called the plaintext, into the final output, called the ciphertext. The number of rounds are
/// as follows: 
///
/// * 10 rounds for 128-bit keys
///
/// * 12 rounds for 192-bit keys
///
/// * 14 rounds for 256-bit keys
///
/// Each round consists of several processing steps, including one that depends on the encryption key
/// itself. A set of reverse rounds are applied to transform ciphertext back into the original plaintext
/// using the same encryption key 
///
/// <B>High-level description of the algorithm</B>
///
/// 1. KeyExpansion—round keys are derived from the cipher key using Rijndael's key schedule. AES requires
///    a separate 128-bit round key block for each round plus one more
///
/// 2. Initial round key addition: 
///
///   1. AddRoundKey—each byte of the state is combined with a block of the round key using bitwise xor
///
/// 3. 9, 11 or 13 rounds: 
///
///   1. SubBytes—a non-linear substitution step where each byte is replaced with another according to a lookup table
///
///   2. ShiftRows—a transposition step where the last three rows of the state are shifted cyclically a certain number of steps
///
///   3. MixColumns—a linear mixing operation which operates on the columns of the state, combining the four bytes in each column.
///
///   4. AddRoundKey
///
/// 4. Final round (making 10, 12 or 14 rounds in total): 
///
///   1. SubBytes
///
///   2. ShiftRows
///
///   3. AddRoundKey
///
/// <B>The SubBytes step</B>
///
/// In the SubBytes step, each byte \f$ a_i,j \f$ in the state array is replaced with a SubByte \f$ S(a_i,j) \f$
/// using an 8-bit substitution box. This operation provides the non-linearity in the cipher. The S-box
/// used is derived from the multiplicative inverse over GF(28), known to have good non-linearity properties.
/// To avoid attacks based on simple algebraic properties, the S-box is constructed by combining the inverse
/// function with an invertible affine transformation. The S-box is also chosen to avoid any fixed points
/// (and so is a derangement), i.e., \f$ S(a_i,j) ≠ a_i,j \f$, and also any opposite fixed points, i.e., 
/// \f$ S(a_i,j) \oplus a_i,j ≠ 0xFF_16 \f$. While performing the decryption, the InvSubBytes step (the inverse of SubBytes) is
/// used, which requires first taking the inverse of the affine transformation and then finding the multiplicative inverse 
///
///\image html AES-SubBytes25.png
///\image latex AES-SubBytes25.eps "AES SubBytes" width=10cm
///
/// <B>The ShiftRows step</B>
///
/// In the ShiftRows step, bytes in each row of the state are shifted cyclically to the left. The number of places
/// each byte is shifted differs for each row. The ShiftRows step operates on the rows of the state; it cyclically shifts
/// the bytes in each row by a certain offset. For AES, the first row is left unchanged. Each byte of the second row is
/// shifted one to the left. Similarly, the third and fourth rows are shifted by offsets of two and three respectively. In
/// this way, each column of the output state of the ShiftRows step is composed of bytes from each column of the input state.
/// The importance of this step is to avoid the columns being encrypted independently, in which case AES degenerates into
/// four independent block ciphers
///
///\image html AES-ShiftRows25.png
///\image latex AES-ShiftRows25.eps "AES Shift Rows" width=10cm
///
/// <B>The MixColumns step</B>
///
/// In the MixColumns step, each column of the state is multiplied with a fixed polynomial \f$ c(x)\f$ 
///
/// In the MixColumns step, the four bytes of each column of the state are combined using an invertible linear transformation.
/// The MixColumns function takes four bytes as input and outputs four bytes, where each input byte affects all four output bytes.
/// Together with ShiftRows, MixColumns provides diffusion in the cipher 
///
/// During this operation, each column is transformed using a fixed matrix (matrix left-multiplied by column gives new value
/// of column in the state): 
///
///\image html MixedMatrix.png
///\image latex MixedMatrix.eps "AES Mixed Matrix" width=5cm
///
/// Matrix multiplication is composed of multiplication and addition of the entries. Entries are 8-bit bytes treated as
/// coefficients of polynomial of order \f$ {x}^{7} \f$. Addition is simply XOR. Multiplication is modulo irreducible polynomial 
/// \f$ {x}^{8}+{x}^{4}+{x}^{3}+x+1 \f$. If processed bit by bit, then, after shifting, a conditional XOR with \f$ 1B_16 \f$ should
/// be performed if the shifted value is larger than \f$ FF_16 \f$ (overflow must be corrected by subtraction of generating polynomial).
/// These are special cases of the usual multiplication in \f$ GF({2}^{8}) \f$
///
/// In more general sense, each column is treated as a polynomial over \f$ GF({2}^{8}) \f$ and is then multiplied modulo 
/// \f$ 01_16 \cdot {z}^{4} + 01_16 \f$ with a fixed polynomial \f$ c(z) = 03_16 \cdot {z}^{3} + 01_16 \cdot {z}^{2} + 01_16 \cdot z + 02_16 \f$ 
/// The coefficients are displayed in their hexadecimal equivalent of the binary representation of bit polynomials from 
/// \f$ GF(2)[x] \f$. The MixColumns step can also be viewed as a multiplication by the shown particular MDS matrix in the
/// finite field \f$ GF({2}^{8}) \f$. This process is described further in the article Rijndael MixColumns 
///
///\image html AES-MixColumns25.png
///\image latex AES-MixColumns25.eps "AES Mix Columns" width=10cm
///
/// <B>The AddRoundKey step</B>
///
/// In the AddRoundKey step, the subkey is combined with the state. For each round, a subkey is derived from the main key
/// using Rijndael's key schedule; each subkey is the same size as the state. The subkey is added by combining each byte
/// of the state with the corresponding byte of the subkey using bitwise XOR 
///
///\image html AES-AddRoundKey25.png
///\image latex AES-AddRoundKey25.eps "AES Add Round Keys" width=10cm
///
/// <B>Optimization of the cipher</B>
///
/// On systems with 32-bit or larger words, it is possible to speed up execution of this cipher by combining the SubBytes
/// and ShiftRows steps with the MixColumns step by transforming them into a sequence of table lookups. This requires four
/// 256-entry 32-bit tables (together occupying 4096 bytes). A round can then be performed with 16 table lookup operations
/// and 12 32-bit exclusive-or operations, followed by four 32-bit exclusive-or operations in the AddRoundKey step.
/// Alternatively, the table lookup operation can be performed with a single 256-entry 32-bit table (occupying 1024 bytes)
/// followed by circular rotation operations
///
/// Using a byte-oriented approach, it is possible to combine the SubBytes, ShiftRows, and MixColumns steps into a single
/// round operation 
///
/// <B>Security</B>
///
/// Until May 2009, the only successful published attacks against the full AES were side-channel attacks on some specific
/// implementations. The National Security Agency (NSA) reviewed all the AES finalists, including Rijndael, and stated that
/// all of them were secure enough for U.S. Government non-classified data. In June 2003, the U.S. Government announced that
/// AES could be used to protect classified information: 
///
///    The design and strength of all key lengths of the AES algorithm (i.e., 128, 192 and 256) are sufficient to protect
///    classified information up to the SECRET level. TOP SECRET information will require use of either the 192 or 256 key
///    lengths. The implementation of AES in products intended to protect national security systems and/or information must
///    be reviewed and certified by NSA prior to their acquisition and use
///
/// AES has 10 rounds for 128-bit keys, 12 rounds for 192-bit keys, and 14 rounds for 256-bit keys 
///
/// By 2006, the best known attacks were on 7 rounds for 128-bit keys, 8 rounds for 192-bit keys, and 9 rounds for 256-bit keys
///
/// <B>Performance</B>
///
/// High speed and low RAM requirements were criteria of the AES selection process. As the chosen algorithm, AES performed
/// well on a wide variety of hardware, from 8-bit smart cards to high-performance computers 
///
/// On a Pentium Pro, AES encryption requires 18 clock cycles per byte, equivalent to a throughput of about 11 Mbit/s
/// for a 200 MHz processor. On a 1.7 GHz Pentium M throughput is about 60 Mbit/s
///
/// On Intel Core i3/i5/i7 and AMD Ryzen CPUs supporting AES-NI instruction set extensions, throughput can be multiple
/// GB/s (even over 10 GB/s)
///
///\section SERPCSA Serpent Block Cipher
///
/// Serpent is a symmetric key block cipher that was a finalist in the Advanced Encryption Standard (AES) contest, where
/// it was ranked second to Rijndael. Serpent was designed by Ross Anderson, Eli Biham, and Lars Knudsen
///
/// Like other AES submissions, Serpent has a block size of 128 bits and supports a key size of 128, 192 or 256 bits. The
/// cipher is a 32-round substitution–permutation network operating on a block of four 32-bit words. Each round applies
/// one of eight 4-bit to 4-bit S-boxes 32 times in parallel. Serpent was designed so that all operations can be executed
/// in parallel, using 32 bit slices. This maximizes parallelism, but also allows use of the extensive cryptanalysis work
/// performed on DES
///
/// Serpent took a conservative approach to security, opting for a large security margin: the designers deemed 16 rounds
/// to be sufficient against known types of attack, but specified 32 rounds as insurance against future discoveries in
/// cryptanalysis. The official NIST report on AES competition classified Serpent as having a high security margin along
/// with MARS and Twofish, in contrast to the adequate security margin of RC6 and Rijndael (currently AES). In final
/// voting, Serpent had the fewest negative votes among the finalists, but scored second place overall because Rijndael
/// had substantially more positive votes, the deciding factor being that Rijndael allowed for a far more efficient
/// software implementation
///
/// The Serpent cipher algorithm is in the public domain and has not been patented. The reference code is public domain
/// software and the optimized code is under GPL. There are no restrictions or encumbrances whatsoever regarding its use.
/// As a result, anyone is free to incorporate Serpent in their software (or hardware implementations) without paying
/// license fees
///
/// <B>Rijndael vs. Serpent</B>
///
/// Rijndael is a substitution-linear transformation network with ten, twelve, or fourteen rounds, depending on the key
/// size, and with block sizes of 128 bits, 192 bits, or 256 bits, independently specified. Serpent is a
/// substitution–permutation network which has thirty-two rounds, plus an initial and a final permutation to simplify
/// an optimized implementation. The round function in Rijndael consists of three parts: a nonlinear layer, a linear
/// mixing layer, and a key-mixing XOR layer. The round function in Serpent consists of key-mixing XOR, thirty-two
/// parallel applications of the same 4×4 S-box, and a linear transformation, except in the last round, wherein another
/// key-mixing XOR replaces the linear transformation. The nonlinear layer in Rijndael uses an 8×8 S-box whereas Serpent
/// uses eight different 4×4 S-boxes. The 32 rounds means that Serpent has a higher security margin than Rijndael; however,
/// Rijndael with 10 rounds is faster and easier to implement for small blocks. Hence, Rijndael was selected as the winner
/// in the AES competition
///
/// <B>Serpent-0 vs. Serpent-1</B>
///
/// The original Serpent, Serpent-0, was presented at the 5th workshop on Fast Software Encryption, but a somewhat tweaked
/// version, Serpent-1, was submitted to the AES competition. The AES submission paper discuss the changes, which include
/// key scheduling differences
///
/// <B>Security</B>
///
/// The XSL attack, if effective, would weaken Serpent (though not as much as it would weaken Rijndael, which became AES).
/// However, many cryptanalysts believe that once implementation considerations are taken into account the XSL attack
/// would be more expensive than a brute force attack
///
/// In 2000, a paper by Kohno et al. presents a meet-in-the-middle attack against 6 of 32 rounds of Serpent and an
/// amplified boomerang attack against 9 of 32 rounds in Serpent
///
/// A 2001 attack by Eli Biham, Orr Dunkelman and Nathan Keller presents a linear cryptanalysis attack that breaks 10 of
/// 32 rounds of Serpent-128 with 2118 known plaintexts and 289 time, and 11 rounds of Serpent-192/256 with 2118 known
/// plaintexts and 2187 time
///
/// A 2009 paper has noticed that the nonlinear order of Serpent S-boxes were not 3 as was claimed by the designers
///
/// A 2011 attack by Hongjun Wu, Huaxiong Wang and Phuong Ha Nguyen, also using linear cryptanalysis, breaks 11 rounds
/// of Serpent-128 with 2116 known plaintexts, 2107.5 time and 2104 memory
///
/// The same paper also describes two attacks which break 12 rounds of Serpent-256. The first requires 2118 known
/// plaintexts, 2228.8 time and 2228 memory. The other attack requires 2116 known plaintexts and 2121 memory but also
/// requires 2237.5 time
///
///\image html Serpent.png "Serpent Linear Function [1]"
///\image latex Serpent.eps "Serpent Linear Function [1]" width=10cm
///
///\section ARIACSA ARIA Block Cipher (Korea)
///
/// ARIA is a general-purpose block cipher algorithm developed by Korean cryptographers in 2003. It is
/// an iterated block cipher with 128-, 192-, and 256-bit keys and encrypts 128-bit blocks in 12, 14,
/// and 16 rounds, depending on the key size. It is secure and suitable for most software and hardware
/// implementations on 32-bit and 8-bit processors. It was established as a Korean standard block cipher
/// algorithm in 2004 [ARIAKS] and has been widely used in Korea, especially for government-to-public
/// services. It was included in PKCS #11 in 2007 [ARIAPKCS]. The algorithm specification and object
/// identifiers are described in [RFC5794].
///
/// <B>ARIA-CTR</B>
///
/// Section 4.1.1 of [RFC3711] defines AES-128 counter mode encryption, which it refers to as "AES_CM".
/// Section 2 of [RFC6188] defines "AES_192_CM" and "AES_256_CM" in SRTP. ARIA counter modes are
/// defined in the same manner except that each invocation of AES is replaced by that of ARIA [RFC5794],
/// and are denoted by ARIA_128_CTR, ARIA_192_CTR and ARIA_256_CTR respectively, according to the key
/// lengths. The plaintext inputs to the block cipher are formed as in AES-CTR(AES_CM, AES_192_CM,
/// AES_256_CM) and the block cipher outputs are processed as in AES-CTR. Note that, ARIA-CTR MUST be
/// used only in conjunction with an authentication transform.
///
/// <B>ARIA-GCM</B>
///
/// GCM (Galois Counter Mode) [GCM][RFC5116] is an AEAD (Authenticated Encryption with Associated Data)
/// block cipher mode. A detailed description of ARIA-GCM is defined similarly as AES-GCM found in
/// [RFC5116][RFC5282].
///
///\section SM4ESA SM4 Block Cipher (China)
///
/// See sm4_encryption_spec 15 May 2008 Version 1.03
///
/// SMS4 is a Chinese block cipher standard, mandated for use in protecting wireless networks
/// and issued in January 2006. The input, output, and key of SMS4 are each 128 bits.
/// The algorithm has 32 rounds, each of which modifies one of the four 32-bit words that make
/// up the block by xoring it with a keyed function of the other three words. Encryption and
/// decryption have the same structure except that the round key schedule for decryption is the
/// reverse of the round key schedule for encryption
///
///
/// <B>1. Terminology (Definitions)</B>
///
/// <B>1.1 Zi and ZiJie (Word and Byte)</B>
///
/// \f${Z_2}^{e}\f$ is the set of e-bit vectors. Specifically, the elements of \f${Z_2}^{32}\f$ are called \f$ Zi\f$ (32-bit words),
/// and the elements of \f${Z_2}^{8}\f$ are called \f$ ZiJie\f$ (8-bit characters, or bytes)
///
///
/// <B>1.2 S box</B>
///
/// The S (substitution) box takes in 8 bits and outputs 8 bits. It is written Sbox(.)
///
///
/// <B>1.3 Fundamental Operations</B>
///
/// The two fundamental operations used by this algorithm are:
///
/// * the bitwise XOR of two 32-bit vectors
///
/// * \f$ \ll\f$ i the circular shift of a 32-bit word, with i bits shifted left
///
///
/// <B>1.4 Input and output blocks and key</B>
///
/// The 128-bit input block consists of four 32-bit words \f$ MK = (MK_1,MK_2,MK_3,MK_4) or MK_i(i = 0, 1, 2, 3)\f$
///
/// The round key schedule, derived from the encryption key, is represented by \f$ (rk_0, rk_1,...,rk_{31})\f$
/// where each \f$ rk_i, i=0,...,31)\f$ is 32 bits long
///
/// The 128-bit output block consists of four 32-bit words \f$ FK = (FK_0, FK_1, FK_2, FK_3)\f$
///
/// For decryption, the round key schedule is represented by \f$ CK = (CK_0,CK_1,...,CK_{31})\f$ or
/// 
/// * \f$ FK_i, (i = 0,...,3), CK_i, (i = 0,...,31)\f$
///
///
/// <B>2. The round function F</B>
///
/// This algorithm uses a nonlinear substitution structure, encrypting 32 bits at a time. This
/// is called a <EM>one-round exchange</EM>. To illustrate, consider a one-round-substitution:
///
/// Let the 128-bit input block be the four 32-bit elements
///
/// * \f$(X_0,X_1,X_2,X_3) \in {({Z_2}^{32})}^{4}\f$, with \f$rk \in {Z_2}^{32}\f$, then F is given by
///
/// * \f$ F(X_0,X_1,X_2,X_3,rk) = X_0 \oplus T(X_1 \oplus X_2 \oplus X_3 \oplus rk)\f$
///
///
/// <B>2.1 Mixer-substitution T</B>
///
/// T is a substitution that generates 32 bits from 32 bits \f$T : {Z_2}^{32} \mapsto {Z_2}^{32}\f$. This substitution
/// is a reversible process. It consists of a non-linear substitution, \f$tau\f$, and a linear substitution
/// L, i.e., \f$T(.) = L(\tau(.))\f$
///
///
/// <B>2.1.1 Non-linear substitution \f$\tau\f$</B>
///
/// \f$\tau\f$ applies 4 S-boxes in parallel
/// Let a 32-bit input word be \f$A = (a_0, a_1, a_2, a_3) \in {({Z_2}^{8})}^{4}\f$, where each ai is an 8-bit character
/// Let the 32-bit output word be \f$B = (b_0, b_1, b_2, b_3) \in {({Z_2}^{8})}^{4}\f$, given by
/// \f$(b_0, b_1, b_2, b_3) = \tau(A) = (Sbox(a_0), Sbox(a_1), Sbox(a_2), Sbox(a_3))\f$
///
///
/// <B>2.1.2 Linear substitution L</B>
///
/// \f$B \in {Z_2}^{32}\f$, the 32-bit output word of the non-linear substitution \f$tau\f$ will be the input word
/// of the linear substitution L. Let \f$C \in {Z_2}^{32}\f$ be the 32-bit output word generated by L. Then
///
/// * \f$C = L(B) = B \oplus (B <<< 2) \oplus (B <<< 10) \oplus (B <<< 18) \oplus (B <<< 24)\f$
///
/// <B>2.2 S box</B>
///
/// All Sbox numbers are in hexadecimal notation
///
/// <table>
/// <caption id="multirowconfsa">\f$ S Box\f$</caption>
/// <tr><th>0<th>1<th>2<th>3<th>4<th>5<th>6<th>7<th>8<th>9<th>10<th>11<th>12<th>13<th>14<th>15
/// <tr><td>d6 <td>90 <td>e9 <td>fe <td>cc <td>e1 <td>3d <td>b7 <td>16 <td>b6 <td>14 <td>c2 <td>28 <td>fb <td>2c <td>05
/// <tr><td>2b <td>67 <td>9a <td>76 <td>2a <td>be <td>04 <td>c3 <td>aa <td>44 <td>13 <td>26 <td>49 <td>86 <td>06 <td>99
/// <tr><td>9c <td>42 <td>50 <td>f4 <td>91 <td>ef <td>98 <td>7a <td>33 <td>54 <td>0b <td>43 <td>ed <td>cf <td>ac <td>62
/// <tr><td>e4 <td>b3 <td>1c <td>a9 <td>c9 <td>08 <td>e8 <td>95 <td>80 <td>df <td>94 <td>fa <td>75 <td>8f <td>3f <td>a6
/// <tr><td>47 <td>07 <td>a7 <td>fc <td>f3 <td>73 <td>17 <td>ba <td>83 <td>59 <td>3c <td>19 <td>e6 <td>85 <td>4f <td>a8
/// <tr><td>68 <td>6b <td>81 <td>b2 <td>71 <td>64 <td>da <td>8b <td>f8 <td>eb <td>0f <td>4b <td>70 <td>56 <td>9d <td>35
/// <tr><td>1e <td>24 <td>0e <td>5e <td>63 <td>58 <td>d1 <td>a2 <td>25 <td>22 <td>7c <td>3b <td>01 <td>21 <td>78 <td>87
/// <tr><td>d4 <td>00 <td>46 <td>57 <td>9f <td>d3 <td>27 <td>52 <td>4c <td>36 <td>02 <td>e7 <td>a0 <td>c4 <td>c8 <td>9e
/// <tr><td>ea <td>bf <td>8a <td>d2 <td>40 <td>c7 <td>38 <td>b5 <td>a3 <td>f7 <td>f2 <td>ce <td>f9 <td>61 <td>15 <td>a1
/// <tr><td>e0 <td>ae <td>5d <td>a4 <td>9b <td>34 <td>1a <td>55 <td>ad <td>93 <td>32 <td>30 <td>f5 <td>8c <td>b1 <td>e3
/// <tr><td>1d <td>f6 <td>e2 <td>2e <td>82 <td>66 <td>ca <td>60 <td>c0 <td>29 <td>23 <td>ab <td>0d <td>53 <td>4e <td>6f
/// <tr><td>d5 <td>db <td>37 <td>45 <td>de <td>fd <td>8e <td>2f <td>03 <td>ff <td>6a <td>72 <td>6d <td>6c <td>5b <td>51
/// <tr><td>8d <td>1b <td>af <td>92 <td>bb <td>dd <td>bc <td>7f <td>11 <td>d9 <td>5c <td>41 <td>1f <td>10 <td>5a <td>d8
/// <tr><td>0a <td>c1 <td>31 <td>88 <td>a5 <td>cd <td>7b <td>bd <td>2d <td>74 <td>d0 <td>12 <td>b8 <td>e5 <td>b4 <td>b0
/// <tr><td>89 <td>69 <td>97 <td>4a <td>0c <td>96 <td>77 <td>7e <td>65 <td>b9 <td>f1 <td>09 <td>c5 <td>6e <td>c6 <td>84
/// <tr><td>18 <td>f0 <td>7d <td>ec <td>3a <td>dc <td>4d <td>20 <td>79 <td>ee <td>5f <td>3e <td>d7 <td>cb <td>39 <td>48
/// </table>
///
/// For example, if the input to the Sbox is 'ef', then go to e-th row and f-th column, to find
/// \f$ Sbox('ef')='84'\f$
///
/// <B>3. Encryption and decryption</B>
///
/// Let the reverse substitution \f$ R\f$ be:
///
/// * \f$R(A_0,A_1,A_2,A_3) = (A_3,A_2,A_1,A_0),A_i \in {Z_2}^{32}, i = 0,1,2,3\f$
///
/// Let the plaintext input be \f$(X_0,X_1,X_2,X_3) \in {({Z_2}^{32})}^{4}\f$, the ciphertext output be \f$(Y_0,Y_1,Y_2,Y_3) \in \f$
/// \f${({Z_2}^{32})}^{4}\f$, and the encrypting key be \f$rk_i \in {Z_2}^{32}, i = 0,1,2,...,31\f$
///
/// Then encryption proceeds as follows:
///
/// *\f$ X_{i+4} = F(X_i,X_{i+1},X_{i+2},X_{i+3}, rk_i) = Xi \oplus T(X_{i+1} \oplus X_{i+2} \oplus X_{i+3} \oplus rk_i)\f$ where \f$ i = 0,1,...,31\f$
///
/// *\f$(Y_0, Y_1, Y_2, Y_3) = R(X_{32},X_{33},X_{34},X_{35}) = (X_{35},X_{34},X_{33},X_{32})\f$
///
/// This algorithm's encryption and decryption methods have the same structure, except the
/// order in which the round keys are used is reversed
///
/// The key order for encryption is: \f$(rk_0, rk_1,...,rk_{31})\f$. The key order for decryption is:
/// 
/// * \f$(rk_{31}, rk_{30},...,rk_0)\f$
///
/// <B>4. Key expansion when encrypting</B>
///
/// The \f$rk_i\f$ round key used for encrypting in this algorithm is derived from the encryption
/// key MK.
///
/// Let \f$MK = (MK_0,MK_1,MK_2,MK_3), MK_i \in {Z_2}^{32}, i = 0,1,2,3;\f$
/// 
/// * \f$K_i \in {Z_2}^{32}, i = 0,1,...,31;\f$
///
/// * \f$rk_i \in {Z_2}^{32}, i = 0,1,...,31\f$;
///
/// the derivation proceeds as follows:
///
/// First,
///
/// * \f$(K_0,K_1,K_2,K_3) = (MK_0 \oplus FK_0; MK_1 \oplus FK_1; MK_2 \oplus FK_2; MK_3 \oplus FK_3)\f$
///
/// Then for i = 0,1,2,...,31:
///
/// * \f$rk_i = K_{i+4} = K_i \oplus T\prime(K_{i+1} \oplus K_{i+2} \oplus K_{i+3} \oplus CK_i)\f$
///
/// Notes:
///
/// 1. T&prime substitution uses the same T as in encryption, except the linear substitution L is
/// changed to L&prime: L&prime\f$(B) = B \oplus (B <<< 13) \oplus (B <<< 23)\f$;
///
/// 2. The system parameter \f$ FK\f$ given in hexadecimal notation is
///
/// * \f$FK_0 = (a3b1bac6), FK_1 = (56aa3350), FK_2 = (677d9197), FK_3 = (b27022dc)\f$
///
/// 3. The constant parameter \f$ CK\f$ is calculated as follows:
///
/// Let \f$ck_{i,j}\f$ be the j-th byte of \f$CK_{i,j}(i = 0,1,...,31; j = 0,1,2,3)\f$, i.e., \f$CK_i = (ck_{i,0}, ck_{i,1}; ck_{i,2}; ck_{i,3}) \in {({Z_2}^{8})}^{4}, then ck_{i,j} = (4i + j) \times (mod 256)\f$
///
/// The 32 constants \f$CK_i\f$ are represented in hexadecimal as tabulated below:
///
/// <table>
/// <caption id="constantsconfsa">\f$ CK_i\f$</caption>
/// <tr><th>0<th>1<th>2<th>3
/// <tr><td>00070e15 <td>1c232a31 <td>383f464d <td>545b6269
/// <tr><td>70777e85 <td>8c939aa1 <td>a8afb6bd <td>c4cbd2d9
/// <tr><td>e0e7eef5 <td>fc030a11 <td>181f262d <td>343b4249
/// <tr><td>50575e65 <td>6c737a81 <td>888f969d <td>a4abb2b9
/// <tr><td>c0c7ced5 <td>dce3eaf1 <td>f8ff060d <td>141b2229
/// <tr><td>30373e45 <td>4c535a61 <td>686f767d <td>848b9299
/// <tr><td>a0a7aeb5 <td>bcc3cad1 <td>d8dfe6ed <td>f4fb0209
/// <tr><td>10171e25 <td>2c333a41 <td>484f565d <td>646b7279
/// </table>
///
///\section CAMELLIACSA Camellia Block Cipher (Japan)
///
///\image html CamelliaLogo75.png
///\image latex CamelliaLogo75.eps "Camellia Logo" width=10cm
///
/// See https://en.wikipedia.org/wiki/Camellia_(cipher)
/// <BR>
/// See https://info.isl.ntt.co.jp/crypt/eng/camellia/dl/01espec.pdf
///
/// In cryptography, Camellia is a symmetric key block cipher with a block size of 128 bits and key
/// sizes of 128, 192 and 256 bits. It was jointly developed by Mitsubishi Electric and NTT of Japan.
/// The cipher has been approved for use by the ISO/IEC, the European Union's NESSIE project and the
/// Japanese CRYPTREC project. The cipher has security levels and processing abilities comparable to
/// the Advanced Encryption Standard 
///
/// The cipher was designed to be suitable for both software and hardware implementations, from
/// low-cost smart cards to high-speed network systems. It is part of the Transport Layer Security (TLS)
/// cryptographic protocol designed to provide communications security over a computer network such
/// as the Internet
///
/// The cipher was named for the flower Camellia japonica, which is known for being long-lived as well
/// as because the cipher was developed in Japan
///
/// <B>Design</B>
///
/// Camellia is a Feistel cipher with either 18 rounds (when using 128-bit keys) or 24 rounds (when
/// using 192- or 256-bit keys). Every six rounds, a logical transformation layer is applied: the
/// so-called "FL-function" or its inverse. Camellia uses four 8×8-bit S-boxes with input and output
/// affine transformations and logical operations. The cipher also uses input and output key whitening.
/// The diffusion layer uses a linear transformation based on a matrix with a branch number of 5 
///
/// <B>Security analysis</B>
///
/// Camellia is considered a modern, safe cipher. Even using the smaller key size option (128 bits),
/// it's considered infeasible to break it by brute-force attack on the keys with current technology.
/// There are no known successful attacks that weaken the cipher considerably. The cipher has been
/// approved for use by the ISO/IEC, the European Union's NESSIE project and the Japanese CRYPTREC
/// project. The Japanese cipher has security levels and processing abilities comparable to the
/// AES/Rijndael cipher 
///
/// Camellia is a block cipher which can be completely defined by minimal systems of multivariate
/// polynomials: 
///
/// * The Camellia (as well as AES) S-boxes can be described by a system of 23 quadratic equations in
///   80 terms
///
/// * The key schedule can be described by 1,120 equations in 768 variables using 3,328 linear and
///   quadratic terms
///
/// * The entire block cipher can be described by 5,104 equations in 2,816 variables using 14,592
///   linear and quadratic terms
///
/// * In total, 6,224 equations in 3,584 variables using 17,920 linear and quadratic terms are required
///
/// * The number of free terms is 11,696, which is approximately the same number as for AES
///
/// Theoretically, such properties might make it possible to break Camellia (and AES) using an algebraic
/// attack, such as extended sparse linearisation, in the future, provided that the attack becomes feasible
///
///\section RC4CSA ARC4 Stream Cipher
///
/// See https://en.wikipedia.org/wiki/RC4
/// <BR>
/// See http://cypherpunks.venona.com/archive/1994/09/msg00304.html
///
/// In cryptography, RC4 (Rivest Cipher 4 also known as ARC4 or ARCFOUR meaning Alleged RC4, see below) is a stream
/// cipher. While it is remarkable for its simplicity and speed in software, multiple vulnerabilities have been
/// discovered in RC4, rendering it insecure. It is especially vulnerable when the beginning of the output keystream is
/// not discarded, or when nonrandom or related keys are used. Particularly problematic uses of RC4 have led to very
/// insecure protocols such as WEP
///
/// As of 2015, there is speculation that some state cryptologic agencies may possess the capability to break RC4 when
/// used in the TLS protocol. IETF has published RFC 7465 to prohibit the use of RC4 in TLS; Mozilla and Microsoft have
/// issued similar recommendations
///
/// A number of attempts have been made to strengthen RC4, notably Spritz, RC4A, VMPC, and RC4+
///
/// <B>History</B>
///
/// RC4 was designed by Ron Rivest of RSA Security in 1987. While it is officially termed "Rivest Cipher 4", the RC
/// acronym is alternatively understood to stand for "Ron's Code" (see also RC2, RC5 and RC6)
///
/// RC4 was initially a trade secret, but in September 1994 a description of it was anonymously posted to the
/// Cypherpunks mailing list. It was soon posted on the sci.crypt newsgroup, where it was broken within days by Bob
/// Jenkins. From there it spread to many sites on the Internet. The leaked code was confirmed to be genuine as its
/// output was found to match that of proprietary software using licensed RC4. Because the algorithm is known, it is no
/// longer a trade secret. The name RC4 is trademarked, so RC4 is often referred to as ARCFOUR or ARC4 (meaning alleged
/// RC4) to avoid trademark problems. RSA Security has never officially released the algorithm; Rivest has, however,
/// linked to the English Wikipedia article on RC4 in his own course notes in 2008 and confirmed the history of RC4 and
/// its code in a 2014 paper by him
///
/// RC4 became part of some commonly used encryption protocols and standards, such as WEP in 1997 and WPA in 2003/2004
/// for wireless cards; and SSL in 1995 and its successor TLS in 1999, until it was prohibited for all versions of TLS
/// by RFC 7465 in 2015, due to the RC4 attacks weakening or breaking RC4 used in SSL/TLS. The main factors in RC4's
/// success over such a wide range of applications have been its speed and simplicity: efficient implementations in
/// both software and hardware were very easy to develop
///
/// <B>Description</B>
///
/// RC4 generates a pseudorandom stream of bits (a keystream). As with any stream cipher, these can be used for
/// encryption by combining it with the plaintext using bit-wise exclusive-or; decryption is performed the same way
/// (since exclusive-or with given data is an involution). This is similar to the one-time pad except that generated
/// pseudorandom bits, rather than a prepared stream, are used
///
/// To generate the keystream, the cipher makes use of a secret internal state which consists of two parts:
///
/// 1. A permutation of all 256 possible bytes (denoted "S" below)
///
/// 2. Two 8-bit index-pointers (denoted "i" and "j")
///
/// The permutation is initialized with a variable length key, typically between 40 and 2048 bits, using the key-
/// scheduling algorithm (KSA). Once this has been completed, the stream of bits is generated using the pseudo-random
/// generation algorithm (PRGA). 
///
/// <B>Key-scheduling algorithm (KSA)</B>
///
/// The key-scheduling algorithm is used to initialize the permutation in the array "S". "keylength" is defined as the
/// number of bytes in the key and can be in the range 1 ≤ keylength ≤ 256, typically between 5 and 16, corresponding
/// to a key length of 40–128 bits. First, the array "S" is initialized to the identity permutation. S is then
/// processed for 256 iterations in a similar way to the main PRGA, but also mixes in bytes of the key at the same
/// time
///
///\code
/// for i from 0 to 255
///    S[i] := i
/// endfor
/// j := 0
/// for i from 0 to 255
///    j := (j + S[i] + key[i mod keylength]) mod 256
///    swap values of S[i] and S[j]
/// endfor
///\endcode
///
///\image html ARC4Lookup25.png
///\image latex ARC4Lookup25.eps "Lookup stage of RC4" width=10cm
///
/// In the above lookup stage of ARC4, the output byte is selected by looking up the values of S[<I>i</I>] and S[<I>j</I>],
/// adding them together modulo 256, and then using the sum as an index into S; S(S[<I>i</I>] + S[<I>j</I>]) is used as
/// a byte of the key stream, K
///
/// <B>Pseudo-random generation algorithm (PRGA)</B>
///
/// The lookup stage of RC4. The output byte is selected by looking up the values of S[i] and S[j], adding them
/// together modulo 256, and then using the sum as an index into S; S(S[i] + S[j]) is used as a byte of the key
/// stream, K
///
/// For as many iterations as are needed, the PRGA modifies the state and outputs a byte of the keystream. In each
/// iteration, the PRGA: 
///
/// * increments i
///
/// * looks up the ith element of S, S[i], and adds that to <I>j</I>
///
/// * exchanges the values of S[<I>i</I>] and S[<I>j</I>] then uses the sum S[<I>i</I>] + S[<I>j</I>] (modulo 256)
///   as an index to fetch a third element of S (the keystream value K below)
///
/// * then bitwise exclusive ORed (XORed) with the next byte of the message to produce the next byte of either
///   ciphertext or plaintext.
///
/// Each element of S is swapped with another element at least once every 256 iterations
///
///\code
/// i := 0
/// j := 0
/// while GeneratingOutput:
///    i := (i + 1) mod 256
///    j := (j + S[i]) mod 256
///    swap values of S[i] and S[j]
///    K := S[(S[i] + S[j]) mod 256]
///    output K
/// endwhile
///\endcode
///
/// <B>Security</B>
///
/// Unlike a modern stream cipher (such as those in eSTREAM), RC4 does not take a separate nonce alongside the key.
/// This means that if a single long-term key is to be used to securely encrypt multiple streams, the protocol must
/// specify how to combine the nonce and the long-term key to generate the stream key for RC4. One approach to
/// addressing this is to generate a "fresh" RC4 key by hashing a long-term key with a nonce. However, many
/// applications that use RC4 simply concatenate key and nonce; RC4's weak key schedule then gives rise to related key
/// attacks, like the Fluhrer, Mantin and Shamir attack (which is famous for breaking the WEP standard)
/// 
/// Because RC4 is a stream cipher, it is more malleable than common block ciphers. If not used together with a strong
/// message authentication code (MAC), then encryption is vulnerable to a bit-flipping attack. The cipher is also
/// vulnerable to a stream cipher attack if not implemented correctly
///
/// It is noteworthy, however, that RC4, being a stream cipher, was for a period of time the only common cipher that
/// was immune to the 2011 BEAST attack on TLS 1.0. The attack exploits a known weakness in the way cipher block
/// chaining mode is used with all of the other ciphers supported by TLS 1.0, which are all block ciphers 
///
/// In March 2013, there were new attack scenarios proposed by Isobe, Ohigashi, Watanabe and Morii, as well as
/// AlFardan, Bernstein, Paterson, Poettering and Schuldt that use new statistical biases in RC4 key table to recover
/// plaintext with large number of TLS encryptions
/// 
/// The use of RC4 in TLS is prohibited by RFC 7465 published in February 2015. 
///
///\section DES3CSA Triple DES
///
/// See https://en.wikipedia.org/wiki/Triple_DES
///
/// In cryptography, Triple DES (3DES or TDES), officially the Triple Data Encryption Algorithm (TDEA or Triple DEA),
/// is a symmetric-key block cipher, which applies the DES cipher algorithm three times to each data block. The Data
/// Encryption Standard’s(DES) 56-bit key is no longer considered adequate in the face of modern cryptanalytic
/// techniques and supercomputing power. However, an adapted version of DES, Triple DES (3DES), uses the same algorithm
/// to produce a more secure encryption 
///
/// While the government and industry standards abbreviate the algorithm's name as TDES (Triple DES) and TDEA (Triple
/// Data Encryption Algorithm),[1] RFC 1851 referred to it as 3DES from the time it first promulgated the idea, and
/// this namesake has since come into wide use by most vendors, users, and cryptographers
///
/// <B>Algorithm</B>
///
/// The original DES cipher's key size of 56 bits was generally sufficient when that algorithm was designed, but the
/// availability of increasing computational power made brute-force attacks feasible. Triple DES provides a relatively
/// simple method of increasing the key size of DES to protect against such attacks, without the need to design a
/// completely new block cipher algorithm 
///
/// A naive approach to increase strength of a block encryption algorithm with short key length (like DES) would be to
/// use two keys (K1, K2) instead of one, and encrypt each block twice: \f$ E_K2(E_K1(plaintext)) \f$. If the original
/// key length is <I>n</I> bits, one would hope this scheme provides security equivalent to using key <I>2n</I> bits
/// long. Unfortunately, this approach is vulnerable to meet-in-the-middle attack: given a known plaintext pair 
/// <B>(x, y)</B>, such that \f$ y = E_K2(E_K1(x))\f$, one can recover the key pair <B>(K1, K2)</B> in \f$ {2}^{n}\f$ steps,
/// instead of \f$ {2}^{2n}\f$ steps one would expect from an ideally secure algorithm with <B><I>2n</I></B> bits of key
///
/// Therefore, Triple DES uses a "key bundle" that comprises three DES keys, <B>K1, K2</B> and <B>K3</B>, each of 56
/// bits (excluding parity bits). The encryption algorithm is:
///
/// \f$ ciphertext = E_K3 (D_K2(E_K1(plaintext)))\f$
///
/// That is, DES encrypt with <B>K1</B>, DES decrypt with <B>K2</B>, then DES encrypt with <B>K3</B>. Decryption is
/// the reverse:
///
/// \f$ plaintext = D_K1(E_K2(D_K3(ciphertext)))\f$
///
/// That is, decrypt with <B>K3</B>, encrypt with <B>K2</B>, then decrypt with <B>K1</B>
///
/// Each triple encryption encrypts one block of 64 bits of data
///
/// In each case the middle operation is the reverse of the first and last. This improves the strength of the algorithm
/// when using keying option 2 and provides backward compatibility with DES with keying option 3
///
/// <B>Keying options</B>
///
/// The standards define three keying options: 
///
/// * Keying option 1
///
///   * All three keys are independent. Sometimes known as 3TDEA or triple-length keys. This is the strongest, with
///     3 × 56 = 168 independent key bits. It is still vulnerable to meet-in-the-middle attack, but the attack requires
///     \f$ {2}^{2 × 56} steps\f$
///
/// * Keying option 2
///
///   * K1 and K2 are independent, and K3 = K1. Sometimes known as 2TDEA or double-length keys. This provides a shorter
///     key length of 112 bits and a reasonable compromise between DES and Kehttps://en.wikipedia.org/wiki/Triple_DESying option 1, with the same caveat as
///     above. This is an improvement over "double DES" which only requires 256 steps to attack. NIST has deprecated
///     this option
///
/// * Keying option 3
///
///   * All three keys are identical, i.e. <B>K1 = K2 = K3</B>. This is backward compatible with DES, since two
///     operations cancel out. ISO/IEC 18033-3 never allowed this option, and NIST no longer allows K1 = K2 or K2 = K3
///
/// Each DES key is 8 odd-parity bytes, with 56 bits of key and 8 bits of error-detection. A key bundle requires 24
/// bytes for option 1, 16 for option 2, or 8 for option 3
///
/// NIST (and the current TCG specifications version 2.0 of approved algorithms for Trusted Platform Module) also
/// disallows using any one of the 64 following 64-bit values in any keys (note that 32 of them are the binary
/// complement of the 32 others; and that 32 of these keys are also the reverse permutation of bytes of the 32 others),
/// listed here in hexadecimal (in each byte, the least significant bit is a odd-parity generated bit, it is discarded
/// when forming the effective 56-bit keys): 
///
///\code
/// 01.01.01.01.01.01.01.01, FE.FE.FE.FE.FE.FE.FE.FE, E0.FE.FE.E0.F1.FE.FE.F1, 1F.01.01.1F.0E.01.01.0E,
/// 01.01.FE.FE.01.01.FE.FE, FE.FE.01.01.FE.FE.01.01, E0.FE.01.1F.F1.FE.01.0E, 1F.01.FE.E0.0E.01.FE.F1,
/// 01.01.E0.E0.01.01.F1.F1, FE.FE.1F.1F.FE.FE.0E.0E, E0.FE.1F.01.F1.FE.0E.01, 1F.01.E0.FE.0E.01.F1.FE,
/// 01.01.1F.1F.01.01.0E.0E, FE.FE.E0.E0.FE.FE.F1.F1, E0.FE.E0.FE.F1.FE.F1.FE, 1F.01.1F.01.0E.01.0E.01,
/// 01.FE.01.FE.01.FE.01.FE, FE.01.FE.01.FE.01.FE.01, E0.01.FE.1F.F1.01.FE.0E, 1F.FE.01.E0.0E.FE.01.F1,
/// 01.FE.FE.01.01.FE.FE.01, FE.01.01.FE.FE.01.01.FE, E0.01.01.E0.F1.01.01.F1, 1F.FE.FE.1F.0E.FE.FE.0E,
/// 01.FE.E0.1F.01.FE.F1.0E, FE.01.1F.E0.FE.01.0E.F1, E0.01.1F.FE.F1.01.0E.FE, 1F.FE.E0.01.0E.FE.F1.01,
/// 01.FE.1F.E0.01.FE.0E.F1, FE.01.E0.1F.FE.01.F1.0E, E0.01.E0.01.F1.01.F1.01, 1F.FE.1F.FE.0E.FE.0E.FE,
/// 01.E0.01.E0.01.F1.01.F1, FE.1F.FE.1F.FE.0E.FE.0E, E0.1F.FE.01.F1.0E.FE.01, 1F.E0.01.FE.0E.F1.01.FE,
/// 01.E0.FE.1F.01.F1.FE.0E, FE.1F.01.E0.FE.0E.01.F1, E0.1F.01.FE.F1.0E.01.FE, 1F.E0.FE.01.0E.F1.FE.01,
/// 01.E0.E0.01.01.F1.F1.01, FE.1F.1F.FE.FE.0E.0E.FE, E0.1F.1F.E0.F1.0E.0E.F1, 1F.E0.E0.1F.0E.F1.F1.0E,
/// 01.E0.1F.FE.01.F1.0E.FE, FE.1F.E0.01.FE.0E.F1.01, E0.1F.E0.1F.F1.0E.F1.0E, 1F.E0.1F.E0.0E.F1.0E.F1,
/// 01.1F.01.1F.01.0E.01.0E, FE.E0.FE.E0.FE.F1.FE.F1, E0.E0.FE.FE.F1.F1.FE.FE, 1F.1F.01.01.0E.0E.01.01,
/// 01.1F.FE.E0.01.0E.FE.F1, FE.E0.01.1F.FE.F1.01.0E, E0.E0.01.01.F1.F1.01.01, 1F.1F.FE.FE.0E.0E.FE.FE,
/// 01.1F.E0.FE.01.0E.F1.FE, FE.E0.1F.01.FE.F1.0E.01, E0.E0.1F.1F.F1.F1.0E.0E, 1F.1F.E0.E0.0E.0E.F1.F1,
/// 01.1F.1F.01.01.0E.0E.01, FE.E0.E0.FE.FE.F1.F1.FE, E0.E0.E0.E0.F1.F1.F1.F1, 1F.1F.1F.1F.0E.0E.0E.0E,
///\endcode
///
/// With these restrictions on allowed keys, Triple DES has been reapproved with keying options 1 and 2 only. Generally
/// the three keys are generated by taking 24 bytes from a strong random generator and only keying option 1 should be
/// used (option 2 needs only 16 random bytes, but strong random generators are hard to assert and it's considered best
/// practice to use only option 1)
///
/// <B>Usage</B>
///
/// The electronic payment industry uses Triple DES and continues to develop and promulgate standards based upon it,
/// such as EMV 
///
/// Earlier versions of Microsoft OneNote, Microsoft Outlook 2007 and Microsoft System Center Configuration Manager
/// 2012 use Triple DES to password-protect user content and system data. However, in December 2018, Microsoft
/// announced the retirement of 3DES throughout their Office 365 service
/// 
/// Firefox and Mozilla Thunderbird use Triple DES in CBC mode to encrypt website authentication login credentials
/// when using a master password
///
///\section SEEDCSA SEED Block Cipher (Korea)
///
/// SEED is a block cipher developed by the Korea Internet & Security Agency (KISA). It is used broadly throughout
/// South Korean industry, but seldom found elsewhere. It gained popularity in Korea because 40-bit encryption was
/// not considered strong enough, so the Korea Information Security Agency developed its own standard. However, this
/// decision has historically limited the competition of web browsers in Korea, as no major SSL libraries or web
/// browsers supported the SEED algorithm, requiring users to use an ActiveX control in Internet Explorer for secure
/// web sites 
///
/// On April 1, 2015 the Ministry of Science, ICT and Future Planning (MSIP) announced its plan to remove the ActiveX
/// dependency from at least 90 percent of the country's top 100 websites by 2017. Instead, HTML5-based technologies
/// will be employed as they operate on many platforms, including mobile devices. Starting with the private sector,
/// the ministry plans to expand this further to ultimately remove this dependency from public websites as well 
///
/// <B>Design</B>
///
/// SEED is a 16-round Feistel network with 128-bit blocks and a 128-bit key. It uses two 8 × 8 S-boxes which, like
/// those of SAFER, are derived from discrete exponentiation (in this case, x247 and x251 – plus some "incompatible
/// operations"). It also has some resemblance to MISTY1 in the recursiveness of its structure: the 128-bit full
/// cipher is a Feistel network with an F-function operating on 64-bit halves, while the F-function itself is a
/// Feistel network composed of a G-function operating on 32-bit halves. However the recursion does not extend further
/// because the G-function is not a Feistel network. In the G-function, the 32-bit word is considered as four 8-bit
/// bytes, each of which is passed through one or the other of the S-boxes, then combined in a moderately complex set
/// of boolean functions such that each output bit depends on 3 of the 4 input bytes
///
/// SEED has a fairly complex key schedule, generating its thirty-two 32-bit subkeys through application of its
/// G-function on a series of rotations of the raw key, combined with round constants derived (as in TEA) from the
/// Golden ratio
///
///\section ZUCAlgSA ZUC Encrytpion Algorithm (128-EEA3 and 128-EIA3)
///
/// @see Specification of the 3GPP Confidentiality and Integrity Algorithms 128-EEA3 and 128-EIA3 Document 2: ZUC Specification
///
/// <B>General structure of the algorithm</B>
///
/// ZUC has three logical layers, see the figure below. The top layer is a linear feedback shift register (LFSR) of 16 stages, the
/// middle layer is for bit-reorganization ( BR), and the bottom layer is a nonlinear function F
///
///\image html ZUCStructure.png "General Structure of ZUC"
///\image latex ZUCStructure.eps "General Structure of ZUC" width=10cm
///
/// <B>The linear feedback shift register (LFSR)</B> 
///
/// The linear feedback shift register (LFSR) has 16 of 31-bit cells \f$ (s_0, s_1,\cdots,s_{15})\f$. Each cell \f$ s_i (0 \leq i \leq 15)\f$ is restricted to take
/// values from the following set <B>\f$ \{1,2,3,\cdots,{2}^{31} – 1\}\f$</B>. The LFSR has 2 modes of operations: the initialization mode and the working mode
///
/// In the initialization mode, the LFSR receives a 31-bit input word u, which is obtained by removing the rightmost bit from the
/// 32-bit output W of  the nonlinear function F, i.e., u=W>>1. More specifically, the initialization mode works as follows:  
///
/// LFSRWithInitialisationMode(u) {
///
/// 1. \f$ v={2}^{15}s_{15}+{2}^{17}s_{13}+{2}_{21}s_{10}+{2}^{20}s_4+(1+{2}^{8})s_0\f$ mod \f$ ({2}^{31}-1)\f$ 
///
/// 2. \f$ s_{16}=(v+u)\f$ mod \f$ ({2}^{31}-1)\f$
///
/// 3. \f$ If s_{16}=0\f$, then set \f$s_{16}={2}^{31}-1\f$
///
/// 4. \f$ (s_1,s_2,\cdots,s_{15},s_{16})\rightarrow(s_0,s_1,\cdots,s_{14},s_{15})\f$  
///
/// }  
///
/// In the working mode, the LFSR does not receive any input, and it works as follows:  
///
/// LFSRWithWorkMode() {
///
/// 1. \f$ s_{16}={2}^{15}s_15+{2}^{17}s_13+{2}^{21}s_10+{2}^{20}s_4+(1+{2}^{8})s_0\f$ mod \f$ ({2}^{31}-1)\f$
///
/// 2. \f$ If s_{16}=0\f$, then set \f$ s_{16}={2}^{31}-1\f$
///
/// 3. \f$ (s_1,s_2,\cdots,s_{15},s_{16})\rightarrow(s_0,s_1,\cdots,s_{14},s_{15})\f$
///
/// }  
///
/// Informative note: Since the multiplication of a 31-bit string s by \f$ {2}^{i}\f$ over \f$ GF({2}^{31}-1)\f$ can be implemented by a
/// cyclic shift of s to the left by i bits, only addition modulo \f$ {2}^{31}-1\f$ is needed in step 1 of the above functions. More precisely,
/// step 1 of the function LFSRWithInitialisationMode can be implemented by  
///
/// \f$ v=(s_{15} <<<_{31} 15)+(s_{13} <<<_{31} 17)+(s_{10} <<<_{31} 21)+(s_4 <<<_{31} 20)+(s_0 <<<_{31} 8)+s_0\f$ mod \f$ ({2}^{31}-1)\f$
///
/// and the same implementation is needed for step 1 of the function LFSRWithWorkMode
///
/// Informative note: For two elements \f$ a,b\f$ over \f$ GF({2}^{31}-1)\f$, the computation of \f$ v=a+b\f$ mod \f$ ({2}^{31}-1)\f$ can be done by
///
/// (1) compute v=a+b and
/// 
/// (2) if the carry bit is 1, then set v=v+1
///
/// Alternatively (and better if the implementation should resist possible timing attacks):
///
/// (1) compute w=a+b, where w is a 32-bit value; and
///
/// (2) set v = (least significant 31 bits of w) + (most significant bit of w)  
///
/// <B>The bit-reorganization</B>
///
/// The middle layer of the algorithm is the bit-reorganization. It extracts 128 bits from the cells of the LFSR and forms 4 of 32-bit words,
/// where the first three words will be used by the nonlinear function F in the bottom layer, and the last word will be involved in producing
/// the keystream
///
/// Let \f$ s_0, s_2, s_5, s_7, s_9, s_{11}, s_{14}, s_{15}\f$ be 8 cells of LFSR as in section 3.2. Then the bitreorganization forms 4 of 32-bit words
/// \f$ X_0, X_1, X_2, X_3\f$ from the above cells as follows:  
///
/// Bitreorganization() {
///
/// 1. \f$ X_0=s_{15H} \parallel s_{14L}\f$
///
/// 2. \f$ X_1=s_{11L} \parallel s_{9H}\f$
///
/// 3. \f$ X_2=s_{7L} \parallel s_{5H}\f$
///
/// 4. \f$ X_3=s_{2L} \parallel s_{0H}\f$
///
/// }  
///
/// Note: The \f$ s_i\f$ are 31-bit integers, so \f$ s_{iH}\f$ means bits 30...15 and not 31...16 of \f$ s_i, for 0 \leq i \leq 15\f$
///
/// <B>The nonlinear function F</B> 
///
/// The nonlinear function F has 2 of 32-bit memory cells \f$ R_1\f$ and \f$ R_2\f$. Let the inputs to F be \f$ X_0, X_1\f$ and \f$ X_2\f$, which come
/// from the outputs of the bit-reorganization (see section 3.3), then the function F outputs a 32-bit word W. The detailed process of F is as follows:  
///
/// F (\f$ X_0, X_1, X_2\f$) {
///
/// 1. \f$ W=(X_0 \oplus R_1) \oplus R_2\f$
///
/// 2. \f$ W_1=R_1 \oplus X_1\f$
///
/// 3. \f$ W_2=R_2 \oplus X_2\f$
///
/// 4. \f$ R_1=S(L_1(W_{1L} \parallel W_{2H}))\f$
///
/// 5. \f$ R_2=S(L_2(W_{2L} \parallel W_{1H}))\f$
///
/// }  
///
/// where <I>S</I> is a 32×32 S-box, see section 3.4.1, \f$ L_1\f$ and \f$ L_2\f$ are linear transforms as defined in section 3.4.2
///
/// <B>The S-box S</B>
///
/// The 32×32 S-box S is composed of 4 juxtaposed  8×8 S-boxes, i.e., S=(\f$ S_0,S_1,S_2,S_3\f$), where \f$ S_0=S_2\f$, \f$ S_1=S_3\f$. The definitions
/// of \f$ S_0\f$ and \f$ S_1\f$ can be found in table 3.1 and table 3.2 respectively
///
/// Let x be an 8-bit input to \f$ S_0\f$ (or \f$ S_1\f$). Write x into two hexadecimal digits as \f$ x=h \parallel l\f$, then the entry at the intersection
/// of the h-th row and the l-th column in table 3.1 (or table 3.2) is the output of \f$ S_0\f$ (or \f$ S_1\f$)
///
///\image html SBOX_S0.png "The S-Box S0"
///\image latex SBOX_S0.eps "The S-Box S0" width=10cm
///
///\image html SBOX_S1.png "The S-Box S1"
///\image latex SBOX_S1.eps "The S-Box S1" width=10cm
///
/// <B>The linear transforms L1 and L2</B>
///
/// Both L1 and L2 are linear transforms from 32-bit words to 32-bit words, and are defined as follows:  
///
/// \f$ L_1(X)=X \oplus (X <<<_{32} 2) \oplus (X <<<_{32} 10) \oplus (X <<<_{32} 18) \oplus (X <<<_{32} 24)\f$
///
/// \f$ L_2(X)=X \oplus (X <<<_{32} 8) \oplus (X <<<_{32} 14) \oplus (X <<<_{32} 22) \oplus (X <<<_{32} 30)\f$
///
/// <B>Key loading</B>
///
/// The key loading procedure will expand the initial key and the initial vector into 16 of 31-bit integers as the initial state of the LFSR. Let the 128-bit
/// initial key k and the 128-bit initial vector iv be  
///
/// \f$ k=k_0 \parallel k_1 \parallel k_2 \parallel \cdots \parallel k_{15}\f$ 
///
/// and  
///
/// \f$ iv=iv_0 \parallel iv_1 \parallel iv_2 \parallel \cdots \parallel iv_{15}\f$
///
/// respectively, where \f$ k_i\f$ and \f$ iv_i, 0\leq i\leq 15\f$, are all bytes. Then k and iv are loaded to the cells \f$ s_0, s_1,\cdots, s_{15}\f$ of LFSR as follows:  
///
/// 1. Let D be a 240-bit long constant string composed of 16 substrings of 15 bits:  
///
/// \f$ D=d_0 \parallel d_1 \parallel \cdots \parallel d_{15}\f$
///
/// where  
///
/// \f$ d00 = 100010011010111_2 \f$
///
/// \f$ d01 = 010011010111100_2 \f$
///
/// \f$ d02 = 110001001101011_2 \f$
///
/// \f$ d03 = 001001101011110_2 \f$
///
/// \f$ d04 = 101011110001001_2 \f$
///
/// \f$ d05 = 011010111100010_2 \f$
///
/// \f$ d06 = 111000100110101_2 \f$
///
/// \f$ d07 = 000100110101111_2 \f$
///
/// \f$ d08 = 100110101111000_2 \f$
///
/// \f$ d09 = 010111100010011_2 \f$
///
/// \f$ d10 = 110101111000100_2 \f$
///
/// \f$ d11 = 001101011110001_2 \f$
///
/// \f$ d12 = 101111000100110_2 \f$
///
/// \f$ d13 = 011110001001101_2 \f$
///
/// \f$ d14 = 111100010011010_2 \f$
///
/// \f$ d15 = 100011110101100_2 \f$
///
/// 2. \f$ For 0 \leq i \leq 15, let s_i=k_i \parallel d_i \parallel iv_i\f$
///
/// <B>The execution of ZUC</B>
///
/// The execution of ZUC has two stages: the initialization stage and the working stage
///
/// <B>The initialization stage</B>
///
/// During the initialization stage, the algorithm calls the key loading procedure (see section 3.5) to load the 128-bit initial key k and the 128-bit initial vector iv
/// into the LFSR, and set the 32bit memory cells R1 and R2 to be all 0. Then the cipher runs the following operations 32 times:
///
/// 1.  Bitreorganization();
///
/// 2.  w=F(\f$ X_0, X_1, X_2\f$);
///
/// 3.  LFSRWithInitialisationMode(w >> 1)
///
/// <B>The working stage</B>
///
/// After the initialization stage, the algorithm moves into the working stage. At the working stage, the algorithm executes the following operations once, and
/// discards the output W of F:
///
/// 1.  Bitreorganization();
///
/// 2.  F(\f$ X_0, X_1, X_2\f$);
///
/// 3.  LFSRWithWorkMode()
///
/// Then the algorithm goes into the stage of producing keystream, i.e., for each iteration, the following operations are executed once, and a 32-bit word Z
/// is produced as an output:
///
/// 1.  Bitreorganization();
///
/// 2.  Z=F(\f$ X_0, X_1, X_2) \oplus X3\f$;
///
/// 3.  LFSRWithWorkMode()
///
///\section SNOWESA Snow3g Stream Cipher (UEA2 and UIA2)
///
/// @see Specification of the 3GPP Confidentiality and Integrity Algorithms UEA2 and UIA2 Document 2: SNOW 3G Specification
///
/// SNOW 3G is a word-oriented stream cipher that generates a sequence of 32-bit words under
/// the control of a 128-bit key and a 128-bit initialisation variable. These words can be used
/// to mask the plaintext. First a key initialisation is performed, i.e. the cipher is clocked
/// without producing output, see 4.1. Then with every clock tick it produces a 32-bit word of
/// output
///
/// <B>Functions used in different Components of SNOW 3G</B> 
///
/// <B>MULx</B> maps 16 bits to 8 bits. Let V and c be 8-bit input values. Then MULx is defined:
///
/// If the leftmost (i.e. the most significant) bit of V equals 1, then
///
/// \f$ MULx(V, c) = (V <<_8 1) \oplus c, else MULx(V, c) = V <<_8 1\f$
///
/// <B>MULxPOW</B> maps 16 bits and an positive integer i to 8 bit. Let V and c be 8-bit input
/// values, then MULxPOW(V, i, c) is recursively defined:
///
/// If i equals 0, then \f$ MULxPOW(V, i, c) = V\f$, else \f$ MULxPOW(V, i, c) = MULx(MULxPOW(V, i-1, c), c)\f$ 
///
/// <B>Linear Feedback Shift Register (LFSR)</B>
///
/// The Linear Feedback Shift Register (LFSR) consists of sixteen stages \f$ s_0, s_1, s_2,\cdots, s_{15}\f$
/// each holding 32 bits
///
/// <B>Finite State Machine (FSM)</B> 
///
/// The Finite State Machine (FSM) has three 32-bit registers R1, R2 and R3. The S-boxes S1
/// and S2 are used to update the registers R2 and R3
///
/// <B>The 32x32-bit S-Box S1</B>
///
/// The S-Box \f$ S_1\f$ maps a 32-bit input to a 32-bit output. Let \f$ w = w_0 || w_1 || w_2 || w_3\f$ the
/// 32-bit input with \f$ w_0\f$ the most and \f$ w3\f$ the least significant byte
///
/// Let \f$ S_1(w)= r_0 || r_1 || r_2 || r_3\f$ with \f$ r_0\f$ the most and \f$ r_3\f$ the least significant byte.
/// We use the 8 to 8 bit Rijndael S-Box \f$ S_R\f$ defined in 5.1
///
/// Then \f$ r_0, r_1, r_2, r_3\f$ are defined as 
///
/// \f$ r_0= MULx(S_R(w_0), 0x1B) \oplus S_R(w_1) \oplus S_R(w_2) \oplus MULx(S_R(w_3), 0x1B) \oplus S_R(w_3)\f$
///
/// \f$ r_1= MULx(S_R(w_0), 0x1B) \oplus S_R(w_0) \oplus MULx(S_R(w_1), 0x1B) \oplus S_R(w_2) \oplus S_R(w_3)\f$
///
/// \f$ r_2= S_R(w_0) \oplus MULx(S_R(w_1), 0x1B) \oplus S_R(w_1) \oplus MULx(S_R(w_2), 0x1B) \oplus S_R(w_3)\f$ 
///
/// \f$ r_3= S_R(w_0) \oplus S_R(w_1) \oplus MULx(S_R(w_2), 0x1B) \oplus S_R(w_2) \oplus MULx(S_R(w_3), 0x1B)\f$
///
/// <B>The 32x32-bit S-Box S2</B> 
///
/// The S-Box \f$ S_2\f$ maps a 32-bit input to a 32-bit output. Let \f$ w = w_0 || w_1 || w_2 || w_3\f$ the
/// 32-bit input with \f$ w_0\f$ the most and \f$ w_3\f$ the least significant byte. Let \f$ S_2(w)= r_0 || r_1 || r_2 || r_3\f$
/// with \f$ r0\f$ the most and \f$ r3\f$ the least significant byte. We use the 8 to 8 bit S-Box \f$ S_Q\f$ defined in 5.2 
///
/// Then \f$ r_0, r_1, r_2, r_3\f$ are defined as 
///
/// \f$ r_0= MULx(S_Q(w_0), 0x69) \oplus S_Q(w_1) \oplus S_Q(w_2) \oplus MULx(S_Q(w_3), 0x69) \oplus SQ(w3)\f$ 
///
/// \f$ r_1= MULx(S_Q(w_0), 0x69) \oplus S_Q(w_0) \oplus MULx(S_Q(w_1), 0x69) \oplus S_Q(w_2) \oplus S_Q(w_3)\f$ 
///
/// \f$ r_2= S_Q(w_0) \oplus MULx(S_Q(w_1), 0x69) \oplus S_Q(w_1) \oplus MULx(S_Q(w_2), 0x69) \oplus S_Q(w_3)\f$ 
///
/// \f$ r_3= S_Q(w_0) \oplus S_Q(w_1) \oplus MULx(S_Q(w_2), 0x69) \oplus S_Q(w_2) \oplus MULx(S_Q(w_3), 0x69)\f$ 
///
///\subsection TCOPSA The Clocking Operations 
///
/// <B>Clocking the LFSR</B>
///
/// The clocking of the LFSR has two different modes of operation, the Initialisation Mode 3.4.4 and the Keystream Mode 3.4.5.
/// In both modes the functions \f$ MUL_α\f$ and \f$ DIV_α\f$ are used which are defined in 3.4.2 resp. 3.4.3
///
/// <B>The function \f$ MUL_α\f$</B>
///
/// The function \f$ MUL_α\f$ maps 8 bits to 32 bits. Let c be the 8-bit input, then \f$ MUL_α\f$ is defined as 
///
/// \f$ MUL_α(c) = (MULxPOW(c, 23, 0xA9) || MULxPOW(c, 245, 0xA9) || MULxPOW(c, 48, 0xA9) || MULxPOW(c, 239, 0xA9))\f$ 
///
/// <B>The function \f$ DIV_α\f$</B>
///
/// The function \f$ DIV_α\f$ maps 8 bits to 32 bits. Let c be the 8-bit input, then \f$ DIV_α\f$ is defined as 
///
/// \f$ DIV_α(c) = (MULxPOW(c, 16, 0xA9) || MULxPOW(c, 39, 0xA9) || MULxPOW(c, 6, 0xA9) || MULxPOW(c, 64, 0xA9))\f$ 
///
/// <B>Initialisation Mode</B>
///
/// In the Initialisation Mode the LFSR receives a 32-bit input word F, which is the output of the FSM
///
/// Let \f$ s_0 = s_{0,0} || s_{0,1} || s_{0,2} || s_{0,3}\f$ with \f$ s_{0,0}\f$ being the most and \f$ s_{0,3}\f$ being
/// the least significant byte of \f$ s_0\f$. 
///
/// Let \f$ s_{11} = s_{11,0} || s_{11,1} || s_{11,2} || s_{11,3}\f$ with \f$ s_{11,0}\f$ being the most and \f$ s_{11,3}\f$
/// being the least significant byte of \f$ s_{11}\f$ 
///
/// Compute the intermediate value v as 
///
/// \f$ v = (s_{0,1} || s_{0,2} || s_{0,3} || 0x00) \oplus MUL_α(s_{0,0}) \oplus s_2 \oplus (0x00 || s_{11,0} || s_{11,1} || s_{11,2}) \oplus DIV_α(s_{11,3}) \oplus F\f$
///
/// Set 
///
/// \f$ s_0=s_1, s_1=s_2, s_2=s_3, s_3=s_4, s_4=s_5, s_5=s_6, s_6=s_7, s_7=s_8\f$
///
/// \f$ s_8=s_9, s_9=s_{10}, s_{10}=s_{11}, s_{11}=s_{12}, s_{12}=s_{13}, s_{13}=s_{14}, s_{14}=s_{15}, s_{15} = v\f$
///
/// <B>Keystream Mode</B>
///
/// In the Keystream Mode the LFSR does not receive any input
///
/// Let \f$ s_0 = s_{0,0} || s_{0,1} || s_{0,2} || s_{0,3}\f$ with \f$ s_{0,0}\f$ being the most and \f$ s_{0,3}\f$ being the least significant byte of \f$ s_0\f$ 
///
/// Let \f$ s_11 = s_{11,0} || s_{11,1} || s_{11,2} || s_{11,3}\f$ with \f$ s_{11,0}\f$ being the most and \f$ s_{11,3}\f$ being the least significant byte of \f$ s_11\f$
///
/// Compute the intermediate value v as 
///
/// v = \f$ (s_{0,1} || s_{0,2} || s_{0,3} || 0x00) \oplus MUL_α(s_{0,0}) \oplus s_2 \oplus (0x00 || s_{11,0} || s_{11,1} || s_{11,2}) \oplus DIV_α(s_{11,3})\f$ 
///
/// Set 
///
/// \f$ s_0=s_1, s_1=s_2, s_2=s_3, s_3=s_4, s_4=s_5, s_5=s_6, s_6=s_7, s_7=s_8\f$
///
/// \f$ s_8=s_9, s_9=s_{10}, s_{10}=s_{11}, s_{11}=s_{12}, s_{12}=s_{13}, s_{13}=s_{14}, s_{14}=s_{15}, s_{15}=v\f$ 
///
/// <B>Clocking the FSM</B>
///
/// The FSM has two input words \f$ s_{15}\f$ and \f$ s_5\f$ from the LFSR. It produces a 32-bit output word F: 
///
/// \f$ F = (s_{15} \oplus R1) \oplus R2\f$
///
/// Then the registers are updated. Compute the intermediate value r as 
///
/// \f$ r = R2 \oplus (R3 \oplus s_5)\f$ 
///
/// Set 
///
/// \f$ R3 = S_2(R2)\f$
///
/// \f$ R2 = S_1(R1)\f$
///
/// \f$ R1 = r\f$
///
///\subsection OPSnow3GSA Operation of SNOW 3G 
///
/// <B>Initialisation</B>
///
/// SNOW 3G is initialized with a 128-bit key consisting of four 32-bit words <B>\f$ k_0, k_1, k_2, k_3\f$</B> and an 128-bit initialisation
/// variable consisting of four 32-bit words <B>\f$ IV_0, IV_1, IV_2, IV_3\f$</B> as follows
///
/// Let <B>1</B> be the all-ones word (0xffffffff)
///
/// \f$ s_{15}=k_3 \oplus IV_0\f$ 
///
/// \f$ s_{14}=k_2\f$
///
/// \f$ s_{13}=k_1\f$
///
/// \f$ s_{12}=k_0 \oplus IV_1\f$ 
/// 
/// \f$ s_{11}=k_3 \oplus 1\f$
///
/// \f$ s_{10}=k_2 \oplus 1 \oplus IV_2 s_9 = k_1 \oplus 1 \oplus IV_3 s_8 = k_0 \oplus 1\f$ 
///
/// \f$ s_7=k_3\f$
///
/// \f$ s_6=k_2\f$
///
/// \f$ s_5=k_1\f$
///
/// \f$ s_4=k_0\f$ 
///
/// \f$ s_3=k_3 \oplus 1\f$
///
/// \f$ s_2=k_2 \oplus 1\f$
///
/// \f$ s_1=k_1 \oplus 1\f$
///
/// \f$ s_0=k_0 \oplus 1\f$ 
///
/// The FSM is initialised with \f$ R1 = R2 = R3 = 0\f$
///
/// Then the cipher runs in a special mode without producing output: 
///
/// repeat 32-times { 
///
/// STEP 1: The FSM is clocked (see 3.4.6) producing the 32-bit word F
///
/// STEP 2: Then the LFSR is clocked in Initialisation Mode (see 3.4.4) consuming F
///
/// } 
///
///\image html Snow3GDuringInit.png "Snow 3G Algorithm During Initialization"
///\image latex Snow3GDuringInit.eps "Snow 3G Algorithm During Initialization" width=15cm
///
/// <B>Generation of Keystream</B>
///
/// First the FSM is clocked once, see 3.4.6. The output word of the FSM is discarded. Then the LFSR is clocked once
/// in Keystream Mode, see 3.4.4
///
/// After that n 32-bit words of keystream are produced:
///
/// for t = 1 to n {
///
/// STEP 1: The FSM is clocked (see 3.4.6) and produces a 32-bit output word F
///
/// STEP 2: The next keystream word is computed as \f$ z_t = F \oplus s_0\f$
///
/// STEP 3: Then the LFSR is clocked in Keystream Mode, see 3.4.4
///
/// } 
///
///\image html Snow3GDuringKeyStream.png "Snow 3G Algorithm During Key-Stream Generation"
///\image latex Snow3GDuringKeyStream.eps "Snow 3G Algorithm During Key-Stream Generation" width=15cm
///
/// <B>The Rijndael S-box \f$ S_R\f$</B>
///
/// The S-box SR maps 8 bit to 8 bit. Here the input and output is presented in hexadecimal form
///
/// Let \f$ x_0, x_1, y_0, y_1\f$ be hexadecimal digits with \f$ S_R(x_0 {2}^{4}+x_1) = y_0 {2}^{4} + y_1\f$, then the
/// cell at the intersection of the \f$ {x_0}^{th}\f$ row and the \f$ {x_1}^{th}\f$ column contains the values for \f$ y_0 || y_1\f$ in 
/// hexadecimal form
///
/// For example \f$ S_R(42) = S_R(0x2A) = 0xE5 = 229\f$
///
///\image html SnowSBOXSr.png "Rijndael S-Box"
///\image latex SnowSBOXSr.eps "Rijndael S-Box" width=15cm
///
/// <B>The S-box \f$ S_Q\f$</B>
///
/// The S-box \f$ S_Q\f$ maps 8 bit to 8 bit. Here the input is presented in hexadecimal form
///
/// Let \f$ x_0, x_1, y_0, y_1\f$ be hexadecimal digits with \f$ S_Q(x_0 {2}^{4}+x_1) = y_0 {2}^{4} + y_1\f$, then the
/// cell at the intersection of the \f$ {x_0}^{th}\f$ row and the \f$ {x_1}^{th}\f$ column contains the values for \f$ y_0 || y_1\f$ in hexadecimal form
///
/// For example \f$ S_Q(42) = S_Q(0x2A) = 0xAC = 172\f$
///
///\image html SnowSBOXSq.png "S-Box SQ"
///\image latex SnowSBOXSq.eps "S-Box SQ" width=15cm
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jconfident
/// @see ProtocolPP::jconfidentsa
/// @see ProtocolPP::jsnow3g
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jzuc
///
/// <B>For Additional Documentation:</B>
/// @see jconfident
/// @see jconfidentsa
/// @see jsnow3g
/// @see jmodes
/// @see jzuc
///
/// [1] By Serpent-linearfunction.png: User:Dakederivative work: Hydrox (talk) - Serpent-linearfunction.png, CC BY-SA 3.0, https://commons.wikimedia.org/w/index.php?curid=7437555
///
/// <center>Protocol++&reg; (Protocolpp&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class jconfidentsa : public jsecass {

public:

    /////////////////////////////////////////////////////////////////
    /// Constructor for default values as follows
    ///
    /// <table>
    /// <caption id="Confidentiality Defaults">Confidentiality Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>cipher<td>cipher_t::AES
    /// <tr><td>mode<td>mode_t::CBC
    /// <tr><td>dir<td>direction_t::ENC
    /// <tr><td>key<td>jarray<uint8_t>(0)
    /// <tr><td>iv<td>jarray<uint8_t>(0)
    /// <tr><td>icvlen<td>0
    /// <tr><td>aadlen<td>0
    /// <tr><td>count<td>0
    /// <tr><td>bearer<td>0
    /// </table>
    ///
    ///\code
    /// jconfidentsa conf;
    ///
    /// conf.set_field<cipher_t>(field_t::CIPHER, cipher_t::SM4);
    /// conf.set_field<uint32_t>(field_t::COUNT, 0xAA11BB22);
    /// conf.set_field<mode_t>(field_t::MODE, mode_t::GCM);
    ///\endcode
    /////////////////////////////////////////////////////////////////
    jconfidentsa();

    /////////////////////////////////////////////////////////////////
    /// Standard constructor (NOTE: SNOWE and ZUCE are the 3GPP implementations, not just the encryption algorithms)
    /// @param cipher - Cipher to use (AES, SERPENT, DES, CAMELLIA, SEED, ARIA, ZUCE, SM4, SNOWE, SNOWV, SNOWV_GCM, CHACHA20)
    /// @param dir - Direction of processing (ENC, DEC, UPLINK, DOWNLINK)
    /// @param key - Cipher key
    /// @param iv - Initialization vector
    /// @param icvlen - Length of the ICV tag (for AEAD modes)
    /// @param aadlen - Length of the prepended AAD data
    /// @param count - Count for ZUCE and SNOWE (not for SNOW-V)
    /// @param bearer - Bearer for ZUCE and SNOWE (not for SNOW-V)
    /////////////////////////////////////////////////////////////////
    jconfidentsa(cipher_t cipher,
                 direction_t dir,
                 std::shared_ptr<jarray<uint8_t>>& key,
                 std::shared_ptr<jarray<uint8_t>>& iv,
                 unsigned int icvlen=0,
                 unsigned int aadlen=0,
                 uint32_t count=0,
                 uint8_t bearer=0);

    //////////////////////////////////////////////////////////////////////
    /// standard copy constructor
    //////////////////////////////////////////////////////////////////////
    jconfidentsa(jconfidentsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// standard copy constructor from shared pointer
    //////////////////////////////////////////////////////////////////////
    explicit jconfidentsa(std::shared_ptr<jconfidentsa>& rhs);
     
    /////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    /////////////////////////////////////////////////////////////////
    ~jconfidentsa() {
        m_ckey.serase();
        m_iv.serase();
    }

    /////////////////////////////////////////////////////////////////
    /// Set the specified field with a new template value
    ///
    /// <table>
    /// <caption id="Confident SA Set Fields">Confidentsa Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>cipher_t<td>CIPHER<td>set_field<cipher_t>(field_t::CIPHER, cipher_t::SERPENT)
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENC)
    /// <tr><td>uint32_t<td>ICVLEN<td>set_field<uint32_t>(field_t::ICVLEN, 16)
    /// <tr><td>uint32_t<td>AADLEN<td>set_field<uint32_t>(field_t::AADLEN, 16)
    /// <tr><td>uint32_t<td>COUNT<td>set_field<uint32_t>(field_t::COUNT, 16)
    /// <tr><td>uint32_t<td>BLOCKSIZE<td>set_field<uint32_t>(field_t::BLOCKSIZE, 8)
    /// <tr><td>uint8_t<td>BEARER<td>set_field<uint8_t>(field_t::BEARER, 5)
    /// <tr><td>jarray<uint8_t><td>CIPHERKEY<td>set_field<jarray<uint8_t>>(field_t::CIPHERKEY, mykey)
    /// <tr><td>jarray<uint8_t><td>IV<td>set_field<jarray<uint8_t>>(field_t::IV, myiv)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, mykeyptr)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>IV<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::IV, myivptr)
    /// </table>
    ///
    /// @param field - field to set
    /// @param fieldval - New value to set in field
    /////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);
    
    /////////////////////////////////////////////////////////////////
    /// Get the specified field template value
    ///
    /// <table>
    /// <caption id="Confident SA Get Fields">Confidentsa Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>cipher_t<td>CIPHER<td>cipher_t tmp = get_field<cipher_t>(field_t::CIPHER)
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t tmp = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>uint32_t<td>ICVLEN<td>uint32_t tmp = get_field<uint32_t>(field_t::ICVLEN)
    /// <tr><td>uint32_t<td>AADLEN<td>uint32_t tmp = get_field<uint32_t>(field_t::AADLEN)
    /// <tr><td>uint32_t<td>COUNT<td>uint32_t tmp = get_field<uint32_t>(field_t::COUNT)
    /// <tr><td>uint32_t<td>BLOCKSIZE<td>uint32_t tmp = get_field<uint32_t>(field_t::BLOCKSIZE)
    /// <tr><td>uint8_t<td>BEARER<td>uint8_t tmp = get_field<uint8_t>(field_t::BEARER)
    /// <tr><td>jarray<uint8_t><td>CIPHERKEY<td>jarray<uint8_t> tmp = get_field<jarray<uint8_t>>(field_t::CIPHERKEY)
    /// <tr><td>jarray<uint8_t><td>IV<td>jarray<uint8_t> tmp = get_field<jarray<uint8_t>>(field_t::IV)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>std::shared_ptr<jarray<uint8_t>> tmp = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>IV<td>std::shared_ptr<jarray<uint8_t>> tmp = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::IV)
    /// </table>
    /// @param field - field to retrieve
    /// @return Value of the field requested
    /////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    /////////////////////////////////////////////////////////////////
    /// to_xml
    /// Convert the security association to XML for printing
    /// @param myxml - XML printing object
    /// @param direction - direction of processing
    /////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction); 

private:

    // don't use these
    jconfidentsa(const jconfidentsa& rhs) = delete;

    // member variables
    cipher_t m_cipher;
    direction_t m_dir;
    jarray<uint8_t> m_ckey;
    jarray<uint8_t> m_iv;
    unsigned int m_blocksize;
    unsigned int m_icvlen;
    unsigned int m_aadlen;
    uint32_t m_count;
    uint8_t m_bearer;
};

}

#endif // jconfidentsa_H
