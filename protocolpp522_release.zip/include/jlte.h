#ifndef JPROTOCOL_JLTE_H_
#define JPROTOCOL_JLTE_H_

///
///\class jlte jlte.h "include/jlte.h"
///
///\section LTEA Long Term Evolution (LTE)
///
///\image html LTE_Protocol_Stack.png "LTE Protocol Stack at the Data-Link Layer [1]"
///\image latex LTE_Protocol_Stack.eps "LTE Protocol Stack at the Data-Link Layer [1]" width=15cm
///
/// See PDCP_LTE_v14_1_0 specification on www.3gpp.org
///
/// If not otherwise mentioned in the definition of each field then the bits in the parameters
/// shall be interpreted as follows: the left most bit string is the first and most significant
/// and the right most bit is the last and least significant bit
///
/// Unless otherwise mentioned, integers are encoded in standard binary encoding for unsigned
/// integers. In all cases the bits appear ordered from MSB to LSB when read in the PDU
///
///\subsection PDCPSN PDCP SN
///
/// Length: 5, 7, 12, 15, 16, or 18 bits as indicated in the following table except for NB-IoT
/// which uses 7 bit PDCP SN for DRB.
///
/// <table>
/// <caption id="pdcpsn">\f$ PDCP SN Length\f$</caption>
/// <tr><th>Length<th>Description
/// <tr><td>5 <td>SRBs
/// <tr><td>7 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// <tr><td>12 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// <tr><td>15 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// <tr><td>16 <td>SLRBs
/// <tr><td>18 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// </table>
///
///\subsection LTEData Data
///
/// Length: Variable
///
/// The Data field may include either one of the following:
///
/// * Uncompressed PDCP SDU (user plane data, or control plane data); or
///
/// * Compressed PDCP SDU (user plane data only)
///
///\subsection LTEMAC MAC-I
///
/// Length: 32 bits
///
/// The MAC-I field carries a message authentication code calculated as specified in subclause 5.7
/// For control plane data that are not integrity protected, the MAC-I field is still present and
/// should be padded with padding bits set to 0
///
///\subsection LTECNT COUNT
///
/// Length: 32 bits
///
/// For ciphering and integrity a COUNT value is maintained. The COUNT value is composed of a HFN
/// and the PDCP SN. The length of the PDCP SN is configured by upper layers
///
/// <table>
/// <caption id="ltecount">Format of COUNT</caption>
/// <tr><td>HFN<td>PDCP SN
/// </table>
///
/// The size of the HFN part in bits is equal to 32 minus the length of the PDCP SN.
///
/// NOTE: When performing comparison of values related to COUNT, the UE takes into account that
/// COUNT is a 32-bit value, which may wrap around (e.g., COUNT value of 232 - 1 is less than
/// COUNT value of 0).
///
///\subsection LTERSVD R
///
/// Length: 1 bit
///
/// Reserved. In this version of the specification reserved bits shall be set to 0. Reserved bits
/// shall be ignored by the receiver
///
///\subsection DATCTRL D/C
///
/// Length: 1 bit
///
/// <table>
/// <caption id="dcfield">\f$ D/C field\f$</caption>
/// <tr><th>Bit<th>Description
/// <tr><td>0<td>Control PDU
/// <tr><td>1<td>Data PDU
/// </table>
///
///\subsection PDUTYPE PDU type
///
/// Length: 3 bits
///
/// <table>
/// <caption id="pdutype">\f$ PDU type\f$</caption>
/// <tr><th>Bit<th>Description
/// <tr><td>000<td>PDCP status report
/// <tr><td>001<td>Interspersed ROHC feedback packet
/// <tr><td>010<td>LWA status report
/// <tr><td>011-111<td>Reserved
/// </table>
///
///\subsection LTEFMS FMS
///
/// Length: 12 bits when a 12 bit SN length is used, 15 bits when a 15 bit SN length is used,
/// and 18 bits when an 18 bit SN length is used
///
/// PDCP SN of the first missing PDCP SDU
///
///\subsection LTEBITMAP Bitmap
///
/// Length: Variable
///
/// The length of the bitmap field can be 0
///
/// The MSB of the first octet of the type "Bitmap" indicates whether or not the PDCP SDU with the
/// SN (FMS + 1) modulo (Maximum_PDCP_SN + 1) has been received and, optionally decompressed correctly.
/// The LSB of the first octet of the type "Bitmap" indicates whether or not the PDCP SDU with the SN
/// (FMS + 8) modulo (Maximum_PDCP_SN + 1) has been received and, optionally decompressed correctly
///
/// <table>
/// <caption id="bitmap">\f$ Bitmap\f$</caption>
/// <tr><th>Bit<th>Description
/// <tr><td>0<td>PDCP SDU with PDCP SN = (FMS + bit position) modulo (Maximum_PDCP_SN+1) is missing in the receiver. The bit position of Nth bit in the Bitmap is N, i.e., the bit position of the first bit in the Bitmap is 1
/// <tr><td>1<td>PDCP SDU with PDCP SN = (FMS + bit position) modulo (Maximum_PDCP_SN+1) does not need to be retransmitted. The bit position of Nth bit in the Bitmap is N, i.e., the bit position of the first bit in the Bitmap is 1
/// </table>
///
/// The UE fills the bitmap indicating which SDUs are missing (unset bit - ’0’), i.e. whether an SDU
/// has not been received or optionally has been received but has not been decompressed correctly,
/// and which SDUs do not need retransmission (set bit - ’1’), i.e. whether an SDU has been received
/// correctly and may or may not have been decompressed correctly
///
///\subsection ROHC Interspersed ROHC feedback packet
///
/// Length: Variable
///
/// Contains one ROHC packet with only feedback, i.e. a ROHC packet that is not associated with a
/// PDCP SDU as defined in subclause 5.5.4.
///
///\subsection PIDX PGK Index
///
/// Length: 5 bits
///
/// 5 LSBs of PGK Identity as specified in [13]
///
///\subsection PIDENT PTK Identity
///
/// Length: 16 bits
///
/// PTK Identity as specified in [13].
///
///\subsection SDUTYPE SDU Type
///
/// Length: 3 bits
///
/// PDCP SDU type, i.e. Layer-3 Protocol Data Unit type as specified in [14]. PDCP entity may handle the
/// SDU differently per SDU Type, e.g. header compression is applicable to IP SDU but not ARP SDU and
/// Non-IP SDU
///
/// <table>
/// <caption id="sdutype">\f$ SDU Type\f$</caption>
/// <tr><th>Bit<th>Description
/// <tr><td>000<td>IP
/// <tr><td>001<td>ARP
/// <tr><td>010<td>PC5 Signaling
/// <tr><td>011<td>Non-IP
/// <tr><td>100-111<td>Reserved
/// </table>
///
///\subsection KID KD-sess ID
///
/// Length: 16 bits
///
/// KD-sess Identity as specified in [13].
///
///\subsection LTENMP NMP
///
/// Length: 12 bits when a 12 bit SN length is used, 15 bits when a 15 bit SN length is used, and 18 bits
/// when an 18 bit SN length is used. Number of missing PDCP SDU(s) with associated COUNT value below the
/// associated COUNT value corresponding to HRW, starting from and including the associated COUNT value
/// corresponding to FMS
///
///\subsection LTEHRW HRW
///
/// Length: 12 bits when a 12 bit SN length is used, 15 bits when a 15 bit SN length is used and 18 bits
/// when an 18 bit SN length is used
///
/// PDCP SN of the PDCP SDU received on WLAN with highest associated PDCP COUNT value
///
///\subsection LTEP P
///
/// Length: 1 bit
///
/// Polling indication. Set to 1 when eNB triggers a PDCP status report or LWA status report for LWA
///
///\subsection LTEENC Encryption
///
///\image html LTE_Encrypt.png "LTE Encryption Block Diagram [2]"
///\image latex LTE_Encrypt.eps "LTE Encryption Block Diagram [2]" width=15cm
///
/// LTE uses the Snow3g and ZUC encryption algorithms for the user plan and AES-CTR mode for the control
/// plane. The key is 128-bit for all three algorithms. As shown above, all algorithms are stream ciphers
/// with inputs of key, 32-bit COUNT, 5-bit BEARER, DIRECTION (UPLINK or DOWNLINK), LENGTH in bits to
/// generate the KEYSTREAM block of (length+31)/32 words. The keystream is XOR'd with the keystream to
/// create the ciphertext block. Encryption is applied to the payload of the packet
///
///\subsection LTEAUTH Authentication
///
///\image html LTE_MAC.png "LTE Authentication MAC Generation Diagram [3]"
///\image latex LTE_MAC.eps "LTE Authentication MAC Generation Diagram [3]" width=15cm
///
/// LTE uses the Snow3g and ZUC authentication algorithms (also known as F9 mode), for the user plane and
/// AES-CMAC mode for the control plan.  The key is 128-bit for all three algorithms. As shown above, using
/// the key, 32-bit COUNT, 5-bit BEARER (or sometimes called FRESH), DIRECTION (UPLINK or DOWNLINK), to 
/// generate a 4-byte MAC.  Authentication is applied over both the header and the payload (the encrypted
/// payload if encryption is enabled) with the MAC appended to the end of the packet
///
///\subsection CPDU LTE Control Plane Packet formats [4]
///
///\image html LTE_Ctrl_SRBs.png
///\image latex LTE_Ctrl_SRBs.eps "" width=15cm
///
///\image html LTE_Ctrl_Status_12bit.png
///\image latex LTE_Ctrl_Status_12bit.eps "" width=15cm
///
///\image html LTE_Ctrl_Status_15bit.png
///\image latex LTE_Ctrl_Status_15bit.eps "" width=15cm
///
///\image html LTE_Ctrl_Status_18bit.png
///\image latex LTE_Ctrl_Status_18bit.eps "" width=15cm
///
///\image html LTE_Ctrl_LWA_12bit.png
///\image latex LTE_Ctrl_LWA_12bit.eps "" width=15cm
/// 
///\image html LTE_Ctrl_LWA_15bit.png
///\image latex LTE_Ctrl_LWA_15bit.eps "" width=15cm
/// 
///\image html LTE_Ctrl_LWA_18bit.png
///\image latex LTE_Ctrl_LWA_18bit.eps "" width=15cm
///
///\image html LTE_Ctrl_ROHC.png
///\image latex LTE_Ctrl_ROHC.eps "" width=15cm
/// 
/// 
///\subsection UPDU LTE User Plane Packet formats [5]
///
///\image html LTE_User_7Bit.png
///\image latex LTE_User_7Bit.eps "" width=15cm
///
///\image html LTE_User_12Bit.png
///\image latex LTE_User_12Bit.eps "" width=15cm
///
///\image html LTE_User_15bit.png
///\image latex LTE_User_15bit.eps "" width=15cm
///
///\image html LTE_User_SLRB_16bit.png
///\image latex LTE_User_SLRB_16bit.eps "" width=15cm
///
///\image html LTE_User_SLRB_16bit_with_Integrity.png
///\image latex LTE_User_SLRB_16bit_with_Integrity.eps "" width=15cm
///
///\image html LTE_User_18bit.png
///\image latex LTE_User_18bit.eps "" width=15cm
/// 
///\image html LTE_User_RN_12bit.png
///\image latex LTE_User_RN_12bit.eps "" width=15cm
///
/// 1. www.nxp.com/Long Term Evolution Protocol Overview p12
/// 2. 3GPP TS 36.323 V14.1.0 (2016-12)
/// 3. 3GPP TS 36.323 V14.1.0 (2016-12)
/// 4. 3GPP TS 36.323 V14.1.0 (2016-12)
/// 5. 3GPP TS 36.323 V14.1.0 (2016-12)
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jlte
/// @see ProtocolPP::jltesa
/// @see ProtocolPP::jsnow3g
/// @see ProtocolPP::jsnowv
/// @see ProtocolPP::jzuc
/// @see ProtocolPP::jmodes
///
/// <B>For Additonal Documentation:</B>
/// @see jprotocol
/// @see jlte
/// @see jltesa
/// @see jsnow3g
/// @see jsnowv
/// @see jzuc
/// @see jmodes
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jltesa.h"
#include "jprotocol.h"

namespace  ProtocolPP {

class jlte : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal LTE containing all necessary fields to
    /// setup and run a LTE connection. All fields are accessible with
    /// the set_field() and get_field() functions
    ///
    /// @param rand - randomizer
    /// @param security - Parameters to setup a LTE flow
    /// @param replay - type of packet to generate
    //////////////////////////////////////////////////////////////////////
    jlte(std::shared_ptr<jrand>& rand,
         std::shared_ptr<jltesa>& security,
         std::string& replay);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jlte() {}

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without a file
    /// handle. Encap will produce a packet from the payload passed in
    ///
    /// @param input - payload to encapsulate with LTE
    /// @param output - encapsulated LTE packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without a file
    /// handle. Decap will produce a payload from the packet passed in
    /// check the flags, and update the window
    ///
    /// @param input - LTE packet to decapsulate
    /// @param output - decapsulated payload
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update a field in the header
    ///
    /// @param field - field to update in the LTE header
    /// @param value - new value to add to the LTE header
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update complete LTE header
    ///
    /// @param hdr - new header to add to the LTE header
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the field from the LTE security association
    ///
    /// @param field - field from LTE header to retrieve
    /// @return field from the LTE security association
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the field from the LTE header
    ///
    /// @param field - field from LTE header to retrieve
    /// @param header - LTE header to retrieve field from
    /// @return field from the LTE header
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& header);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the complete LTE header
    ///
    /// @return LTE header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr();

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jltesa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Writes the XML protocol and security objects to XML
    /// @param myxml - XMLPrinter object
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jlte() = delete;
    jlte(jlte& jlte) = delete;
    jlte(const jlte& jlte) = delete;

    // member variables
    std::shared_ptr<jltesa> m_sec;
    std::string m_replaypkt;
    jarray<uint8_t> m_ltehdr;
    std::shared_ptr<jreplay<uint32_t, uint32_t>> m_replay;
    std::shared_ptr<jmodes> engine;
    std::shared_ptr<jmodes> angine;
};

}

#endif // JPROTOCOL_JLTE_H_
