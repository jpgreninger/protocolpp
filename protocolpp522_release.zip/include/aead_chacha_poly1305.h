#ifndef AEAD_CHACHA_POLY1305_H
#define AEAD_CHACHA_POLY1305_H

///
///\class aead_chacha_poly1305 aead_chacha_poly1305.h "include/aead_chacha_poly1305.h"
///
/// See IETF https://tools.ietf.org/pdf/draft-nir-cfrg-chacha20-poly1305-01.pdf
///
///\section AEAD ChaCha20 and Poly1305 for IETF protocols
///
/// This document defines the ChaCha20 stream cipher, as well as the use of the
/// Poly1305 authenticator, both as stand-alone algorithms, and as a "combined mode",
/// or Authenticated Encryption with Additional Data (AEAD) algorithm.
///
/// <B>AEAD Construction</B>
///
/// Note: Much of the content of this document, including this AEAD construction is
/// taken from Adam Langley’s draft ([ agl-draft ]) for the use of these algorithms
/// in TLS. The AEAD construction described here is called AEAD_CHACHA20-POLY1305
///
/// AEAD_CHACHA20-POLY1305 is an authenticated encryption with additional data
/// algorithm. The inputs to AEAD_CHACHA20-POLY1305 are:
///
/// * A 256-bit key
///
/// * A 96-bit nonce - different for each invocation with the same key.
///
/// * An arbitrary length plaintext
///
/// * Arbitrary length additional data
///
/// The ChaCha20 and Poly1305 primitives are combined into an AEAD that takes a
/// 256-bit key and 64-bit IV as follows:
/// 
/// * First the 96-bit nonce is constructed by prepending a 32-bit
///   constant value to the IV.  This could be set to zero, or could be
///   derived from keying material, or could be assigned to a sender.
///   It is up to the specific protocol to define the source for that
///   32-bit value
///
/// * Next, a Poly1305 one-time key is generated from the 256-bit key
///   and nonce using the procedure described in Section 2.6
///
/// * The ChaCha20 encryption function is called to encrypt the
///   plaintext, using the same key and nonce, and with the initial
///   counter set to 1
///
/// * The Poly1305 function is called with the Poly1305 key calculated
///   above, and a message constructed as a concatenation of the
///   following:
///
/// * The additional data
///
/// * The length of the additional data in octets (as a 64-bit
///   little-endian integer).  TBD: bit count rather than octets? network order?
///
/// * The ciphertext
///
/// * The length of the ciphertext in octets (as a 64-bit little-
///   endian integer).  TBD: bit count rather than octets? network
///   order?
///
/// Decryption is pretty much the same thing
///
/// The output from the AEAD is twofold:
///
/// * A ciphertext of the same length as the plaintext
///
/// * A 128-bit tag, which is the output of the Poly1305 function
///
/// A few notes about this design:
///
/// 1. The amount of encrypted data possible in a single invocation is
///    \f${2}^{32}-1\f$ blocks of 64 bytes each, for a total of 247,877,906,880
///    bytes, or nearly 256 GB.  This should be enough for traffic
///    protocols such as IPsec and TLS, but may be too small for file
///    and/or disk encryption.  For such uses, we can return to the
///    original design, reduce the nonce to 64 bits, and use the integer
///    at position 13 as the top 32 bits of a 64-bit block counter,
///    increasing the total message size to over a million petabytes
///    (1,180,591,620,717,411,303,360 bytes to be exact)
///
/// 2. Despite the previous item, the ciphertext length field in the
///    construction of the buffer on which Poly1305 runs limits the
///    ciphertext (and hence, the plaintext) size to \f${2}^{64}\f$ bytes, or
///    sixteen thousand petabytes (18,446,744,073,709,551,616 bytes to
///    be exact)
///
/// <B>Implementation Advice</B>
///
/// Each block of ChaCha20 involves 16 move operations and one increment
/// operation for loading the state, 80 each of XOR, addition and Roll
/// operations for the rounds, 16 more add operations and 16 XOR
/// operations for protecting the plaintext  
///
/// Section 2.3 describes the ChaCha block function as "adding the original
/// input words". This implies that before starting the rounds on the ChaCha
/// state, it is copied aside only to be added in later. This would be correct,
/// but it saves a few operations to instead copy the state and do the work
/// on the copy. This way, for the next block you don’t need to recreate
/// the state, but only to increment the block counter. This saves
/// approximately 5.5% of the cycles
///
/// It is NOT RECOMMENDED to use a generic big number library such as the
/// one in OpenSSL for the arithmetic operations in Poly1305.  Such
/// libraries use dynamic allocation to be able to handle any-sized
/// integer, but that flexibility comes at the expense of performance as
/// well as side-channel security. More efficient implementations that
/// run in constant time are available, one of them in DJB’s own library,
/// NaCl ([ NaCl ]).
///
/// <B>Security Considerations</B>
///
/// The ChaCha20 cipher is designed to provide 256-bit security. The
/// Poly1305 authenticator is designed to ensure that forged messages are
/// rejected with a probability of \f$1-(\frac{n}{{2}^{102}})\f$ for a 16n-byte message, even
/// after sending \f${2}^{64}\f$ legitimate messages, so it is SUF-CMA in the
/// terminology of [ AE ].
///
/// Proving the security of either of these is beyond the scope of this document.
/// Such proofs are available in the referenced academic papers. The most
/// important security consideration in implementing this draft is the uniqueness
/// of the nonce used in ChaCha20. Counters and LFSRs are both acceptable ways of
/// generating unique nonces, as is encrypting a counter using a 64-bit cipher such
/// as DES. Note that it is not acceptable to use a truncation of a counter encrypted
/// with a 128-bit or 256-bit cipher, because such a truncation may repeat after a
/// short time
///
/// The Poly1305 key MUST be unpredictable to an attacker. Randomly generating the
/// key would fulfill this requirement, except that Poly1305 is often used in
/// communications protocols, so the receiver should know the key. Pseudo-random
/// number generation such as by encrypting a counter is acceptable. Using ChaCha with
/// a secret key and a nonce is also acceptable
///
/// The algorithms presented here were designed to be easy to implement in constant
/// time to avoid side-channel vulnerabilities. The operations used in ChaCha20 are
/// all additions, XORs, and fixed rotations. All of these can and should be implemented
/// in constant time. Access to offsets into the ChaCha state and the number of
/// operations do not depend on any property of the key, eliminating the chance of
/// information about the key leaking through the timing of cache misses
///
/// For Poly1305, the operations are addition, multiplication and modulus, all on
/// >128-bit numbers. This can be done in constant time, but a naive implementation
/// (such as using some generic big number library) will not be constant time. For
/// example, if the multiplication is performed as a separate operation from the modulus,
/// the result will some times be under \f${2}^{256}\f$ and some times be above
/// \f$2^256\f$. Implementers should be careful about timing side-channels for Poly1305
/// by using the appropriate implementation of these operations
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::chacha20
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::ciphers
///
/// <B>For Additional Documentation:</B>
/// @see chacha20
/// @see jmodes
/// @see ciphers
///
/// See the license for POLY1305 and CHACHA20 at:
/// 
/// * [MIT](http://www.opensource.org/licenses/mit-license.php) or PUBLIC DOMAIN
///
/// <center>Protocol++&reg; (Protocolpp&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <vector>
#include <iostream>

#include "aes.h"
using CryptoPP::AES;

#include "poly1305.h"
using CryptoPP::Poly1305;

#include "chacha.h"
//using CryptoPP::ChaCha20;

#include "chacha20.h"

namespace ProtocolPP {

class aead_chacha_poly1305 {

public:

    ////////////////////////////////////////////////////////
    /// Direction of processing for dual mode
    ////////////////////////////////////////////////////////
    enum dir_t { /// Encryption
        ENC,     /// Decryption
        DEC
    };

    ////////////////////////////////////////////////////////
    /// Constructor for AEAD CHACHA20-POLY1305 algorithm
    /// @param direction - direction of processing
    /// @param key - initialization key
    /// @param keylen - length of the key in bytes
    /// @param nonce - nonce for computation
    /// @param noncelen - length of the nonce in bytes
    /// @param icvlen - for decryption, length of the ICV tag
    ////////////////////////////////////////////////////////
    aead_chacha_poly1305(dir_t direction,
                         const unsigned char *key,
                         unsigned int keylen,
                         const unsigned char *nonce,
                         unsigned int noncelen,
                         unsigned int icvlen=0);

    ////////////////////////////////////////////////////////
    /// Standard Deconstructor for AEAD CHACHA20-POLY1305 algorithm
    ////////////////////////////////////////////////////////
    virtual ~aead_chacha_poly1305() {}

    ////////////////////////////////////////////////////////
    /// Calculates the ciphertext and MAC for AEAD CHACHA20-POLY1305 algorithm
    /// @param input - data to process
    /// @param output - result of the computation
    /// @param length - length of the data
    /// @param aad - authentication only data 
    /// @param aadlen - length of the AAD data
    ////////////////////////////////////////////////////////
    void ProcessData(const unsigned char *input,
                     unsigned char *output,
                     unsigned int length,
                     const unsigned char *aad,
                     unsigned int aadlen);

    ////////////////////////////////////////////////////////
    /// Returns the MAC using for AEAD CHACHA20-POLY1305 algorithm
    /// @param icv - ICV tag to retrieve
    /// @param length - length of ICV to retrieve
    ////////////////////////////////////////////////////////
    void result(unsigned char *icv, unsigned int length=16);

private:

    // don't use these
    aead_chacha_poly1305() = delete;
    aead_chacha_poly1305(aead_chacha_poly1305& rhs) = delete;
    aead_chacha_poly1305(const aead_chacha_poly1305& rhs) = delete;

    dir_t m_dir;
    std::vector<uint8_t> m_key;
    std::vector<uint8_t> m_authkey;
    std::vector<uint8_t> m_nonce;
    std::vector<uint8_t> m_icv;
    unsigned int m_icvlen;
    //std::shared_ptr<CryptoPP::ChaCha20::Encryption> m_engine;
    std::shared_ptr<chacha20> m_engine;
    std::shared_ptr<CryptoPP::Poly1305<CryptoPP::AES>> m_auth;
};

}

#endif /* AEAD_CHACHA_POLY1305_H */

