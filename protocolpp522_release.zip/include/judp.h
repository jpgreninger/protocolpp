#ifndef JPROTOCOL_JUDP_H_
#define JPROTOCOL_JUDP_H_

///
///\class judp judp.h "include/judp.h"
///
///\section UDP_Class User Datagram Protocol (UDP)
///
/// See https://en.wikipedia.org/wiki/User_Datagram_Protocol
///
/// This User Datagram Protocol (UDP) is defined to make available a datagram
/// mode of packet-switched computer communication in the environment of an
/// interconnected set of computer networks. This protocol assumes that the
/// Internet Protocol (IP) [1] is used as the underlying protocol. This protocol
/// provides a procedure for application programs to send messages to other
/// programs with a minimum of protocol mechanism. The protocol is transaction
/// oriented, and delivery and duplicate protection are not guaranteed.
/// Applications requiring ordered reliable delivery of streams of data should
/// use the Transmission Control Protocol (TCP) [2]
///
/// <B>User Datagram Header Format [1]</B>
///
///\image html UDP_headers.png "User Datagram Protocol (UDP) Header Format"
///\image latex UDP_headers.eps "User Datagram Protocol (UDP) Header Format" width=15cm
///
/// <B>Source Port</B>
///
/// An optional field, when meaningful, it indicates the port of the sending  process
/// and may be assumed to be the port to which a reply should be addressed in the
/// absence of any other information.  If not used, a value of zero is inserted.
///
///
/// <B>Destination Port</B> 
///
/// Has a meaning within the context of a particular internet destination address
///
///
/// <B>Length</B>
///
/// The length in octets of this user datagram including this header and the data
/// (This means the minimum value of the length is eight)
///
///
/// <B>Checksum</B>
///
/// The 16-bit one’s complement of the one’s complement sum of a pseudo header of
/// information from the IP header, the UDP header, and the data, padded with
/// zero octets at the end (if necessary) to make a multiple of two octets
///
/// The pseudo header conceptually prefixed to the UDP header contains the source
/// address, the destination address, the protocol, and the UDP length. This
/// information gives protection against misrouted datagrams. This checksum
/// procedure is the same as is used in TCP.
///
///\code
///      0      7 8     15 16    23 24    31
///     +--------+--------+--------+--------+
///     |          source address           |
///     +--------+--------+--------+--------+
///     |        destination address        |
///     +--------+--------+--------+--------+
///     |  zero  |protocol|   UDP length    |
///     +--------+--------+--------+--------+
///\endcode
///
/// If the computed checksum is zero, it is transmitted as all ones (the equivalent
/// in one’s complement  arithmetic). An all zero transmitted checksum value means
/// that the transmitter generated no checksum (for debugging or for higher level
/// protocols that don’t care)
///
/// <B>Checksum computation</B>
///
/// The method used to compute the checksum is defined in RFC 768:
///
/// Checksum is the 16-bit one's complement of the one's complement sum of a pseudo header
/// of information from the IP header, the UDP header, and the data, padded with zero octets
/// at the end (if necessary) to make a multiple of two octets
///
/// In other words, all 16-bit words are summed using one's complement arithmetic. Add the
/// 16-bit values up. Each time a carry-out (17th bit) is produced, swing that bit around and
/// add it back into the least significant bit.[8] The sum is then one's complemented to yield
/// the value of the UDP checksum field.
///
/// If the checksum calculation results in the value zero (all 16 bits 0) it should be sent as
/// the one's complement (all 1s).
///
/// The difference between IPv4 and IPv6 is in the data used to compute the checksum.
///
/// <B>IPv4 Pseudo Header</B>
///
/// When UDP runs over IPv4, the checksum is computed using a "pseudo header" that contains some
/// of the same information from the real IPv4 header. The pseudo header is not the real IPv4 header
/// used to send an IP packet, it is used only for the checksum calculation.
///
/// <B>IPv4 Pseudo Header Format [2]</B>
///
///\image html UDP_IPv4_Psuedo_Header.png "User Datagram Packet IPv4 Psuedo Header for Checksum Calculation"
///\image latex UDP_IPv4_Psuedo_Header.eps "User Datagram Packet IPv4 Psuedo Header for Checksum Calculation" width=15cm
///
///
/// * The source and destination addresses are those in the IPv4 header
///
/// * The protocol is that for UDP (see List of IP protocol numbers): 17 (0x11)
///
/// * The UDP length field is the length of the UDP header and data
///
/// * The field data is the transmitted data
///
/// UDP checksum computation is optional for IPv4. If a checksum is not used it should be set to the
/// value zero.
///
/// <B>IPv6 Pseudo Header</B>
///
/// When UDP runs over IPv6, the checksum is mandatory. The method used to compute it is changed as
/// documented in RFC 2460:
///
/// Any transport or other upper-layer protocol that includes the addresses from the IP header in its
/// checksum computation must be modified for use over IPv6 to include the 128-bit IPv6 addresses
///
/// When computing the checksum, again a pseudo header is used that mimics the real IPv6 header:
///
/// <B>IPv6 Pseudo Header Format [3]</B>
///
///\image html UDP_IPv6_Psuedo_Header.png "User Datagram Packet IPv6 Psuedo Header for Checksum Calculation" 
///\image latex UDP_IPv6_Psuedo_Header.eps "User Datagram Packet IPv6 Psuedo Header for Checksum Calculation" width=15cm
///
///
/// * The source address is the one in the IPv6 header
/// 
/// * The destination address is the final destination; if the IPv6 packet does not contain a
///   Routing header, that will be the destination address in the IPv6 header; otherwise, at the
///   originating node, it will be the address in the last element of the Routing header, and, at
///   the receiving node, it will be the destination address in the IPv6 header
///
/// * The value of the Next Header field is the protocol value for UDP: 17
/// 
/// * The UDP length field is the length of the UDP header and data
///
/// [1] http://microchip.wikidot.com/tcpip:tcp-vs-udp
///
/// [2] https://en.wikipedia.org/wiki/User_Datagram_Protocol
///
/// [3] https://en.wikipedia.org/wiki/User_Datagram_Protocol
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::judpsa
/// @see ProtocolPP::judp
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see judpsa
/// @see judp
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "judpsa.h"
#include "jprotocol.h"

namespace ProtocolPP {

class judp : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal UDP
    ///
    /// @param security - Parameters necessary to setup UDP flow
    //////////////////////////////////////////////////////////////////////
    explicit judp(std::shared_ptr<judpsa>& security);

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal UDP with file input
    ///
    /// @param security - Parameters necessary to setup UDP flow
    /// @param file - path to file to use for payload data
    //////////////////////////////////////////////////////////////////////
    judp(std::shared_ptr<judpsa>& security,
         std::string& file);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~judp() {}

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor that accepts
    /// a file. Encap will produce a packet each time it's called from
    /// the data found in the file until all data is exhausted
    ///
    /// @param output - packet generated from payload data extracted
    ///                 from the file
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without a file
    /// handle. Encap will produce a packet from the payload passed in
    ///
    /// @param input - payload to encapsulate with UDP
    /// @param output - encapsulated UDP packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input,
                      std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor that accepts a file
    /// Decap will extract the data and write it to the file specificed
    /// in the constuctor
    ///
    /// @param input - UDP packet to decapsulate and write to file
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without a file
    /// handle. Decap will produce a payload from the packet passed in
    ///
    /// @param input - UDP packet to decapsulate
    /// @param output - decapsulated payload
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input,
                      std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the source address in the UDP header
    ///
    /// @param field - field to update in UDP
    /// @param value - new value
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the complete UDP header
    ///
    /// @param hdr - new UDP header
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the field from the security association
    ///
    /// @return source address from the UDP header
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the field from the UDP header
    ///
    /// @return source address from the UDP header
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the complete UDP header
    ///
    /// @return the UDP header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr();

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<judpsa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Print the protocol object to XML
    ///
    /// @param myxml - XMLPrinter object
    /// @param direction - facilitator for random generation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    judp() = delete;
    judp(judp& judp) = delete;
    judp(const judp& judp) = delete;

    void init();

    // array for UDP header
    std::shared_ptr<judpsa> m_sec;
    jarray<uint8_t> m_udphdr;
};

}

#endif // JPROTOCOL_JUDP_H_
