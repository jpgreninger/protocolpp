#ifndef JLTESA_H_
#define JLTESA_H_

///
///\class jltesa jltesa.h "include/jltesa.h"
///
///\section LTEASASA Long Term Evolution (LTE) Security Association
///
///\image html LTE_Protocol_Stack.png "LTE Protocol Stack at the Data-Link Layer [1]"
///\image latex LTE_Protocol_Stack.eps "LTE Protocol Stack at the Data-Link Layer [1]" width=15cm
///
/// See PDCP_LTE_v14_1_0 specification on www.3gpp.org
///
/// If not otherwise mentioned in the definition of each field then the bits in the parameters
/// shall be interpreted as follows: the left most bit string is the first and most significant
/// and the right most bit is the last and least significant bit
///
/// Unless otherwise mentioned, integers are encoded in standard binary encoding for unsigned
/// integers. In all cases the bits appear ordered from MSB to LSB when read in the PDU
///
///\subsection PDCPSNSASA PDCP SN
///
/// Length: 5, 7, 12, 15, 16, or 18 bits as indicated in the following table except for NB-IoT
/// which uses 7 bit PDCP SN for DRB.
///
/// <table>
/// <caption id="pdcpsnsa">\f$ PDCP SN Length\f$</caption>
/// <tr><th>Length<th>Description
/// <tr><td>5 <td>SRBs
/// <tr><td>7 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// <tr><td>12 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// <tr><td>15 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// <tr><td>16 <td>SLRBs
/// <tr><td>18 <td>DRBs, if configured by upper layers (pdcp-SN-Size)
/// </table>
///
///\subsection LTESADataSA Data
///
/// Length: Variable
///
/// The Data field may include either one of the following:
///
/// * Uncompressed PDCP SDU (user plane data, or control plane data); or
///
/// * Compressed PDCP SDU (user plane data only)
///
///\subsection LTESAMACSA MAC-I
///
/// Length: 32 bits
///
/// The MAC-I field carries a message authentication code calculated as specified in subclause 5.7
/// For control plane data that are not integrity protected, the MAC-I field is still present and
/// should be padded with padding bits set to 0
///
///\subsection LTESACNTSA COUNT
///
/// Length: 32 bits
///
/// For ciphering and integrity a COUNT value is maintained. The COUNT value is composed of a HFN
/// and the PDCP SN. The length of the PDCP SN is configured by upper layers
///
/// <table>
/// <caption id="ltesacount">Format of COUNT</caption>
/// <tr><td>HFN<td>PDCP SN
/// </table>
///
/// The size of the HFN part in bits is equal to 32 minus the length of the PDCP SN.
///
/// NOTE: When performing comparison of values related to COUNT, the UE takes into account that
/// COUNT is a 32-bit value, which may wrap around (e.g., COUNT value of 232 - 1 is less than
/// COUNT value of 0).
///
///\subsection LTESARSVDSA R
///
/// Length: 1 bit
///
/// Reserved. In this version of the specification reserved bits shall be set to 0. Reserved bits
/// shall be ignored by the receiver
///
///\subsection DATSACTRLSA D/C
///
/// Length: 1 bit
///
/// <table>
/// <caption id="dcfieldsa">\f$ D/C field\f$</caption>
/// <tr><th>Bit<th>Description
/// <tr><td>0<td>Control PDU
/// <tr><td>1<td>Data PDU
/// </table>
///
///\subsection PDUTYPESASA PDU type
///
/// Length: 3 bits
///
/// <table>
/// <caption id="pdutypesa">\f$ PDU type\f$</caption>
/// <tr><th>Bit<th>Description
/// <tr><td>000<td>PDCP status report
/// <tr><td>001<td>Interspersed ROHC feedback packet
/// <tr><td>010<td>LWA status report
/// <tr><td>011-111<td>Reserved
/// </table>
///
///\subsection LTEFMSSASA FMS
///
/// Length: 12 bits when a 12 bit SN length is used, 15 bits when a 15 bit SN length is used,
/// and 18 bits when an 18 bit SN length is used
///
/// PDCP SN of the first missing PDCP SDU
///
///\subsection LTESABITMAPSA Bitmap
///
/// Length: Variable
///
/// The length of the bitmap field can be 0
///
/// The MSB of the first octet of the type "Bitmap" indicates whether or not the PDCP SDU with the
/// SN (FMS + 1) modulo (Maximum_PDCP_SN + 1) has been received and, optionally decompressed correctly.
/// The LSB of the first octet of the type "Bitmap" indicates whether or not the PDCP SDU with the SN
/// (FMS + 8) modulo (Maximum_PDCP_SN + 1) has been received and, optionally decompressed correctly
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jlte
/// @see ProtocolPP::jltesa
/// @see ProtocolPP::jsnow3g
/// @see ProtocolPP::jzuc
/// @see ProtocolPP::jmodes
///
/// <B>For Additonal Documentation:</B>
/// @see jsecass
/// @see jprotocol
/// @see jlte
/// @see jltesa
/// @see jsnow3g
/// @see jzuc
/// @see jmodes
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class jltesa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard Constructor with defaults
    ///
    /// <table>
    /// <caption id="LTE/RLC Defaults">LTE/RLC Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::DOWNLINK
    /// <tr><td>type<td>protocol_t::LTE
    /// <tr><td>cipher<td>cipher_t::SNOWE
    /// <tr><td>auth<td>auth_t::SNOWA
    /// <tr><td>snlen<td>7
    /// <tr><td>datctrl<td>true
    /// <tr><td>poll<td>false
    /// <tr><td>ext<td>true
    /// <tr><td>rsn<td>false
    /// <tr><td>pdutype<td>0
    /// <tr><td>hdrext<td>0
    /// <tr><td>pgkindex<td>0
    /// <tr><td>sdutype<td>0
    /// <tr><td>bearer<td>0
    /// <tr><td>lenind<td>0
    /// <tr><td>ptkident<td>0
    /// <tr><td>kdid<td>0
    /// <tr><td>seqnum<td>0
    /// <tr><td>hfni<td>0x000FFFFF
    /// <tr><td>fms<td>0
    /// <tr><td>nmp<td>0
    /// <tr><td>hrw<td>0
    /// <tr><td>fresh<td>0
    /// <tr><td>icvlen<td>4
    /// <tr><td>ckeylen<td>16
    /// <tr><td>akeylen<td>16
    /// <tr><td>bitmaplen<td>0
    /// <tr><td>sufi<td>0
    /// <tr><td>bitmap<td>0
    /// <tr><td>cipherkey<td>0
    /// <tr><td>authkey<td>0
    /// </table>
    ///
    ///\code
    /// jltesa rcv;
    ///
    /// rcv.set_field<cipher_t>(field_t::CIPHER, cipher_t::ZUCE);
    /// rcv.set_field<uint8_t>(field_t::BEARER, 0x1E);
    /// rcv.set_field<uint32_t>(field_t::HFNI, 0x000ABCDE);
    /// rcv.set_field<uint32_t>(field_t::FRESH, 0x12345678);
    /// rcv.set_field<uint32_t>(field_t::ICVLEN, 4);
    /// rcv.set_field<uint32_t>(field_t::CKEYLEN, 16);
    /// rcv.set_field<uint32_t>(field_t::AKEYLEN, 16);
    /// rcv.set_field<jarray<uint8_t>>(field_t::CIPHERKEY, m_rand->getbyte(16));
    /// rcv.set_field<jarray<uint8_t>>(field_t::AIPHERKEY, m_rand->getbyte(16));
    ///\endcode
    //////////////////////////////////////////////////////////////////////
    jltesa();

    //////////////////////////////////////////////////////////////////////
    /// LTE security association
    ///
    /// @param dir - direction either UPLINK or DOWNLINK
    /// @param type - Type of packet (RLC or LTE)
    /// @param cipher - Encryption cipher (SNOWE, ZUCE, AES_CCM, SNOWV, SNOWV_GCM)
    /// @param auth - Authentication method (SNOW3G, ZUCA, AES_CCM, SNOWVA)
    /// @param snlen - Sequence number length in bits (7 or 12 for RLC, 5, 7, 12, 15, 16, or 18 bits for LTE)
    /// @param datctrl - Data or Control flag bit (1-bit)
    /// @param poll - Polling flag. Used to request a status report from the receiver (1-bit)
    /// @param ext - Extension bit (1-bit)
    /// @param rsn - Reset sequence number (RSN)
    /// @param pdutype - Type of Control PDU (STATUS, RESET, RESET_ACK, RSVD, 3-bits)
    /// @param hdrext - Header extension flag (2-bits)
    /// @param pgkindex - Five LSB(s) of PGK identity
    /// @param sdutype - PDCP SDU type i.e., Layer-3 Protocol Data Unit (IP, ARP, PC5SIG, NONIP, RSVD)
    /// @param bearer - BEARER (F8) value for SNOW3G and ZUC, not for SNOWV*
    /// @param lenind - Length indicator
    /// @param ptkident - PTK identity
    /// @param kdid - Kd identity
    /// @param seqnum - Sequence Number (5, 7, 12, 15, 16, or 18 bits)
    /// @param hfni - Hyper Frame Number Indicator (HFNI, 20-bits)
    /// @param fms - PDCP SN of the First Missing PDCP SDU (FMS)
    /// @param nmp - Number of missing PDCP SDU(s) with associated COUNT value
    /// @param hrw - PDCP SN of the PDCP SDU received on WLAN with highest associated PDCP COUNT value
    /// @param fresh - FRESH (F9) value for SNOW3G and ZUC, not for SNOWVA
    /// @param icvlen - ICV length value for SNOW3G and ZUC (must be 4), and SNOWVA or SNOWV_GCM (can be 4, 8, or 16)
    /// @param ckeylen - Length of the encryption key
    /// @param akeylen - Length of the authentication key
    /// @param bitmaplen - Length of the packet bit map
    /// @param sufi - Super Field (variable number of bits)
    /// @param bitmap - Sounds alot like a replay window
    /// @param cipherkey - Encryption key
    /// @param authkey - Authentication key
    //////////////////////////////////////////////////////////////////////
    jltesa(direction_t dir,
           protocol_t type,
           cipher_t cipher,
           auth_t auth,
           int snlen,
           bool datctrl,
           bool poll,
           bool ext,
           bool rsn,
           uint8_t pdutype,
           uint8_t hdrext,
           uint8_t pgkindex,
           uint8_t sdutype,
           uint8_t bearer,
           uint16_t lenind,
           uint16_t ptkident,
           uint16_t kdid,
           uint32_t seqnum,
           uint32_t hfni,
           uint32_t fms,
           uint32_t nmp,
           uint32_t hrw,
           uint32_t fresh,
           uint32_t icvlen,
           unsigned int ckeylen,
           unsigned int akeylen,
           unsigned int bitmaplen,
           jarray<uint8_t> sufi,
           jarray<uint8_t> bitmap,
           std::shared_ptr<jarray<uint8_t>> cipherkey,
           std::shared_ptr<jarray<uint8_t>> authkey);

    //////////////////////////////////////////////////////////////////////
    /// Standard copy constructor
    //////////////////////////////////////////////////////////////////////
    jltesa(jltesa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard copy constructor from shared pointer
    //////////////////////////////////////////////////////////////////////
    explicit jltesa(std::shared_ptr<jltesa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jltesa() {
        if (!m_cipherkey.empty()) {
            m_cipherkey.serase();
        }
        if (!m_authkey.empty()) {
            m_authkey.serase();
        }
    }

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the LTE security association
    ///
    /// <table>
    /// <caption id="LTE/RLC Get Fields">LTE/RLC Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::UPLINK)
    /// <tr><td>protocol_t<td>TYPE<td>set_field<protocol_t>(field_t::TYPE, protocol_t::LTE)
    /// <tr><td>cipher_t<td>CIPHER<td>set_field<cipher_t>(field_t::CIPHER, cipher_t::ZUCE)
    /// <tr><td>auth_t<td>AUTH<td>set_field<auth_t>(field_t::AUTH, auth_t::SNOWA)
    /// <tr><td>int<td>SNLEN<td>set_field<int>(field_t::SNLEN, 7)
    /// <tr><td>bool<td>DATCTRL<td>set_field<bool>(field_t::DATCTRL, true)
    /// <tr><td><td>POLLBIT<td>set_field<bool>(field_t::POLLBIT, false)
    /// <tr><td><td>EXTENSION<td>set_field<bool>(field_t::EXTENSION, false)
    /// <tr><td><td>RN<td>set_field<bool>(field_t::RSN, true)
    /// <tr><td>uint8_t<td>PDUTYPE<td>set_field<uint8_t>(field_t::PDUTYPE, 0x32)
    /// <tr><td><td>HDREXT<td>set_field<uint8_t>(field_t::HDREXT, 0xFC)
    /// <tr><td><td>PGKINDEX<td>set_field<uint8_t>(field_t::PGKINDEX, 0x03)
    /// <tr><td><td>SDUTYPE<td>set_field<uint8_t>(field_t::SDUTYPE, 0x15)
    /// <tr><td><td>BEARER<td>set_field<uint8_t>(field_t::BEARER, 0x54)
    /// <tr><td>uint16_t<td>LENGTHIND<td>set_field<uint16_t>(field_t::LENGTHIND, 0x0101)
    /// <tr><td><td>PTKINDENT<td>set_field<uint16_t>(field_t::PTKINDENT, 0x0142)
    /// <tr><td><td>KDID<td>set_field<uint16_t>(field_t::KDID, 0x3542)
    /// <tr><td>uint32_t<td>SEQNUM<td>set_field<uint32_t>(field_t::SEQNUM, 0x00000001)
    /// <tr><td><td>HFNI<td>set_field<uint32_t>(field_t::HFNI, 0xFFFFFF80)
    /// <tr><td><td>FMS<td>set_field<uint32_t>(field_t::FMS, 0x89432178)
    /// <tr><td><td>NMP<td>set_field<uint32_t>(field_t::NMP, 0x43217874)
    /// <tr><td><td>HRW<td>set_field<uint32_t>(field_t::HRW, 0x78741122)
    /// <tr><td><td>FRESH<td>set_field<uint32_t>(field_t::FRESH, 0x78741122)
    /// <tr><td><td>ICVLEN<td>set_field<uint32_t>(field_t::ICVLEN, 4)
    /// <tr><td><td>CKEYLEN<td>set_field<uint32_t>(field_t::CKEYLEN, 16)
    /// <tr><td><td>AKEYLEN<td>set_field<uint32_t>(field_t::AKEYLEN, 16)
    /// <tr><td><td>BITMAPLEN<td>set_field<uint32_t>(field_t::BITMAPLEN, 128)
    /// <tr><td>jarray<uint8_t><td>SUFI<td>set_field<jarray<uint8_t>>(field_t::SUFI, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td><td>BITMAP<td>set_field<jarray<uint8_t>>(field_t::BITMAP, jarray<uint8_t>("3322CCDD"))
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, std::make_shared<jarray<uint8_t>>("3322CCDD"))
    /// <tr><td><td>AUTHKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY, std::make_shared<jarray<uint8_t>>("3322CCDD"))
    /// </table>
    ///
    /// @param field - field to update the LTE security association
    /// @param fieldval - value to update the LTE security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the LTE security association
    ///
    /// <table>
    /// <caption id="LTE/RLCSA Get Fields">LTE/RLC Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>protocol_t<td>TYPE<td>protocol_t mytype = get_field<protocol_t>(field_t::TYPE)
    /// <tr><td>cipher_t<td>CIPHER<td>cipher_t mycipher = get_field<cipher_t>(field_t::CIPHER)
    /// <tr><td>auth_t<td>AUTH<td>auth_t myauth = get_field<auth_t>(field_t::AUTH)
    /// <tr><td>int<td>SNLEN<td>int mysnlen = get_field<int>(field_t::SNLEN)
    /// <tr><td>booL<td>DATCTRL<td>bool mydatctrl = get_field<bool>(field_t::DATCTRL)
    /// <tr><td><td>POLLBIT<td>bool mypoll = get_field<bool>(field_t::POLLBIT)
    /// <tr><td><td>EXTENSION<td>bool myext = get_field<bool>(field_t::EXTENSION)
    /// <tr><td><td>RN<td>bool myrn = get_field<bool>(field_t::RSN)
    /// <tr><td>uint8_t<td>PDUTYPE<td>uint8_t mypdu = get_field<uint8_t>(field_t::PDUTYPE)
    /// <tr><td><td>HDREXT<td>uint8_t myhdrext = get_field<uint8_t>(field_t::HDREXT)
    /// <tr><td><td>PGKINDEX<td>uint8_t mypgkident = get_field<uint8_t>(field_t::PGKINDEX)
    /// <tr><td><td>SDUTYPE<td>uint8_t mysdutype = get_field<uint8_t>(field_t::SDUTYPE)
    /// <tr><td><td>BEARER<td>uint8_t mybearer = get_field<uint8_t>(field_t::BEARER)
    /// <tr><td>uint16_t<td>LENGTHIND<td>uint16_t mylenind = get_field<uint16_t>(field_t::LENGTHIND)
    /// <tr><td><td>PTKINDENT<td>uint16_t ptkident = get_field<uint16_t>(field_t::PTKINDENT)
    /// <tr><td><td>KDID<td>uint16_t mykdid = get_field<uint16_t>(field_t::KDID)
    /// <tr><td>uint32_t<td>SEQNUM<td>uint32_t myseqnum = get_field<uint32_t>(field_t::SEQNUM)
    /// <tr><td><td>HFNI<td>uint32_t myhfni = get_field<uint32_t>(field_t::HFNI)
    /// <tr><td><td>FMS<td>uint32_t myfms = get_field<uint32_t>(field_t::FMS)
    /// <tr><td><td>NMP<td>uint32_t mynmp = get_field<uint32_t>(field_t::NMP)
    /// <tr><td><td>HRW<td>uint32_t myhrw = get_field<uint32_t>(field_t::HRW)
    /// <tr><td><td>FRESH<td>uint32_t myfresh =  get_field<uint32_t>(field_t::FRESH)
    /// <tr><td><td>ICVLEN<td>uint32_t myicvlen =  get_field<uint32_t>(field_t::ICVLEN)
    /// <tr><td><td>CKEYLEN<td>uint32_t myckeylen = get_field<uint32_t>(field_t::CKEYLEN)
    /// <tr><td><td>AKEYLEN<td>uint32_t myakeylen = get_field<uint32_t>(field_t::AKEYLEN)
    /// <tr><td><td>BITMAPLEN<td>uint32_t mybitmaplen = get_field<uint32_t>(field_t::BITMAPLEN)
    /// <tr><td>jarray<uint8_t><td>SUFI<td>jarray<uint8_t> mysufi = get_field<jarray<uint8_t>>(field_t::SUFI)
    /// <tr><td><td>BITMAP<td>jarray<uint8_t> mybitmap = get_field<jarray<uint8_t>>(field_t::BITMAP)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>std::shared_ptr<jarray<uint8_t>> mycipherkey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY)
    /// <tr><td><td>AUTHKEY<td>std::shared_ptr<jarray<uint8_t>> myauthkey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY)
    /// </table>
    ///
    /// @param field - field to retrieve from the LTE security association
    /// @return version field of the LTE security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jltesa(const jltesa& rhs) = delete;
    
    // member variables
    direction_t m_dir;
    protocol_t m_type;
    cipher_t m_cipher;
    auth_t m_auth;
    int m_snlen;
    bool m_datctrl;
    bool m_poll;
    bool m_ext;
    bool m_rsn;
    uint8_t m_pdutype;
    uint8_t m_hdrext;
    uint8_t m_pgkindex;
    uint8_t m_sdutype;
    uint8_t m_bearer;
    uint16_t m_lenind;
    uint16_t m_ptkident;
    uint16_t m_kdid;
    uint32_t m_seqnum;
    uint32_t m_hfni;
    uint32_t m_fms;
    uint32_t m_nmp;
    uint32_t m_hrw;
    uint32_t m_fresh;
    uint32_t m_icvlen;
    unsigned int m_ckeylen;
    unsigned int m_akeylen;
    unsigned int m_bitmaplen;
    jarray<uint8_t> m_sufi;
    jarray<uint8_t> m_bitmap;
    jarray<uint8_t> m_cipherkey;
    jarray<uint8_t> m_authkey;
};

}

#endif /* JLTESA_H_ */
