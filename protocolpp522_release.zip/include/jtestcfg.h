#ifndef JTESTCFG_H_
#define JTESTCFG_H_

///
///\class jtestcfg jtestcfg.h "include/jtestcfg.h"
///
///\section JTSTCFG XML Parser for Testbench Configuration
///
/// Parser class for Protocol++&reg; testbench configuration files. Supports the following
/// schema also found in testpp.xsd 
///\code
///
/// <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
///     <xs:element name="testpp">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="general"   type="xs:string"/>
///                 <xs:element name="flowring"  type="xs:string"/>
///                 <xs:element name="inring"    type="xs:string"/>
///                 <xs:element name="outring"   type="xs:string"/>
///                 <xs:element name="responder" type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="ver"    type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="general">
///         <xs:complexType>
///             <xs:attribute name="seed"     type="xs:unsignedLong"/>
///             <xs:attribute name="loglvl">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:integer">
///                         <xs:pattern value="0|1|2|3|4"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="stdout">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="platform" type="xs:string"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="WASP"/>
///                         <xs:enumeration value="SEC"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="endian">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BIG"/>
///                         <xs:enumeration value="LITTLE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ptrsize">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:pattern value="4|8"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="sgtsize">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:pattern value="8|16"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="debugclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="infoclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="warnclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="fatalclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="passclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="flowring">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="inring"    type="xs:string"/>
///                 <xs:element name="outring"   type="xs:string"/>
///                 <xs:element name="responder" type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="name"    type="xs:string"/>
///             <xs:attribute name="index"   type="xs:integer"/>
///             <xs:attribute name="addr"    type="xs:unsignedLong"/>
///             <xs:attribute name="size"    type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="inring">
///         <xs:complexType>
///             <xs:attribute name="name"     type="xs:string"/>
///             <xs:attribute name="index"    type="xs:integer"/>
///             <xs:attribute name="addr"     type="xs:unsignedLong"/>
///             <xs:attribute name="size"     type="xs:unsignedInt"/>
///             <xs:attribute name="input"    type="xs:string"/>
///             <xs:attribute name="flow"     type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="outring">
///         <xs:complexType>
///             <xs:attribute name="name"     type="xs:string"/>
///             <xs:attribute name="index"    type="xs:integer"/>
///             <xs:attribute name="addr"     type="xs:unsignedLong"/>
///             <xs:attribute name="size"     type="xs:string"/>
///             <xs:attribute name="flow"     type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="responder">
///         <xs:complexType>
///             <xs:attribute name="name"           type="xs:string"/>
///             <xs:attribute name="units"          type="xs:string"/>
///             <xs:attribute name="index"          type="xs:integer"/>
///             <xs:attribute name="threads"        type="xs:integer"/>
///             <xs:attribute name="flow"           type="xs:string"/>
///             <xs:attribute name="input"          type="xs:string"/>
///             <xs:attribute name="output"         type="xs:string"/>
///             <xs:attribute name="readlatency"    type="xs:string"/>
///             <xs:attribute name="computelatency" type="xs:string"/>
///             <xs:attribute name="writelatency"   type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
/// </xs:schema>
///\endcode
///
/// <B>For API Documentation:</B>
/// @see tinyxml2::XMLPrinter
/// @see tinyxml2::XMLVisitor
/// @see ProtocolPP::jtestcfg
///
/// <B>For Additional Documentation:</B>
/// @see tinyxml2::XMLPrinter
/// @see tinyxml2::XMLVisitor
/// @see jtestcfg
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <ctime>
#include <sys/types.h>
#if defined(_MSC_VER)
#include <io.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#endif
#include <exception>
#include <unordered_map>
#include "jrand.h"
#include "jlogger.h"
#include "tinyxml2.h"

namespace ProtocolPP {

class jtestcfg : public tinyxml2::XMLPrinter, public std::exception {

public :

    //////////////////////////////////////////////////////////////////////
    /// tstresp - Responder configuration structure
    ///
    /// @param threads - number of threads in this responder
    /// @param units - unit of time for latencies (s, ms, us, ns, ps, fs)
    /// @param rname - name of the responder
    /// @param writelatency - latency for writes to memory
    /// @param readlatency - latency for reads to memory
    /// @param computelatency - latency for computation of protocol, encryption, or authentication
    //////////////////////////////////////////////////////////////////////
    struct tstresp {
        int threads;
        std::string rname;
        std::string units;
        std::string writelatency;
        std::string readlatency;
        std::string computelatency;

        tstresp() : threads(1),
                    units("us"),
                    rname("NORESPONDER"),
                    writelatency("50..200"),
                    readlatency("200..500"),
                    computelatency("1000..2500") {}
    };

    //////////////////////////////////////////////////////////////////////
    /// tstcfg - Ring and configuration structure
    ///
    /// @param name - name of the configuration
    /// @param fname - name of the flow
    /// @param iname - name of the input ring
    /// @param oname - name of the output ring
    /// @param index - index of the ring
    /// @param fsize - size of the flow ring in entries
    /// @param isize - size of the input ring in entries
    /// @param osize - size of the output ring in entries
    /// @param faddr - address of the flow ring
    /// @param iaddr - address of the input ring
    /// @param oaddr - address of the output ring
    /// @param input - name of the input file (with path)
    /// @param resp  - vector of responders
    //////////////////////////////////////////////////////////////////////
    struct tstcfg {
        std::string name;
        std::string fname;
        std::string iname;
        std::string oname;
        int index;
        int fsize;
        int isize;
        int osize;
        uint64_t faddr;
        uint64_t iaddr;
        uint64_t oaddr;
        std::string input;
        std::vector<tstresp> resp;

        tstcfg() : name("NOCONFIG"),
                   fname("NOFLOW"),
                   iname("NOIRING"),
                   oname("NOORING"),
                   index(0),
                   fsize(50),
                   isize(50),
                   osize(50),
                   faddr(0),
                   iaddr(0),
                   oaddr(0),
                   input("NOINPUT"),
                   resp() {}
    };

    //////////////////////////////////////////////////////////////////////
    /// jtestcfg - Parse testbench configuration files
    ///
    /// @param input - XML data represented in a character string
    /// @param out - output file to write to (if desired)
    //////////////////////////////////////////////////////////////////////
    jtestcfg(const char* input,
             const char* out);

    //////////////////////////////////////////////////////////////////////
    /// jtestcfg - Parse testbench configuration files
    ///
    /// @param input - Filename of an XML data file to load
    /// @param out - output file to write to (if desired)
    //////////////////////////////////////////////////////////////////////
    jtestcfg(std::string& input,
             const char* out);

    //////////////////////////////////////////////////////////////////////
    /// jtestcfg - Parse testbench configuration files
    ///
    /// @param input - XMLDocument to load
    /// @param out - output file to write to (if desired)
    //////////////////////////////////////////////////////////////////////
    jtestcfg(std::shared_ptr<tinyxml2::XMLDocument>& input,
             const char* out);

    //////////////////////////////////////////////////////////////////////
    /// jtestcfg standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jtestcfg() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the IP security association
    ///
    /// <table>
    /// <caption id="TestCfg Set Fields">TestCfg Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>bool<td>STDOUT<td>set_field<bool>(field_t::STDOUT, true)
    /// <tr><td>endian_t<td>ENDIAN<td>set_field<endian_t>(field_t::ENDIAN, endian_t::BIG)
    /// <tr><td>platform_t<td>PLATFORM<td>set_field<platform_t>(field_t::NH, platform_t::WASP)
    /// <tr><td>uint64_t<td>SEED<td>set_field<uint64_t>(field_t::SEED, 0x0123456789ABCDEF)
    /// <tr><td>uint32_t<td>PTRSIZE<td>set_field<uint32_t>(field_t::PTRSIZE, 8)
    /// </table>
    ///
    /// @param field - field to update
    /// @param value - value to update
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T value);

    //////////////////////////////////////////////////////////////////////
    /// Returns the field of the test configuration
    ///
    /// <table>
    /// <caption id="TestCfg Get Fields">TestCfg Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>bool<td>STDOUT<td>bool stout = get_field<bool>(field_t::STDOUT)
    /// <tr><td>endian_t<td>ENDIAN<td>endian_t end = get_field<endian_t>(field_t::ENDIAN)
    /// <tr><td>platform_t<td>PLATFORM<td>platform_t plat = get_field<platform_t>(field_t::PLATFORM)
    /// <tr><td>uint64_t<td>SEED<td>uint64_t seed = get_field<uint64_t>(field_t::SEED)
    /// <tr><td>uint32_t<td>PTRSIZE<td>uint32_t ptrsize = get_field<uint32_t>(field_t::PTRSIZE)
    /// </table>
    ///
    /// @param field - field to retrieve
    /// @return value of field of the test configuration
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Returns the configuration for rings, responders, and threads
    //////////////////////////////////////////////////////////////////////
    void get(std::shared_ptr<std::map<int,tstcfg>>& cfg);

    //////////////////////////////////////////////////////////////////////
    /// Updates the configuration for rings, responders, and threads
    //////////////////////////////////////////////////////////////////////
    void set(std::shared_ptr<std::map<int,tstcfg>>& cfg);

    //////////////////////////////////////////////////////////////////////
    /// Generate XML output
    //////////////////////////////////////////////////////////////////////
    void to_xml();

private :

    // don't use these
    jtestcfg() = delete;
    jtestcfg(jtestcfg& rhs) = delete;
    jtestcfg(const jtestcfg& rhs) = delete;

    /// Visit an element
    bool VisitEnter(const tinyxml2::XMLElement& element, const tinyxml2::XMLAttribute* attribute);
   
    /// Exit the element
    bool VisitExit(const tinyxml2::XMLElement& element);

    // member variables
    tinyxml2::XMLError m_err;
    std::shared_ptr<tinyxml2::XMLDocument> m_doc;

    uint64_t m_seed;
    platform_t m_platform;
    endian_t m_endian;
    uint32_t m_ptrsize;
    uint32_t m_sgtsize;
    uint32_t m_loglvl;
    uint32_t m_flowidx;
    bool     m_logstd;
    bool     m_status;
    InterfacePP::jlogger::asciicolor m_debugclr;
    InterfacePP::jlogger::asciicolor m_infoclr;
    InterfacePP::jlogger::asciicolor m_warnclr;
    InterfacePP::jlogger::asciicolor m_errclr;
    InterfacePP::jlogger::asciicolor m_fatalclr;
    InterfacePP::jlogger::asciicolor m_passclr;
    std::map<int,tstcfg> m_testidx;
};

}

#endif /* JTESTCFG_H_ */
