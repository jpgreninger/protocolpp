#ifndef JSECASS_H_
#define JSECASS_H_

///
///\class jsecass jsecass.h "include/jsecass.h"
///
///\section JSECASSC Security Association Base Class for Protocol++&reg; (ProtocolPP&reg;)
///
/// This class is the base for all security associations in Protocol++&reg;. Access to the different elements
/// in the security associations is by calling the templated function with the type needed. For example,
/// to access a uint8_t type from jipsecsa one would call the function as
///
/// * uint8_t myuint8 = mysecass->get_field<uint8_t>(field_t::TTLHOP);
///
/// To set the same field one would call the function as
///
/// * mysecass->set_field<uint8_t>(field_t::TTLHOP, myuint8);
///
/// Each of the security associations directly return the types needed. To access an ENUM of type
/// direction_t a user would call the jwifisa function as
///
/// * direction_t mydirection = mysecass->get_field<direction_t>(field_t::DIRECTION);
///
/// To set the same field it would be
///
/// * mysecass->set_field<direction_t>(field_t::DIRECTION, mydirection);
///
/// To retrieve the jarray that holds the ARWIN for jtlsa, the call would be
///
/// * jarray<uint8_t> myarwin = mysecass->get_field<jarray<uint8_t>>(field_t::ARWIN);
///
/// To set the ARWIN with a new array it would be
///
/// * mysecass->set_field<jarray<uint8_t>>(field_t::ARWIN, myarwin);
///
/// See \ref jenum field_t for the field names for all security associations and protocols
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::tinyxml2
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jreplay
/// @see ProtocolPP::ciphers
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jconfidentsa
/// @see ProtocolPP::jdsasa
/// @see ProtocolPP::jecdsaf2msa
/// @see ProtocolPP::jecdsafpsa
/// @see ProtocolPP::jicmpsa
/// @see ProtocolPP::jintegritysa
/// @see ProtocolPP::jipsa
/// @see ProtocolPP::jipsecsa
/// @see ProtocolPP::jltesa
/// @see ProtocolPP::jmacsecsa
/// @see ProtocolPP::jmemblobsa
/// @see ProtocolPP::jrsasa
/// @see ProtocolPP::jsrtpsa
/// @see ProtocolPP::jtcpsa
/// @see ProtocolPP::jtlsa
/// @see ProtocolPP::judpsa
/// @see ProtocolPP::jwifisa
/// @see ProtocolPP::jwimaxsa
///
/// <B>For Additional Documentation:</B>
/// @see tinyxml2
/// @see jarray
/// @see jrand
/// @see jreplay
/// @see ciphers
/// @see jprotocol
/// @see jsecass
/// @see jconfidentsa
/// @see jdsasa
/// @see jecdsaf2msa
/// @see jecdsafpsa
/// @see jicmpsa
/// @see jintegritysa
/// @see jipsa
/// @see jipsecsa
/// @see jltesa
/// @see jmacsecsa
/// @see jmemblobsa
/// @see jrsasa
/// @see jsrtpsa
/// @see jtcpsa
/// @see jtlsa
/// @see judpsa
/// @see jwifisa
/// @see jwimaxsa
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jprotocol.h"

namespace ProtocolPP {

class jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Constructor for base class of security associations which is
    /// pure virtual
    //////////////////////////////////////////////////////////////////////
    jsecass();

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jsecass() {}

    //////////////////////////////////////////////////////////////////////
    /// print the protocol and security objects as XML
    /// @param myxml - object to print to
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    virtual void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction) = 0;

private:

    // don't use these
    jsecass(jsecass& jsecass) = delete;
    jsecass(const jsecass& jsecass) = delete;

    bool init();
    bool activate();
    bool activateTrial();
    bool chkLicense();
};

}

#endif // JSECASS_H_
