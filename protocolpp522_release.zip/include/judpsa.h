#ifndef JUDPSA_H_
#define JUDPSA_H_

///
///\class judpsa judpsa.h "include/judpsa.h"
///
///\section UDPSA_ClassSA User Datagram Protocol Security Association (UDPSA)
///
/// See https://en.wikipedia.org/wiki/User_Datagram_Protocol
///
/// This User Datagram Protocol (UDP) is defined to make available a datagram
/// mode of packet-switched computer communication in the environment of an
/// interconnected set of computer networks. This protocol assumes that the
/// Internet Protocol (IP) [1] is used as the underlying protocol. This protocol
/// provides a procedure for application programs to send messages to other
/// programs with a minimum of protocol mechanism. The protocol is transaction
/// oriented, and delivery and duplicate protection are not guaranteed.
/// Applications requiring ordered reliable delivery of streams of data should
/// use the Transmission Control Protocol (TCP) [2]
///
/// <B>User Datagram Header Format [1]</B>
///
///\image html UDP_headers.png "User Datagram Protocol (UDP) Header Format"
///\image latex UDP_headers.eps "User Datagram Protocol (UDP) Header Format" width=15cm
///
/// <B>Source Port</B>
///
/// An optional field, when meaningful, it indicates the port of the sending  process
/// and may be assumed to be the port to which a reply should be addressed in the
/// absence of any other information.  If not used, a value of zero is inserted.
///
///
/// <B>Destination Port</B> 
///
/// Has a meaning within the context of a particular internet destination address
///
///
/// <B>Length</B>
///
/// The length in octets of this user datagram including this header and the data
/// (This means the minimum value of the length is eight)
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::judpsa
/// @see ProtocolPP::judp
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jsecasss
/// @see judpsa
/// @see judp
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class judpsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor using default values
    ///
    /// <table>
    /// <caption id="UDP Defaults">UDP Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::ENCAP
    /// <tr><td>src<td>0xFEED
    /// <tr><td>dst<td>0xBEEF
    /// <tr><td>mtu<td>0
    /// </table>
    //////////////////////////////////////////////////////////////////////
    judpsa();

    //////////////////////////////////////////////////////////////////////
    /// Parameters necessary to setup a UDP flow
    ///
    /// @param dir - Direction of UDP data flow (ENCAP or DECAP)
    /// @param src - Source port for data
    /// @param dst - Destination port for data
    /// @param mtu - Maximum transmission size
    //////////////////////////////////////////////////////////////////////
    judpsa(direction_t dir,
           uint16_t src,
           uint16_t dst,
           unsigned int mtu);
    
    //////////////////////////////////////////////////////////////////////
    /// Standard copy constructor
    //////////////////////////////////////////////////////////////////////
    judpsa(judpsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Copy constructor from shared pointer
    //////////////////////////////////////////////////////////////////////
    explicit judpsa(std::shared_ptr<judpsa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~judpsa() {}

    //////////////////////////////////////////////////////////////////////
    /// Sets a boolean field in the security association. If the function
    /// is called with a field that is not boolean, this function prints
    /// an error to the screen
    ///
    /// <table>
    /// <caption id="UDP Set Fields">UDP Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP)
    /// <tr><td>uint16_t<td>SOURCE<td>set_field<uint16_t>(field_t::SOURCE, 0xFEED)
    /// <tr><td><td>DESTINATION<td>set_field<uint16_t>(field_t::DESTINATION, 0xBEEF)
    /// <tr><td>uint32_t<td>MTU<td>set_field<uint32_t>(field_t::MTU, 1500)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in judp
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    ///
    /// @param field - field to set
    /// @param fieldval - boolean value for the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves a boolean value from the field requested. If the
    /// function is called with a field that is not a boolean, this
    /// function prints an error to the screen
    ///
    /// <table>
    /// <caption id="UDP Get Fields">UDP Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>uint16_t<td>SOURCE<td>uint16_t mysrc = get_field<uint16_t>(field_t::SOURCE)
    /// <tr><td><td>DESTINATION<td>uint16_t mydst = get_field<uint16_t>(field_t::DESTINATION)
    /// <tr><td>uint32_t<td>MTU<td>uint32_t mymtu = get_field<uint32_t>(field_t::MTU)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in judp
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    ///
    /// @param field - field to set
    /// @return - boolean value from the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// print the protocol and security objects as XML
    /// @param myxml - object to print to
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    judpsa(const judpsa& judpsa) = delete;

    // member variables
    direction_t m_dir;
    uint16_t m_src;
    uint16_t m_dst;
    unsigned int m_mtu;
};

}

#endif // JUDPSA_H_
