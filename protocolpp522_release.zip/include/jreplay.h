#ifndef JPROTOCOL_JREPLAY_H
#define JPROTOCOL_JREPLAY_H

///
///\class jreplay jreplay.h "include/jreplay.h"
///
///\section AR Anti-Replay Class for Protocol++&reg; (ProtocolPP&reg;)
///
/// This class uses the sliding window anti-replay method found in the
/// IPsec specification to track any number of packets. To allow large
/// numbers of packets, the class uses a BYTE array instead of an
/// unsigned integer to track received packets. The replay window can
/// either be initialized to an empty window or with a windows that's
/// provided. The double template is for use with current protocols
/// that may have an extended packet number. This assumes that the
/// extended packet number is the same size as the seqnum.
///
///
/// <B>Example initialzed empty window to track 16 packets</B>
///
///\code
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   0 
/// ---------------------------------------------------------------------
/// | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
/// ---------------------------------------------------------------------
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   C
///   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   u
///   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   r
///   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r
///   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e
///   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   n
///   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   t
///   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o
///   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u
///   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s
///
///\endcode
///
///
/// <B>Example of LATE packet</B>
///
///\code
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   0 
/// ---------------------------------------------------------------------
/// | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
/// ---------------------------------------------------------------------
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   C
///   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   u
///   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   r
///   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r
///   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e
///   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   n
///   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   t
///   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o
///   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u
///   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s
///
///\endcode
///
/// For the LATE example, say we receive a packet that has a packet
/// number placing it 18 packets behind the current packet. As shown in
/// the example, the packet would not be recorded in the window and
/// would be dropped. Packet numbers would not be updated and a LATE
/// error would be returned
///
///
/// <B>Example of packet in the window</B>
///
///\code
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   0 
/// ---------------------------------------------------------------------
/// | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
/// ---------------------------------------------------------------------
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   C
///   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   u
///   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   r
///   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r
///   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e
///   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   n
///   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   t
///   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o
///   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u
///   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s
///
///\endcode
///
/// For the packet in window example, say we receive a packet that has
/// a packet number placing it 9 packets behind the current packet. As
/// shown in the example, the packet would be recorded in the window in
/// the spot nine packets behind the current packet. Packet numbers
/// would not be updated and no error would be returned
///
///
/// <B>Example of REPLAY packet</B>
///
///\code
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   0 
/// ---------------------------------------------------------------------
/// | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
/// ---------------------------------------------------------------------
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   C
///   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   u
///   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   r
///   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r
///   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e
///   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   n
///   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   t
///   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o
///   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u
///   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s
///
///\endcode
///
/// For the REPLAY example, say we receive a packet that has a packet
/// number placing it 9 packets behind the current packet. As shown in
/// the example, the packet would coincide with the previously received
/// packet nine packets behind the current packet. The packet would be
/// discarded and a REPLAY error would be returned. Packet numbers would
/// not be updated
///
/// <B>Example of EARLY packet</B>
///
///\code
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   0 
/// ---------------------------------------------------------------------
/// | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
/// ---------------------------------------------------------------------
///   16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   C
///   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   u
///   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   r
///   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r
///   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e
///   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   n
///   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   t
///   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o
///   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u
///   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s
///
///\endcode
///
/// For the EARLY example, say we receive a packet that has a packet
/// number placing it 2 packets ahead of the current packet. As shown in
/// the example, window would be shifted left by two packets and a one
/// would be placed in the current packet position. Packet numbers will
/// be updated to reflect the newer packet number received. No error
/// is reported
///
/// <B> Over and underflow support</B>
/// Finally, the anti-replay window also supports OVERFLOW and UNDERFLOW
/// of the sequence numbers. When detected, these errors are returned by
/// the anti_replay() function status uint32_t
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jreplay
/// @see ProtocolPP::jarray
///
/// <B>For Additional Documentation:</B>
/// @see jreplay
/// @see jarray
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#define DEBUG_PROTPP
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <string>
#include "jarray.h"
#include "jrand.h"
#include "jenum.h"

namespace ProtocolPP {

template <typename T, typename TE> class jreplay {

public:

    //////////////////////////////////////////////////////////////////////
    /// Constructor for replay
    ///
    /// @param rand   - randomizer
    /// @param prot   - protocol for anti-replay
    /// @param seqnum - sequence number to verify
    /// @param extseq - extended sequence number to verify
    /// @param usext  - flag to indicate use of extended sequence number
    /// @param winsize - number of packets to track in the window
    //////////////////////////////////////////////////////////////////////
    jreplay(std::shared_ptr<jrand>& rand,
            protocol_t prot,
            T& seqnum,
            TE& extseq,
            bool usext,
            unsigned int winsize);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for replay
    ///
    /// @param rand   - randomizer
    /// @param prot   - protocol for anti-replay
    /// @param seqnum - sequence number to verify
    /// @param extseq - extended sequence number to verify
    /// @param usext  - flag to indicate use of extended sequence number
    /// @param winsize - number of packets to track in the window
    /// @param window - initial replay window to start with populated
    ///                 with UNIT8_T values where one bit equals a packet
    ///                 e.g., 0xF0 would mean four packets have been received
    //////////////////////////////////////////////////////////////////////
    jreplay(std::shared_ptr<jrand>& rand,
            protocol_t prot,
            T& seqnum,
            TE& extseq,
            bool usext,
            unsigned int winsize,
            jarray<uint8_t>& window);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jreplay() {}

    //////////////////////////////////////////////////////////////////////
    /// anti-replay function, uses an BYTE array to support any size
    /// window instead of being limited to 32, 64, or 128 packets
    ///
    /// @param currseq - received sequence number to verify
    /// @param currext - received extended sequence number to verify
    ///
    /// @return value indicating type of error
    ///
    /// 0 - no error
    ///
    /// 1 - late error
    ///
    /// 2 - replay error
    ///
    /// 3 - rollover error (overflow)
    ///
    /// 4 - rollunder error (underflow)
    ///
    /// 5 - programming error
    ///
    //////////////////////////////////////////////////////////////////////
    uint32_t antireplay(T& currseq, TE& currext);

    //////////////////////////////////////////////////////////////////////
    /// Return the size of the anti-replay window
    /// @return size of the window
    //////////////////////////////////////////////////////////////////////
    unsigned int size();

    //////////////////////////////////////////////////////////////////////
    /// Return value to add to seqnum for next value for debug purposes
    /// If the user would like to create a LATE packet, this function may
    /// be called with the current sequence number and the type=LATE and
    /// this function will return the value the should be added to the 
    /// sequence number to create the desired packet
    /// @param type - Type of seqnum/extseqnum to retrieve (NORMAL, WINDOW, REPLAY, LATE, OVERFLOW, UNDERFLOW)
    /// @param currseq - Current seqnum
    /// @param currext - Current extended seqnum
    /// @return amount to add (or subtract) to the current seqnum for the type requested
    //////////////////////////////////////////////////////////////////////
    int next(T& currseq, TE& currext, replay_t type=NORMAL);

    //////////////////////////////////////////////////////////////////////
    /// Return current sequence number
    /// @return size of the window
    //////////////////////////////////////////////////////////////////////
    T get_seqnum();

    //////////////////////////////////////////////////////////////////////
    /// Return the current extended sequence number
    /// @return size of the window
    //////////////////////////////////////////////////////////////////////
    TE get_extseq();

    //////////////////////////////////////////////////////////////////////
    /// Return the current anti-replay window
    /// @return the window
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_window();

    //////////////////////////////////////////////////////////////////////
    /// Return string representation of replay window
    /// 
    /// @param pretty - adds formatting to the replay window to make
    ///                 it more readable as follows
    ///
    ///
    /// @param indent - causes each line of the pretty print window
    ///                 to be indented the number of spaces requested
    ///
    /// @return string representation of replay window array
    ///
    ///\image html newReplay75.png "Screen Capture of Anti-Replay Pretty-Print"
    ///\image latex newReplay75.eps "Screen Capture of Anti-Replay Pretty-Print" width=15cm
    ///
    //////////////////////////////////////////////////////////////////////
    std::string print(bool pretty=false, int indent=10);

private:

    // don't use these
    jreplay() = delete;
    jreplay(jreplay& jreplay) = delete;
    jreplay(const jreplay& jreplay) = delete;

    std::shared_ptr<jrand> m_rand;
    protocol_t m_prot;
    T m_seqnum;
    TE m_extseq;
    bool m_usext;
    unsigned int m_size;
    uint32_t m_mask;
    jarray<uint8_t> m_arwindow;
};

//////////////////////////////////////////////////////////////////////
// Constructor that intializes an empty window
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
jreplay<T,TE>::jreplay(std::shared_ptr<jrand>& rand,
                       protocol_t prot,
                       T& seqnum,
                       TE& extseq,
                       bool usext,
                       unsigned int winsize) : m_rand(rand),
                                               m_prot(prot),
                                               m_seqnum(seqnum),
                                               m_extseq(extseq),
                                               m_usext(usext),
                                               m_size(winsize),
                                               m_arwindow(((winsize/8) + (((winsize%8) != 0) ? 1 : 0)), 0)
{
    if (winsize > 0) {
        // calculate window size, create it and mask
        m_mask = (0xFFFFFF >> (24-(m_size%24)));
        
        // if the initial packet is not set, set it
        m_arwindow[m_arwindow.get_size()-1] = 0x01;
    }
}

//////////////////////////////////////////////////////////////////////
// Constructor that intializes with arwindow
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
jreplay<T,TE>::jreplay(std::shared_ptr<jrand>& rand,
                       protocol_t prot,
                       T& seqnum,
                       TE& extseq,
                       bool usext,
                       unsigned int winsize,
                       jarray<uint8_t>& arwindow) : m_rand(rand),
                                                    m_prot(prot),
                                                    m_seqnum(seqnum),
                                                    m_extseq(extseq),
                                                    m_usext(usext),
                                                    m_size(winsize),
                                                    m_arwindow(arwindow)
{
    if (m_size > 0) {
        // calculate what the window size passed in should be
        unsigned int win = ((winsize/8) + (((winsize%8) != 0) ? 1 : 0));

        if (m_arwindow.get_size() < win) {
            // if the initial window is too small, enlarge it
            jarray<uint8_t> tmp(win-m_arwindow.get_size(), 0);
            tmp.append(m_arwindow);
            m_arwindow = tmp;
        }
        else if (m_arwindow.get_size() > win) {
            // if the initial window is too big, shorten it
            m_arwindow = m_arwindow.extract(m_arwindow.get_size()-win, win);
        }

        // calculate the mask and mask the bits off
        m_mask = (0xFFFFFF >> (24-(m_size%24)));

        // if the initial packet is not set, set it
        m_arwindow[m_arwindow.get_size()-1] = m_arwindow[m_arwindow.get_size()-1] | 0x01;
    }
}

//////////////////////////////////////////////////////////////////////
// Anti-replay function
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
uint32_t jreplay<T,TE>::antireplay(T& currseq, TE& currext) {
    uint64_t seqnum = 0;
    uint64_t iseqnum = 0;

    // check for extended sequence number use
    if (m_usext) {
        if ((sizeof(currseq) == 8) && (sizeof(currext) == 8)) {
            std::string prot(EnumString<protocol_t>::From(m_prot));
            std::cerr << "For protocol " << prot << ", unable to process two UINT64_t packet"
                      << " numbers, if using extended packets numbers both packet numbers must"
                      << " be UINT32_t or smaller values" << std::endl;
            return ERR_PROGRAM;
        }
        else {
            if (m_prot == protocol_t::SRTP) {
                if (((currseq & 0xF000) == 0) && ((m_seqnum & 0xF000) == 0xF000)) {
                    currext += 1;
                }
                else if (((currseq & 0xF000) == 0xF000) && ((m_seqnum & 0xF000) == 0)) {
                    currext -= 1;
                }
                seqnum = ((currext << 16) | currseq);
                iseqnum = ((m_extseq << 16) | m_seqnum);
            }
            else if (m_prot == protocol_t::TLS) {
                if (((currseq & 0x0000FF0000000000) == 0) && ((m_seqnum & 0x0000FF0000000000) == 0x0000FF0000000000)) {
                    currext += 1;
                }
                else if (((currseq & 0x0000FF0000000000) == 0x0000FF0000000000) && ((m_seqnum & 0x0000FF0000000000) == 0)) {
                    currext -= 1;
                }
                seqnum = currext;
                seqnum = ((seqnum << 48) | currseq);
                iseqnum = m_extseq;
                iseqnum = ((iseqnum << 48) | m_seqnum);
            }
            else {
                if (((currseq & 0xFF000000) == 0) && ((m_seqnum & 0xFF000000) == 0xFF000000)) {
                    currext += 1;
                }
                else if (((currseq & 0xFF000000) == 0xFF000000) && ((m_seqnum & 0xFF000000) == 0)) {
                    currext -= 1;
                }
                seqnum = currext;
                seqnum = ((seqnum << 32) | currseq);
                iseqnum = m_extseq;
                iseqnum = ((iseqnum << 32) | m_seqnum);
            }
        }
    }
    else {
       seqnum = currseq;
       iseqnum = m_seqnum;
    }

    // check seqnum number difference
    int diff = static_cast<int>(seqnum - iseqnum);

#ifdef DEBUG_PROTPP
    std::cout << "Current replay window: " << std::endl
              << "diff=" << diff << std::endl
              << "seqnum=" << HEX(seqnum,16) << std::endl
              << "iseqnum=" << HEX(iseqnum,16) << std::endl << std::endl;
#endif

    // check for extended sequence number use
    // decide on packet validity
    if (m_size == 0) {
        // anti-replay not enabled
        return ERR_NONE;
    }
    else if ((m_usext) && ((((iseqnum >> 52) & 0xFFF) == 0xFFF) && (((seqnum >> 52) & 0xFFF) == 0x000))) {
        // ROLLOVER error detected
        return ERR_ROLLOVER;
    }
    else if ((m_usext) && ((((iseqnum >> 52) & 0xFFF) == 0x000) && (((seqnum >> 52) & 0xFFF) == 0xFFF))) {
        // ROLLUNDER error detected
        return ERR_ROLLUNDER;
    }
    else if ((((iseqnum >> 20) & 0xFFF) == 0xFFF) && (((seqnum >> 20) & 0xFFF) == 0x000)) {
        // ROLLOVER error detected
        return ERR_ROLLOVER;
    }
    else if ((((iseqnum >> 20) & 0xFFF) == 0x000) && (((seqnum >> 20) & 0xFFF) == 0xFFF)) {
        // ROLLUNDER error detected
        return ERR_ROLLUNDER;
    }
    else if (seqnum == 0) {
        // ROLLUNDER error detected - seqnum of zero not used for IPsec
        return ERR_ROLLUNDER;
    }
    else if (diff < 0) {
        unsigned int chk = m_arwindow.get_size() - (abs(diff)/8) - 1;
        uint8_t bit = (1 << (((abs(diff)%8) == 0) ? 0 : (abs(diff)%8)));
        if (abs(diff) > (int)m_size) {
            // LATE error detected
            return ERR_LATE;
        }
        else {
            if (m_arwindow[chk] & bit) {
                // REPLAY error detected - already received this packet in the past
                return ERR_REPLAY;
            }
            else {
                // Received packet within window that hasn't been received before
                m_arwindow[chk] |= bit;
                return ERR_NONE;
            }
        }
    }
    else if ((diff == 0) && (m_prot != protocol_t::TLS)) {
        // REPLAY error detected - already received this packet in the past
        return ERR_REPLAY;
    }
    else {
        // Received good packet - shift the window length of diff, set bit
        for (int i=0; i<(diff + ((diff==0) ? 1 : 0)); i++) {
            for (unsigned int j=0; j<m_arwindow.get_size(); j++) {
                if (j == (m_arwindow.get_size()-1)) {
                    m_arwindow[j] = (m_arwindow[j] << 1);
                }
                else {
                    m_arwindow[j] = ((m_arwindow[j] << 1) | ((m_arwindow[j+1] & 0x80) >> 7));
                }
            }
        }
        
        // update window
        m_arwindow[m_arwindow.get_size()-1] |= 0x01;

#ifdef DEBUG_PROTPP
        std::cout << print() << std::endl;
#endif

        // mask the window to number of packets
        m_arwindow[0] &= (0xFF >> (m_size%8));

        // TLS starts with packet zero, seqnum should be next expected number
        if (m_prot == protocol_t::TLS) {
            if (diff == 0) {
                m_seqnum = currseq+1;
            }
            else {
                m_seqnum = currseq;
            }
        }
        else {
            m_seqnum = currseq;
        }

        // update extended packet number
        if (m_usext) {
            m_extseq = currext;
        }

        return ERR_NONE;
    }
}

//////////////////////////////////////////////////////////////////////
// Return the size of the anti-replay window
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
unsigned int jreplay<T,TE>::size() {
    return m_size;
}

//////////////////////////////////////////////////////////////////////
// Return the current anti-replay window
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
jarray<uint8_t> jreplay<T,TE>::get_window() {
    return m_arwindow;
}

//////////////////////////////////////////////////////////////////////
// Return current sequence number
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
T jreplay<T,TE>::get_seqnum() {
    return m_seqnum;
}

//////////////////////////////////////////////////////////////////////
// Return the current extended sequence number
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
TE jreplay<T,TE>::get_extseq() {
    return m_extseq;
}

/////////////////////////////////////////////////////////////////////
// Returns sequence number difference
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
int jreplay<T,TE>::next(T& currseq, TE& currext, replay_t type) {
    uint64_t seqnum = 0;
    int mydiff=1;

    // check for extended sequence number use
    if (m_usext) {
        if ((sizeof(currseq) == 8) && (sizeof(currext) == 8)) {
            std::string prot(EnumString<protocol_t>::From(m_prot));
            std::cerr << "For protocol " << prot << ", unable to process two UINT64_t packet"
                      << " numbers, if using extended packets numbers both packet numbers must"
                      << " be UINT32_t or smaller values" << std::endl;
            return ERR_PROGRAM;
        }
        else {
            if (m_prot == protocol_t::SRTP) {
                seqnum = ((currext << 16) | currseq);
            }
            else if (m_prot == protocol_t::TLS) {
                seqnum = currext;
                seqnum = ((seqnum << 48) | currseq);
            }
            else {
                seqnum = currext;
                seqnum = ((seqnum << 32) | currseq);
            }
        }
    }
    else {
       seqnum = currseq;
    }

    if (type == replay_t::LATE) {
        // return a late packet
        mydiff = -(m_size + m_rand->get_int("1..50"));
    }
    else if ((type == replay_t::WINDOW) || (type == replay_t::REPLAY)) {
        // find a random starting point
        std::string range("1..");
        range += std::to_string(m_size/2);
        unsigned int chk = (m_rand->get_int(range.c_str())/8);
        uint8_t bit = 1;
        bool found=false;

        // return a replay error or a valid packet in the window
        for (int j=chk; j>=0; j--) {
            bit=1;
            for (unsigned int i=0; i<8; i++) {
                if ((type == replay_t::WINDOW) && (!(m_arwindow[j] & bit)) && ((((m_arwindow.get_size()-j-1)*8)+i) < m_size)) {
                    // open slot found, return difference
                    mydiff = -((((m_arwindow.get_size()-j-1) * 8) + i));
                    found = true;
                    break;
                }
                else if (((type == replay_t::REPLAY) && (m_arwindow[j] & bit)) && ((((m_arwindow.get_size()-j-1)*8)+i) < m_size)) {
                    // replay found, return difference
                    mydiff = -((((m_arwindow.get_size()-j-1) * 8) + i));
                    found = true;
                    break;
                }
                else {
                    bit <<= 1;
                }
            }
            if (found) { break; }
        }

        // didn't find one, go the other way
        if (mydiff==1) {
            for (int j=chk; j<m_arwindow.get_size(); j++) {
                bit=1;
                for (unsigned int i=0; i<8; i++) {
                    if ((type == replay_t::WINDOW) && (!(m_arwindow[j] & bit)) && ((((m_arwindow.get_size()-j-1)*8)+i) < m_size)) {
                        // open slot found, return difference
                        mydiff = -((((m_arwindow.get_size()-j-1) * 8) + i));
                        found = true;
                        break;
                    }
                    else if (((type == replay_t::REPLAY) && (m_arwindow[j] & bit)) && ((((m_arwindow.get_size()-j-1)*8)+i) < m_size)) {
                        // replay found, return difference
                        mydiff = -((((m_arwindow.get_size()-j-1) * 8) + i));
                        found = true;
                        break;
                    }
                    else {
                        bit <<= 1;
                    }
                }
                if (found) { break; }
            }
        }
    }
    else if (type == replay_t::ROLLOVER) {
        // return rollover error
        uint64_t max = 0xFFFFFFFFFFFFFFFF;
        if (m_prot == TLS) {
            // 48-bit seqnum
            max &= 0x0000FFFFFFFFFFFF;
        }
        else if ((!m_usext) && (sizeof(currseq) != 8)) {
            // 32-bit seqnum
            max &= 0x00000000FFFFFFFF;
        }
        mydiff = ((max-m_rand->get_int("1..5"))-seqnum);
    }
    else if (type == replay_t::ROLLUNDER) {
        // return rollunder error
        mydiff = seqnum-(seqnum+m_rand->get_int("1..5"));
    }
    else if (type == replay_t::SHIFT) {
        // shift packet
        mydiff = m_rand->get_int("1..31");
    }
    else {
        // increment packet by one
        mydiff = 1;
    }

#ifdef DEBUG_PROTPP
    std::cout << "Current replay window: " << std::endl
              << "type="
              << EnumString<replay_t>::From(type) << std::endl
              << "diff="
              << mydiff << std::endl
              << "currseq="
              << HEX(currseq, 16) << std::endl
              << "currext="
              << HEX(currext, 16) << std::endl
              << print(true) << std::endl
              << print() << std::endl;
#endif

    // update the window
    if (mydiff < 0) {
        T tmpseq = currseq - abs(mydiff);
        TE tmpext;

        if (m_prot == protocol_t::SRTP) {
            if (((tmpseq & 0xF000) == 0xF000) && ((currseq & 0xF000) == 0)) {
                tmpext = currext-1;
            }
            else {
                tmpext = currext;
            }
        }
        else if (m_prot == protocol_t::TLS) {
            if (((tmpseq & 0x0000FF0000000000) == 0x0000FF0000000000) && ((currseq & 0x0000FF0000000000) == 0)) {
                tmpext = currext-1;
            }
            else {
                tmpext = currext;
            }
        }
        else {
            if (((tmpseq & 0xFF000000) == 0xFF000000) && ((currseq & 0xFF000000) == 0)) {
                tmpext = currext-1;
            }
            else {
                tmpext = currext;
            }
        }

        antireplay(tmpseq,tmpext);
    }
    else {
        T tmpseq = currseq + mydiff;
        TE tmpext;

        if (m_prot == protocol_t::SRTP) {
            if (((tmpseq & 0xF000) == 0) && ((currseq & 0xF000) == 0xF000)) {
                tmpext = currext+1;
            }
            else {
                tmpext = currext;
            }
        }
        else if (m_prot == protocol_t::TLS) {
            if (((tmpseq & 0x0000FF0000000000) == 0) && ((currseq & 0x0000FF0000000000) == 0x0000FF0000000000)) {
                tmpext = currext+1;
            }
            else {
                tmpext = currext;
            }
        }
        else {
            if (((tmpseq & 0xFF000000) == 0) && ((currseq & 0xFF000000) == 0xFF000000)) {
                tmpext = currext+1;
            }
            else {
                tmpext = currext;
            }
        }

        antireplay(tmpseq,tmpext);
    }

#ifdef DEBUG_PROTPP
    std::cout << "Current updated replay window: " << std::endl
              << print(true) << std::endl
              << print() << std::endl
              << "**************************************************************" << std::endl << std::endl;
#endif

    // return the difference
    return mydiff;
}

//////////////////////////////////////////////////////////////////////
// Anti-replay pretty print function
//////////////////////////////////////////////////////////////////////
template <typename T, typename TE>
std::string jreplay<T,TE>::print(bool pretty, int indent) {

    std::string ident;
    std::string hdr;
    std::string border("-------------------------------------------------------------------------------------------------");

    // create the indent
    for(int i=0; i<indent; i++) {
        ident += " ";
    }

    if (pretty) {
        hdr = hdr + "\n";
        hdr = hdr + ident + "                             Anti-replay window (size=" + std::to_string(m_size) + ")\n";
        hdr = hdr + ident + "-------------------------------------------------------------------------------------------------\n";
        hdr = hdr + ident + "| 23  22  21  20  19  18  17  16  15  14  13  12  11  10  9   8   7   6   5   4   3   2   1   C |\n";
        hdr = hdr + ident + "| *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   u |\n";
        hdr = hdr + ident + "| P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   P   r |\n";
        hdr = hdr + ident + "| r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r   r |\n";
        hdr = hdr + ident + "| e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e   e |\n";
        hdr = hdr + ident + "| v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   v   n |\n";
        hdr = hdr + ident + "| i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   i   t |\n";
        hdr = hdr + ident + "| o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   o   | |\n";
        hdr = hdr + ident + "| u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   u   | |\n";
        hdr = hdr + ident + "| s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   s   V |\n";
        hdr = hdr + ident + "-------------------------------------------------------------------------------------------------\n";
        hdr = hdr + ident + "| oldest                                     <-----                                 most recent |\n";
        hdr = hdr + ident + "-------------------------------------------------------------------------------------------------";
    }

    int line=0;
    uint8_t mymask;
    std::string tmp;
    std::string win;
    unsigned int format=0;
    uint32_t mask = (0xFFFFFF >> (24-(m_size%24)));
    unsigned int winsize = ((pretty) ? (m_size+(24-(m_size%24))) : ((m_size/8) + (((m_size%8) != 0) ? 1 : 0)));
    jarray<uint8_t> cpy(m_arwindow);

    if ((cpy.get_size()%3) != 0) {
        jarray<uint8_t> mytmp((3-(cpy.get_size()%3)), 0);
        cpy.insert(0, mytmp);
    }

    if (pretty) {
        win = win + "\n" + ident;
    }

    for (int i=(cpy.get_size()-1); i>=0; --i) {
        if (pretty) {
            mymask = 0x01;
            for (unsigned int j=0; j<8; j++) {
                if ((i==0) && (format >= m_size) && ((mymask & (mask >> 16)) == 0)) {
                    tmp.insert(0, " X |");
                }
                else if ((i==1) && (format >= m_size) && ((mymask & (mask >> 8)) == 0)) {
                    tmp.insert(0, " X |");
                }
                else if ((i==2) && (format >= m_size) && ((mymask & mask) == 0)) {
                    tmp.insert(0, " X |");
                }
                else if ((cpy[i] & mymask) != 0) {
                    tmp.insert(0, " 1 |");
                }
                else {
                    tmp.insert(0, " 0 |");
                }

                // convert line number to string
                std::string lineno = std::to_string(line);

                if (format == (winsize-1)) {
                    tmp.insert(0, "|");
                    win += tmp + " * " + lineno + "\n" + ident + border + "\n";
                    win.insert(0, hdr);
                    line += 24;
                    break;
                }
                else if (((format+1)%24) == 0) {
                    tmp.insert(0, "|");
                    win += tmp + " * " + lineno + "\n"+ ident + border + "\n" + ident;
                    line += 24;
                    tmp = "";
                }

                mymask <<= 1;
                format++;
            }
        }
        else {
            mymask = 0x01;
            for (unsigned int k=0; k<8; k++) {
                if (format < m_size) {
                    if ((cpy[i] & mymask) != 0) {
                        win.insert(0, "1");
                    }
                    else if (format <= (m_size-1)) {
                        win.insert(0, "0");
                    }
    
                    mymask <<= 1;
                    format++;
                }
            }
        }
    }

    return win;
}

}

#endif //JPROTOCOL_JREPLAY_H
