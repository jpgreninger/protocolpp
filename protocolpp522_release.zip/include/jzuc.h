#ifndef JZUC_H_
#define JZUC_H_

///
///\class jzuc jzuc.h "include/jzuc.h"
///
///\section ZUCAlgZUC ZUC Encrytpion Algorithm (128-EEA3)
///
/// @see Specification of the 3GPP Confidentiality and Integrity Algorithms 128-EEA3 and 128-EIA3 Document 2: ZUC Specification
///
/// <B>General structure of the algorithm</B>
///
/// ZUC has three logical layers, see the figure below. The top layer is a linear feedback shift register (LFSR) of 16 stages, the
/// middle layer is for bit-reorganization ( BR), and the bottom layer is a nonlinear function F
///
///\image html ZUCStructure.png "General Structure of ZUC"
///\image latex ZUCStructure.eps "General Structure of ZUC" width=15cm
///
/// <B>The linear feedback shift register (LFSR)</B> 
///
/// The linear feedback shift register (LFSR) has 16 of 31-bit cells \f$ (s_0, s_1,\cdots,s_{15})\f$. Each cell \f$ s_i (0 \leq i \leq 15)\f$ is restricted to take
/// values from the following set <B>\f$ \{1,2,3,\cdots,{2}^{31} – 1\}\f$</B>. The LFSR has 2 modes of operations: the initialization mode and the working mode
///
/// In the initialization mode, the LFSR receives a 31-bit input word u, which is obtained by removing the rightmost bit from the
/// 32-bit output W of  the nonlinear function F, i.e., u=W>>1. More specifically, the initialization mode works as follows:  
///
/// LFSRWithInitialisationMode(u) {
///
/// 1. \f$ v={2}^{15}s_{15}+{2}^{17}s_{13}+{2}_{21}s_{10}+{2}^{20}s_4+(1+{2}^{8})s_0\f$ mod \f$ ({2}^{31}-1)\f$ 
///
/// 2. \f$ s_{16}=(v+u)\f$ mod \f$ ({2}^{31}-1)\f$
///
/// 3. \f$ If s_{16}=0\f$, then set \f$s_{16}={2}^{31}-1\f$
///
/// 4. \f$ (s_1,s_2,\cdots,s_{15},s_{16})\rightarrow(s_0,s_1,\cdots,s_{14},s_{15})\f$  
///
/// }  
///
/// In the working mode, the LFSR does not receive any input, and it works as follows:  
///
/// LFSRWithWorkMode() {
///
/// 1. \f$ s_{16}={2}^{15}s_15+{2}^{17}s_13+{2}^{21}s_10+{2}^{20}s_4+(1+{2}^{8})s_0\f$ mod \f$ ({2}^{31}-1)\f$
///
/// 2. \f$ If s_{16}=0\f$, then set \f$ s_{16}={2}^{31}-1\f$
///
/// 3. \f$ (s_1,s_2,\cdots,s_{15},s_{16})\rightarrow(s_0,s_1,\cdots,s_{14},s_{15})\f$
///
/// }  
///
/// Informative note: Since the multiplication of a 31-bit string s by \f$ {2}^{i}\f$ over \f$ GF({2}^{31}-1)\f$ can be implemented by a
/// cyclic shift of s to the left by i bits, only addition modulo \f$ {2}^{31}-1\f$ is needed in step 1 of the above functions. More precisely,
/// step 1 of the function LFSRWithInitialisationMode can be implemented by  
///
/// \f$ v=(s_{15} <<<_{31} 15)+(s_{13} <<<_{31} 17)+(s_{10} <<<_{31} 21)+(s_4 <<<_{31} 20)+(s_0 <<<_{31} 8)+s_0\f$ mod \f$ ({2}^{31}-1)\f$
///
/// and the same implementation is needed for step 1 of the function LFSRWithWorkMode
///
/// Informative note: For two elements \f$ a,b\f$ over \f$ GF({2}^{31}-1)\f$, the computation of \f$ v=a+b\f$ mod \f$ ({2}^{31}-1)\f$ can be done by
///
/// (1) compute v=a+b and
/// 
/// (2) if the carry bit is 1, then set v=v+1
///
/// Alternatively (and better if the implementation should resist possible timing attacks):
///
/// (1) compute w=a+b, where w is a 32-bit value; and
///
/// (2) set v = (least significant 31 bits of w) + (most significant bit of w)  
///
/// <B>The bit-reorganization</B>
///
/// The middle layer of the algorithm is the bit-reorganization. It extracts 128 bits from the cells of the LFSR and forms 4 of 32-bit words,
/// where the first three words will be used by the nonlinear function F in the bottom layer, and the last word will be involved in producing
/// the keystream
///
/// Let \f$ s_0, s_2, s_5, s_7, s_9, s_{11}, s_{14}, s_{15}\f$ be 8 cells of LFSR as in section 3.2. Then the bitreorganization forms 4 of 32-bit words
/// \f$ X_0, X_1, X_2, X_3\f$ from the above cells as follows:  
///
/// Bitreorganization() {
///
/// 1. \f$ X_0=s_{15H} \parallel s_{14L}\f$
///
/// 2. \f$ X_1=s_{11L} \parallel s_{9H}\f$
///
/// 3. \f$ X_2=s_{7L} \parallel s_{5H}\f$
///
/// 4. \f$ X_3=s_{2L} \parallel s_{0H}\f$
///
/// }  
///
/// Note: The \f$ s_i\f$ are 31-bit integers, so \f$ s_{iH}\f$ means bits 30...15 and not 31...16 of \f$ s_i, for 0 \leq i \leq 15\f$
///
/// <B>The nonlinear function F</B> 
///
/// The nonlinear function F has 2 of 32-bit memory cells \f$ R_1\f$ and \f$ R_2\f$. Let the inputs to F be \f$ X_0, X_1\f$ and \f$ X_2\f$, which come
/// from the outputs of the bit-reorganization (see section 3.3), then the function F outputs a 32-bit word W. The detailed process of F is as follows:  
///
/// F (\f$ X_0, X_1, X_2\f$) {
///
/// 1. \f$ W=(X_0 \oplus R_1) \oplus R_2\f$
///
/// 2. \f$ W_1=R_1 \oplus X_1\f$
///
/// 3. \f$ W_2=R_2 \oplus X_2\f$
///
/// 4. \f$ R_1=S(L_1(W_{1L} \parallel W_{2H}))\f$
///
/// 5. \f$ R_2=S(L_2(W_{2L} \parallel W_{1H}))\f$
///
/// }  
///
/// where <I>S</I> is a 32×32 S-box, see section 3.4.1, \f$ L_1\f$ and \f$ L_2\f$ are linear transforms as defined in section 3.4.2
///
/// <B>The S-box S</B>
///
/// The 32×32 S-box S is composed of 4 juxtaposed  8×8 S-boxes, i.e., S=(\f$ S_0,S_1,S_2,S_3\f$), where \f$ S_0=S_2\f$, \f$ S_1=S_3\f$. The definitions
/// of \f$ S_0\f$ and \f$ S_1\f$ can be found in table 3.1 and table 3.2 respectively
///
/// Let x be an 8-bit input to \f$ S_0\f$ (or \f$ S_1\f$). Write x into two hexadecimal digits as \f$ x=h \parallel l\f$, then the entry at the intersection
/// of the h-th row and the l-th column in table 3.1 (or table 3.2) is the output of \f$ S_0\f$ (or \f$ S_1\f$)
///
///\image html SBOX_S0.png "The S-Box S0"
///\image latex SBOX_S0.eps "The S-Box S0" width=10cm
///
///\image html SBOX_S1.png "The S-Box S1"
///\image latex SBOX_S1.eps "The S-Box S1" width=10cm
///
/// <B>The linear transforms L1 and L2</B>
///
/// Both L1 and L2 are linear transforms from 32-bit words to 32-bit words, and are defined as follows:  
///
/// \f$ L_1(X)=X \oplus (X <<<_{32} 2) \oplus (X <<<_{32} 10) \oplus (X <<<_{32} 18) \oplus (X <<<_{32} 24)\f$
///
/// \f$ L_2(X)=X \oplus (X <<<_{32} 8) \oplus (X <<<_{32} 14) \oplus (X <<<_{32} 22) \oplus (X <<<_{32} 30)\f$
///
/// <B>Key loading</B>
///
/// The key loading procedure will expand the initial key and the initial vector into 16 of 31-bit integers as the initial state of the LFSR. Let the 128-bit
/// initial key k and the 128-bit initial vector iv be  
///
/// \f$ k=k_0 \parallel k_1 \parallel k_2 \parallel \cdots \parallel k_{15}\f$ 
///
/// and  
///
/// \f$ iv=iv_0 \parallel iv_1 \parallel iv_2 \parallel \cdots \parallel iv_{15}\f$
///
/// respectively, where \f$ k_i\f$ and \f$ iv_i, 0\leq i\leq 15\f$, are all bytes. Then k and iv are loaded to the cells \f$ s_0, s_1,\cdots, s_{15}\f$ of LFSR as follows:  
///
/// 1. Let D be a 240-bit long constant string composed of 16 substrings of 15 bits:  
///
/// \f$ D=d_0 \parallel d_1 \parallel \cdots \parallel d_{15}\f$
///
/// where  
///
/// \f$ d00 = 100010011010111_2 \f$
///
/// \f$ d01 = 010011010111100_2 \f$
///
/// \f$ d02 = 110001001101011_2 \f$
///
/// \f$ d03 = 001001101011110_2 \f$
///
/// \f$ d04 = 101011110001001_2 \f$
///
/// \f$ d05 = 011010111100010_2 \f$
///
/// \f$ d06 = 111000100110101_2 \f$
///
/// \f$ d07 = 000100110101111_2 \f$
///
/// \f$ d08 = 100110101111000_2 \f$
///
/// \f$ d09 = 010111100010011_2 \f$
///
/// \f$ d10 = 110101111000100_2 \f$
///
/// \f$ d11 = 001101011110001_2 \f$
///
/// \f$ d12 = 101111000100110_2 \f$
///
/// \f$ d13 = 011110001001101_2 \f$
///
/// \f$ d14 = 111100010011010_2 \f$
///
/// \f$ d15 = 100011110101100_2 \f$
///
/// 2. \f$ For 0 \leq i \leq 15, let s_i=k_i \parallel d_i \parallel iv_i\f$
///
/// <B>The execution of ZUC</B>
///
/// The execution of ZUC has two stages: the initialization stage and the working stage
///
/// <B>The initialization stage</B>
///
/// During the initialization stage, the algorithm calls the key loading procedure (see section 3.5) to load the 128-bit initial key k and the 128-bit initial vector iv
/// into the LFSR, and set the 32bit memory cells R1 and R2 to be all 0. Then the cipher runs the following operations 32 times:
///
/// 1.  Bitreorganization();
///
/// 2.  w=F(\f$ X_0, X_1, X_2\f$);
///
/// 3.  LFSRWithInitialisationMode(w >> 1)
///
/// <B>The working stage</B>
///
/// After the initialization stage, the algorithm moves into the working stage. At the working stage, the algorithm executes the following operations once, and
/// discards the output W of F:
///
/// 1.  Bitreorganization();
///
/// 2.  F(\f$ X_0, X_1, X_2\f$);
///
/// 3.  LFSRWithWorkMode()
///
/// Then the algorithm goes into the stage of producing keystream, i.e., for each iteration, the following operations are executed once, and a 32-bit word Z
/// is produced as an output:
///
/// 1.  Bitreorganization();
///
/// 2.  Z=F(\f$ X_0, X_1, X_2) \oplus X3\f$;
///
/// 3.  LFSRWithWorkMode()
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jzuc
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jconfident
/// @see ProtocolPP::jintegrity
///
/// <B>For Additional Documentation:</B>
/// @see jarray
/// @see jzuc
/// @see jmodes
/// @see jconfident
/// @see jintegrity
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) modified by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <cstring>
#include <iostream>
#include "jenum.h"

namespace ProtocolPP {

#define MulByPow2(x, k) ((((x) << k) | ((x) >> (31 - k))) & 0x7FFFFFFF)
#define ROT(a, k) (((a) << k) | ((a) >> (32 - k)))
#define MAKEuint32_t(a, b, c, d) (((uint32_t)(a) << 24) | ((uint32_t)(b) << 16) | ((uint32_t)(c) << 8) | ((uint32_t)(d)))
#define MAKEU31(a, b, c) (((uint32_t)(a) << 23) | ((uint32_t)(b) << 8) | (uint32_t)(c))
#define MAKEU314(a, b, c, d) (((uint32_t)(a) << 23) | ((uint32_t)(b) << 16) | ((uint32_t)(c) << 8) | ((uint32_t)(d)))

class jzuc {

public:

    //////////////////////////////////////////////////////////////////////
    /// Direction of processing for ZUC
    /// @param UPLINK - User to tower
    /// @param DOWNLINK - Tower to user
    //////////////////////////////////////////////////////////////////////
    enum dir_t {
        UPLINK=0x00,
        DOWNLINK=0x01
    };

    //////////////////////////////////////////////////////////////////////
    /// Constructor for ZUC encryption
    /// @param dir - direction of processing
    /// @param key - encryption key
    /// @param keylen - length of the encryption key (16 bytes)
    /// @param count - 32-bit COUNT value
    /// @param bearer - bearer value
    //////////////////////////////////////////////////////////////////////
    jzuc(dir_t dir,
         uint8_t* key,
         unsigned int keylen,
         uint32_t count,
         uint8_t bearer);
    
    //////////////////////////////////////////////////////////////////////
    /// Constructor for ZUC-256 encryption and authentication
    /// @param dir - direction of processing
    /// @param key - encryption key
    /// @param keylen - length of the encryption key (32 bytes)
    /// @param iv - initialization vector
    /// @param ivlen - length of the initialization vector (25 bytes)
    //////////////////////////////////////////////////////////////////////
    jzuc(dir_t dir,
         uint8_t* key,
         unsigned int keylen,
         uint8_t* iv,
         unsigned int ivlen);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for ZUC authentication with 4-byte ICV
    /// @param dir - direction of processing (DOWNLINK, UPLINK)
    /// @param key - authentication key
    /// @param keylen - length of the authentication key (16 bytes)
    /// @param count - 32-bit COUNT value
    /// @param bearer - bearer value
    //////////////////////////////////////////////////////////////////////
    jzuc(dir_t dir,
         uint8_t* key,
         unsigned int keylen,
         uint32_t count,
         uint32_t bearer);
   
    //////////////////////////////////////////////////////////////////////
    /// Constructor for ZUC-256 authentication
    /// @param dir - direction of processing (DOWNLINK, UPLINK)
    /// @param key - authentication key
    /// @param keylen - length of the authentication key (32 bytes)
    /// @param iv - initialization vector
    /// @param ivlen - length of the initialization vector (25 bytes)
    /// @param icvlen - length of the ICV (4, 8, 16 for zuc256) 
    //////////////////////////////////////////////////////////////////////
    jzuc(dir_t dir,
         uint8_t* key,
         unsigned int keylen,
         uint8_t* iv,
         unsigned int ivlen,
         unsigned int icvlen);
    
    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jzuc() {
        delete [] m_key;
        m_key=nullptr;
        delete [] m_iv;
        m_iv=nullptr;
        if (m_icv != nullptr) {
            delete [] m_icv;
            m_icv=nullptr;
        }
        delete m_z;
        m_z=nullptr;
    }

    //////////////////////////////////////////////////////////////////////
    /// calculates the ciphertext/plaintext
    /// @param input - input data
    /// @param output - output data
    /// @param length - length of the input data
    //////////////////////////////////////////////////////////////////////
    void ProcessData(const uint8_t* input, uint8_t* output, uint32_t length);

    //////////////////////////////////////////////////////////////////////
    /// calculates the MAC (icv)
    /// @param input - input authentication data
    /// @param length - length of the input data
    //////////////////////////////////////////////////////////////////////
    void ProcessData(const uint8_t* input, uint32_t length);

    //////////////////////////////////////////////////////////////////////
    /// returns the MAC (icv)
    /// @param result - ICV of length 4-bytes
    //////////////////////////////////////////////////////////////////////
    void result(uint8_t* result);

    //////////////////////////////////////////////////////////////////////
    /// returns the length of the MAC (icv)
    /// @return - length of the ICV (4 bytes for ZUC or 4, 8, or 16 for ZUC-256)
    //////////////////////////////////////////////////////////////////////
    unsigned int result_size();

private:

    // don't allow these
    jzuc() = delete;
    jzuc(jzuc& rhs) = delete;
    jzuc(const jzuc& rhs) = delete;

    // member variables
    dir_t m_dir;
    unsigned int m_keylen;
    uint8_t* m_key;
    uint8_t* m_iv;
    uint8_t* m_icv;
    uint32_t m_LFSR[16];
    uint32_t m_F_R[2];
    uint32_t m_BRCX[4];
    static const uint32_t m_EK_d[16];
    uint8_t m_EK_d256[16];
    static const uint8_t m_S0[256];
    static const uint8_t m_S1[256];
    uint32_t* m_z;
    unsigned int m_icvlen;

    // c = a + b mod (2^31 – 1)
    uint32_t AddM(uint32_t a, uint32_t b);

    // LFSR with initialization mode
    void LFSRWithInitialisationMode(uint32_t u);

    // LFSR with work mode
    void LFSRWithWorkMode();

    // BitReorganization
    void BitReorganization();

    // L1
    uint32_t L1(uint32_t X);

    // L2
    uint32_t L2(uint32_t X);

    // F
    uint32_t F();

    // initialize
    void Initialization(uint8_t* k, uint8_t* iv);

    // Generates the keystream for XOR with data
    void GenerateKeystream(uint32_t* pKeystream, int KeystreamLen);

    // see Annex 1
    uint32_t get_word(uint32_t* data, uint32_t i);

    // see Annex 1
    uint8_t get_bit(uint32_t data, uint32_t i);
};

}

#endif /* JZUC_H_ */
