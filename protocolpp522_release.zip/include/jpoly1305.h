#ifndef JPOLY1305_H
#define JPOLY1305_H

///
///\class jpoly1305 jpoly1305.h "include/jpoly1305.h"
///
/// See the license at:
/// 
/// * [MIT](http://www.opensource.org/licenses/mit-license.php) or PUBLIC DOMAIN
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) modified by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

/* auto detect between 32bit / 64bit */
///#define HAS_SIZEOF_INT128_64BIT true ///(defined(__SIZEOF_INT128__) && defined(__LP64__))
///#define HAS_MSVC_64BIT true ///(defined(_MSC_VER) && defined(_M_X64))
///#define HAS_GCC_4_4_64BIT true ///(defined(__GNUC__) && defined(__LP64__) && ((__GNUC__ > 4) || ((__GNUC__ == 4) && (__GNUC_MINOR__ >= 4))))

#if _WIN32 || _WIN64
    #if _WIN64
        #ifndef HAS_SIZEOF_INT128_64BIT
            #define HAS_SIZEOF_INT128_64BIT
        #endif
        #ifndef HAS_SIZEOF_INT128_64BIT
            #define HAS_MSVC_64BIT
        #endif
        #ifndef HAS_SIZEOF_INT128_64BIT
            #define HAS_GCC_4_4_64BIT
        #endif
    #endif
#endif

#if __GNUC__
    #if __x86_64__ || __ppc64__
        #ifndef HAS_SIZEOF_INT128_64BIT
            #define HAS_SIZEOF_INT128_64BIT
        #endif
        #ifndef HAS_SIZEOF_INT128_64BIT
            #define HAS_MSVC_64BIT
        #endif
        #ifndef HAS_SIZEOF_INT128_64BIT
            #define HAS_GCC_4_4_64BIT
        #endif
    #endif
#endif

#include <cstddef>
#include <iostream>
#include <cstring>

namespace ProtocolPP {

class jpoly1305 {

public:

    ////////////////////////////////////////////////////////
    /// Constructor for JPOLY1305 algorithm
    /// @param key - initialization key
    /// @param length - length of the key in bytes (32)
    ////////////////////////////////////////////////////////
    jpoly1305(const unsigned char *key, unsigned int length);

    ////////////////////////////////////////////////////////
    /// Constructor for JPOLY1305 algorithm with context
    /// @param ctx - context from previous session
    ////////////////////////////////////////////////////////
    explicit jpoly1305(unsigned char *ctx);

    ////////////////////////////////////////////////////////
    /// Standard Deconstructor for JPOLY1305 algorithm
    ////////////////////////////////////////////////////////
    virtual ~jpoly1305() {}

    ////////////////////////////////////////////////////////
    /// Calculates the MAC using JPOLY1305
    /// @param input - data to hash
    /// @param length - length of the input data
    ////////////////////////////////////////////////////////
    void ProcessData(const unsigned char *input, unsigned int length);

    ////////////////////////////////////////////////////////
    /// Returns the context of JPOLY1305
    /// @param ctx - context of the engine
    /// @param length - length of the context in bytes (144)
    ////////////////////////////////////////////////////////
    void context(unsigned char *ctx, unsigned int length=144);

    ////////////////////////////////////////////////////////
    /// Returns the MAC using JPOLY1305
    /// @param mac - result of the hash calculation
    /// @param length - length of the MAC data
    ////////////////////////////////////////////////////////
    void result(unsigned char *mac, unsigned int length=16);

private:
  
    // don't allow these
    jpoly1305() = delete;
    jpoly1305(jpoly1305& rhs) = delete;
    jpoly1305(const jpoly1305& rhs) = delete;

    typedef struct jpoly1305_context {
        size_t aligner;
        unsigned char opaque[136];
    } jpoly1305_context;

    jpoly1305_context m_ctx;

    void jpoly1305_init(jpoly1305_context *ctx, const unsigned char key[32]);

    void jpoly1305_update(jpoly1305_context *ctx, const unsigned char *m, size_t bytes);

    void jpoly1305_finish(jpoly1305_context *ctx, unsigned char mac[16]);
};

}

#endif /* JPOLY1305_H */
