#ifndef JARRAY_H_
#define JARRAY_H_

///
///\class jarray jarray.h "include/jarray.h"
///
///\section JARRAYC Array Class for Protocol++&reg; (ProtocolPP&reg;)
///
/// This is the array class used throughout ProtocolPP&reg; (Protocol++&reg;) and it's derivatives. It's main
/// purpose is to provide easy accessibilty to data for the user. There are several different types
/// of constuctor for the class
///
/// The standard constructor generates a empty array of size zero and can be constructed as
///\code
///
/// jarray<uint8_t> array1;
///\endcode
///
/// The second type of constructor creates an array of the size requested initialized to zero
///\code
///
/// jarray<uint8_t> array2(20);
///\endcode
///
/// The third type creates an array of the size requested intialized with the given value
///\code
///
/// jarray<uint16_t> array3(10, 0xFFAA);
///\endcode
///
/// The fourth type creates a copy of another array
///\code
///
/// jarray<uint16_t> array4(array3);
///\endcode
///
/// The fifth type creates an array from a standard vector
///\code
///
/// std::vector<uint32_t> vector1(10, 0xAABBCCDD);
/// jarray<uint32_t> array5(vector1, endian_t::BIG);
///\endcode
///
/// The sixth type creates an array from a raw uint8_t pointer
///\code
///
/// uint8_t* pointer1 = new uint8_t[10];
/// jarray<uint8_t> array6(pointer1, 10);
///\endcode
///
/// The last constructor allows the user to convert from one type to another
/// such as changing a uint32_t array to a uint8_t array
///\code
///
/// jarray<uint32_t> wordarray1(2, 0xAABBCCDD);
/// jarray<uint8_t>  array7(wordarray1, endian_t::LITTLE);
///
/// array7 = [DDCCBBAA_DDCCBBAA]
///\endcode
/// 
/// The next set of methods are accessor methods for the array as follows:
///\code
///
/// // return array size (number of elements)
/// unsigned int array1_size = array1.get_size()
///
/// // returns whether the array is empty
/// bool empty = array2.empty(); // returns false
/// 
/// // returns first n elements from this array as new array, removing elements from this array
/// jarray<uint16_t> newarray3 = array3.split(5);
///
/// newarray3 = [FFAAFFAA_FFAAFFAA
///              FFAA]
/// 
/// // extract elements starting at n for the next y elements
/// jarray<uint8_t> extract = array5.extract(1,2);
///
/// extract = [BBCC]
///
/// // push an element onto the end of the array
/// array6.push_back(0x00);
///
/// array6 = [00000000_00000000_000000]
/// 
/// // removed element from the end of the array
/// array6.pop_back();
/// array6.pop_back();
///
/// array6 = [00000000_00000000]
///
/// // resize the array
/// array6.resize(array6.size()+10);
///
/// array6 = [00000000_00000000_00000000_00000000
///           0000]
///
/// // append array6 on the end of array3
/// array3.append(array6);
///
/// array3 = [00000000_00000000_00000000_00000000
///           00000000_00000000_00000000_0000]
///
/// // insert new array into array3
/// jarray<uint8_t> array8(2,0xAA);
///
/// array3.insert(24,array8);
///
/// array3 = [00000000_00000000_00000000_00000000
///           00000000_00000000_AAAA0000_00000000]
///
/// // update array3 with new array
/// jarray<uint8_t> array9(8,0xCC);
///
/// array3.update(24,array9);
///
/// array3 = [00000000_00000000_00000000_00000000
///           00000000_00000000_CCCCCCCC_CCCCCCCC]
///
/// // erase the first four bytes
/// array3.erase(0,4);
///
/// array3 = [00000000_00000000_00000000_00000000
///           00000000_CCCCCCCC_CCCCCCCC]
/// 
/// // reverse the array
/// array3.reverse()
///
/// array3 = [CCCCCCCC_CCCCCCCC_00000000_00000000
///           00000000_00000000_00000000]
///
/// // return the raw pointer to the underlying array
/// uint32_t* wordptr = array5.get_ptr();
///
/// // return the raw pointer as a constant pointer
/// const uin32_t* constptr = array5.get_ptr();
///
/// // convert the array to a string representation with no formatting
/// std::string strarray = array3.to_string();
/// 
/// array3 = "CCCCCCCCCCCCCCCC0000000000000000000000000000000000000000";
///
/// // convert the array to a string representation 16-bytes wide with formatting
/// std::string strpretty = array3.to_string(true);
///
/// array3 = "[CCCCCCCC_CCCCCCCC_00000000_00000000
///            00000000_00000000_00000000]"
///
/// // compare two arrays of the same type for differences, annotate differences
/// arrayx.debug(arrayz);
///
/// AAAABBBB_CCCCDDDD_EEEEFFFF_00001111     AAAABBBB_CCCCDDDD_EEEEFFFF_00001111
/// 22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
/// 22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
///\endcode
///
/// Overloaded operators allow two arrays of the same length to be manipulated on
/// a element-by-element basis
///
/// * XOR
/// * OR
/// * AND
/// * MULTIPLY
/// * ADD
///
/// For examples for their use see below
///\code
///
/// jarray<uint8_t> arrayX1(4,0xAA);
/// jarray<uint8_t> arrayX2(4,0xCC);
///
/// arrayX1 ^= arrayX2;
/// arrayX1 = [66666666]
///
/// arrayX1 |= arrayX2;
/// arrayX1 = [EEEEEEEE]
///
/// arrayX1 &= arrayX2;
/// arrayX1 = [88888888]
///
/// arrayX1 *= arrayX2;
/// arrayX1 = [78787878]
///
/// arrayX1 += arrayX2;
/// arrayX1 = [16161616]
///
///\endcode
///
/// Access to individual elements can be accomplished with the overloaded square
/// bracket as follows
///\code
///
/// // get single element
/// uint8_t element1 = array3[7];
/// element1 = 0xCC
///
/// // retrieve element as a constant value
/// const uint32_t element2 = array5[1];
/// element2 = 0xAABBCCDD
///\endcode
///
/// Obtain the format for this array (endian format) with
///\code
///
/// endian_t thisendian = array5.get_format();
///\endcode
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <vector>
#include <iostream>
#include <sstream>
#include <string>
#include <regex>
#include <chrono>
#include <random>
#include <algorithm>
#include <iomanip>
#include "jenum.h"
#include "osrng.h"
#include <netinet/in.h>
using CryptoPP::AutoSeededRandomPool;

namespace ProtocolPP {

template <typename T> class jarray {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor for jarray class
    //////////////////////////////////////////////////////////////////////
    jarray();

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jarray initialized to size
    /// @param size - size to initialize the array to
    //////////////////////////////////////////////////////////////////////
    explicit jarray(unsigned int size);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jarray initialized to size with value
    /// @param size - size to initialize the array to
    /// @param value - value to initialize the array to
    /// @param format - endianness of the constructed array (BIG, LITTLE)
    //////////////////////////////////////////////////////////////////////
    jarray(unsigned int size, T value, endian_t format=BIG);

    //////////////////////////////////////////////////////////////////////
    /// Copy Constructor for jarray
    /// @param rhs - array to copy
    /// @param format - endianness of the constructed array (BIG, LITTLE)
    //////////////////////////////////////////////////////////////////////
    jarray(const jarray<T>& rhs, endian_t format=BIG);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jarray from a string
    /// @param rhs - string to populate the array with
    /// @param format - endianness of the constructed array (BIG, LITTLE)
    /// @param encoded - Input string has already been encoded as HEX
    ///                  characters instead of being a simple string.
    ///                  For example, if the input string had been
    ///                  encoded as bytes each character in the string
    ///                  would be equal to something like '0x6C' or 
    ///                  '0xAE'. If the input was a simple string each
    ///                  character would represent a single value such
    ///                  that the string "123ABC" is really "1", "2"
    ///                  "3", "A", "B", "C" and needs to be converted
    ///                  and grouped into HEX such that the resulting
    ///                  array has "0x12", "0x3A", and "0xBC". The 
    ///                  Crypto++ library uses encoded strings. Set
    ///                  encoded to true to read in ASCII characters
    //////////////////////////////////////////////////////////////////////
    explicit jarray(const std::string& rhs, endian_t format=BIG, bool encoded=false);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jarray from a standard vector
    /// @param rhs - vector to initialize the array with
    /// @param format - endianness of the constructed array (BIG, LITTLE)
    //////////////////////////////////////////////////////////////////////
    explicit jarray(const std::vector<T>& rhs, endian_t format=BIG);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jarray from a uint8_t raw pointer and size
    /// @param rhs - byte pointer to initialize the array with
    /// @param size - length of the data to convert
    /// @param format - endianness of the constructed array (BIG, LITTLE)
    //////////////////////////////////////////////////////////////////////
    jarray(const uint8_t* rhs, unsigned int size, endian_t format=BIG);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jarray from one type to another
    /// @param rhs - initial array to convert. Conversion is to type of
    ///              array that is being constructed. Example:
    ///\code
    ///              jarray<uint32_t> oldarray("AABBCCDD");
    ///              jarray<uint8_t> newarray(oldarray, LITTLE);
    ///              newarray.to_sting();
    ///              "DDCCBBAA"
    ///\endcode
    /// @param format - endianness of the constructed array (BIG, LITTLE)
    //////////////////////////////////////////////////////////////////////
    template <typename TT>
    explicit jarray(jarray<TT>& rhs, endian_t format=BIG);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor for jarray
    //////////////////////////////////////////////////////////////////////
    virtual ~jarray() {}

    //////////////////////////////////////////////////////////////////////
    /// Method to retrieve size of this array
    /// @return Size of the array
    //////////////////////////////////////////////////////////////////////
    unsigned int get_size();

    //////////////////////////////////////////////////////////////////////
    /// Method to determine if the array is empty
    /// @return True/False if araay is empty
    //////////////////////////////////////////////////////////////////////
    bool empty();

    //////////////////////////////////////////////////////////////////////
    /// Method to split the number of elements from the front of the
    /// array and return it to the caller. The original array is reduced
    /// by the number of elements split from it
    /// @param elements - number of elements to split from the array
    /// @return new array containing the split off values
    //////////////////////////////////////////////////////////////////////
    jarray<T> split(unsigned int elements);

    //////////////////////////////////////////////////////////////////////
    /// Method to extract the number of elements from the array starting
    /// at the start value
    /// @param index - index to start the extraction
    /// @param elements - number of elements to split from the array
    /// @return new array containing the split off values
    //////////////////////////////////////////////////////////////////////
    jarray<T> extract(unsigned int index, unsigned int elements);

    //////////////////////////////////////////////////////////////////////
    /// Method to add a single element to the end of the array
    /// @param rhs - element to add to this array
    //////////////////////////////////////////////////////////////////////
    void push_back(T rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to removed the last element from the array. The element
    /// is destroyed in the process
    //////////////////////////////////////////////////////////////////////
    void pop_back();

    //////////////////////////////////////////////////////////////////////
    /// Method to change the array size
    /// @param newsize - either shrink or expand the array to the new size
    //////////////////////////////////////////////////////////////////////
    void resize(unsigned int newsize);

    //////////////////////////////////////////////////////////////////////
    /// Method to add the array rhs to the current array
    /// @param rhs - array to add to this array
    //////////////////////////////////////////////////////////////////////
    void append(jarray<T> rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to insert the array rhs into this array starting at index
    /// The array is resized to accomodate this array plus the new array
    /// No elements of the original array are overwritten
    /// @param index - location to start the insertion
    /// @param rhs - array to insert into this array
    //////////////////////////////////////////////////////////////////////
    void insert(unsigned int index, jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to update the array rhs into this array starting at index
    /// The array is resized to accomodate this array plus the new array
    /// Elements of the original array starting at index and extending
    /// for the length of rhs are overwritten with the new values
    /// @param index - location to start the update
    /// @param rhs - array to update this array with
    //////////////////////////////////////////////////////////////////////
    void update(unsigned int index, jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to remove the elements from the array starting at index
    /// and continuing for size. The original array is reduced by the
    /// number of elements requested
    /// @param index - location to start erasing elements
    /// @param elements - number of elements to remove from this array
    //////////////////////////////////////////////////////////////////////
    void erase(unsigned int index, unsigned int elements);

    //////////////////////////////////////////////////////////////////////
    /// Method to intersect two arrays and return the shared valeus in
    /// both arrays
    /// @param rhs - array to intersect with this array (retains shared values)
    //////////////////////////////////////////////////////////////////////
    void intersect(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to reverse the elements of the array
    //////////////////////////////////////////////////////////////////////
    void reverse();

    //////////////////////////////////////////////////////////////////////
    /// Method to return the pointer to the underlying data object
    /// of the array
    /// @return pointer to the data object
    //////////////////////////////////////////////////////////////////////
    T* get_ptr();

    //////////////////////////////////////////////////////////////////////
    /// Method to return the pointer to the underlying data object
    /// of the array
    /// @return pointer to the data object
    //////////////////////////////////////////////////////////////////////
    const T* get_ptr() const;

    //////////////////////////////////////////////////////////////////////
    /// Method to convert this array into a string representation for
    /// printing purposes. Output is formatted either as a single, long
    /// string of HEX characters if 'printable' is false or is a pretty
    /// printed 16-bytes across with underscores as follows if
    /// 'printable' is true
    ///\code
    /// [AAAABBBB_CCCCDDDD_EEEEFFFF_00001111
    ///  22223333_44445555_66667777_88889999
    ///  22223333_44445555_66667777_88889999
    ///  22223333_44445555_66667777_88889999
    ///  22223333_44445555_66667777_88889999
    ///  22223333_44445555_66667777_88889999
    ///  22223333_44445555_66667777_88889999]
    ///\endcode
    /// @param printable - if false, output is a single string of HEX
    ///                    characters. If true, enables pretty_printing
    ///                    of the array with formatting
    /// @param indent    - default indentation for pretty printing
    ///                    ignored if printable is false
    /// @param xml       - Print as an XML data object as found below
    ///\verbatim
    /// 22223333444455556666777788889999
    /// 2222333344445555666677778888
    ///\endverbatim
    /// @return string representation of this array
    //////////////////////////////////////////////////////////////////////
    std::string to_string(bool printable=false, int indent=10, bool xml=false);

    //////////////////////////////////////////////////////////////////////
    /// Method to compare arrays side by side for debug as shown below
    /// prints to std::err
    ///
    ///\code
    ///  AAAABBBB_CCCCDDDD_EEEEFFFF_00001111     AAAABBBB_CCCCDDDD_EEEEFFFF_00001111
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_FE889999 <-- MISMATCH
    ///  22223333_44445555_66667777_88889999     22223333_44445555_66667777_88889999
    ///\endcode
    /// @param expect - Expected data to print
    /// @param indent - default indentation for pretty printing
    /// @return string representation of this array
    //////////////////////////////////////////////////////////////////////
    std::string debug(jarray<T>& expect, int indent=10);

    //////////////////////////////////////////////////////////////////////
    /// Method to compare two different arrays. First compares array
    /// size then iterates through all array values and compares them
    /// for equality
    /// @param rhs - array to compare with this array
    /// @return true/false value for array comparison
    //////////////////////////////////////////////////////////////////////
    bool operator==(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to compare two different arrays. First compares array
    /// size then iterates through all array values and compares them
    /// for equality
    /// @param rhs - array to compare with this array
    /// @return true/false value for array comparison
    //////////////////////////////////////////////////////////////////////
    bool operator==(const jarray<T>& rhs) const;

    //////////////////////////////////////////////////////////////////////
    /// Method to compare two different arrays. First compares array
    /// size then iterates through all array values and compares them
    /// for inequality
    /// @param rhs - array to compare with this array
    /// @return true/false value for array comparison
    //////////////////////////////////////////////////////////////////////
    bool operator!=(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to compare two different arrays. First compares array
    /// size then iterates through all array values and compares them
    /// for inequality
    /// @param rhs - array to compare with this array
    /// @return true/false value for array comparison
    //////////////////////////////////////////////////////////////////////
    bool operator!=(const jarray<T>& rhs) const;

    //////////////////////////////////////////////////////////////////////
    /// Method to XOR two different arrays
    /// @param rhs - array to XOR with this array
    //////////////////////////////////////////////////////////////////////
    void operator^=(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to OR two different arrays
    /// @param rhs - array to OR with this array
    //////////////////////////////////////////////////////////////////////
    void operator|=(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to AND two different arrays
    /// @param rhs - array to AND with this array
    //////////////////////////////////////////////////////////////////////
    void operator&=(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to MULTIPLY two different arrays
    /// @param rhs - array to MULTIPLY with this array
    //////////////////////////////////////////////////////////////////////
    void operator*=(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to ADD two different arrays
    /// @param rhs - array to ADD with this array
    //////////////////////////////////////////////////////////////////////
    void operator+=(jarray<T>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Method to return array value at index
    /// @param index - location of array element to return
    /// @return array element at index
    //////////////////////////////////////////////////////////////////////
    T& operator[](unsigned int index);

    //////////////////////////////////////////////////////////////////////
    /// Method to return const array value at index
    /// @param index - location of array element to return
    /// @return const array element at index
    //////////////////////////////////////////////////////////////////////
    const T& operator[](unsigned int index) const;

    //////////////////////////////////////////////////////////////////////
    /// Method to return endianness format of this array
    /// @return endianness format for this array
    //////////////////////////////////////////////////////////////////////
    endian_t get_format();

    //////////////////////////////////////////////////////////////////////
    /// Method to scrub array in memory
    //////////////////////////////////////////////////////////////////////
    void serase();

private:

    void endian_swap();

    std::vector<T> m_data;
    endian_t m_endian;
};

//
// Standard constructor
template <typename T>
jarray<T>::jarray() : m_data(0),
                      m_endian(BIG)
{}

//
// Constructor for given size
template <typename T>
jarray<T>::jarray(unsigned int size) : m_data(size),
                                       m_endian(BIG)
{}

//
// Constructor to initialize with given value and size
template <typename T>
jarray<T>::jarray(unsigned int size, T value, endian_t format) : m_data(size),
                                                                 m_endian(format)
{
    for (unsigned int i=0; i<size; i++) {
        m_data[i] = value;
    }
}

//
// Copy Constructor
template <typename T>
jarray<T>::jarray(const jarray<T>& rhs, endian_t format) : m_data(rhs.m_data),
                                                           m_endian(format)
{}

//
// Constructor to initialize from HEX string
template <typename T>
jarray<T>::jarray(const std::string& rhs, endian_t format, bool encoded) : m_data(0),
                                                                           m_endian(format)
{
    std::string conv(rhs);
    std::regex pat("[\\s+\t\f\r\n\b_]");

    if (encoded) {
        m_data = std::vector<uint8_t>(conv.begin(), conv.end());
    }
    else {
        jarray<uint8_t> tmpp(0);
        
        conv = std::regex_replace(conv, pat, "");

        if ((conv.size() % 2) != 0) {
            std::cerr << "In jarray::constr_string(), strings must be an even number of HEX digits, found :" << std::endl
                      << conv << std::endl;
        }
        else {

            for (unsigned int i=0; i<conv.size(); i=i+2) {
                uint8_t tmp = static_cast<uint8_t>(conv[i]) & 0xFF;
                uint8_t tmp2 = static_cast<uint8_t>(conv[i+1]) & 0xFF;
    
                // convert first character
                if ((tmp >= 0x30) && (tmp <= 0x39)) {
                    tmp -= 0x30;
                    tmp = ((tmp & 0x0F) << 4);
                }
                else if ((tmp >= 0x41) && (tmp <= 0x46)) {
                    tmp -= 0x37;
                    tmp = ((tmp & 0x0F) << 4);
                }
                else if ((tmp >= 0x61) && (tmp <= 0x66)) {
                    tmp -= 0x57;
                    tmp = ((tmp & 0x0F) << 4);
                }
                else {

                    std::cerr << "In jarray::constr_string(), non-HEX character in string : "
                              << std::hex << conv[i] << std::dec
                              << std::endl;
                    return;
                }
    
                // convert second character
                if ((tmp2 >= 0x30) && (tmp2 <= 0x39)) {
                    tmp2-= 0x30;
                }
                else if ((tmp2 >= 0x41) && (tmp2 <= 0x46)) {
                    tmp2 -= 0x37;
                }
                else if ((tmp2 >= 0x61) && (tmp2 <= 0x66)) {
                    tmp2 -= 0x57;
                }
                else {

                    std::cerr << "In jarray::constr_string(), non-HEX character in string+1 : "
                              << std::hex << conv[i+1] << std::dec
                              << std::endl;
                    return;
                }
    
                // add the HEX character to the uint8_t array
                tmp2 = (tmp | (tmp2 & 0x0F));
                tmpp.push_back(tmp2);
            }
    
            // convert to type array
            jarray<T> newtmp(tmpp, format);
            m_data = newtmp.m_data;
        }
    }
}

//
// Constructor to initialize from vector, must provide vector endianess
template <typename T>
jarray<T>::jarray(const std::vector<T>& rhs, endian_t format) : m_data(rhs),
                                                                m_endian(format)
{}

//
// Constructor to initialize from byte pointer, must provide length and endianess
template <typename T>
jarray<T>::jarray(const uint8_t* rhs, unsigned int size, endian_t format) : m_data(size),
                                                                            m_endian(format)
{
    for (unsigned int i=0; i<size; i++) {
        m_data[i] = *rhs++;
    }
}

//
// Constructor to initialize from one type to another
template <typename T>
template <typename TT>
jarray<T>::jarray(jarray<TT>& rhs, endian_t format) : m_data(0),
                                                      m_endian(format)
{
    if (rhs.get_size() != 0) {
        if ((sizeof(T) == 1) && (sizeof(TT) == 2)) {
            m_data.resize(rhs.get_size()*2);
            for (unsigned int i=0; i<m_data.size(); i=i+2) {
                uint16_t tmp = rhs[i/2];
                m_data[i] = ((tmp >> 8) & 0xFF);
                m_data[i+1] = (tmp & 0xFF);
            }
        }
        else if ((sizeof(T) == 1) && (sizeof(TT) == 4)) {
            m_data.resize(rhs.get_size()*4);
            for (unsigned int i=0; i<m_data.size(); i=i+4) {
                uint32_t tmp = rhs[i/4];
                m_data[i]   = ((tmp >> 24) & 0xFF);
                m_data[i+1] = ((tmp >> 16) & 0xFF);
                m_data[i+2] = ((tmp >> 8) & 0xFF);
                m_data[i+3] = (tmp & 0xFF);
            }
        }
        else if ((sizeof(T) == 1) && (sizeof(TT) == 8)) {
            m_data.resize(rhs.get_size()*8);
            for (unsigned int i=0; i<m_data.size(); i=i+8) {
                uint64_t tmp = rhs[i/8];
                m_data[i]   = ((tmp >> 56) & 0xFF);
                m_data[i+1] = ((tmp >> 48) & 0xFF);
                m_data[i+2] = ((tmp >> 40) & 0xFF);
                m_data[i+3] = ((tmp >> 32) & 0xFF);
                m_data[i+4] = ((tmp >> 24) & 0xFF);
                m_data[i+5] = ((tmp >> 16) & 0xFF);
                m_data[i+6] = ((tmp >> 8) & 0xFF);
                m_data[i+7] = (tmp & 0xFF);
            }
        }
        else if ((sizeof(T) == 2) && (sizeof(TT) == 1)) {
            m_data.resize(rhs.get_size()/2 + (((rhs.get_size()%2) == 0) ? 0 : 1));
            for (unsigned int i=0; i<rhs.get_size(); i=i+2) {
                uint16_t tmp = rhs[i];
                tmp = (tmp << 8) | rhs[i+1];
                m_data[i/2] = tmp;
            }
        }
        else if ((sizeof(T) == 2) && (sizeof(TT) == 4)) {
            m_data.resize(rhs.get_size()*2);
            for (unsigned int i=0; i<rhs.get_size(); i++) {
                uint32_t tmp = rhs[i];
                m_data[2*i] = ((tmp >> 16) & 0xFFFF);
                m_data[(2*i) + 1] = (tmp & 0xFFFF);
            }
        }
        else if ((sizeof(T) == 2) && (sizeof(TT) == 8)) {
            m_data.resize(rhs.get_size()*4);
            for (unsigned int i=0; i<rhs.get_size(); i++) {
                uint64_t tmp = rhs[i];
                m_data[4*i]       = ((tmp >> 48) & 0xFFFF);
                m_data[(4*i) + 1] = ((tmp >> 32) & 0xFFFF);
                m_data[(4*i) + 2] = ((tmp >> 16) & 0xFFFF);
                m_data[(4*i) + 3] = (tmp & 0xFFFF);
            }
        }
        else if ((sizeof(T) == 4) && (sizeof(TT) == 1)) {
            m_data.resize(rhs.get_size()/4 + (((rhs.get_size()%4) == 0) ? 0 : 1));
            for (unsigned int i=0; i<rhs.get_size(); i=i+4) {
                uint32_t tmp = rhs[i];
                tmp = ((tmp << 8) | rhs[i+1]);
                tmp = ((tmp << 8) | rhs[i+2]);
                tmp = ((tmp << 8) | rhs[i+3]);
                m_data[i/4] = tmp;
            }
        }
        else if ((sizeof(T) == 4) && (sizeof(TT) == 2)) {
            m_data.resize(rhs.get_size()/2 + (((rhs.get_size()%2) == 0) ? 0 : 1));
            for (unsigned int i = 0; i<rhs.get_size(); i=i+2) {
                uint32_t tmp = rhs[i];
                tmp = ((tmp << 16) | rhs[i+1]);
                m_data[i/2] = tmp;
            }
        }
        else if ((sizeof(T) == 4) && (sizeof(TT) == 8)) {
            m_data.resize(rhs.get_size()*2);
            for (unsigned int i = 0; i<rhs.get_size(); i++) {
                uint64_t tmp = rhs[i];
                m_data[i] = ((tmp >> 32) & 0xFFFFFFFF);
                m_data[i+1] = (tmp & 0xFFFFFFFF);
            }
        }
        else if ((sizeof(T) == 8) && (sizeof(TT) == 1)) {
            m_data.resize(rhs.get_size()/8 + (((rhs.get_size()%8) == 0) ? 0 : 1));
            for (unsigned int i = 0; i<rhs.get_size(); i=i+8) {
                uint64_t tmp = rhs[i];
                tmp   = ((tmp << 8) | rhs[i+1]);
                tmp   = ((tmp << 8) | rhs[i+2]);
                tmp   = ((tmp << 8) | rhs[i+3]);
                tmp   = ((tmp << 8) | rhs[i+4]);
                tmp   = ((tmp << 8) | rhs[i+5]);
                tmp   = ((tmp << 8) | rhs[i+6]);
                tmp   = ((tmp << 8) | rhs[i+7]);
                m_data[i/8] = tmp;
            }
        }
        else if ((sizeof(T) == 8) && (sizeof(TT) == 2)) {
            m_data.resize(rhs.get_size()/4 + (((rhs.get_size()%4) == 0) ? 0 : 1));
            for (unsigned int i = 0; i<rhs.get_size(); i=i+4) {
                uint64_t tmp = rhs[i];
                tmp   = ((tmp << 16) | rhs[i+1]);
                tmp   = ((tmp << 16) | rhs[i+2]);
                tmp   = ((tmp << 16) | rhs[i+3]);
                m_data[i/4] = tmp;
            }
        }
        else if ((sizeof(T) == 8) && (sizeof(TT) == 4)) {
            m_data.resize(rhs.get_size()/2 + (((rhs.get_size()%2) == 0) ? 0 : 1));
            for (unsigned int i = 0; i<rhs.get_size(); i=i+2) {
                uint64_t tmp = rhs[i];
                tmp   = ((tmp << 32) | rhs[i+1]);
                m_data[i/2] = tmp;
            }
        }
        else if (sizeof(T) == sizeof(TT)) {
            m_data.resize(rhs.get_size());
            for (unsigned int i = 0; i<rhs.get_size(); i++) {
                if (sizeof(T) == 4) {
                    m_data[i] = rhs[i];
                }
                else if (sizeof(T) == 2) {
                    m_data[i] = rhs[i];
                }
                else {
                    m_data[i] = rhs[i];
                }
            }
        }
        else {
            std::cerr << "In jarray() conversion constructor, unknown combination of sizes requested" << std::endl
                        << " Width of array : " << sizeof(T) << std::endl
                        << " Width of new array : " << sizeof(TT) << std::endl;
        }
    
        // swap endianness if needed
        if (m_endian != rhs.get_format()) {
            endian_swap();
        }
    }
}

//
// returns the size of the array
template <typename T>
unsigned int jarray<T>::get_size() 
{
    return m_data.size();
}

//
// returns true if size of array is zero
template <typename T>
bool jarray<T>::empty() 
{
    return m_data.empty();
}

//
// splits number of elements from front of this array and returns them
// modifies the original array to the new size
template <typename T>
jarray<T> jarray<T>::split(unsigned int elements) 
{
    // boundary check the split
    if (elements > m_data.size()) {
        std::cerr << "Number of elements requested in ::split() exceeds array length" << std::endl;
        return jarray<T>(0);
    }

    jarray<T> result(elements);

    for (unsigned int i=0; i<elements; i++) {
        result[i] = m_data[i];
    }

    m_data.erase(m_data.begin(), m_data.begin()+elements);

    return result;
}

//
// extracts elements at index and returns them
template <typename T>
jarray<T> jarray<T>::extract(unsigned int index, unsigned int elements) 
{
    // boundary check the extraction
    if ((index+elements) > m_data.size()) {
        std::cerr << "Number of elements in ::extract() : " << (index+elements) << " goes beyond the end of the array : " << m_data.size() << std::endl
                  << " IDX : " << index << std::endl
                  << " ELE : " << elements << std::endl
                  << " DAT : " << this->to_string() << std::endl;
        return jarray<T>(0);
    }

    jarray<T> result(elements);

    for (unsigned int i=0; i<elements; i++) {
        result[i] = m_data[i+index];
    }

    return result;
}

//
// adds the element to the end of the array
template <typename T>
void jarray<T>::push_back(T rhs)
{
    m_data.push_back(rhs);
}

//
// deletes the element from the end of the array
template <typename T>
void jarray<T>::pop_back()
{
    m_data.pop_back();
}

//
// resize the array to the new size
template <typename T>
void jarray<T>::resize(unsigned int newsize) {
    m_data.resize(newsize);
}

//
// appends rhs onto this array
template <typename T>
void jarray<T>::append(jarray<T> rhs) {
    unsigned int curr = m_data.size();

    m_data.resize(m_data.size()+rhs.get_size());

    for (unsigned int i=curr; i<m_data.size(); i++) {
        m_data[i] = rhs[i-curr];
    }
}

//
// inserts rhs into this array, resizes if necessary
template <typename T>
void jarray<T>::insert(unsigned int index, jarray<T>& rhs) {
    // create a new vector with the correct size
    std::vector<T> temp(rhs.get_size() + m_data.size());

    // insert the new elements into the middle of the old ones
    for (unsigned int i=0; i<temp.size(); i++) {
        if (i < index) {
            temp[i] = m_data[i];
        }
        else if (i < (index + rhs.get_size())) {
            temp[i] = rhs[(i-index)];
        }
        else {
            temp[i] = m_data[i-rhs.get_size()];
        }
    }

    // assign the internal element with the new vector
    m_data = temp;
}

//
// updates the array starting at index with the
// data found in rhs, resizes if necessary
// current values starting at index and spanning
// rhs.size() are replaced with rhs
template <typename T>
void jarray<T>::update(unsigned int index, jarray<T>& rhs) {
    // if the new array will fall off the end, resize
    if ((index + rhs.get_size()) > m_data.size()) {
        m_data.resize(m_data.size() + ((index + rhs.get_size()) - m_data.size()));
    }

    // update the current contexts with the new ones
    for (unsigned int i=index; i<(index+rhs.get_size()); i++) {
        m_data[i] = rhs[i-index];
    }
}

//
// erase the specified number of elements from the array
// starting at index and ending at index+elements
template <typename T>
void jarray<T>::erase(unsigned int index, unsigned elements) {
    m_data.erase(m_data.begin()+index, m_data.begin()+index+elements);
}

//
// intersect the two arrays and return shared values
template <typename T>
void jarray<T>::intersect(jarray<T>& rhs) {
    std::vector<T> temp;

    // search for shared values
    for(unsigned int i=0; i<rhs.get_size(); i++) {
        for(unsigned int j=0; j<m_data.size(); j++) {
            if (m_data[j]==rhs[i]) {
                temp.push_back(m_data[j]);
            }
        }
    }

    // replace original array with intersected array
    m_data = temp;
}

//
// reverses the elements in the array
template <typename T>
void jarray<T>::reverse() {
    std::vector<T> temp(m_data.size());

    // reverse the elements
    for (unsigned int i=0; i<temp.size(); i++) {
        temp[i] = m_data[m_data.size()-1-i];
    }

    m_data = temp;
}

//
// returns the pointer to the underlying data object of the array
template <typename T>
T* jarray<T>::get_ptr() {
    return m_data.data();
}

//
// returns the pointer to the underlying data object of the array
template <typename T>
const T* jarray<T>::get_ptr() const {
    return m_data.data();
}

//
// converts this array to string and returns result
template <typename T>
std::string jarray<T>::to_string(bool printable, int indent, bool xml) {

    std::string result;
    std::ostringstream myhex;
    std::string myindent(indent, 32);

    if (m_data.empty()) {
        result = std::string("");
    }
    else {
        jarray<uint8_t> tmp(*this, m_endian);

        for (unsigned int i=0; i<tmp.get_size(); i++) {
            myhex << std::setw(2)
                  << std::setfill('0')
                  << std::uppercase
                  << std::hex
                  << +tmp[i];

            // if we're priting the array, make it pretty
            if (printable) {
                // if we're not on the last element, insert items
                if ((i+1) != tmp.get_size()) {
                    if (((i + 1) % 16) == 0) {
                        myhex << "\n " << myindent;
                    }
                    else if (((i + 1) % 4) == 0) {
                        myhex << "_";
                    }
                }
            }
        }

        result = std::string(myhex.str());
    }

    // if we're printing the array, make it pretty
    if (printable) {
        if (!xml) {
            result.insert(0, "\n"+myindent+"[");
            result.append("]\n");
        }
        else {
            result.insert(0, "\n "+myindent);
            result.append("\n     ");
        }
    }

    return result;
}

//
// compare two arrays and identify differences
template <typename T>
std::string jarray<T>::debug(jarray<T>& expect, int indent) {

    bool error=false;
    std::ostringstream myhex;
    std::ostringstream myhex2;
    std::string myindent(indent, 32);
    std::string myspace(3, 32);
    std::string arrow = "  <-- MISMATCH";

    // convert to byte arrays to simplyfy the code
    jarray<uint8_t> tmp(*this, m_endian);
    jarray<uint8_t> tmp2(expect, expect.get_format());

    for (unsigned int i=0; i<tmp.get_size(); i++) {
        myhex << std::setw(2)
              << std::setfill('0')
              << std::uppercase
              << std::hex
              << +tmp[i];

        myhex2 << std::setw(2)
               << std::setfill('0')
               << std::uppercase
               << std::hex
               << +tmp2[i];

        if (tmp[i] != tmp2[i]) {
            error = true;
        }

        // if we're not on the last element, insert items
        if ((i+1) != tmp.get_size()) {
            if (((i + 1) % 16) == 0) {
                if (error) {
                    myhex << myspace << myhex2.str() << arrow << "\n" << myindent;
                }
                else {
                    myhex << myspace << myhex2.str() << "\n" << myindent;
                }
                myhex2.str("");
                myhex2.clear();
                error = false;
            }
            else if (((i + 1) % 4) == 0) {
                myhex << "_";
                myhex2 << "_";
            }
        }
        else {
            if (tmp.get_size()%16 != 0) {
                std::string empty((2*(16-(tmp.get_size()%16))), 32);
                empty += (((16-(tmp.get_size()%16)) >= 12) ? "   " :
                         (((16-(tmp.get_size()%16)) >= 8) ? "  " :
                         (((16-(tmp.get_size()%16)) >= 4) ? " " : "")));

                if (error) {
                    myhex << myspace << empty << myhex2.str() << empty << arrow << "\n";
                }
                else {
                    myhex << myspace << empty << myhex2.str() << empty << "\n";
                }
            }
            else {
                if (error) {
                    myhex << myspace << myhex2.str() << arrow << "\n";
                }
                else {
                    myhex << myspace << myhex2.str() << "\n";
                }
            }
        }
    }

    std::string title;
    title += myindent + "\n                        ACTUAL                                EXPECT                 \n";
    title += myindent + "-------------------------------------------------------------------------\n";
    std::string result(myhex.str());
    result.insert(0, title+myindent);
    return result;
}

//
// compares this array to rhs to determine if they are equal
template <typename T>
bool jarray<T>::operator==(jarray<T>& rhs) {
    if (m_data.size() != rhs.get_size()) {
        return false;
    }

    for(unsigned int i=0; i<rhs.get_size(); i++) {
        if (m_data[i] != rhs[i]) {
            return false;
        }
    }

    return true;
}

//
// compares this array to rhs to determine if they are equal
template <typename T>
bool jarray<T>::operator==(const jarray<T>& rhs) const {
    if (m_data.size() != rhs.get_size()) {
        return false;
    }

    for(unsigned int i=0; i<rhs.get_size(); i++) {
        if (m_data[i] != rhs[i]) {
            return false;
        }
    }

    return true;
}

//
// compares this array to rhs to determine if they are not equal
template <typename T>
bool jarray<T>::operator!=(jarray<T>& rhs) {
    return !(*this == rhs);
}

//
// compares this array to rhs to determine if they are not equal
template <typename T>
bool jarray<T>::operator!=(const jarray<T>& rhs) const {
    return !(*this == rhs);
}

//
// XOR this array with rhs
template <typename T>
void jarray<T>::operator^=(jarray<T>& rhs) {
    if (m_data.size() != rhs.get_size()) {
        std::cerr << "In jarray ^=, this array and RHS are of different lengths" << std::endl
        << " size of THIS : " << m_data.size() << std::endl
        << " size of RHS : " << rhs.get_size() << std::endl;
    }
    else {
        for (unsigned int i=0; i<rhs.get_size(); i++) {
            m_data[i] = m_data[i] ^ rhs[i];
        }
    }
}

//
// OR this array with rhs
template <typename T>
void jarray<T>::operator|=(jarray<T>& rhs) {
    if (m_data.size() != rhs.get_size()) {
        std::cerr << "In jarray |=, this array and RHS are of different lengths" << std::endl
                  << " size of THIS : " << m_data.size() << std::endl
                  << " size of RHS : " << rhs.get_size() << std::endl;
    }
    else {
        for (unsigned int i=0; i<rhs.get_size(); i++) {
            m_data[i] = m_data[i] | rhs[i];
        }
    }
}

//
// AND this array with rhs
template <typename T>
void jarray<T>::operator&=(jarray<T>& rhs) {
    if (m_data.size() != rhs.get_size()) {
        std::cerr << "In jarray &=, this array and RHS are of different lengths" << std::endl
        << " size of THIS : " << m_data.size() << std::endl
        << " size of RHS : " << rhs.get_size() << std::endl;
    }
    else {
        for (unsigned int i = 0; i < rhs.get_size(); i++) {
            m_data[i] = m_data[i] & rhs[i];
        }
    }
}

//
// MULTIPLY this array with rhs
template <typename T>
void jarray<T>::operator*=(jarray<T>& rhs) {
    if (m_data.size() != rhs.get_size()) {
        std::cerr << "In jarray *=, this array and RHS are of different lengths" << std::endl
        << " size of THIS : " << m_data.size() << std::endl
        << " size of RHS : " << rhs.get_size() << std::endl;
    }
    else {
        for (unsigned int i = 0; i < rhs.get_size(); i++) {
            m_data[i] = static_cast<T>(m_data[i] * rhs[i]);
        }
    }
}

//
// ADD this array with rhs
template <typename T>
void jarray<T>::operator+=(jarray<T>& rhs) {
    if (m_data.size() != rhs.get_size()) {
        std::cerr << "In jarray +=, this array and RHS are of different lengths" << std::endl
        << " size of THIS : " << m_data.size() << std::endl
        << " size of RHS : " << rhs.get_size() << std::endl;
    }
    else {
        for (unsigned int i = 0; i < rhs.get_size(); i++) {
            m_data[i] = m_data[i] + rhs[i];
        }
    }
}

//
// returns value at index in this array
template <typename T>
T& jarray<T>::operator[](unsigned int index) {
    return m_data[index];
}

//
// returns value at index in this array
template <typename T>
const T& jarray<T>::operator[](unsigned int index) const {
    return m_data[index];
}

//
// returns endian for this array
template <typename T>
endian_t jarray<T>::get_format() { 
    return m_endian; 
}

//
// scrubs the memory of this array
template <typename T>
void jarray<T>::serase() {
    if (sizeof(T) == 1) {
        unsigned int idx;
        unsigned int seed;
        std::vector<uint8_t> pattern(m_data.size(), 0);
        std::vector<unsigned int> randpat = {4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
                                             14, 15, 16, 17, 18, 19, 20, 21,
                                             22, 23, 24, 25, 26, 27, 28, 29, 30};

        // for random patterns we don't care about the seed
        CryptoPP::AutoSeededRandomPool osrand;
    
        // randomize the order of patterns 4-30
        seed = std::chrono::system_clock::now().time_since_epoch().count();
        std::shuffle(randpat.begin(), randpat.end(), std::default_random_engine(seed));
    
        // choose pattern and overwrite data
        for(unsigned int i=0; i<35; i++) {
            if ((i>=4) && (i<=30)) {
                idx = randpat[i-4];
            }
            else {
                idx = i;
            }

            switch (idx) {
                case  0:
                case  1:
                case  2:
                case  3: osrand.GenerateBlock(pattern.data(), pattern.size()); break;
                case  4: pattern = std::vector<uint8_t>(m_data.size(), 0x55); break;
                case  5: pattern = std::vector<uint8_t>(m_data.size(), 0xAA); break;
                case  6: {
                         pattern = std::vector<uint8_t>(1,0x92); // 0x924924
                         pattern.push_back(0x49); // 0x924924
                         pattern.push_back(0x24); // 0x924924
                         break;
                }
                case  7: {
                         pattern = std::vector<uint8_t>(1,0x49); // 0x492492
                         pattern.push_back(0x24); // 0x492492
                         pattern.push_back(0x92); // 0x492492
                         break;
                }
                case  8: {
                         pattern = std::vector<uint8_t>(1,0x24); // 0x249249
                         pattern.push_back(0x92); // 0x249249
                         pattern.push_back(0x49); // 0x249249
                         break;
                }
                case  9: pattern = std::vector<uint8_t>(m_data.size(), 0x00); break;
                case 10: pattern = std::vector<uint8_t>(m_data.size(), 0x11); break;
                case 11: pattern = std::vector<uint8_t>(m_data.size(), 0x22); break;
                case 12: pattern = std::vector<uint8_t>(m_data.size(), 0x33); break;
                case 13: pattern = std::vector<uint8_t>(m_data.size(), 0x44); break;
                case 14: pattern = std::vector<uint8_t>(m_data.size(), 0x55); break;
                case 15: pattern = std::vector<uint8_t>(m_data.size(), 0x66); break;
                case 16: pattern = std::vector<uint8_t>(m_data.size(), 0x77); break;
                case 17: pattern = std::vector<uint8_t>(m_data.size(), 0x88); break;
                case 18: pattern = std::vector<uint8_t>(m_data.size(), 0x99); break;
                case 19: pattern = std::vector<uint8_t>(m_data.size(), 0xAA); break;
                case 20: pattern = std::vector<uint8_t>(m_data.size(), 0xBB); break;
                case 21: pattern = std::vector<uint8_t>(m_data.size(), 0xCC); break;
                case 22: pattern = std::vector<uint8_t>(m_data.size(), 0xDD); break;
                case 23: pattern = std::vector<uint8_t>(m_data.size(), 0xEE); break;
                case 24: pattern = std::vector<uint8_t>(m_data.size(), 0xFF); break;
                case 25: {
                         pattern = std::vector<uint8_t>(1,0x92); // 0x924924
                         pattern.push_back(0x49); // 0x924924
                         pattern.push_back(0x24); // 0x924924
                         break;
                }
                case 26: {
                         pattern = std::vector<uint8_t>(1,0x49); // 0x492492
                         pattern.push_back(0x24); // 0x492492
                         pattern.push_back(0x92); // 0x492492
                         break;
                }
                case 27: {
                         pattern = std::vector<uint8_t>(1,0x24); // 0x249249
                         pattern.push_back(0x92); // 0x249249
                         pattern.push_back(0x49); // 0x249249
                         break;
                }
                case 28: {
                         pattern = std::vector<uint8_t>(1,0x6D); // 0x6DB6DB
                         pattern.push_back(0xB6); // 0x6DB6DB
                         pattern.push_back(0xDB); // 0x6DB6DB
                         break;
                }
                case 29: {
                         pattern = std::vector<uint8_t>(1,0xB6); // 0xB6DB6D
                         pattern.push_back(0xDB); // 0xB6DB6D
                         pattern.push_back(0x6D); // 0xB6DB6D
                         break;
                }
                case 30: {
                         pattern = std::vector<uint8_t>(1,0xDB); // 0xDB6DB6
                         pattern.push_back(0x6D); // 0xDB6DB6
                         pattern.push_back(0xB6); // 0xDB6DB6
                         break;
                }
                case 31:
                case 32:
                case 33:
                case 34: osrand.GenerateBlock(pattern.data(), pattern.size()); break;
                default: pattern = std::vector<uint8_t>(m_data.size(), 0x00); break;
            }
    
            // overwrite the array
            if ((idx==6)  || (idx==7)  || (idx==8) ||
                (idx==25) || (idx==26) || (idx==27) ||
                (idx==28) || (idx==29) || (idx==30)) {
                for(unsigned int j=0; j<m_data.size(); j++) {
                    m_data[j] = pattern[(j%3)];
                }
            }
            else {
                for(unsigned int k=0; k<m_data.size(); k++) {
                    m_data[k] = pattern[k];
                }
            }

            if (i == 30) {
                pattern = std::vector<uint8_t>(m_data.size(), 0);
            }
        }
    
        // erase the scrubbed memory
        // this may cause a segfault when it tries to delete an array of m_data.size()=0
        m_data.erase(m_data.begin(), m_data.begin()+m_data.size());
    }
}

//
// swaps the values in this array for endianness
template <typename T>
void jarray<T>::endian_swap() {
    if (sizeof(T) == 1) {
        reverse();
    }
    else if (sizeof(T) == 2) {
        for(unsigned int i=0; i<m_data.size(); i++) {
            uint16_t tmp = m_data[i];
            m_data[i] = ((tmp >> 8) |
                         (tmp << 8));
        }
    }
    else if (sizeof(T) == 4) {
        for(unsigned int i=0; i<m_data.size(); i++) {
            uint32_t tmp = m_data[i];
            m_data[i] = ((tmp >> 24) |
                        ((tmp >> 8) & 0xFF00) |
                        ((tmp & 0xFF) << 24) |
                        ((tmp & 0xFF00) << 8));
        }
    }
    else if (sizeof(T) == 8) {
        for(unsigned int i=0; i<m_data.size(); i++) {
            uint64_t tmp = m_data[i];
            m_data[i] = ((tmp >> 56) |
                        ((tmp >> 40) & 0xFF00) |
                        ((tmp >> 24) & 0xFF0000) |
                        ((tmp >>  8) & 0xFF000000) |
                        ((tmp & 0xFF) << 56) |
                        ((tmp & 0xFF00) << 40) |
                        ((tmp & 0xFF0000) << 24) |
                        ((tmp & 0xFF000000) << 8));
        }
    }
    else {
        std::cerr << "In jarray::endian_swap(), unknown width for jarray : " << sizeof(T) << std::endl;
    }
}

}

#endif /* JARRAY_H_ */

