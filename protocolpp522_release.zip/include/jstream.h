#ifndef JPROTOCOL_JSTREAM_H_
#define JPROTOCOL_JSTREAM_H_

///
///\class jstream jstream.h "include/jstream.h"
///
///\section STREAM Stream class for Protocol++&reg; (ProtocolPP&reg;)
///
/// JSTREAM is the object in Protocol++&reg; (ProtocolPP&reg;) that holds all information pertaining to a
/// stream or flow of packets. When processing packets in a cryptographic context, the packets
/// require a set a parameters to process the information. This includes keys, IVs, salts, 
/// sequence numbers, type of flow, and other parameters
///
/// In Protocol++&reg;, the parameters for a flow are gathered together in a security association.
/// The type identifies to the user what protocol is being used in order to cast the jprotocol
/// object to the correct type as well as the direction of processing. Streams that have packets
/// with random IVs may also set the postprocess flag to signify to the testbench it's need
/// to decrypt and verify the payload and checksum of the packet
///
/// The different constructors are useful for different situations. At times it may be necessary
/// to keep the processing engine with the stream. In this case, the first constructor
/// should be used:
///\code
///
/// std::shared_ptr<jwifisa> wifisec = std::make_shared<jwifisa>();
/// std::shared_ptr<jwifi>   wifieng = std::make_shared<jwifi>(wifisec);
///
/// jstream(std::string("stream1"),
///         direction_t::DECAP,
///         protocol_t::WIFI,
///         false,
///         wifisec,
///         wifieng);
///\endcode
/// Engines update the security association with new sequence numbers and IV values during
/// processing allowing the engine to be deleted after updating the security association
/// in the jstream object. This reduces the memory footprint of the stream object to only
/// the security association, a string for the name and an enumerator
///
/// The second constructor can be used to generate a stream object with all information
/// necessary for processing data in the stream. Use of the second constructor is for
/// these situations:
///\code
///
/// std::shared_ptr<jltesa> ltesec = std::make_shared<jltesa>();
///
/// jstream(std::string("stream2"),
///         direction_t::ENCAP,
///         protocol_t::LTE,
///         false,
///         ltesec);
///\endcode
/// The final constructor can be used with a security engine that's already been created
///\code 
///
/// std::shared_ptr<jipsecsa> ipsec = std::make_shared<jipsecsa>();
/// std::shared_ptr<jipsec>   ipeng = std::make_shared<jipsec>(ipsec);
///
/// jstream(std::string("stream3"),
///         direction_t::DECAP,
///         protocol_t::IPSEC,
///         true,
///         ipeng);
///\endcode
/// Fields may be set using the accessor function "set". They are templated to access the
/// type of field desired. STREAMSIZE is necessary to provide support for CAAM/SEC shared
/// descriptor size (in 32-bit words)
///\code
///
/// void set_field<std::string>(field_t::NAME, std::string("stream3"));
///
/// void set_field<unsigned int>(field_t::STREAMSIZE, 32);
///
/// void set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP);
///
/// void set_field<protocol_t>(field_t::TYPE, protocol_t::IPSEC);
///
/// void set_field<bool>(field_t::SETUP, true);
///\endcode
/// The security association and engine for the stream can be set using the functions below
/// Security associations and engines are required to be wrapped in a shared pointer
///\code
///
/// void set_security(security);
///
/// void set_engine(engine);
///\endcode
/// Fields may be retrieved using the accessor "get" funcion. They are templated to retrieve
/// the type of field requested
///\code
///
/// std::string name = get_field<std::string>(field_t::NAME);
///
/// unsigned int size = get_field<unsigned int>(field_t::STREAMSIZE);
///
/// direction_t dir = get_field<direction_t>(field_t::DIRECTION);
///
/// protocol_t prot = get_field<protocol_t>(field_t::TYPE);
///
/// bool postproc = get_field<bool>(field_t::POSTPROCESS);
///
/// bool setup = get_field<bool>(field_t::SETUP);
///\endcode
///
/// The security association can be retrieved by passing a shared pointer of the correct type found
/// by calling the get_field<protocol_t>(field_t::TYPE) function
///\code
///
/// std::shared_ptr<jipsecsa> ipsec;
///
/// void get_security(ipsec);
///\endcode
/// The encryption engine for the stream can be retrieved by passing the correct shared pointer
/// to the get_engine() function. The type can be found in the field_t::TYPE
///\code
///
/// std::shared_ptr<jipsec> newengine = std::make_shared<jipsec>();
///
/// void get_engine(newengine);
///\endcode
/// The encryption engine if not needed can be deleted from the stream by using the following
/// function
///\code
///
/// void jstream::clean();
///\endcode
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::tinyxml2
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jreplay
/// @see ProtocolPP::ciphers
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jconfidentsa
/// @see ProtocolPP::jconfident
/// @see ProtocolPP::jdsasa
/// @see ProtocolPP::jdsa
/// @see ProtocolPP::jecdsaf2msa
/// @see ProtocolPP::jecdsaf2m
/// @see ProtocolPP::jecdsafpsa
/// @see ProtocolPP::jecdsafp
/// @see ProtocolPP::jicmpsa
/// @see ProtocolPP::jicmp
/// @see ProtocolPP::jintegritysa
/// @see ProtocolPP::jintegrity
/// @see ProtocolPP::jipsa
/// @see ProtocolPP::jip
/// @see ProtocolPP::jipsecsa
/// @see ProtocolPP::jipsec
/// @see ProtocolPP::jltesa
/// @see ProtocolPP::jlte
/// @see ProtocolPP::jmacsecsa
/// @see ProtocolPP::jmacsec
/// @see ProtocolPP::jmemblobsa
/// @see ProtocolPP::jmemblob
/// @see ProtocolPP::jrsasa
/// @see ProtocolPP::jrsa
/// @see ProtocolPP::jsrtpsa
/// @see ProtocolPP::jsrtp
/// @see ProtocolPP::jtcpsa
/// @see ProtocolPP::jtcp
/// @see ProtocolPP::jtlsa
/// @see ProtocolPP::jtls
/// @see ProtocolPP::judpsa
/// @see ProtocolPP::judp
/// @see ProtocolPP::jwifisa
/// @see ProtocolPP::jwifi
/// @see ProtocolPP::jwimaxsa
/// @see ProtocolPP::jwimax
///
/// <B>For Additional Documentation:</B>
/// @see tinyxml2
/// @see jarray
/// @see jrand
/// @see jreplay
/// @see ciphers
/// @see jprotocol
/// @see jsecass
/// @see jconfidentsa
/// @see jconfident
/// @see jdsasa
/// @see jdsa
/// @see jecdsaf2msa
/// @see jecdsaf2m
/// @see jecdsafpsa
/// @see jecdsafp
/// @see jicmpsa
/// @see jicmp
/// @see jintegritysa
/// @see jintegrity
/// @see jipsa
/// @see jip
/// @see jipsecsa
/// @see jipsec
/// @see jltesa
/// @see jlte
/// @see jmacsecsa
/// @see jmacsec
/// @see jmemblobsa
/// @see jmemblob
/// @see jrsasa
/// @see jrsa
/// @see jsrtpsa
/// @see jsrtp
/// @see jtcpsa
/// @see jtcp
/// @see jtlsa
/// @see jtls
/// @see judpsa
/// @see judp
/// @see jwifisa
/// @see jwifi
/// @see jwimaxsa
/// @see jwimax
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <memory>
#include <cstddef>
#include "jsecass.h"
//#include "jprotocolpp.h"

namespace ProtocolPP {

class jstream {

public :

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jstream
    /// @param name - name of the stream
    /// @param dir - direction of processing
    /// @param type - type of security association
    /// @param postprocess - if using a random IV, postprocess the descriptor to decap the payload and verify
    /// @param security - Security association for this stream
    /// @param engine - Encryption engine for this stream
    //////////////////////////////////////////////////////////////////////
    jstream(std::string name,
            direction_t dir,
            protocol_t type,
            bool postprocess,
            std::shared_ptr<jsecass> security,
            std::shared_ptr<jprotocol> engine);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jstream
    /// @param name - name of the stream
    /// @param dir - direction of processing
    /// @param type - type of security association
    /// @param postprocess - if using a random IV, postprocess the descriptor to decap the payload and verify
    /// @param security - Security association for this stream
    //////////////////////////////////////////////////////////////////////
    jstream(std::string name,
            direction_t dir,
            protocol_t type,
            bool postprocess,
            std::shared_ptr<jsecass> security);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jstream
    /// @param name - name of the stream
    /// @param dir - direction of processing
    /// @param type - type of security association
    /// @param postprocess - if using a random IV, postprocess the descriptor to decap the payload and verify
    /// @param engine - Encryption engine for this stream
    //////////////////////////////////////////////////////////////////////
    jstream(std::string name,
            direction_t dir,
            protocol_t type,
            bool postprocess,
            std::shared_ptr<jprotocol> engine);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jstream() {}

    //////////////////////////////////////////////////////////////////////
    /// set the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T value);

    //////////////////////////////////////////////////////////////////////
    /// get the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Set the security association for this stream
    /// @param security - pointer to security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_security(std::shared_ptr<T>& security) {
        m_sa = reinterpret_cast<std::shared_ptr<jsecass>&>(security);
    }

    //////////////////////////////////////////////////////////////////////
    /// Set the encryption engine for this stream
    /// @param engine - encryption engine
    //////////////////////////////////////////////////////////////////////
    void set_engine(std::shared_ptr<jprotocol> engine);

    //////////////////////////////////////////////////////////////////////
    /// Get the security association for this stream
    /// @return - pointer to the security association
    /// NOTE : User must cast the security association to its correct type
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void get_security(std::shared_ptr<T>& security) {
        std::shared_ptr<T> tmp = reinterpret_cast<std::shared_ptr<T>&>(m_sa);
        security = std::make_shared<T>(tmp);
    }

    //////////////////////////////////////////////////////////////////////
    /// Get the encryption engine for this stream
    /// @return - pointer to the encryption engine
    //////////////////////////////////////////////////////////////////////
    void get_engine(std::shared_ptr<jprotocol>& newengine);

    //////////////////////////////////////////////////////////////////////
    /// Erase the encryption engine if not needed
    /// Encryption engine is only needed to generate random packets. If
    /// running W.A.S.P, the encryption engine will be deleted after
    /// generating random packets to reduce the memory footprint of
    /// the stream object
    //////////////////////////////////////////////////////////////////////
    void clean();

private:

    // don't use these
    jstream() = delete;
    jstream(jstream& rhs) = delete;
    jstream(const jstream& rhs) = delete;

    // member variables
    std::string m_name;
    unsigned int m_size;
    direction_t m_dir;
    protocol_t m_type;
    bool m_post;
    std::shared_ptr<jsecass> m_sa;
    std::shared_ptr<jprotocol> m_engine;
    bool m_setup;
};

}

#endif /* JPROTOCOL_JSTREAM_H_ */
