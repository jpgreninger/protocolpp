#ifndef JSRTPSA_H_
#define JSRTPSA_H_

///
///\class jsrtpsa jsrtpsa.h "include/jsrtpsa.h"
///
///\section SRTPSA_ClassSA Secure Real-Time Protocol Security Association (SRTP)
///
/// <B>SRTP Framework</B>
///
/// RTP is the Real-time Transport Protocol [RFC3550]. We define SRTP as a
/// profile of RTP. This profile is an extension to the RTP Audio/Video Profile
/// [RFC3551]. Except where explicitly noted, all aspects of that profile apply,
/// with the addition of the SRTP security features. Conceptually, we consider
/// SRTP to be a "bump in the stack" implementation which resides between the
/// RTP application and the transport layer. SRTP intercepts RTP packets and then
/// forwards an equivalent SRTP packet on the sending side, and intercepts SRTP
/// packets and passes an equivalent RTP packet up the stack on the receiving side.
///
/// Secure RTCP (SRTCP) provides the same security services to RTCP as SRTP does
/// to RTP. SRTCP message authentication is MANDATORY and thereby protects the RTCP
/// fields to keep track of membership, provide feedback to RTP senders, or maintain
/// packet sequence counters. SRTCP is described in Section 3.4.
///
///
/// <B>Secure RTP (see IETF specifications RFC3711, RFC7741)</B>
///
/// The format of an SRTP packet is illustrated in Figure 1 [1]
///
///\image html SRTP_HDR.png "Secure Real-Time Packet (SRTP) Structure"
///\image latex SRTP_HDR.eps "Secure Real-Time Packet (SRTP) Structure" width=15cm
///
/// The ﬁrst twelve octets are present in every RTP packet, while the list of CSRC
/// identiﬁers is present only when inserted by a mixer. The ﬁelds have the following meaning:
///
/// * version (V): 2 bits
///
///   This ﬁeld identiﬁes the version of RTP. The version deﬁned by this
///   speciﬁcation is two (2). (The value 1 is used by the ﬁrst draft version of
///   RTP and the value 0 is used by the protocol initially implemented in the
///   “vat” audio tool.)
///
/// * padding (P): 1 bit
///
///   If the padding bit is set, the packet contains one or more additional
///   padding octets at the end which are not part of the payload. The last octet
///   of the padding contains a count of how many padding octets should be ignored,
///   including itself. Padding may be needed by some encryption algorithms with
///   ﬁxed block sizes or for carrying several RTP packets in a lower-layer protocol
///   data unit.
/// 
/// * extension (X): 1 bit
///
///   If the extension bit is set, the ﬁxed header must be followed by exactly
///   one header extension, with a format deﬁned in Section 5.3.1.
///
/// * CSRC count (CC): 4 bits
///
///   The CSRC count contains the number of CSRC identiﬁers that follow the ﬁxed header.
///
/// * marker (M): 1 bit
///
///   The interpretation of the marker is deﬁned by a proﬁle. It is intended
///   to allow signiﬁcant events such as frame boundaries to be marked in the packet
///   stream. A proﬁle may deﬁne additional marker bits or specify that there is no
///   marker bit by changing the number of bits in the payload type ﬁeld (see Section 5.3).
///
/// * payload type (PT): 7 bits
///
///   This ﬁeld identiﬁes the format of the RTP payload and determines its interpretation
///   by the application. A proﬁle may specify a default static mapping of payload type
///   codes to payload formats. Additional payload type codes may bedeﬁned dynamically
///   through non-RTP means (see Section 3). A set of default mappings for audio and
///   video is speciﬁed in the companion RFC 3551 [1]. An RTP source may change the
///   payload type during a session, but this ﬁeld should not be used for multiplexing
///   separate media streams (see Section 5.2). A receiver must ignore packets with
///   payload types that it does not understand.
///
/// * sequence number: 16 bits
///
///   The sequence number increments by one for each RTP data packet sent,
///   and may be used by the receiver to detect packet loss and to restore packet
///   sequence. The initial value of the sequence number should be random (unpredictable)
///   to make known-plaintext attacks on encryption more diﬃcult, even if the source
///   itself does not encrypt according to the method in Section 9.1, because the
///   packets may ﬂow through a translator that does. Techniques for choosing
///   unpredictable numbers are discussed in [17].
///
/// * timestamp: 32 bits
///
///   The timestamp reﬂects the sampling instant of the ﬁrst octet in the RTP
///   data packet. The sampling instant must be derived from a clock that increments
///   monotonically and linearly in time to allow synchronization and jitter calculations
///   (see Section 6.4.1). The resolution of the clock must be suﬃcient for the desired
///   synchronization accuracy and for measuring packet arrival jitter (one tick per
///   video frame is typically not suﬃcient). The clock frequency is dependent on the
///   format of data carried as payload and is speciﬁed statically in the proﬁle or
///   payload format speciﬁcation that deﬁnes the format, or may be speciﬁed dynamically
///   for payload formats deﬁned through non-RTP means. If RTP packets are generated
///   periodically, the nominal sampling instant as determined from the sampling clock
///   is to be used, not a reading of the system clock. As an example, for ﬁxed-rate
///   audio the timestamp clock would likely increment byone for each samplingperiod.
///   If an audio application reads blocks covering 160 sampling periods from the input
///   device, the timestamp would be increased by 160 for each such block, regardless
///   of whether the block is transmitted in a packet or dropped as silent. The initial
///   value of the timestamp should be random, as for the sequence number. Several
///   consecutive RTP packets will have equal timestamps if they are (logically)
///   generated at once, e.g., belong to the same video frame. Consecutive RTP packets
///   may contain timestamps that are not monotonic if the data is not transmitted in
///   the order it was sampled, as in the case of MPEG interpolated video frames.
///   (The sequence numbers of the packets as transmitted will still be monotonic.)
///   RTP timestamps from diﬀerent media streams may advance at diﬀerent rates and
///   usually have independent, random oﬀsets. Therefore, although these timestamps
///   are suﬃcient to reconstruct the timing of a single stream, directly comparing
///   RTP timestamps from diﬀerent media is not eﬀective for synchronization. Instead,
///   for each medium the RTP timestamp is related to the sampling instant by pairing
///   it with a timestamp from a reference clock (wallclock) that represents the time
///   when the data corresponding to the RTP timestamp was sampled. The reference
///   clock is shared by all media to be synchronized. The timestamp pairs are not
///   transmitted in every data packet, but at a lower rate in RTCP SR packets as 
///   described in Section 6.4. The sampling instant is chosen as the point of reference
///   for the RTP timestamp because it is known to the transmitting endpoint and has a 
///   common deﬁnition for all media, independent of encoding delays or other processing. 
///   The purpose is to allow synchronized presentation of all media sampled at the same 
///   time. Applications transmitting stored data rather than data sampled in real time
///   typically use a virtual presentation timeline derived from wallclock time to
///   determine when the next frame or other unit of each medium in the stored data
///   should be presented. In this case, the RTP timestamp would reﬂect the presentation
///   time for each unit. That is, the RTP timestamp for each unit would be related
///   to the wallclock time at which the unit becomes current on the virtual presentation
///   timeline. Actual presentation occurs some time later as determined by the receiver.
///   An example describing live audio narration of prerecorded video illustrates the
///   signiﬁcance of choosing the sampling instant as the reference point. In this
///   scenario, the video would be presented locally for the narrator to view and
///   would be simultaneously transmitted using RTP. The “sampling instant” of a video
///   frame transmitted in RTP would be established by referencing its timestamp to the
///   wallclock time when that video frame was presented to the narrator. The sampling
///   instant for the audio RTP packets containing the narrator’s speech would be
///   established by referencing the same wallclock time when the audio was sampled.
///   The audio and video may even be transmitted by diﬀerent hosts if the reference
///   clocks on the two hosts are synchronized by some means such as NTP. A receiver
///   can then synchronize presentation of the audio and video packets by relating
///   their RTP timestamps using the timestamp pairs in RTCP SR packets.
///
/// * SSRC: 32 bits
///
///   The SSRC ﬁeld identiﬁes the synchronization source. This identiﬁer should
///   be chosen randomly, with the intent that no two synchronization sources within the
///   same RTP session will have the same SSRC identiﬁer. An example algorithm for generating
///   a random identiﬁer is presented in Appendix A.6. Although the probability of multiple
///   sources choosing the same identiﬁer is low, all RTP implementations must be prepared
///   to detect and resolve collisions. Section 8 describes the probability of collision
///   along with a mechanism for resolving collisions and detecting RTP-level forwarding
///   loops based on the uniqueness of the SSRC identiﬁer. If a source changes its source 
///   transport address, it must also choose a new SSRC identiﬁer to avoid being interpreted 
///   as a looped source (see Section 8.2).
///
/// * CSRC list: 0 to 15 items, 32 bits each
///             
///   The CSRC list identiﬁes the contributing sources for the payload contained in this packet.
///   The number of identiﬁers is given by the CC ﬁeld. If there are more than 15 contributing
///   sources, only 15 can be identiﬁed. CSRC identiﬁers are inserted by mixers (see Section 7.1),
///   using the SSRC identiﬁers of contributing sources. For example, for audio packets the SSRC
///   identiﬁers of all sources that were mixed together to create a packet are listed, allowing
///   correct talker indication at the receiver.
///
///
/// The "Encrypted Portion" of an SRTP packet consists of the encryption of the RTP
/// payload (including RTP padding when present) of the equivalent RTP packet. The
/// Encrypted Portion MAY be the exact size of the plaintext or MAY be larger. Figure 1
/// shows the RTP payload including any possible padding for RTP [RFC3550].
/// 
/// None of the pre-defined encryption transforms uses any padding; for these, the RTP and
/// SRTP payload sizes match exactly. New transforms added to SRTP (following Section
/// 6) may require padding, and may hence produce larger payloads. RTP provides its own
/// padding format (as seen in Fig. 1), which due to the padding indicator in the RTP
/// header has merits in terms of compactness relative to paddings using prefix-free
/// codes. This RTP padding SHALL be the default method for transforms requiring padding.
/// Transforms MAY specify other padding methods, and MUST then specify the amount,
/// format, and processing of their padding. It is important to note that encryption
/// transforms that use padding are vulnerable to subtle attacks, especially when
/// message authentication is not used [V02]. Each specification for a new encryption
/// transform needs to carefully consider and describe the security implications of the
/// padding that it uses. Message authentication codes define their own padding, so this
/// default does not apply to authentication transforms.
/// 
/// The OPTIONAL MKI and the RECOMMENDED authentication tag are the only fields defined
/// by SRTP that are not in RTP. Only 8-bit alignment is assumed.
///
///    * MKI (Master Key Identifier): configurable length, OPTIONAL. The MKI is defined,
///          signaled, and used by key management. The MKI identifies the master key from
///          which the session key(s) were derived that authenticate and/or encrypt the
///          particular packet. Note that the MKI SHALL NOT identify the SRTP cryptographic
///          context, which is identified according to Section 3.2.3. The MKI MAY be used by
///          key management for the purposes of re-keying, identifying a particular master
///          key within the cryptographic context (Section 3.2.1).
///
///    * Authentication tag: configurable length, RECOMMENDED. The authentication tag is
///          used to carry message authentication data. The Authenticated Portion of an SRTP
///          packet consists of the RTP header followed by the Encrypted Portion of the SRTP
///          packet. Thus, if both encryption and authentication are applied, encryption SHALL
///          be applied before authentication on the sender side and conversely on the receiver
///          side. The authentication tag provides authentication of the RTP header and payload,
///          and it indirectly provides replay protection by authenticating the sequence number.
///          Note that the MKI is not integrity protected as this does not provide any extra
///          protection.
///
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jsrtp
/// @see ProtocolPP::jsrtpsa
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jsrtp
/// @see jsrtpsa
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class jsrtpsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor with defaults
    ///
    /// <table>
    /// <caption id="SRTP Defaults">SRTP Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>mode<td>protocol_t::SRTP
    /// <tr><td>cipher<td>srtpcipher_t::AES_CTR_SHA1
    /// <tr><td>icvlen<td>20
    /// <tr><td>blksize<td>0
    /// <tr><td>seqnum<td>0
    /// <tr><td>roc<td>0
    /// <tr><td>ssrc<td>0
    /// <tr><td>ver<td>0x80
    /// <tr><td>type<td>0
    /// <tr><td>pad<td>false
    /// <tr><td>ext<td>false
    /// <tr><td>marker<td>false
    /// <tr><td>mki<td>false
    /// <tr><td>ckeylen<td>16
    /// <tr><td>akeylen<td>20
    /// <tr><td>saltlen<td>4
    /// <tr><td>mkilen<td>0
    /// <tr><td>cc<td>0
    /// <tr><td>arlen<td>0
    /// <tr><td>cipherkey<td>0
    /// <tr><td>salt<td>0
    /// <tr><td>mkidata<td>0
    /// <tr><td>exthdr<td>0
    /// <tr><td>authkey<td>0
    /// <tr><td>csrc<td>0
    /// <tr><td>arwin<td>0
    /// </table>
    //////////////////////////////////////////////////////////////////////
    jsrtpsa();

    //////////////////////////////////////////////////////////////////////
    /// Security Association for SRTP
    ///
    /// @param dir - Direction of processing (ENCAP or DECAP)
    /// @param mode - Mode of operation either SRTP or SCRTP
    /// @param cipher - indicates the cipher used for SRTP encryption
    /// @param icvlen - ICV length 
    /// @param blksize - Size of the encryption data size
    /// @param seqnum - Sequence number
    /// @param roc - Rollover counter (ROC)
    /// @param ssrc - Synchronization source identifier (SSRC)
    /// @param ver - Version of SRTP (currently 2)
    /// @param type - Type of the payload data
    /// @param pad - Indicates padding is present in the payload
    /// @param ext - If asserted, a single extension header follows the SRTP header
    /// @param exthdr - Extension header data if present
    /// @param marker - Marker for debug
    /// @param mki - MKI flag
    /// @param ckeylen - Cipher key length
    /// @param cipherkey - the session encryption key
    /// @param akeylen - Authentication key length
    /// @param authkey - the session authentication key for HMAC-SHA1
    /// @param saltlen - Salt length
    /// @param salt - the session salting key
    /// @param mkilen - MKI length
    /// @param mkidata - MKI data
    /// @param cc - Number of CSRC identifiers
    /// @param csrc - Contributing source identifier (CSRC)
    /// @param arlen - Number of packets to track in replay window
    /// @param arwin - Anti-replay window
    //////////////////////////////////////////////////////////////////////
    jsrtpsa(direction_t dir,
            protocol_t mode,
            srtpcipher_t cipher,
            unsigned int icvlen,
            unsigned int blksize,
            uint16_t seqnum,
            uint32_t roc,
            uint32_t ssrc,
            uint8_t ver,
            uint8_t type,
            bool pad,
            bool ext,
            std::shared_ptr<jarray<uint8_t>> exthdr,
            bool marker,
            bool mki,
            unsigned int ckeylen,
            std::shared_ptr<jarray<uint8_t>>  cipherkey,
            unsigned int akeylen,
            std::shared_ptr<jarray<uint8_t>>  authkey,
            unsigned int saltlen,
            std::shared_ptr<jarray<uint8_t>>  salt,
            unsigned int mkilen,
            std::shared_ptr<jarray<uint8_t>>  mkidata,
            unsigned int cc,
            std::shared_ptr<jarray<uint32_t>> csrc,
            unsigned int arlen,
            jarray<uint8_t> arwin);
        
    //////////////////////////////////////////////////////////////////////
    /// constructor for SRTP Security Association
    /// @param rhs - security association for SRTP
    //////////////////////////////////////////////////////////////////////
    jsrtpsa(jsrtpsa& rhs);
    
    //////////////////////////////////////////////////////////////////////
    /// constructor for SRTP Security Association
    /// @param rhs - security association for SRTP
    //////////////////////////////////////////////////////////////////////
    explicit jsrtpsa(std::shared_ptr<jsrtpsa>& rhs);
    
    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jsrtpsa() {
        if (!m_cipherkey.empty()) {
            m_cipherkey.serase();
        }
        if (!m_authkey.empty()) {
            m_authkey.serase();
        }
        if (!m_salt.empty()) {
            m_salt.serase();
        }
    }
    
    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the SRTP security association
    ///
    /// <table>
    /// <caption id="SRTP Set Fields">SRTP Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP)
    /// <tr><td>protocol_t<td>MODE<td>set_field<protocol_t>(field_t::MODE, protocol_t::SRTP)
    /// <tr><td>srtpcipher_t<td>CIPHER<td>set_field<srtpcipher_t>(field_t::CIPHER, srtpcipher_t::AEAD_AES_256_CCM)
    /// <tr><td>uint32_t<td>ICVLEN<td>set_field<uint32_t>(field_t::ICVLEN, 16)
    /// <tr><td><td>BLKSIZE<td>set_field<uint32_t>(field_t::BLKSIZE, 16)
    /// <tr><td><td>ROC<td>set_field<uint32_t>(field_t::ROC, 1)
    /// <tr><td><td>SSRC<td>set_field<uint32_t>(field_t::SSRC, 2)
    /// <tr><td><td>CKEYLEN<td>set_field<uint32_t>(field_t::CKEYLEN, 32)
    /// <tr><td><td>AKEYLEN<td>set_field<uint32_t>(field_t::AKEYLEN, 0)
    /// <tr><td><td>SALTLEN<td>set_field<uint32_t>(field_t::SALTLEN, 3)
    /// <tr><td><td>MKILEN<td>set_field<uint32_t>(field_t::MKILEN, 0)
    /// <tr><td><td>CC<td>set_field<uint32_t>(field_t::CC, 1)
    /// <tr><td><td>ARLEN<td>set_field<uint32_t>(field_t::ARLEN, 64)
    /// <tr><td>uint16_t<td>SEQNUM<td>set_field<uint16_t>(field_t::SEQNUM, 0x0001)
    /// <tr><td>uint8_t<td>VERSION<td>set_field<uint8_t>(field_t::VERSION, 0x02)
    /// <tr><td><td>TYPE<td>set_field<uint8_t>(field_t::TYPE, 0x13)
    /// <tr><td>bool<td>PAD<td>set_field<bool>(field_t::PAD, true)
    /// <tr><td><td>EXTENSION<td>set_field<bool>(field_t::EXTENSION, true)
    /// <tr><td><td>MARKER<td>set_field<bool>(field_t::MARKER, false)
    /// <tr><td><td>MKI<td>set_field<bool>(field_t::MKI, true)
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>set_field<jarray<uint8_t>>(field_t::ARWIN, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>EXTHDR<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::EXTHDR, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td><td>CIPHERKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td><td>AUTHKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td><td>SALT<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td><td>MKIDATA<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::MKIDATA, jarray<uint8_t>("AABBCCDD"))
    /// <tr><td><td>CSRC<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CSRC, jarray<uint8_t>("AABBCCDD"))
    /// </table>
    ///
    /// @param field - field to update the SRTP security association
    /// @param fieldval - value to update the SRTP security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the field of the SRTP security association
    ///
    /// <table>
    /// <caption id="SRTPSA Set Fields">SRTP Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>protocol_t<td>MODE<td>protocol_t mymode = get_field<protocol_t>(field_t::MODE)
    /// <tr><td>srtpcipher_t<td>CIPHER<td>srtpcipher_t mycipher = get_field<srtpcipher_t>(field_t::CIPHER)
    /// <tr><td>uint32_t<td>ICVLEN<td>uint32_t myicvlen = get_field<uint32_t>(field_t::ICVLEN)
    /// <tr><td><td>BLKSIZE<td>uint32_t myblksize = get_field<uint32_t>(field_t::BLKSIZE)
    /// <tr><td><td>ROC<td>uint32_t myroc = get_field<uint32_t>(field_t::ROC)
    /// <tr><td><td>SSRC<td>uint32_t myssrc = get_field<uint32_t>(field_t::SSRC)
    /// <tr><td><td>CKEYLEN<td>uint32_t myckeylen = get_field<uint32_t>(field_t::CKEYLEN)
    /// <tr><td><td>AKEYLEN<td>uint32_t myakeylen = get_field<uint32_t>(field_t::AKEYLEN)
    /// <tr><td><td>SALTLEN<td>uint32_t mysaltlen = get_field<uint32_t>(field_t::SALTLEN)
    /// <tr><td><td>MKILEN<td>uint32_t mymkilen = get_field<uint32_t>(field_t::MKILEN)
    /// <tr><td><td>CC<td>uint32_t mycc = get_field<uint32_t>(field_t::CC)
    /// <tr><td><td>ARLEN<td>uint32_t myarlen = get_field<uint32_t>(field_t::ARLEN)
    /// <tr><td>uint16_t<td>SEQNUM<td>uint16_t myseqnum = get_field<uint16_t>(field_t::SEQNUM)
    /// <tr><td>uint8_t<td>VERSION<td>uint8_t myver = get_field<uint8_t>(field_t::VERSION)
    /// <tr><td><td>TYPE<td>uint8_t mytype = get_field<uint8_t>(field_t::TYPE)
    /// <tr><td>bool<td>PAD<td>bool mypad = get_field<bool>(field_t::PAD)
    /// <tr><td><td>EXTENSION<td>bool myext = get_field<bool>(field_t::EXTENSION)
    /// <tr><td><td>MARKER<td>bool mymarker = get_field<bool>(field_t::MARKER)
    /// <tr><td><td>MKI<td>bool mymki = get_field<bool>(field_t::MKI)
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>jarray<uint8_t> myarwin = get_field<jarray<uint8_t>>(field_t::ARWIN)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>EXTHDR<td>std::shared_ptr<jarray<uint8_t>> myexthdr = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::EXTHDR)
    /// <tr><td><td>CIPHERKEY<td>std::shared_ptr<jarray<uint8_t>> mycipherkey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY)
    /// <tr><td><td>AUTHKEY<td>std::shared_ptr<jarray<uint8_t>> myauthkey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY)
    /// <tr><td><td>SALT<td>std::shared_ptr<jarray<uint8_t>> mysalt = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT)
    /// <tr><td><td>MKIDATA<td>std::shared_ptr<jarray<uint8_t>> mymkidata = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::MKIDATA)
    /// <tr><td><td>CSRC<td>std::shared_ptr<jarray<uint8_t>> mycsrc = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CSRC)
    /// </table>
    ///
    /// @param field - field to retrieve
    /// @return value of the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol and security objects to XML
    /// @param myxml - XMLPrinter object
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);
    
private:
    
    // don't use these
    jsrtpsa(const jsrtpsa& rhs) = delete;

    direction_t m_dir;
    protocol_t m_mode;
    srtpcipher_t m_cipher;
    unsigned int m_icvlen;
    unsigned int m_blksize;
    uint16_t m_seqnum;
    uint32_t m_roc;
    uint32_t m_ssrc;
    uint8_t m_ver;
    uint8_t m_type;
    bool m_pad;
    bool m_ext;
    jarray<uint8_t> m_exthdr;
    bool m_marker;
    bool m_mki;
    unsigned int m_ckeylen;
    jarray<uint8_t> m_cipherkey;
    unsigned int m_akeylen;
    jarray<uint8_t> m_authkey;
    unsigned int m_saltlen;
    jarray<uint8_t> m_salt;
    unsigned int m_mkilen;
    jarray<uint8_t> m_mkidata;
    unsigned int m_cc;
    jarray<uint32_t> m_csrc;
    unsigned int m_arlen;
    jarray<uint8_t> m_arwin;
};

}

#endif /* JSRTPSA_H_ */
