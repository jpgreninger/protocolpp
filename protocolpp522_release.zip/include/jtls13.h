#ifndef JPROTOCOL_JTLS13_H_
#define JPROTOCOL_JTLS13_H_

///
///\class jtls13 jtls13.h "include/jtls13.h"
///
///\section TLS_Class_v13 Transport Layer Security v1.3 (TLS13)
///
/// For additional information see http://en.wikipedia.org/wiki/Transport_Layer_Security
///
/// The TLS protocol exchanges records—which encapsulate the data to be exchanged
/// in a specific format (see below). Each record can be compressed, padded, appended
/// with a message authentication code (MAC), or encrypted, all depending on the state
/// of the connection. Each record has a content type field that designates the type
/// of data encapsulated, a length field and a TLS version field. The data encapsulated
/// may be control or procedural messages of the TLS itself, or simply the application
/// data needed to be transferred by TLS. The specifications (cipher suite, keys etc.)
/// required to exchange application data by TLS, are agreed upon in the "TLS handshake"
/// between the client requesting the data and the server responding to requests. The
/// protocol therefore defines both the structure of payloads transferred in TLS and the
/// procedure to establish and monitor the transfer
///
/// <B>TLS handshake</B>
///
/// When the connection starts, the record encapsulates a "control" protocol—the
/// handshake messaging protocol  (content type 22). This protocol is used to exchange
/// all the information required by both sides for the exchange of the actual application
/// data by TLS. It defines the messages formatting or containing this information and the
/// order of their exchange. These may vary according to the demands of the client and
/// server—i.e., there are several possible procedures to set up the connection. This
/// initial exchange results in a successful TLS connection (both parties ready to transfer
/// application data with TLS) or an alert message (as specified below)
///
///\subsection TLS_HS_v13 Basic TLS handshake
///
/// A typical connection example follows, illustrating a handshake where the server (but
/// not the client) is authenticated by its certificate:
///
/// 1. Negotiation phase: A client sends a ClientHello message specifying the highest
///    TLS protocol version it supports, a random number, a list of suggested cipher
///    suites and suggested compression methods. If the client is attempting to perform
///    a resumed handshake, it may send a session ID. The server responds with a
///    ServerHello message, containing the chosen protocol version, a random number,
///    CipherSuite and compression method from the choices offered by the client. To
///    confirm or allow resumed handshakes the server may send a session ID. The chosen
///    protocol version should be the highest that both the client and server support.
///    For example, if the client supports TLS version 1.1 and the server supports version
///    1.2, version 1.1 should be selected; version 1.0 should not be selected. The server
///    sends its Certificate message (depending on the selected cipher suite, this may be
///    omitted by the server).[257] The server sends its ServerKeyExchange message (depending
///    on the selected cipher suite, this may be omitted by the server). This message is sent
///    for all DHE and DH_anon ciphersuites.[1] The server sends a ServerHelloDone message,
///    indicating it is done with handshake negotiation. The client responds with a
///    ClientKeyExchange message, which may contain a PreMasterSecret, public key, or nothing.
///    (Again, this depends on the selected cipher.) This PreMasterSecret is encrypted using
///    the public key of the server certificate. The client and server then use the random
///    numbers and PreMasterSecret to compute a common secret, called the "master secret".
///    All other key data for this connection is derived from this master secret (and the
///    client- and server-generated random values), which is passed through a carefully
///    designed pseudorandom function.
///
/// 2. The client now sends a ChangeCipherSpec record, essentially telling the server,
///    "Everything I tell you from now on will be authenticated (and encrypted if encryption
///    parameters were present in the server certificate)." The ChangeCipherSpec is itself a
///    record-level protocol with content type of 20. Finally, the client sends an authenticated
///    and encrypted Finished message, containing a hash and MAC over the previous handshake
///    messages. The server will attempt to decrypt the client's Finished message and verify
///    the hash and MAC. If the decryption or verification fails, the handshake is considered
///    to have failed and the connection should be torn down.
///
/// 3. Finally, the server sends a ChangeCipherSpec, telling the client, "Everything I tell you
///    from now on will be authenticated (and encrypted, if encryption was negotiated)." The
///    server sends its authenticated and encrypted Finished message. The client performs the
///    same decryption and verification.
///
/// 4. Application phase: at this point, the "handshake" is complete and the application protocol
///    is enabled, with content type of 23. Application messages exchanged between client and server
///    will also be authenticated and optionally encrypted exactly like in their Finished message.
///    Otherwise, the content type will return 25 and the client will not authenticate.
///
///
/// <B>Client-authenticated TLS handshake</B>
///
/// The following full example shows a client being authenticated (in addition to the server as in the
/// example above) via TLS using certificates exchanged between both peers.
///
/// 1. Negotiation Phase: A client sends a ClientHello message specifying the highest TLS protocol
///    version it supports, a random number, a list of suggested cipher suites and compression methods.
///    The server responds with a ServerHello message, containing the chosen protocol version, a random
///    number, cipher suite and compression method from the choices offered by the client. The server
///    may also send a session id as part of the message to perform a resumed handshake. The server sends
///    its Certificate message (depending on the selected cipher suite, this may be omitted by the server).[257]
///    The server sends its ServerKeyExchange message (depending on the selected cipher suite, this may be
///    omitted by the server). This message is sent for all DHE and DH_anon ciphersuites.[1] The server
///    requests a certificate from the client, so that the connection can be mutually authenticated, using
///    a CertificateRequest message. The server sends a ServerHelloDone message, indicating it is done
///    with handshake negotiation. The client responds with a Certificate message, which contains the
///    client's certificate. The client sends a ClientKeyExchange message, which may contain a PreMasterSecret,
///    public key, or nothing. (Again, this depends on the selected cipher.) This PreMasterSecret is
///    encrypted using the public key of the server certificate. The client sends a CertificateVerify
///    message, which is a signature over the previous handshake messages using the client's certificate's
///    private key. This signature can be verified by using the client's certificate's public key. This
///    lets the server know that the client has access to the private key of the certificate and thus owns
///    the certificate. The client and server then use the random numbers and PreMasterSecret to compute a
///    common secret, called the "master secret". All other key data for this connection is derived from
///    this master secret (and the client- and server-generated random values), which is passed through a
///    carefully designed pseudorandom function.
///
/// 2. The client now sends a ChangeCipherSpec record, essentially telling the server, "Everything I tell
///    you from now on will be authenticated (and encrypted if encryption was negotiated). " The ChangeCipherSpec
///    is itself a record-level protocol and has type 20 and not 22. Finally, the client sends an encrypted
///    Finished message, containing a hash and MAC over the previous handshake messages. The server will attempt
///    to decrypt the client's Finished message and verify the hash and MAC. If the decryption or verification
///    fails, the handshake is considered to have failed and the connection should be torn down.
///
/// 3. Finally, the server sends a ChangeCipherSpec, telling the client, "Everything I tell you from now
///    on will be authenticated (and encrypted if encryption was negotiated). " The server sends its own
///    encrypted Finished message. The client performs the same decryption and verification.
///
/// 4. Application phase: at this point, the "handshake" is complete and the application protocol is enabled,
///    with content type of 23. Application messages exchanged between client and server will also be encrypted
///    exactly like in their Finished message.
///
/// <B>Resumed TLS handshake</B>
///
/// Public key operations (e.g., RSA) are relatively expensive in terms of computational power. TLS provides a secure
/// shortcut in the handshake mechanism to avoid these operations: resumed sessions. Resumed sessions are implemented
/// using session IDs or session tickets.
///
/// Apart from the performance benefit, resumed sessions can also be used for Single sign-on, as it guarantees that
/// both the original session and any resumed session originate from the same client. This is of particular importance
/// for the FTP over TLS/SSL protocol, which would otherwise suffer from a man-in-the-middle attack in which an attacker
/// could intercept the contents of the secondary data connections.[258]
///
/// <B>Session IDs</B>
///
/// In an ordinary full handshake, the server sends a session id as part of the ServerHello message. The client associates
/// this session id with the server's IP address and TCP port, so that when the client connects again to that server, it
/// can use the session id to shortcut the handshake. In the server, the session id maps to the cryptographic parameters
/// previously negotiated, specifically the "master secret". Both sides must have the same "master secret" or the resumed
/// handshake will fail (this prevents an eavesdropper from using a session id). The random data in the ClientHello and
/// ServerHello messages virtually guarantee that the generated connection keys will be different from in the previous
/// connection. In the RFCs, this type of handshake is called an abbreviated handshake. It is also described in the
/// literature as a restart handshake.
///
/// 1. Negotiation phase: A client sends a ClientHello message specifying the highest TLS protocol version it
///    supports, a random number, a list of suggested cipher suites and compression methods. Included in the
///    message is the session id from the previous TLS connection. The server responds with a ServerHello message,
///    containing the chosen protocol version, a random number, cipher suite and compression method from the
///    choices offered by the client. If the server recognizes the session id sent by the client, it responds
///    with the same session id. The client uses this to recognize that a resumed handshake is being performed.
///    If the server does not recognize the session id sent by the client, it sends a different value for its
///    session id. This tells the client that a resumed handshake will not be performed. At this point, both
///    the client and server have the "master secret" and random data to generate the key data to be used for
///    this connection.
///
/// 2. The server now sends a ChangeCipherSpec record, essentially telling the client, "Everything I tell you
///    from now on will be encrypted." The ChangeCipherSpec is itself a record-level protocol and has type 20
///    and not 22. Finally, the server sends an encrypted Finished message, containing a hash and MAC over the
///    previous handshake messages. The client will attempt to decrypt the server's Finished message and verify
///    the hash and MAC. If the decryption or verification fails, the handshake is considered to have failed and
///    the connection should be torn down.
///
/// 3. Finally, the client sends a ChangeCipherSpec, telling the server, "Everything I tell you from now on will
///    be encrypted. " The client sends its own encrypted Finished message. The server performs the same decryption
///    and verification.
///
/// 4. Application phase: at this point, the "handshake" is complete and the application protocol is enabled,
///    with content type of 23. Application messages exchanged between client and server will also be encrypted
///    exactly like in their Finished message.
///
///\image latex TLS_Message.eps "General Message Format of TLS Records (Packets)" width=15cm
///
/// <B>Content Type</B>
///
/// This field identifies the Record Layer Protocol Type contained in this Record
///
/// <table>
/// <caption id="tlsctypesv13">TLS Content Types</caption>
/// <tr><th>Hex<th>Dec<th>Type
/// <tr><td>0x14<td>20<td>ChangeCipherSpec
/// <tr><td>0x15<td>21<td>Alert
/// <tr><td>0x16<td>22<td>Handshake
/// <tr><td>0x17<td>23<td>Application
/// <tr><td>0x18<td>24<td>Heartbeat
/// </table>
///
/// <B>Version</B>
///
/// This field identifies the major and minor version of TLS for the contained message. For a ClientHello message, this
/// need not be the highest version supported by the client
///
/// <table>
/// <caption id="tlsversionsv13">TLS Versions</caption>
/// <tr><th>Major Version<th>Minor Version<th>Version Type
/// <tr><td>0x03<td>0x04<td>TLS1.3
/// </table>
///
/// <B>Length</B> 
///
/// The length of Protocol message(s), MAC and Padding, not to exceed \f${2}^{14}\f$ bytes (16KB)
///
/// <B>Protocol Message(s)</B>
///
/// One or more messages identified by the Protocol field. Note that this field may be encrypted depending
/// on the state of the connection
///
/// <B>MAC and Padding</B>
///
/// A message authentication code computed over the Protocol message, with additional key material included
/// Note that this field may be encrypted, or not included entirely, depending on the state of the connection
/// No MAC or Padding can be present at end of TLS records before all cipher algorithms and parameters have
/// been negotiated and handshaked and then confirmed by sending a CipherStateChange record (see below) for
/// signaling that these parameters will take effect in all further records sent by the same peer
///
/// <B>Handshake protocol</B>
///
/// Most messages exchanged during the setup of the TLS session are based on this record, unless an
/// error or warning occurs and needs to be signaled by an Alert protocol record (see below), or the
/// encryption mode of the session is modified by another record (see ChangeCipherSpec protocol below)
///
/// <table>
/// <caption id="tlshandshakev13">TLS Handshake Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x16</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5..8<td>Message Type<td colspan="3"><center>Handshake Message Data Length</center>
/// <tr><td>Byte 9-(n-1)<td colspan="4"><center>Handshake Message Data</center>
/// <tr><td><center><b>. . .</b></center><td colspan="4"><center><b>. . .</b></center>
/// </table>
///
/// <B>Message type</B> 
///
/// This field identifies the handshake message type
///
/// <table>
/// <caption id="tlsmsgtypev13">TLS Message Types</caption>
/// <tr><th>Code<th>Description
/// <tr><td>0<td>HelloRequest
/// <tr><td>1<td>ClientHello
/// <tr><td>2<td>ServerHello
/// <tr><td>4<td>NewSessionTicket
/// <tr><td>11<td>Certificate
/// <tr><td>12<td>ServerKeyExchange
/// <tr><td>13<td>CertificateRequest
/// <tr><td>14<td>ServerHelloDone
/// <tr><td>15<td>CertificateVerify
/// <tr><td>16<td>ClientExchange
/// <tr><td>20<td>Finished
/// </table>
///
/// <B>Handshake message data length</B>
///
/// This is a 3-byte field indicating the length of the handshake data, not including the header
/// Note that multiple handshake messages may be combined within one record
///
/// <B>Alert protocol</B>
///
/// This record should normally not be sent during normal handshaking or application exchanges.  However,
/// this message can be sent at any time during the handshake and up to the closure of the session. If
/// this is used to signal a fatal error, the session will be closed immediately after sending this
/// record, so this record is used to give a reason for this closure.  If the alert level is flagged
/// as a warning, the remote can decide to close the session if it decides that the session is not 
/// reliable enough for its needs (before doing so, the remote may also send its own signal)
///
/// <table>
/// <caption id="tlsalertv13">TLS Alert Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x15</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5..6<td><center>Level</center><td><center>Description</center><td colspan="2">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 7-(n-1)<td colspan="4"><center>MAC (optional)</center>
/// <tr><td>Byte p-(q-1)<td colspan="4"><center>Padding (block ciphers only)</center>
/// </table>
///
/// <B>Level</B>
///  
/// This field identifies the level of alert. If the level is fatal, the sender should close the session
/// immediately. Otherwise, the recipient may decide to terminate the session itself, by sending its own
/// fatal alert and closing the session itself immediately after sending it. The use of Alert records is
/// optional, however if it is missing before the session closure, the session may be resumed automatically
/// (with its handshakes)
///
/// Normal closure of a session after termination of the transported application should preferably be
/// alerted with at least the Close notify Alert type (with a simple warning level) to prevent such
/// automatic resume of a new session. Signaling explicitly the normal closure of a secure session before
/// effectively closing its transport layer is useful to prevent or detect attacks (like attempts to 
/// truncate the securely transported data, if it intrinsically does not have a predetermined length or
/// duration that the recipient of the secured data may expect)
///
/// <B>ChangeCipherSpec protocol</B>
///
/// <table>
/// <caption id="tlscipherchangev13">TLS ChangeCipherSpec Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x14</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5<td><center>CCS Prot Type</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// </table>
///
/// <table>
/// <caption id="tlsciphersuitesv13">TLSv13 CipherSuites Protocol</caption>
/// <tr><th>Description<th>Value
/// <tr><td>TLS_AES_128_GCM_SHA256<td><center>0x1301</center>
/// <tr><td>TLS_AES_256_GCM_SHA384<td><center>0x1302</center>
/// <tr><td>TLS_CHACHA20_POLY1305_128_SHA256<td><center>0x1303</center>
/// <tr><td>TLS_AES_128_CCM_SHA256<td><center>0x1304</center>
/// <tr><td>TLS_AES_128_CCM_8_SHA256<td><center>0x1305</center>
/// </table>
///
/// <B>CCS protocol type</B>
///
/// Currently only 1
///
/// <B>Application protocol</B>
///
/// <table>
/// <caption id="tlsappv13">TLS Application Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x17</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5-(m-1)<td colspan="4"><center>Application Data</center>
/// <tr><td>Byte m-(p-1)<td colspan="4"><center>MAC (optional)</center>
/// <tr><td>Byte p-(q-1)<td colspan="4"><center>Padding (block ciphers only)</center>
/// </table>
///
/// <table>
/// <caption id="tlsdtlsv13">DTLS Datagram</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x17</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Epoch</center>
/// <tr><td>Byte 5-8<td colspan="4"><center>Seqnum</center>
/// <tr><td>Byte 9-12<td colspan="2"><center>Seqnum</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 13-(m-1)<td colspan="4"><center>Application Data</center>
/// <tr><td>Byte m-(p-1)<td colspan="4"><center>MAC (optional)</center>
/// <tr><td>Byte p-(q-1)<td colspan="4"><center>Padding (block ciphers only)</center>
/// </table>
///
/// <B>Length</B>
///
/// Length of the application data (excluding the protocol header and including the MAC and padding trailers)
///
/// <B>MAC</B>
///
/// 20 bytes for the SHA1 based HMAC, 16 bytes for the MD5 based HMAC
///
/// <B>Padding</B>
/// 
/// Variable length; last byte contains the padding length
///
/// <B>IANA Considerations</B>
///
/// IANA has allocated the following numbers in the TLS Cipher Suite Registry:
///
/// <B>Applying Encrypt-then-MAC</B>
///
/// Once the use of encrypt-then-MAC has been negotiated, processing of TLS/DTLS packets switches from the standard:
///
/// * encrypt( data || MAC || pad )
///
/// to the new:
///
/// * encrypt( data || pad ) || MAC
///
/// <B>Major Differences from TLS 1.2</B>
///
/// The following is a list of the major functional differences between TLS 1.2 and TLS 1.3. It is not intended to be exhaustive, and there
/// are many minor differences
///
/// * The list of supported symmetric encryption algorithms has been pruned of all algorithms that are considered legacy. Those that remain
///   are all Authenticated Encryption with Associated Data (AEAD) algorithms. The cipher suite concept has been changed to separate the
///   authentication and key exchange mechanisms from the record protection algorithm (including secret key length) and a hash to be used
///   with both the key derivation function and handshake message authentication code (MAC)
///
/// * A zero round-trip time (0-RTT) mode was added, saving a round trip at connection setup for some application data, at the cost of
///   certain security properties
/// 
/// * Static RSA and Diffie-Hellman cipher suites have been removed; all public-key based key exchange mechanisms now provide forward secrecy
/// 
/// * All handshake messages after the ServerHello are now encrypted. The newly introduced EncryptedExtensions message allows various extensions
///   previously sent in the clear in the ServerHello to also enjoy confidentiality protection
///
/// * The key derivation functions have been redesigned. The new design allows easier analysis by cryptographers due to their improved key
///   separation properties. The HMAC-based Extract-and-Expand Key Derivation Function (HKDF) is used as an underlying primitive
///
/// * The handshake state machine has been significantly restructured to be more consistent and to remove superfluous messages such as
///   ChangeCipherSpec (except when needed for middlebox compatibility)
///
/// * Elliptic curve algorithms are now in the base spec, and new signature algorithms, such as EdDSA, are included.  TLS 1.3 removed point
///   format negotiation in favor of a single point format for each curve
///
/// * Other cryptographic improvements were made, including changing the RSA padding to use the RSA Probabilistic Signature Scheme (RSASSA-PSS),
///   and the removal of compression, the Digital Signature Algorithm (DSA), and custom Ephemeral Diffie-Hellman (DHE) groups
///
/// * The TLS 1.2 version negotiation mechanism has been deprecated in favor of a version list in an extension. This increases compatibility
///   with existing servers that incorrectly implemented version negotiation
///
/// * Session resumption with and without server-side state as well as the PSK-based cipher suites of earlier TLS versions have been replaced
///   by a single new PSK exchange
///
/// * References have been updated to point to the updated versions of RFCs, as appropriate (e.g., RFC 5280 rather than RFC 3280)
///
/// <B>Updates Affecting TLS 1.2</B>
///
/// This document defines several changes that optionally affect implementations of TLS 1.2, including those which do not also support TLS 1.3
///
/// * A version downgrade protection mechanism is described inSection 4.1.3
/// 
/// * RSASSA-PSS signature schemes are defined in Section 4.2.3
/// 
/// * The "supported_versions" ClientHello extension can be used to negotiate the version of TLS to use, in preference to the legacy_version
///   field of the ClientHello
///
/// * The "signature_algorithms_cert" extension allows a client to indicate which signature algorithms it can validate in X.509 certificates
/// 
/// Additionally, this document clarifies some compliance requirements for earlier versions of TLS; see Section 9.3
///
/// <B>Per-Record Nonce</B>
///
/// A 64-bit sequence number is maintained separately for reading and writing records. Each sequence number is set
/// to zero at the beginning of a connection and whenever the key is changed. The sequence number is incremented by
/// one after reading or writing each record. The first record transmitted under a particular set of traffic keys
/// MUST use sequence number 0
///
/// Because the size of sequence numbers is 64-bit, they should not wrap. If a TLS implementation would need to wrap
/// a sequence number, it MUST either re-key (Section 4.6.3) or terminate the connection
///
/// Each AEAD algorithm will specify a range of possible lengths for the per-record nonce, from N_MIN bytes to N_MAX
/// bytes of input ([RFC5116]). The length of the TLS per-record nonce (iv_length) is set to the larger of 8 bytes
/// and N_MIN for the AEAD algorithm (see [RFC5116] Section 4). An AEAD algorithm where N_MAX is less than 8 bytes
/// MUST NOT be used with TLS. The per-record nonce for the AEAD construction is formed as follows:
///
/// 1. The 64-bit record sequence number is encoded in network byte order and padded to the left with zeros to
///    iv_length
///
/// 2. The padded sequence number is XORed with the static client_write_iv or server_write_iv, depending on the
///    role. The resulting quantity (of length iv_length) is used as the per-record nonce
///
/// <B>*** Note: This is a different construction from that in TLS 1.2, which specified a partially explicit nonce ***</B>
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jtlsa13
/// @see ProtocolPP::jtls13
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jtlsa13
/// @see jtls13
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///
 
#include <regex>
#include "jtlsa13.h"
#include "jprotocol.h"

namespace ProtocolPP {

class jtls13 : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// Constructor for TLS13
    /// @param rand - Random data generation for IVs and padding
    /// @param security - Security association (SA) for this TLS flow
    /// @param replay - Type of packet
    //////////////////////////////////////////////////////////////////////
    jtls13(std::shared_ptr<jrand>& rand,
           std::shared_ptr<jtlsa13>& security,
           std::string& replay);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for TLS13
    /// @param rand - Random data generation for IVs and padding
    /// @param security - Security association (SA) for this TLS flow
    /// @param file - file for input/output data
    /// @param replay - Type of packet
    //////////////////////////////////////////////////////////////////////
    jtls13(std::shared_ptr<jrand>& rand,
           std::shared_ptr<jtlsa13>& security,
           std::string& file,
           std::string& replay);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jtls13() {}

    //////////////////////////////////////////////////////////////////////
    /// Encap will produce a packet from the payload passed
    /// @param input - payload to protect with TLS
    /// @param output - packet encapsulated with TLS
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Decap will produce a payload from the packet passed
    /// @param input - packet to decapsulate with TLS
    /// @param output - packet encapsulated with TLS
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    ////////////////////////////////////////////////////////
    /// hkdf_extract creates the pseudorandom key using the
    /// random salt and input key material (IKM). The PRK is
    /// then expanded by hkdf_expand() to create the required
    /// output key material
    /// @param ciphersuite - Ciphersuite to generate PRF data for
    /// @param salt - optional salt (a non-secret random value)
    /// @param ikm - input keying material (IKM)
    /// @param prk - a pseudorandom key of length equal to the hash output
    ////////////////////////////////////////////////////////
    static void hkdf_extract(tls_ciphersuite_t ciphersuite,
                             jarray<uint8_t>& salt,
                             jarray<uint8_t>& ikm,
                             std::shared_ptr<jarray<uint8_t>>& prk);
   
    ////////////////////////////////////////////////////////
    /// hkdf_expand that expands the psuedorandom key material
    /// into the output key material using the PRK, INFO that
    /// uniquifies the output key material, and generates enough
    /// material for keymatlen
    /// @param ciphersuite - Ciphersuite to generate PRF data for
    /// @param keymatlen - length in bytes of the output key material
    /// @param prk - psuedorandom key for the hash function
    /// @param info - optional context and application specific information
    /// @param okm - output keying material (of length keymatlen)
    ////////////////////////////////////////////////////////
    static void hkdf_expand(tls_ciphersuite_t ciphersuite,
                            unsigned int keymatlen,
                            std::shared_ptr<jarray<uint8_t>>& prk,
                            std::shared_ptr<jarray<uint8_t>>& info,
                            std::shared_ptr<jarray<uint8_t>>& okm);

    //////////////////////////////////////////////////////////////////////
    /// Update the type field in the TLS header
    ///
    /// @param hdr - new header
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Update the type field in the TLS header
    ///
    /// @param field - TLS field to update
    /// @param value - new value for the field
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the TLS header
    ///
    /// @return - the header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr();

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the field from the security association
    ///
    /// @param field - field to retrieve
    /// @return value of the field 
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the field from the TLS header
    ///
    /// @param field - field to retrieve
    /// @param header - TLS header to retrieve field from
    /// @return value of the field 
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& header);

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jtlsa13>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Print the protocol and security objects to XML
    ///
    /// @param myxml - XMLPrinter object
    /// @param direction - facilitator for random descriptor generation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jtls13() = delete;
    jtls13(jtls13& jtls13) = delete;
    jtls13(const jtls13& jtls13) = delete;

    // variables for packet generation
    unsigned int m_blksize;
    std::shared_ptr<jtlsa13> m_sec;
    std::string m_replaypkt;
    std::shared_ptr<jreplay<uint64_t, uint16_t>> m_replay;
    jarray<uint8_t> m_tlshdr;
    cipher_t m_cipher;
    auth_t m_auth;

    // initialization routine
    void init(tlstype_t type);
};

}

#endif // JPROTOCOL_JTLS13_H_
