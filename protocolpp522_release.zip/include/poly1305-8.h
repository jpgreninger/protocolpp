///
/// jpoly1305 implementation using 8 bit * 8 bit = 16 bit multiplication and 32 bit addition
/// based on the public domain reference version in supercop by djb
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) modified by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

namespace ProtocolPP {

#if defined(_MSC_VER)
    #define JPOLY1305_NOINLINE __declspec(noinline)
#elif defined(__GNUC__)
    #define JPOLY1305_NOINLINE __attribute__((noinline))
#else
    #define JPOLY1305_NOINLINE
#endif

#define jpoly1305_block_size 16

/* 17 + sizeof(size_t) + 51*sizeof(unsigned char) */
typedef struct jpoly1305_state_internal_t {
    unsigned char buffer[jpoly1305_block_size];
    size_t leftover;
    unsigned char h[17];
    unsigned char r[17];
    unsigned char pad[17];
    unsigned char final;
} jpoly1305_state_internal_t;

void
jpoly1305::jpoly1305_init(jpoly1305_context *ctx, const unsigned char key[32]) {
    jpoly1305_state_internal_t *st = (jpoly1305_state_internal_t *)ctx;
    size_t i;

    st->leftover = 0;

    /* h = 0 */
    for (i = 0; i < 17; i++)
        st->h[i] = 0;

    /* r &= 0xffffffc0ffffffc0ffffffc0fffffff */
    st->r[ 0] = key[ 0] & 0xff;
    st->r[ 1] = key[ 1] & 0xff;
    st->r[ 2] = key[ 2] & 0xff;
    st->r[ 3] = key[ 3] & 0x0f;
    st->r[ 4] = key[ 4] & 0xfc;
    st->r[ 5] = key[ 5] & 0xff;
    st->r[ 6] = key[ 6] & 0xff;
    st->r[ 7] = key[ 7] & 0x0f;
    st->r[ 8] = key[ 8] & 0xfc;
    st->r[ 9] = key[ 9] & 0xff;
    st->r[10] = key[10] & 0xff;
    st->r[11] = key[11] & 0x0f;
    st->r[12] = key[12] & 0xfc;
    st->r[13] = key[13] & 0xff;
    st->r[14] = key[14] & 0xff;
    st->r[15] = key[15] & 0x0f;
    st->r[16] = 0;

    /* save pad for later */
    for (i = 0; i < 16; i++)
        st->pad[i] = key[i + 16];
    st->pad[16] = 0;

    st->final = 0;
}

/// Function of 8-bit version
/// @param h
/// @param c
static void
jpoly1305::jpoly1305_add(unsigned char h[17], const unsigned char c[17]) {
    unsigned short u;
    unsigned int i;
    for (u = 0, i = 0; i < 17; i++) {
        u += (unsigned short)h[i] + (unsigned short)c[i];
        h[i] = (unsigned char)u & 0xff;
        u >>= 8;
    }
}

/// Function of 8-bit version to squeeze the data
/// @param h
/// @param hr
static void
jpoly1305::jpoly1305_squeeze(unsigned char h[17], unsigned long hr[17]) {
    unsigned long u;
    unsigned int i;
    u = 0;
    for (i = 0; i < 16; i++) {
        u += hr[i];
        h[i] = (unsigned char)u & 0xff;
        u >>= 8;
    }
    u += hr[16];
    h[16] = (unsigned char)u & 0x03;
    u >>= 2;
    u += (u << 2); /* u *= 5; */
    for (i = 0; i < 16; i++) {
        u += h[i];
        h[i] = (unsigned char)u & 0xff;
        u >>= 8;
    }
    h[16] += (unsigned char)u;
}

/// Function of 8-bit version to freeze the data
/// @param h
static void
jpoly1305::jpoly1305_freeze(unsigned char h[17]) {
    static const unsigned char minusp[17] = {
        0x05,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0xfc
    };
    unsigned char horig[17], negative;
    unsigned int i;

    /* compute h + -p */
    for (i = 0; i < 17; i++)
        horig[i] = h[i];
    jpoly1305_add(h, minusp);

    /* select h if h < p, or h + -p if h >= p */
    negative = -(h[16] >> 7);
    for (i = 0; i < 17; i++)
        h[i] ^= negative & (horig[i] ^ h[i]);
}

static void
jpoly1305::jpoly1305_blocks(jpoly1305_state_internal_t *st, const unsigned char *m, size_t bytes) {
    const unsigned char hibit = st->final ^ 1; /* 1 << 128 */

    while (bytes >= jpoly1305_block_size) {
        unsigned long hr[17], u;
        unsigned char c[17];
        unsigned int i, j;

        /* h += m */
        for (i = 0; i < 16; i++)
            c[i] = m[i];
        c[16] = hibit;
        jpoly1305_add(st->h, c);

        /* h *= r */
        for (i = 0; i < 17; i++) {
            u = 0;
            for (j = 0; j <= i ; j++) {
                u += (unsigned short)st->h[j] * st->r[i - j];
            }
            for (j = i + 1; j < 17; j++) {
                unsigned long v = (unsigned short)st->h[j] * st->r[i + 17 - j];
                v = ((v << 8) + (v << 6)); /* v *= (5 << 6); */
                u += v;
            }
            hr[i] = u;
        }

        /* (partial) h %= p */
        jpoly1305_squeeze(st->h, hr);

        m += jpoly1305_block_size;
        bytes -= jpoly1305_block_size;
    }
}

JPOLY1305_NOINLINE void
jpoly1305::jpoly1305_finish(jpoly1305_context *ctx, unsigned char mac[16]) {
    jpoly1305_state_internal_t *st = (jpoly1305_state_internal_t *)ctx;
    size_t i;

    /* process the remaining block */
    if (st->leftover) {
        size_t i = st->leftover;
        st->buffer[i++] = 1;
        for (; i < jpoly1305_block_size; i++)
            st->buffer[i] = 0;
        st->final = 1;
        jpoly1305_blocks(st, st->buffer, jpoly1305_block_size);
    }

    /* fully reduce h */
    jpoly1305_freeze(st->h);

    /* h = (h + pad) % (1 << 128) */
    jpoly1305_add(st->h, st->pad);
    for (i = 0; i < 16; i++)
        mac[i] = st->h[i];

    /* zero out the state */
    for (i = 0; i < 17; i++)
        st->h[i] = 0;
    for (i = 0; i < 17; i++)
        st->r[i] = 0;
    for (i = 0; i < 17; i++)
        st->pad[i] = 0;
}

}

