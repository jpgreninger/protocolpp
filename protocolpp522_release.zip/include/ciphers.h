#ifndef CIPHERS_H
#define CIPHERS_H

///
///\class ciphers ciphers.h
///
/// This class is a wrapper for the Crypto++ library to simplify it's interface
/// and hide some of the more esoteric aspects of the interface and returns a
/// static shared_ptr to access the encryption/authentication/crc engine.
///
/// The implementation of the modes of operation are found in the class \ref jmodes
/// as well as any implementation for authentication or CRC32
///
/// The ciphers class contains three factory methods for ciphers, authentication
/// algorithms, and CRC32 as follows
///
/// The underlying ECB mode engines are from the CryptoPP library with mode logic
/// for all approved modes (GCM, CCM, GHASH, CMAC, CBC, XCBC-MAC, AEAD) coded by
/// myself
///
/// Beginning with CryptoPP 5.6.0, CryptoPP uses SIMD and AVX commands for several
/// hardware supported algorithms such as AES, CRC, SHA2, CHACHA20, etc if detected
/// on the CPU being used
///
///\code
///
/// static std::shared_ptr<jmodes> get_cipher(jmodes::cipher_t cipher,
///                                           jmodes::dir_t direction,
///                                           jmodes::mode_t mode,
///                                           uint8_t* key,
///                                           unsigned int keylen,
///                                           uint8_t* iv=NULL,
///                                           unsigned int ivlen=0,
///                                           unsigned int icvlen=16,
///                                           uint32_t count=0,
///                                           uint8_t bearer=0);
///
/// static std::shared_ptr<jmodes> get_auth(auth_t auth,
///                                         uint8_t* authkey=NULL,
///                                         unsigned int authkeylen=0,
///                                         jmodes::dir_t dir=jmodes::ENC,
///                                         uint32_t count=0,
///                                         uint32_t fresh=0);
///
/// static std::shared_ptr<jmodes> get_crc();
///\endcode
///
/// Usage examples for get_cipher() are found below
///
///\code
///
///        ///////////////////////////////////////////////////////////////////////
///        /// From gcm-nist-6 Appendix B Test Case #1
///        ///////////////////////////////////////////////////////////////////////
///
///        // Key (K)       :
///        ProtocolPP::jarray<uint8_t> key("00000000000000000000000000000000");
///        
///        //Message (M)    : <empty string>
///        ProtocolPP::jarray<uint8_t> aad(0);
///        ProtocolPP::jarray<uint8_t> message(0);
///        ProtocolPP::jarray<uint8_t> iv("000000000000000000000000");
///        ProtocolPP::jarray<uint8_t> expect(0);
///        ProtocolPP::jarray<uint8_t> output(message.get_size());
///        ProtocolPP::jarray<uint8_t> ricv("58e2fccefa7e3061367f1d57a4e7455a");
///        ProtocolPP::jarray<uint8_t> icv(16);
///    
///        std::shared_ptr<ProtocolPP::jmodes> engine;
///
///        ///////////////////////////////////////////////////////////////////////
///        /// create engine
///        ///////////////////////////////////////////////////////////////////////
///        engine = ProtocolPP::ciphers::get_cipher(ProtocolPP::jmodes::AES,
///                                                 ProtocolPP::jmodes::ENC,
///                                                 ProtocolPP::jmodes::GCM,
///                                                 key.get_ptr(),
///                                                 key.get_size(),
///                                                 iv.get_ptr(),
///                                                 iv.get_size(),
///                                                 icv.get_size());
///
///        engine->ProcessData(message.get_ptr(),
///                            output.get_ptr(),
///                            message.get_size(),
///                            aad.get_ptr(),
///                            aad.get_size());
///    
///        engine->result(icv.get_ptr(),
///                       icv.get_size());
///    
///        if (output != expect) {
///            std::cerr << "In testgcm() conformance #1 data mismatch" << std::endl;
///            std::cerr << output.debug(expect);
///        }
///        else if (ricv != icv) {
///            std::cerr << "In testgcm() conformance #1 icv mismatch" << std::endl;
///            std::cerr << ricv.debug(icv);
///        }
///\endcode
///
/// Usage examples for get_auth()
///
///\code
///
///         // create random data and array for ICV and context
///         ProtocolPP::jarray<uint8_t> tmpkey = myrand->getbyte(32);
///         ProtocolPP::jarray<uint8_t> icv(16);
///         ProtocolPP::jarray<uint8_t> input = myrand->getbyte(125);
///         ProtocolPP::jarray<uint8_t> roundkeys(144);
///
///         // create the engine
///         ProtocolPP::jpoly1305 tmp(tmpkey.get_ptr(), tmpkey.get_size());
///
///         // save the context of the poly1305 engine for later processing
///         tmp.context(roundkeys.get_ptr(), roundkeys.get_size());
///
///         // create engine with the context
///         ProtocolPP::jpoly1305 tmp2(roundkeys.get_ptr());
///
///         // Process data
///         tmp2.ProcessData(input.get_ptr(), input.get_size());
///
///         // retrieve the ICV
///         tmp2.result(icv.get_ptr(), icv.get_size());
///\endcode
///
/// Usage example for get_crc()
///
///\code
///
///        ProtocolPP::jarray<uint8_t> idat = myrand->getbyte(300);
///        ProtocolPP::jarray<uint8_t> result(1,0);
///
///        engine = ProtocolPP::ciphers::get_crc(ProtocolPP::CRC8);
///        engine->ProcessData(idat.get_ptr(), idat.get_size());
///        engine->result(result.get_ptr(), result.get_size());
///
///        poly = 0x92;
///        engine = ProtocolPP::ciphers::get_crc(ProtocolPP::CRC_POLY,
///                                              poly,
///                                              8,
///                                              false,
///                                              true,
///                                              false,
///                                              true);
///
///        engine->ProcessData(idat.get_ptr(), idat.get_size());
///        engine->result(result.get_ptr(), result.get_size());
///\endcode
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::ciphers
/// @see ProtocolPP::jconfident
/// @see ProtocolPP::jconfidentsa
/// @see ProtocolPP::jintegrity
/// @see ProtocolPP::jintegritysa
///
/// <B>For Addtional Documentation:</B>
/// @see jmodes
/// @see ciphers
/// @see jconfident
/// @see jconfidentsa
/// @see jintegrity
/// @see jintegritysa
///
/// <center>Protocol++&reg; (Protocolpp&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jmodes.h"

namespace ProtocolPP {

class ciphers {

public:

    //////////////////////////////////////////////////////////////////////
    /// Factory method to create an instance of a cipher algorithm
    ///
    /// @param cipher - DES, DES_EDE3, AES, ARIA, Camellia, SM4,
    ///                 SEED, CHACHA20, SNOWE, SNOWVE, ZUCE, ARC4
    /// @param direction - Direction of processing (ENC or DEC)
    /// @param mode - ECB, CBC, CTR, GCM, CCM, CMAC,
    ///               XCBC_MAC, AUTH, AEAD, STREAM
    /// @param key - Encryption key
    /// @param keylen - Length of the encryption key
    /// @param iv - Initialization vector (IV)
    /// @param ivlen - Length of the IV
    /// @param icvlen - ICV length
    /// @param count - Count value for SNOW3G and ZUC
    /// @param bearer - Bearer value for SNOW3G and ZUC
    //////////////////////////////////////////////////////////////////////
    static std::shared_ptr<jmodes> get_cipher(jmodes::cipher_t cipher,
                                              jmodes::dir_t direction,
                                              jmodes::mode_t mode,
                                              uint8_t* key,
                                              unsigned int keylen,
                                              uint8_t* iv=nullptr,
                                              unsigned int ivlen=0,
                                              unsigned int icvlen=16,
                                              uint32_t count=0,
                                              uint8_t bearer=0);

    //////////////////////////////////////////////////////////////////////
    /// Factory method to create an instance of authenticator
    ///
    /// @param auth - POLY1305, SNOWA, ZUCA, MD5, SHA1, SHA224,
    ///               SHA3_224, SHA256, SHA3_256, SHA384,
    ///               SHA3_384, SHA512, SHA3_512
    ///
    /// @param authkey - Key for the authentication engine
    /// @param authkeylen - Length of the key for the authentication engine
    /// @param dir - direction of processing for SNOW3G and ZUC (UPLINK or DOWNLINK)
    /// @param count - Count value for SNOW3G and ZUC
    /// @param fresh - Fresh value for SNOW3G and ZUC
    //////////////////////////////////////////////////////////////////////
    static std::shared_ptr<jmodes> get_auth(auth_t auth,
                                            uint8_t* authkey=nullptr,
                                            unsigned int authkeylen=0,
                                            jmodes::dir_t dir=jmodes::ENC,
                                            uint32_t count=0,
                                            uint32_t fresh=0);

    //////////////////////////////////////////////////////////////////////
    /// Factory method to create an instance of CRC
    /// @param crc - Type of CRC to create CRC5, CRC7, CRC8, CRC11, CRC12, CRC16_CCITT, CRC24, CRC32_IETF, CRC32_IEEE, CRC_POLY
    /// @param poly - Polynomial for CRC if not predefined (CRC_POLY type only)
    /// @param polylen - length of polynomial in bits (CRC_POLY only)
    /// @param zeroinit - Initial value of the CRC is all zeros (rather than all 1s, CRC_POLY only)
    /// @param swapin - Input data is swapped before use (CRC_POLY only)
    /// @param swapout - Output data is swapped after final calculation (CRC_POLY only)
    /// @param xorout - XOR of output data (CRC_POLY only)
    //////////////////////////////////////////////////////////////////////
    static std::shared_ptr<jmodes> get_crc(auth_t crc=auth_t::CRC32_IEEE,
                                           uint32_t poly=0,
                                           unsigned int polylen=0,
                                           bool zeroinit=false,
                                           bool swapin=true,
                                           bool swapout=true,
                                           bool xorout=true);
private:

    // don't use these
    ciphers() = delete;
    ciphers(ciphers& rhs) = delete;
    ciphers(const ciphers& rhs) = delete;
};

}

#endif //CIPHERS_H
