#ifndef JDSASA_H_
#define JDSASA_H_

///
///\class jdsasa jdsasa.h "include/jdsasa.h"
///
///\section DSASAClassSA Digital Signature Algorithm (DSA) Security Association
///
/// See https://en.wikipedia.org/wiki/Digital_Signature_Algorithm
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jdsa
/// @see ProtocolPP::jdsasa
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
/// @see jsecass
/// @see jprotocol
/// @see jdsa
/// @see jdsasa
/// @see jarray
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#include <sys/types.h>
//#include <unistd.h>
//#include <crypt.h>
#include "jsecass.h"
#include <cstring>
#include <memory>
#include "jlogger.h"
#include "jenum.h"
#include "jarray.h"

#include "filters.h"
using CryptoPP::StringSink;
using CryptoPP::StringStore;

#include "nbtheory.h"
using CryptoPP::ModularExponentiation;

#include "osrng.h"
using CryptoPP::AutoSeededRandomPool;

#include "dh.h"
using CryptoPP::DH;

#include "sha.h"
using CryptoPP::SHA1;
using CryptoPP::SHA256;
using CryptoPP::SHA384;
using CryptoPP::SHA512;

#include "secblock.h"
using CryptoPP::SecByteBlock;

#include "integer.h"
using CryptoPP::Integer;

namespace ProtocolPP {

class jdsasa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor with defaults
    ///
    /// <table>
    /// <caption id="DSA Defaults">DSA Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>bitsize<td>3078
    /// <tr><td>mode<td>keymode_t::GENKEYPAIR
    /// <tr><td>product<td>0
    /// <tr><td>quotient<td>0
    /// <tr><td>generator<td>0
    /// <tr><td>prvkey<td>0
    /// <tr><td>pubkey<td>0
    /// </table>
    //////////////////////////////////////////////////////////////////////
    jdsasa();
   
    //////////////////////////////////////////////////////////////////////
    /// Security Association for DSA
    ///
    /// Required fields for DSA
    ///
    /// @param bitsize - size of the private key (768:1024:2048:3078:4096:6172:8192)
    /// @param mode - Direction of data flow (GENKEYPAIR:PKISIGN:PKIVERIFY)
    //////////////////////////////////////////////////////////////////////
    jdsasa(int bitsize,
           keymode_t mode);

    //////////////////////////////////////////////////////////////////////
    /// Security Association for DSA
    ///
    /// Required fields for DSA
    ///
    /// @param bitsize - size of the private key (768:1024:2048:3078:4096:6172:8192)
    /// @param mode - Direction of data flow (GENKEYPAIR:PKISIGN:PKIVERIFY)
    /// @param prime - Product (Prime) parameter for DSA field
    /// @param subprime - Quotient (SubPrime) parameter for DSA field
    /// @param generator - Generator parameter for DSA field
    //////////////////////////////////////////////////////////////////////
    jdsasa(int bitsize,
           keymode_t mode,
           CryptoPP::Integer prime,
           CryptoPP::Integer subprime,
           CryptoPP::Integer generator);

    //////////////////////////////////////////////////////////////////////
    /// Security Association for DSA
    ///
    /// Required fields for DSA
    ///
    /// @param bitsize - size of the private key (768:1024:2048:3078:4096:6172:8192)
    /// @param mode - Direction of data flow (GENKEYPAIR:PKISIGN:PKIVERIFY)
    /// @param prvkey - Private DSA key
    /// @param pubkey - Public DSA key
    //////////////////////////////////////////////////////////////////////
    jdsasa(int bitsize,
           keymode_t mode,
           CryptoPP::DSA::PrivateKey prvkey,
           CryptoPP::DSA::PublicKey pubkey);

    //////////////////////////////////////////////////////////////////////
    /// standard copy constructor
    //////////////////////////////////////////////////////////////////////
    jdsasa(jdsasa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// standard copy constructor from shared pointer
    //////////////////////////////////////////////////////////////////////
    explicit jdsasa(std::shared_ptr<jdsasa>& rhs);
     
    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jdsasa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the DSA security association
    ///
    /// <table>
    /// <caption id="DSASA Set Fields">DSA Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>int<td>BITSIZE<td>set_field<int>(field_t::BITSIZE, 3078)
    /// <tr><td>keymode_t<td>MODE<td>set_field<keymode_t>(field_t::MODE, keymode_t::GENKEYPAIR)
    /// <tr><td>CryptoPP::Integer <td>PRIME<td>set_field<CryptoPP::Integer>(field_t::PRIME, product)
    /// <tr><td>CryptoPP::Integer <td>SUBPRIME<td>set_field<CryptoPP::Integer>(field_t::SUBPRIME, quotient)
    /// <tr><td>CryptoPP::Integer <td>GENERATOR<td>set_field<CryptoPP::Integer>(field_t::GENERATOR, generator)
    /// <tr><td>CryptoPP::DSA::PrivateKey <td>PRVKEY<td>set_field<CryptoPP::DSA::PrivateKey>(field_t::PRVKEY, prvkey)
    /// <tr><td>CryptoPP::DSA::PublicKey <td>PUBKEY<td>set_field<CryptoPP::DSA::PublicKey>(field_t::PUBKEY, pubkey)
    /// </table>
    ///
    /// @param field - field to update the DSA security association
    /// @param fieldval - value to update the DSA security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the DSA security association
    ///
    /// <table>
    /// <caption id="DSASA Get Fields">DSA Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>int<td>BITSIZE<td>int bitsize = get_field<int>(field_t::BITSIZE)
    /// <tr><td>keymode_t<td>MODE<td>keymode_t mode = get_field<keymode_t>(field_t::MODE)
    /// <tr><td>CryptoPP::Integer <td>PRIME<td>CryptoPP::Integer product = get_field<CryptoPP::Integer>(field_t::PRIME)
    /// <tr><td>CryptoPP::Integer <td>SUBPRIME<td>CryptoPP::Integer quotient = get_field<CryptoPP::Integer>(field_t::SUBPRIME)
    /// <tr><td>CryptoPP::Integer <td>GENERATOR<td>CryptoPP::Integer generator = get_field<CryptoPP::Integer>(field_t::GENERATOR)
    /// <tr><td>CryptoPP::DSA::PrivateKey <td>PRVKEY<td>CryptoPP::DSA::PrivateKey prvkey = get_field<CryptoPP::DSA::PrivateKey>(field_t::PRVKEY)
    /// <tr><td>CryptoPP::DSA::PublicKey <td>PUBKEY<td>CryptoPP::DSA::PublicKey pubkey = get_field<CryptoPP::DSA::PublicKey>(field_t::PUBKEY)
    /// </table>
    ///
    /// @param field - field to retrieve from the DSA security association
    /// @return field of the DSA security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jdsasa(const jdsasa& jdsasa) = delete;
    
    // member variables
    direction_t m_dir;
    int m_bitsize;
    keymode_t m_mode;
    CryptoPP::Integer m_prime;
    CryptoPP::Integer m_subprime;
    CryptoPP::Integer m_generator;
    CryptoPP::DSA::PrivateKey m_prvkey;
    CryptoPP::DSA::PublicKey m_pubkey;
};

}

#endif // JDSASA_H_
