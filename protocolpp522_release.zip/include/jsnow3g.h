#ifndef JSNOW3G_H
#define JSNOW3G_H

///
///\class jsnow3g jsnow3g.h "include/jsnow3g.h"
///
///\section SNOWESNOWE Snow3g Stream Cipher
///
/// @see Specification of the 3GPP Confidentiality and Integrity Algorithms UEA2 and UIA2 Document 2: SNOW 3G Specification
///
/// SNOW 3G is a word-oriented stream cipher that generates a sequence of 32-bit words under
/// the control of a 128-bit key and a 128-bit initialisation variable. These words can be used
/// to mask the plaintext. First a key initialisation is performed, i.e. the cipher is clocked
/// without producing output, see 4.1. Then with every clock tick it produces a 32-bit word of
/// output
///
/// <B>Functions used in different Components of SNOW 3G</B> 
///
/// <B>MULx</B> maps 16 bits to 8 bits. Let V and c be 8-bit input values. Then MULx is defined:
///
/// If the leftmost (i.e. the most significant) bit of V equals 1, then
///
/// \f$ MULx(V, c) = (V <<_8 1) \oplus c, else MULx(V, c) = V <<_8 1\f$
///
/// <B>MULxPOW</B> maps 16 bits and an positive integer i to 8 bit. Let V and c be 8-bit input
/// values, then MULxPOW(V, i, c) is recursively defined:
///
/// If i equals 0, then \f$ MULxPOW(V, i, c) = V\f$, else \f$ MULxPOW(V, i, c) = MULx(MULxPOW(V, i-1, c), c)\f$ 
///
/// <B>Linear Feedback Shift Register (LFSR)</B>
///
/// The Linear Feedback Shift Register (LFSR) consists of sixteen stages \f$ s_0, s_1, s_2,\cdots, s_{15}\f$
/// each holding 32 bits
///
/// <B>Finite State Machine (FSM)</B> 
///
/// The Finite State Machine (FSM) has three 32-bit registers R1, R2 and R3. The S-boxes S1
/// and S2 are used to update the registers R2 and R3
///
/// <B>The 32x32-bit S-Box S1</B>
///
/// The S-Box \f$ S_1\f$ maps a 32-bit input to a 32-bit output. Let \f$ w = w_0 || w_1 || w_2 || w_3\f$ the
/// 32-bit input with \f$ w_0\f$ the most and \f$ w3\f$ the least significant byte
///
/// Let \f$ S_1(w)= r_0 || r_1 || r_2 || r_3\f$ with \f$ r_0\f$ the most and \f$ r_3\f$ the least significant byte.
/// We use the 8 to 8 bit Rijndael S-Box \f$ S_R\f$ defined in 5.1
///
/// Then \f$ r_0, r_1, r_2, r_3\f$ are defined as 
///
/// \f$ r_0= MULx(S_R(w_0), 0x1B) \oplus S_R(w_1) \oplus S_R(w_2) \oplus MULx(S_R(w_3), 0x1B) \oplus S_R(w_3)\f$
///
/// \f$ r_1= MULx(S_R(w_0), 0x1B) \oplus S_R(w_0) \oplus MULx(S_R(w_1), 0x1B) \oplus S_R(w_2) \oplus S_R(w_3)\f$
///
/// \f$ r_2= S_R(w_0) \oplus MULx(S_R(w_1), 0x1B) \oplus S_R(w_1) \oplus MULx(S_R(w_2), 0x1B) \oplus S_R(w_3)\f$ 
///
/// \f$ r_3= S_R(w_0) \oplus S_R(w_1) \oplus MULx(S_R(w_2), 0x1B) \oplus S_R(w_2) \oplus MULx(S_R(w_3), 0x1B)\f$
///
/// <B>The 32x32-bit S-Box S2</B> 
///
/// The S-Box \f$ S_2\f$ maps a 32-bit input to a 32-bit output. Let \f$ w = w_0 || w_1 || w_2 || w_3\f$ the
/// 32-bit input with \f$ w_0\f$ the most and \f$ w_3\f$ the least significant byte. Let \f$ S_2(w)= r_0 || r_1 || r_2 || r_3\f$
/// with \f$ r0\f$ the most and \f$ r3\f$ the least significant byte. We use the 8 to 8 bit S-Box \f$ S_Q\f$ defined in 5.2 
///
/// Then \f$ r_0, r_1, r_2, r_3\f$ are defined as 
///
/// \f$ r_0= MULx(S_Q(w_0), 0x69) \oplus S_Q(w_1) \oplus S_Q(w_2) \oplus MULx(S_Q(w_3), 0x69) \oplus SQ(w3)\f$ 
///
/// \f$ r_1= MULx(S_Q(w_0), 0x69) \oplus S_Q(w_0) \oplus MULx(S_Q(w_1), 0x69) \oplus S_Q(w_2) \oplus S_Q(w_3)\f$ 
///
/// \f$ r_2= S_Q(w_0) \oplus MULx(S_Q(w_1), 0x69) \oplus S_Q(w_1) \oplus MULx(S_Q(w_2), 0x69) \oplus S_Q(w_3)\f$ 
///
/// \f$ r_3= S_Q(w_0) \oplus S_Q(w_1) \oplus MULx(S_Q(w_2), 0x69) \oplus S_Q(w_2) \oplus MULx(S_Q(w_3), 0x69)\f$ 
///
///\section TCOPSnow3G The Clocking Operations 
///
/// <B>Clocking the LFSR</B>
///
/// The clocking of the LFSR has two different modes of operation, the Initialisation Mode 3.4.4 and the Keystream Mode 3.4.5.
/// In both modes the functions \f$ MUL_α\f$ and \f$ DIV_α\f$ are used which are defined in 3.4.2 resp. 3.4.3
///
/// <B>The function \f$ MUL_α\f$</B>
///
/// The function \f$ MUL_α\f$ maps 8 bits to 32 bits. Let c be the 8-bit input, then \f$ MUL_α\f$ is defined as 
///
/// \f$ MUL_α(c) = (MULxPOW(c, 23, 0xA9) || MULxPOW(c, 245, 0xA9) || MULxPOW(c, 48, 0xA9) || MULxPOW(c, 239, 0xA9))\f$ 
///
/// <B>The function \f$ DIV_α\f$</B>
///
/// The function \f$ DIV_α\f$ maps 8 bits to 32 bits. Let c be the 8-bit input, then \f$ DIV_α\f$ is defined as 
///
/// \f$ DIV_α(c) = (MULxPOW(c, 16, 0xA9) || MULxPOW(c, 39, 0xA9) || MULxPOW(c, 6, 0xA9) || MULxPOW(c, 64, 0xA9))\f$ 
///
/// <B>Initialisation Mode</B>
///
/// In the Initialisation Mode the LFSR receives a 32-bit input word F, which is the output of the FSM
///
/// Let \f$ s_0 = s_{0,0} || s_{0,1} || s_{0,2} || s_{0,3}\f$ with \f$ s_{0,0}\f$ being the most and \f$ s_{0,3}\f$ being
/// the least significant byte of \f$ s_0\f$. 
///
/// Let \f$ s_{11} = s_{11,0} || s_{11,1} || s_{11,2} || s_{11,3}\f$ with \f$ s_{11,0}\f$ being the most and \f$ s_{11,3}\f$
/// being the least significant byte of \f$ s_{11}\f$ 
///
/// Compute the intermediate value v as 
///
/// \f$ v = (s_{0,1} || s_{0,2} || s_{0,3} || 0x00) \oplus MUL_α(s_{0,0}) \oplus s_2 \oplus (0x00 || s_{11,0} || s_{11,1} || s_{11,2}) \oplus DIV_α(s_{11,3}) \oplus F\f$
///
/// Set 
///
/// \f$ s_0=s_1, s_1=s_2, s_2=s_3, s_3=s_4, s_4=s_5, s_5=s_6, s_6=s_7, s_7=s_8\f$
///
/// \f$ s_8=s_9, s_9=s_{10}, s_{10}=s_{11}, s_{11}=s_{12}, s_{12}=s_{13}, s_{13}=s_{14}, s_{14}=s_{15}, s_{15} = v\f$
///
/// <B>Keystream Mode</B>
///
/// In the Keystream Mode the LFSR does not receive any input
///
/// Let \f$ s_0 = s_{0,0} || s_{0,1} || s_{0,2} || s_{0,3}\f$ with \f$ s_{0,0}\f$ being the most and \f$ s_{0,3}\f$ being the least significant byte of \f$ s_0\f$ 
///
/// Let \f$ s_11 = s_{11,0} || s_{11,1} || s_{11,2} || s_{11,3}\f$ with \f$ s_{11,0}\f$ being the most and \f$ s_{11,3}\f$ being the least significant byte of \f$ s_11\f$
///
/// Compute the intermediate value v as 
///
/// v = \f$ (s_{0,1} || s_{0,2} || s_{0,3} || 0x00) \oplus MUL_α(s_{0,0}) \oplus s_2 \oplus (0x00 || s_{11,0} || s_{11,1} || s_{11,2}) \oplus DIV_α(s_{11,3})\f$ 
///
/// Set 
///
/// \f$ s_0=s_1, s_1=s_2, s_2=s_3, s_3=s_4, s_4=s_5, s_5=s_6, s_6=s_7, s_7=s_8\f$
///
/// \f$ s_8=s_9, s_9=s_{10}, s_{10}=s_{11}, s_{11}=s_{12}, s_{12}=s_{13}, s_{13}=s_{14}, s_{14}=s_{15}, s_{15}=v\f$ 
///
/// <B>Clocking the FSM</B>
///
/// The FSM has two input words \f$ s_{15}\f$ and \f$ s_5\f$ from the LFSR. It produces a 32-bit output word F: 
///
/// \f$ F = (s_{15} \oplus R1) \oplus R2\f$
///
/// Then the registers are updated. Compute the intermediate value r as 
///
/// \f$ r = R2 \oplus (R3 \oplus s_5)\f$ 
///
/// Set 
///
/// \f$ R3 = S_2(R2)\f$
///
/// \f$ R2 = S_1(R1)\f$
///
/// \f$ R1 = r\f$
///
///\section OPSnow3GSnow3G Operation of SNOW 3G 
///
/// <B>Initialisation</B>
///
/// SNOW 3G is initialized with a 128-bit key consisting of four 32-bit words <B>\f$ k_0, k_1, k_2, k_3\f$</B> and an 128-bit initialisation
/// variable consisting of four 32-bit words <B>\f$ IV_0, IV_1, IV_2, IV_3\f$</B> as follows
///
/// Let <B>1</B> be the all-ones word (0xffffffff)
///
/// \f$ s_{15}=k_3 \oplus IV_0\f$ 
///
/// \f$ s_{14}=k_2\f$
///
/// \f$ s_{13}=k_1\f$
///
/// \f$ s_{12}=k_0 \oplus IV_1\f$ 
/// 
/// \f$ s_{11}=k_3 \oplus 1\f$
///
/// \f$ s_{10}=k_2 \oplus 1 \oplus IV_2 s_9 = k_1 \oplus 1 \oplus IV_3 s_8 = k_0 \oplus 1\f$ 
///
/// \f$ s_7=k_3\f$
///
/// \f$ s_6=k_2\f$
///
/// \f$ s_5=k_1\f$
///
/// \f$ s_4=k_0\f$ 
///
/// \f$ s_3=k_3 \oplus 1\f$
///
/// \f$ s_2=k_2 \oplus 1\f$
///
/// \f$ s_1=k_1 \oplus 1\f$
///
/// \f$ s_0=k_0 \oplus 1\f$ 
///
/// The FSM is initialised with \f$ R1 = R2 = R3 = 0\f$
///
/// Then the cipher runs in a special mode without producing output: 
///
/// repeat 32-times { 
///
/// STEP 1: The FSM is clocked (see 3.4.6) producing the 32-bit word F
///
/// STEP 2: Then the LFSR is clocked in Initialisation Mode (see 3.4.4) consuming F
///
/// } 
///
///\image html Snow3GDuringInit.png "Snow 3G Algorithm During Initialization"
///\image latex Snow3GDuringInit.eps "Snow 3G Algorithm During Initialization" width=5cm
///
/// <B>Generation of Keystream</B>
///
/// First the FSM is clocked once, see 3.4.6. The output word of the FSM is discarded. Then the LFSR is clocked once
/// in Keystream Mode, see 3.4.4
///
/// After that n 32-bit words of keystream are produced:
///
/// for t = 1 to n {
///
/// STEP 1: The FSM is clocked (see 3.4.6) and produces a 32-bit output word F
///
/// STEP 2: The next keystream word is computed as \f$ z_t = F \oplus s_0\f$
///
/// STEP 3: Then the LFSR is clocked in Keystream Mode, see 3.4.4
///
/// } 
///
///\image html Snow3GDuringKeyStream.png "Snow 3G Algorithm During Key-Stream Generation"
///\image latex Snow3GDuringKeyStream.eps "Snow 3G Algorithm During Key-Stream Generation" width=5cm
///
/// <B>The Rijndael S-box \f$ S_R\f$</B>
///
/// The S-box SR maps 8 bit to 8 bit. Here the input and output is presented in hexadecimal form
///
/// Let \f$ x_0, x_1, y_0, y_1\f$ be hexadecimal digits with \f$ S_R(x_0 {2}^{4}+x_1) = y_0 {2}^{4} + y_1\f$, then the
/// cell at the intersection of the \f$ {x_0}^{th}\f$ row and the \f$ {x_1}^{th}\f$ column contains the values for \f$ y_0 || y_1\f$ in 
/// hexadecimal form
///
/// For example \f$ S_R(42) = S_R(0x2A) = 0xE5 = 229\f$
///
///\image html SnowSBOXSr.png "Rijndael S-Box"
///\image latex SnowSBOXSr.eps "Rijndael S-Box" width=5cm
///
/// <B>The S-box \f$ S_Q\f$</B>
///
/// The S-box \f$ S_Q\f$ maps 8 bit to 8 bit. Here the input is presented in hexadecimal form
///
/// Let \f$ x_0, x_1, y_0, y_1\f$ be hexadecimal digits with \f$ S_Q(x_0 {2}^{4}+x_1) = y_0 {2}^{4} + y_1\f$, then the
/// cell at the intersection of the \f$ {x_0}^{th}\f$ row and the \f$ {x_1}^{th}\f$ column contains the values for \f$ y_0 || y_1\f$ in hexadecimal form
///
/// For example \f$ S_Q(42) = S_Q(0x2A) = 0xAC = 172\f$
///
///\image html SnowSBOXSq.png "S-Box SQ"
///\image latex SnowSBOXSq.eps "S-Box SQ" width=5cm
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jsnow3g
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jconfident
/// @see ProtocolPP::jintegrity
///
/// <B>For Additional Documentation:</B>
/// @see jarray
/// @see jsnow3g
/// @see jmodes
/// @see jconfident
/// @see jintegrity
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>
#include "jenum.h"

namespace ProtocolPP {

class jsnow3g {

public:

    //////////////////////////////////////////////////////////////////////
    /// Direction of processing for SNOW3G
    /// UPLINK - User to tower
    /// DOWNLINK - Tower to user
    //////////////////////////////////////////////////////////////////////
    enum dir_t {
        UPLINK,
        DOWNLINK
    };

    //////////////////////////////////////////////////////////////////////
    /// Interface for Snow-3G encryption
    ///
    /// @param dir - Direction of the data
    /// @param key - Key for encryption of the data
    /// @param keylen - Key length for encryption of the data
    /// @param count - Count value to generate key stream
    /// @param bearer - Bearer value for initialize the cipher
    //////////////////////////////////////////////////////////////////////
    jsnow3g(dir_t dir,
            uint8_t* key,
            unsigned int keylen,
            uint32_t count,
            uint8_t bearer);

    //////////////////////////////////////////////////////////////////////
    /// Interface for Snow-3G authentication
    ///
    /// @param dir - Direction of the data
    /// @param key - Key for authentication of the data
    /// @param keylen - Key length for authentication of the data
    /// @param count - Count value to generate key stream
    /// @param fresh - Fresh value for initialize the authenticator
    //////////////////////////////////////////////////////////////////////
    jsnow3g(dir_t dir,
            uint8_t* key,
            unsigned int keylen,
            uint32_t count,
            uint32_t fresh);

    //////////////////////////////////////////////////////////////////////
    /// Interface for Snow-3G authentication
    ///
    /// @param dir - Direction of the data
    /// @param ctx - Context (keystream data) to rebuild engine
    /// @param ctxlen - Length of context in words (should be 19)
    //////////////////////////////////////////////////////////////////////
    jsnow3g(dir_t dir,
            uint32_t* ctx,
            unsigned int ctxlen);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jsnow3g() {
        delete m_KS;
        m_KS=nullptr;
    }

    //////////////////////////////////////////////////////////////////////
    /// Calculates either the ciphertext or plaintext based on dir using
    /// a bitlength that is passed to the function
    ///
    /// @param input - either the ciphertext or plaintext to be calculated
    /// @param output - result of encryption process
    /// @param length - bit length
    //////////////////////////////////////////////////////////////////////
    void ProcessData(const uint8_t* input, uint8_t* output, int length);

    //////////////////////////////////////////////////////////////////////
    /// Authenticates the input
    ///
    /// @param input - data to authenticate
    /// @param length - bit length
    //////////////////////////////////////////////////////////////////////
    void ProcessData(const uint8_t* input, uint64_t length);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the context of the engine
    ///
    /// @return context - current keystream context during processing, 19 word pointer expected
    //////////////////////////////////////////////////////////////////////
    void context(uint32_t* context);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the result of the authentication
    ///
    /// @return icv - result of the authentication process
    //////////////////////////////////////////////////////////////////////
    void result(uint8_t* icv);

    //////////////////////////////////////////////////////////////////////
    /// Size of the result
    ///
    /// @return size of the result or ICV
    //////////////////////////////////////////////////////////////////////
    unsigned int result_size() { return 4; }

private:

    // don't allow these
    jsnow3g() = delete;
    jsnow3g(jsnow3g& rhs) = delete;
    jsnow3g(const jsnow3g& rhs) = delete;

    // direction of processing
    dir_t m_dir;

    // cipher or auth key
    uint32_t m_key[4];
    unsigned int m_keylen;

    // internal variables
    uint32_t m_iv[4];
    uint32_t* m_KS;

    // LFSR
    uint32_t m_LFSR[16];

    // FSM
    uint32_t m_FSM[3];

    // ICV
    uint8_t m_icv[4];

    // Rijndael S-box SR
    static const uint8_t m_SR[256];

    // S-box SQ
    static const uint8_t m_SQ[256];

    // MULx
    uint8_t MULx(uint8_t V, uint8_t c);

    // MULxPOW
    uint8_t MULxPOW(uint8_t V, uint8_t i, uint8_t c);

    // The function MUL alpha
    uint32_t MULalpha(uint8_t c);

    // The function DIV alpha
    uint32_t DIValpha(uint8_t c);

    // The 32x32-bit S-Box S1
    uint32_t S1(uint32_t w);

    // The 32x32-bit S-Box S2
    uint32_t S2(uint32_t w);

    // Clocking LFSR in initialization mode
    void ClockLFSRInitializationMode(uint32_t F);

    // Clocking LFSR in keystream mode
    void ClockLFSRKeyStreamMode();

    // Clocking FSM
    uint32_t ClockFSM();

    // Initialization
    void Initialize(uint32_t* k, uint32_t* IV);

    // Generation of Keystream
    void GenerateKeystream(uint32_t n, uint32_t* ks);

    // MUL64x
    uint64_t MUL64x(uint64_t V, uint64_t c);

    // MUL64xPOW
    uint64_t MUL64xPOW(uint64_t V, uint8_t i, uint64_t c);

    // MUL64
    uint64_t MUL64(uint64_t V, uint64_t P, uint64_t c);

    // mask32bit
    uint32_t mask32bit(int n);
};

}

#endif //JSNOW3G_H
