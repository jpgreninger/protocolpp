#ifndef JECDSAEDSA_H_
#define JECDSAEDSA_H_

///
///\class jecdsaedsa jecdsaedsa.h "include/jecdsaedsa.h"
///
///\section ECDSAEd Edwards Curve Digital Signature Algorithm Security Association (ECDSAEDSA) for Ed25519
///
/// See RFC8032 for more information
///
/// The Edwards-curve Digital Signature Algorithm (EdDSA) is a variant of Schnorr’s
/// signature system with (possibly twisted) Edwards curves. EdDSA needs to be
/// instantiated with certain parameters, and this document describes some recommended
/// variants
///
/// To facilitate adoption of EdDSA in the Internet community, this document describes
/// the signature scheme in an implementation-oriented way and provides sample code
/// and test vectors
///
/// The advantages with EdDSA are as follows:
///
///   1. EdDSA provides high performance on a variety of platforms
///
///   2. The use of a unique random number for each signature is not required
///
///   3. It is more resilient to side-channel attacks
///
///   4. EdDSA uses small public keys (32 or 57 bytes) and signatures (64 or 114 bytes)
///      for Ed25519 and Ed448, respectively
///
///   5. The formulas are "complete", i.e., they are valid for all points on the curve,
///      with no exceptions. This obviates the need for EdDSA to perform expensive point
///      validation on untrusted public values
///
///   6. EdDSA provides collision resilience, meaning that hash-function collisions do
///      not break this system (only holds for PureEdDSA)
///
/// Ed25519 is intended to operate at around the 128-bit security level and Ed448 at
/// around the 224-bit security level. A sufficiently large quantum computer would be
/// able to break both. Reasonable projections of the abilities of classical computers
/// conclude that Ed25519 is perfectly safe. Ed448 is provided for those applications with
/// relaxed performance requirements and where there is a desire to hedge against analytical
/// attacks on elliptic curves
///
/// <B>For API information:</B>
///
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jecdsaedsa
/// @see ProtocolPP::jecdsaed
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jprotocolpp
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
///
/// @see jsecass
/// @see jecdsaedsa
/// @see jecdsaed
/// @see jprotocol
/// @see jprotocolpp
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#include <sys/types.h>
//#include <unistd.h>
//#include <crypt.h>
#include "jsecass.h"
#include <cstring>
#include <memory>
#include "tinyxml2.h"
#include "jlogger.h"
#include "jenum.h"
#include "jarray.h"

#include "xed25519.h"

#include "filters.h"
using CryptoPP::StringSink;
using CryptoPP::StringStore;

#include "osrng.h"
using CryptoPP::AutoSeededRandomPool;

#include "sha.h"
using CryptoPP::SHA512;

#include "secblock.h"
using CryptoPP::SecByteBlock;

#include "oids.h"
using CryptoPP::OID;

#include "asn.h"
using namespace CryptoPP::ASN1;

#include "integer.h"
using CryptoPP::Integer;

namespace ProtocolPP {

class jecdsaedsa : public jsecass {

public:

  	//////////////////////////////////////////////////////////////////////
    /// ECDSAEd Constructor for named type
    /// with default parameters as follows
    /// keymode_t::GENKEYPAIR
    /// ike_hash_t::SHA512
  	//////////////////////////////////////////////////////////////////////
    jecdsaedsa();

  	//////////////////////////////////////////////////////////////////////
    /// ECDSAEd Constructor for named type
    /// @param mode - Mode of operation (GENKEYPAIR, PKISIGN, PKIVERIFY)
    /// @param hash - hash type for curve (HMAC_SHA2_512 only)
    /// @param curve - Name of the OID curve (curve25519 only)
  	//////////////////////////////////////////////////////////////////////
    jecdsaedsa(keymode_t mode,
               ike_hash_t hash,
               CryptoPP::OID curve);

  	//////////////////////////////////////////////////////////////////////
    /// ECDSAEd Copy Constructor ECDSAEd Security Association
    /// @param rhs - ECDSAEd security association to copy
  	//////////////////////////////////////////////////////////////////////
    jecdsaedsa(jecdsaedsa& rhs);

  	//////////////////////////////////////////////////////////////////////
    /// ECDSAEd Copy Constructor shared_ptr
    /// @param rhs - ECDSAEd security association to copy
  	//////////////////////////////////////////////////////////////////////
    explicit jecdsaedsa(std::shared_ptr<jecdsaedsa>& rhs);

  	//////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
  	//////////////////////////////////////////////////////////////////////
    ~jecdsaedsa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the ECDSAEd Security Association object
    ///
    /// <table>
    /// <caption id="ECDSAEd Security Association Set Fields">ECDSAEdSA Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>keymode_t <td>MODE<td>set_field<keymode_t>(field_t::MODE, keymode_t::GENKEYPAIR)
    /// <tr><td>ike_hash_t <td>ECHASH<td>set_field<ike_hash_t>(field_t::ECHASH, hash)
    /// <tr><td>CryptoPP::OID <td>CURVE<td>set_field<CryptoPP::OID>(field_t::CURVE, CryptoPP::OID::secp256r1)
    /// <tr><td>CryptoPP::ed25519PrivateKey <td>PRVKEY<td>set_field<CryptoPP::ed25519PrivateKey>(field_t::PRVKEY, prvkey)
    /// <tr><td>CryptoPP::ed25519PublicKey <td>PUBKEY<td>set_field<CryptoPP::ed25519PublicKey>(field_t::PUBKEY, pubkey)
    /// <tr><td>CryptoPP::ed25519::Signer <td>SIGNER<td>set_field<CryptoPP::ed25519::Signer>(field_t::SIGNER, signer)
    /// <tr><td>CryptoPP::ed25519::Verifier <td>VERIFIER<td>set_field<CryptoPP::ed25519::Verifier>(field_t::VERIFIER, verifier)
    /// </table>
    ///
    /// @param field - field to update for ECDSAEd Security Association
    /// @param fieldval - value to update for ECDSAEd Security Association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the ECDSAEd Security Association object
    ///
    /// <table>
    /// <caption id="ECDSAEd Security Association Get Fields">ECDSAEDSA Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>ike_hash_t <td>IKEHASH<td>ike_hash_t hash = get_field<ike_hash_t>(field_t::IKEHASH)
    /// <tr><td>keymode_t <td>MODE<td>keymode_t mode = get_field<keymode_t>(field_t::MODE)
    /// <tr><td>ike_hash_t <td>ECHASH<td>ike_hash_t hash = get_field<ike_hash_t>(field_t::ECHASH)
    /// <tr><td>CryptoPP::OID <td>CURVE<td>CryptoPP::OID curve = get_field<CryptoPP::OID>(field_t::CURVE)
    /// <tr><td>CryptoPP::ed25519PrivateKey <td>PRVKEY<td>CryptoPP::ed25519 prvkey = get_field<CryptoPP::ed25519PrivateKey>(field_t::PRVKEY)
    /// <tr><td>CryptoPP::ed25519PublicKey <td>PUBKEY<td>CryptoPP::ed25519 pubkey = get_field<CryptoPP::ed25519PublicKey>(field_t::PUBKEY)
    /// <tr><td>CryptoPP::ed25519::Signer <td>SIGNER<td>CryptoPP::ed25519::Signer signer = get_field<CryptoPP::ed25519::Signer>(field_t::SIGNER)
    /// <tr><td>CryptoPP::ed25519::Verifier <td>VERIFIER<td>CryptoPP::ed25519::Verifier verifier = get_field<CryptoPP::ed25519::Verifier>(field_t::VERIFIER)
    /// </table>
    ///
    /// @param field - field to retrieve from the ECDSAEd Security Association object
    /// @return field of the ECDSAEd Security Association object
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jecdsaedsa(const jecdsaedsa& jecdsaedsa) = delete;

    // member variables
    keymode_t m_mode;
    ike_hash_t m_hash;
    CryptoPP::OID m_curve;

    // private key container
    CryptoPP::ed25519::Signer signer;

    // public key container
    CryptoPP::ed25519::Verifier verifier;
};

}

#endif /* JECDSAEDSA_H_ */

