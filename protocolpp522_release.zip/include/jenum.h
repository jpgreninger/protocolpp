#ifndef JENUM_H
#define JENUM_H

///
///\class jenum jenum.h "include/jenum.h"
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "EnumString.h"

namespace ProtocolPP {

//////////////////////////////////////////////////////////////////////
/// Converts numbers into hexidecimal representation
/// @param a - value to convert to hexidecimal
/// @param b - number of hexidecimal characters to use for representation
//////////////////////////////////////////////////////////////////////
#define HEX(a, b) \
    "0x" << std::setw(b) << std::setfill('0') << std::hex << static_cast<unsigned long long>(a) << std::dec

#define HEXLOG(a, b) \
    "0x", std::setw(b), std::setfill('0'), std::hex, static_cast<unsigned long long>(a), std::dec

//////////////////////////////////////////////////////////////////////
/// @param DIRECTION - Direction of processing (ENCAP or DECAP)
///
///\section IKEF IKEv2 fields
///
/// @param IKECNXT - IKE Connection Name
/// @param EXCHG - IKE Exchange type
/// @param NXTPYLD - Next IKE payload type
/// @param MAJOR_REVISION - IKE Major revision value
/// @param MINOR_REVISION - IKE Minor revision value
/// @param FLAGS - IKE Minor revision value
/// @param MSGIDINIT - IKE Message Identifier when Initiator(starts at zero)
/// @param MSGIDRESP - IKE Message Identifier when Responder(starts at zero)
/// @param SPIi - IKE Initiator Security Parameter Index (SPI)
/// @param SPIr - IKE Responder Security Parameter Index (SPI)
/// @param Ni - IKE Initiator Nonce
/// @param Nr - IKE Responder Nonce
/// @param SKd - IKE PRF Key for Child SA Key Generation
/// @param CIPHER - IKE Encryption Cipher
/// @param CKEYLEN - IKE Encryption Key Length
/// @param IVLEN - IKE Initialization Vector (ICV) Length
/// @param SALTLEN - IKE Salt Length
/// @param SKei - IKE Initiator Encryption Key
/// @param SKer - IKE Responder Encryption Key
/// @param IV - IKE Initialization Vector
/// @param SKsi - IKE Initiator Salt Value
/// @param SKsr - IKE Responder Salt Value
/// @param INTEG - IKE Integrity Algorithm
/// @param AKEYLEN - IKE Integrity Key Length
/// @param AADLEN - Authentication only data (AADLEN)
/// @param ICVLEN - IKE Integrity Check Value (ICV)
/// @param SKai - IKE Initiator Integrity Key
/// @param SKar - IKE Responder Integrity Key
/// @param PRF - IKE Psuedo Random Function (PRF)
/// @param prflen - IKE Psuedo Random Function (PRF) output length
/// @param SKpi - IKE Initiator Psuedo Random Key
/// @param SKpr - IKE Responder Psuedo Random Key
/// @param DH - IKE Diffie-Hellman Group ID
/// @param IKEAUTH - IKE Signing Algorithm
/// @param IKEHASH - IKE Hash Algorithm
/// @param ARLEN - Length of the Anti-Replay Window
///
///\section IPSF IPsec fields
///
/// @param VERSION - First nibble in the IP header defines IPv4 or IPv6
/// @param MODE - Mode of operation either TUNNEL or TRANSPORT
/// @param SPI - Security paramater index (SPI)
/// @param SEQNUM - Sequence number for the packet from ESP header
/// @param EXTSEQNUM - Extended sequence number for this packet
/// @param ARLEN - Length of the anti-replay window
/// @param ARWIN - Anti-Replay window represented as a byte array
/// @param CIPHER - Cipher for encryption
/// @param CKEYLEN - Length of the cipher key
/// @param CIPHERKEY - Cipher key for encryption
/// @param AUTH - Authentication mode
/// @param AKEYLEN - Length of the authentication key
/// @param AUTHKEY - Authentication key
/// @param IVLEN - Length of the initialization vector in bytes (IV)
/// @param IV - Initialization vector
/// @param SALTLEN - Length of the salt for encryption use
/// @param SALT - Salt for encryption use
/// @param BYTECNT - Number of bytes encrypted or decrypted by this flow
/// @param LIFETIME - Amount of time for this flow to exist
/// @param SEQNUMOVRFLW - Enable SEQNUM overflow during ENCAP
/// @param STATEFULFRAG - Stateful FRAG bit
/// @param BYPASSDF - Enable bypassing the DONT FRAGMENT bit
/// @param BYPASSDSCP - Enable bypassing the DiffServices copy from inner to outer header
/// @param NAT - Enable Network Address Translation (NAT) insertion
/// @param NCHK - Enable NAT checksum generation and checking
/// @param DSECN - Diff Services/Congestion bits
/// @param TTLHOP - Time-to-Live field for the packet
/// @param FLAGS - Flags field in IPv4
/// @param NATSRC - Source port for NAT
/// @param NATDST - Destination port for NAT
/// @param ID - Identification field for IPv4
/// @param LABEL - Label field for IPv6
/// @param FRAGOFFSET - Fragment offset from first packet
/// @param MOREFRAG - Enable fragmentation of packet
/// @param FRAGID - Fragmentation ID for this segment of the overall packet
/// @param MTU - Maximum Transmission unit (MTU)
/// @param SOURCE - Source address
/// @param DESTINATION - Destination address
/// @param EXTHDR - IPv6 Extension header
/// @param NH - Next header in either the extension header or the payload
/// @param ICVLEN - Length of the ICV
/// @param HDRLEN - Length of the IP header
/// @param TFCLEN - Length of the Traffic Flow Confidentiality (TFC) padding
/// @param USEXT - Use extended sequence number
/// @param RANDIV - Use random IV rather than user IV
/// @param NODEJUMBO - Nodal JUMBOGRAM support
/// @param AUDIT - Enable auditing of IP flow
/// @param AUDITLOG - Path to the audit log
/// @param CHECKSUM - IPv4 header checksum
/// @param LENGTH -Length of the packet(IPv4) or length of the packet minus the standard 40-byte header (IPv6)
///
///\section ICMPF ICMP fields
///
/// @param VERSION - Version (ICMP or ICMPv6)
/// @param TYPE - ICMP Type
/// @param CODE - ICMP SubType
/// @param CHECKSUM - Checksum field
/// @param POINTER - Pointer to error in packet
/// @param IDENTIFIER - Identifier from the invoking message
/// @param SEQNUM - Sequence number of the packet
/// @param GATEWAY - Gateway Internet Address
/// @param MTU - Maximum transmission unit for the next-hop link
/// @param ORIGTIMESTAMP - Timestamp from the origination node
/// @param RXTIMESTAMP - Receive timestamp
/// @param TXTIMESTAMP - Transmit timestamp
/// @param SOURCE - Source Address
/// @param DESTINATION - Destination Address
/// @param MESSAGE - Message to send
/// @param ICMPCODE - Code to send
///
///\section IPF IP fields
///
/// @param VERSION - First nibble in the IP header defines IPv4 or IPv6
/// @param DSECN - Diff Services/Congestion bits
/// @param ID - Identification field for IPv4
/// @param LABEL - Label field for IPv6
/// @param FRAGOFFSET - Fragment offset from first packet
/// @param NH - Next header in either the extension header or the payload
/// @param TTLHOP - Time-to-Live field for the packet
/// @param CHECKSUM - IPv4 header checksum
/// @param FLAGS - Flags field in IPv4
/// @param LENGTH -Length of the packet(IPv4) or length of the packet minus the standard 40-byte header (IPv6)
/// @param EXTHDR - IPv6 Extension header
/// @param NODEJUMBO - Nodal JUMBOGRAM support
///
///\section LTEF LTE/3GPP fields
///
/// @param DATACTRL - Data or Control flag (Control - 0, Data - 1)
/// @param PDUTYPE - Control PDU type field
/// @param POLLBIT - Polling bit
/// @param EXTENSION - Extension bit
/// @param RSN - Reset sequence number (RSN)
/// @param SNLEN - Sequence number length in bits
/// @param HDREXT - Header extension type field
/// @param LENGTHIND - Length indicator field
/// @param SEQNUM - Sequence number
/// @param HFNI - Hyper frame number indicator (HFNI)
/// @param SUFI - Super Field (SUFI)
/// @param FMS - PDCP SN of the first missing PDCP SDU (FMS)
/// @param PGKINDEX - Five LSBs of PGK identity
/// @param PTKINDENT - PTK identity
/// @param SDUTYPE - PDCP SDU type (IP, ARP, PC5SIG, NONIP, RSVD)
/// @param KDID - Kd identity
/// @param NMP - Number of missing PDCP SDUs with associated COUNT value
/// @param HRW - PDCP SN of the PDCP SDU received on WLAN with highest associated PDCP COUNT value
/// @param BEARER - Bearer value
/// @param FRESH - Fresh value
/// @param COUNT - Count value
/// @param BITMAPLEN - Length of the BitMap
/// @param BITMAP - Bitmap for LTE
///
///\section MSF MacSEC fields
///
/// @param SOURCE - Source address
/// @param DESTINATION - Destination address
/// @param ETHERTYPE - Ethertype type
/// @param SL - Short Length field
/// @param TCIAN - TAG Control Information and Association Number
/// @param PN - Packet number
/// @param XPN - Extended packet number
/// @param SCI - Secure Channel Identifier
/// @param SSCI - Short Secure Channel Identifier
/// @param SAKEY - Security Association Key
/// @param ENRECEIVE - Enable reception of packets
/// @param ENTRANSMIT - Enable transmission of packets
/// @param PROTECTFRAMES - Protect outgoing packets
/// @param INUSE - This MacSEC flow is in use and receiving packets
/// @param CREATETIME - Time this MacSEC was created
/// @param STARTTIME - Time this MacSEC last enabled reception of packets
/// @param STOPTIME - Time this MacSEC last disabled reception of packets
/// @param VLANTAG1 - Customer, Service, or Service Instance 802.1Q VLAN tag
/// @param VLANTAG2 - Customer, Service, or Service Instance 802.1Q VLAN tag
///
///\section SRTPF SRTP fields
///
/// @param VERSION - Version of SRTP used (currently set to 2)
/// @param PADDING - Padding flag to indicate padding in the payload
/// @param EXTENSION - Flag to indicate presence of extension headers
/// @param CC - Number of CSRC fields present
/// @param MARKER - Marker flag
/// @param PT - Type of payload present (much like NH in IPsec)
/// @param SEQNUM - Sequence number for the packet
/// @param ROC - Rollover counter
/// @param TIMESTAMP - Timestamp for the packet
/// @param SSRC - Synchronization Source Identifier
/// @param CSRC - Contributing Source Identifier
/// @param BLKSIZE - Block size of the encryption cipher
///
///\section TCPF TCP fields
///
/// @param SOURCE - Source address
/// @param DESTINATION - Destination address
/// @param SEQNUM - Sequence number
/// @param ACKNUM - Acknowledge number
/// @param OFFSET - Data offset
/// @param FLAGS - Flags field
/// @param RCVWINDOW - Receive size window
/// @param CHECKSUM - Checksum field
/// @param URGENT - Urgent pointer
/// @param STATE - TCP state of operation
/// @param OPTIONS - Options field
/// @param SEGLEN - Segment length
/// @param PRECEDENCE - Precendence of this flow
/// @param SNDUNA - Send UNA
/// @param SNDNXT - Send next seqnum
/// @param SNDWND - Send window size
/// @param SNDUP - Send UP
/// @param SNDW1 - Send window 1
/// @param SNDW2 - Send window 2
/// @param ISS - ISS
/// @param RCVNXT - Receive next seqnum expected
/// @param RCVWND - Receive window size
/// @param RCVUP - RCVUP
/// @param IRS - IRS
/// @param TCPTIMEOUT - Timeout for TCP shutdown
///
///\section TLSF TLS fields
///
/// @param TYPE - Type of packet being sent/received
/// @param VERSION - Version of TLS used
/// @param LENGTH - Length of the packet
/// @param SEQNUM - Current or recently received packet
/// @param EPOCH - Current EPOCH in DTLS
/// @param CIPHERSUITE - Cipher and authentication scheme for this flow
/// @param ENCTHENMAC - Enable ENCRYPT-THEN-MAC for TLS
/// @param IVEX - Implicit(false) or Explicit(true) IV
///
///\section UDPF UDP fields
///
/// @param SOURCE - Source address
/// @param DESTINATION - Destination address
/// @param LENGTH - Length of the packet
/// @param CHECKSUM - Checksum for UDP packet
///
///\section WIFIF Wifi/Wigig fields
///
/// @param FRAMECTL - Frame control sequence in entirety
/// @param CTLEXT - Control frame extension
/// @param PROTVER - Protocol version
/// @param TYPE - Type
/// @param SUBTYPE - SubType
/// @param TDS - To Data Stream (TDS)
/// @param FDS - From Data Stream (FDS)
/// @param MFRAG - More fragmentation
/// @param RETRY - retry bit
/// @param PWRMGMT - Power management
/// @param MDATA - More data field
/// @param WEP - Wireless Encryption Protection (WEP)
/// @param ORDER - Order
/// @param KDFALG - Key derivation function algorithm (KDF)
/// @param ID - Duration ID
/// @param ADD1 - First address
/// @param ADD2 - Second address
/// @param ADD3 - Third address
/// @param SEQCTL - Sequence Control
/// @param ADDR4 - Fourth address
/// @param QOSCTL - Quality of Service field
/// @param HTCTL - HT control field
/// @param PN - Packet Number
/// @param EXTIV - Extended IV flag
/// @param KEYID - Key identification
/// @param HDRLEN - Length of the header according to option bits
/// @param SPPCAP - SPPCAP
/// @param FCS - Enable CRC checking for Wifi packet
///
///\section WIMAXF WiMax fields
///
/// @param HT - Header type where zero for generic MAC header
/// @param EC - Encrytion Control 0=no encryption 1=encryption
/// @param TYPE - Indicates the subheaders and payload types
/// @param ESF - Extended subheader field ESF=1 then ESF present and follows MAC header
/// @param CI - CRC indicator 0=no CRC 1=CRC present
/// @param EKS - Encryption key sequence. Index of TEK and IV used to encrypt the payload
/// @param LENGTH - length in bytes of MAC PDU including header and CRC if present
/// @param CID - Connection Identifier
/// @param FID - Flow Identifier (AGHM header only)
/// @param EH - Extended header group indicator (AGHM header only)
/// @param HCS - Header check sequence 8-bit header checksum
/// @param PN - Packet Number
///
///\section RSA Cryptosystem
///
/// @param BITSIZE - Size of the private key
/// @param RSAPAD - Pad type for RSA (PSS or PKCS)
/// @param PRVKEY - Private key
/// @param PUBKEY - Public key
/// @param KEYPAIR - Public/Private key pair
/// @param RSAENC - RSA Encryption type
///
///\section ENUMDSA Digital Signal Algorithm fields
///
/// @param BITSIZE - Size of the private key
/// @param PRIME - Prime value for DSA (usually called "p")
/// @param SUBPRIME - Prime value for DSA (usually called "q")
/// @param GENERATOR - Prime value for DSA (usually called "g")
/// @param PRVKEY - Private key
/// @param PUBKEY - Public key
/// @param KEYPAIR - Public/Private key pair
/// @param BLOCKSIZE - Block size
///
///\section ENUMECDSA Elliptic Curve Digital Signal Algorithm fields
///
/// @param GX - X-coordinate for the ECDSA curve
/// @param GY - Y-coordinate for the ECDSA curve
/// @param CURVE - Name of the current curve
/// @param PRVKEY - Private key
/// @param PUBKEY - Public key
/// @param KEYPAIR - Public/Private key pair
/// @param ECHASH - Hash function to use for ECDSA
///
///\section ENUMECDSAEd Elliptic Curve Digital Signal Algorithm fields for Ed25519
///
/// @param SIGNER - Signature object for Ed25519
/// @param VERIFIER - Verification object for Ed25519
///
///\section JPKT Packet Class for ProtocolPP
///
/// @param OUTADDR - Output address for the packet
/// @param NAME - Name of this packet
/// @param OUTLEN - Output length for the packet
/// @param STREAM - Name of the stream associated with the packet
/// @param PREVIOUS - Name of the packet preceeding this packet
/// @param INLEN - Input length for the packet
/// @param OUTPUTLEN - Output length
/// @param EXPLEN - Expected data length for the packet
/// @param STATUS - Status word of this packet
/// @param ZEROINIT - Initial value of CRC zero
/// @param SWAPIN - Swap input data before calculating CRC
/// @param SWAPOUT - Swap output data before calculating CRC
/// @param COMPOUT - Complement output CRC
///
///\section TSTBNCH Testbench Configuration fields
///
/// @param SEED - Testbench seed         
/// @param ERRORS - Number of errors
/// @param FLOWS - Number of flows
/// @param PACKETS - Number of packets
/// @param LOGLVL - Logging level
/// @param PTRSIZE - Pointer size for testbench
/// @param SGTSIZE - Scatter-gather table entry size
/// @param STDOUT - Log to std::cout
/// @param ENDIAN - Endianness for testbench
/// @param PLATFORM - Platform to run testbench with
/// @param DEBUGCLR - Color of debug messages
/// @param INFOCLR - Color of info messages
/// @param WARNCLR - Color of warn messages
/// @param ERRCLR - Color of error messages
/// @param FATALCLR - Color of fatal messages
/// @param PASSCLR - Color of pass messages
///
///\section MBLOB Memory Blob fields
///
/// @param BKEK - Blob Key Encryption Key (BKEK)
/// @param BKEKLEN - Blob Key Encryption Key Length (BKEK)
/// @param BLOBKEY - Blob Key Encryption Key
/// @param BLOBKEYLEN - Blob Key Encryption Key Lenth
///
///\section XMSSF XMSS and WOTS+ fields
/// @param LAYERADDR - Address of the tree layer
/// @param TREEADDR - Address in the binary tree
/// @param TYPEVAL - Value of the TYPE (0, 1, or 2)
/// @param ADDRORPAD - One-Time Signature Address, LTREE address, or padding
/// @param CHAINHEIGHT - Chain Address or Tree Height
/// @param HASHORIDX - Hash address in tree or Tree Index
/// @param KEYNMASK - Key and mask address
/// @param BYTEARRAY - Convert OTS addresses to byte array
/// @param WINTZ - Winternitz parameter
/// @param SIGLEN - Signature length
/// @param STACK - Stack in XMSS/LMS
/// @param STACKPUSH - Push to the XMSS/LMS stack
/// @param STACKPOP - Pop the top of the XMSS/LMS stack
/// @param STACKTOP - Return the top of the XMSS/LMS stack
/// @param STACKIDX - Access index of the XMSS/LMS stack
/// @param STACKLEN - Height of the top node of the XMSS/LMS stack
///
///\section LMS, LMOTS, and HSS fields
/// @param LMOTSQ - LMOTS value of 'q'
/// @param LMOTSN - LMOTS value of 'n', the length of the hash function output
/// @param LMOTSW - LMOTS value of 'w', the Winternitz parameter
/// @param LMOTSP - LMOTS value of 'p', the number of w-bit values in the signature
/// @param LMOTSLS - LMOTS value of 'ls', the left-shift value of the checksum calculation
/// @param LMOTSSIGLEN - LMOTS value of 'siglen', the length of the signature
/// @param LMOTSI - LMOTS key pair identifier
/// @param LMOTSEED - LMOTS seed value
/// @param LMOTC - LMOTS c-array value
/// @param LMOTS - LMOTS engine
/// @param LMSALGVAL - LMS Algorithm value as a jarray<uint8_t>
/// @param LMOTSALGVAL - LMOTS Algorithm value as a jarray<uint8_t>
//////////////////////////////////////////////////////////////////////
enum field_t {     /// Direction of processing (ENCAP or DECAP)
    DIRECTION,     /// Version field for the packet either IPV4 or IPV6 (ICMP or ICMPV6) (SSL30, TLS10, TLS11, TLS12, TLS13, DTLS)
    VERSION,       /// Mode of operation either TUNNEL or TRANSPORT
    MODE,          /// Security parameter index (SPI)
    SPI,           /// Sequence number for the packet
    SEQNUM,        /// Extended sequence number
    EXTSEQNUM,     /// Length of the anti-replay window
    ARLEN,         /// Anti-Replay window represented as a byte array
    ARWIN,         /// Cipher for encryption
    CIPHER,        /// Length of the cipher key
    CKEYLEN,       /// Cipher key for encryption
    CIPHERKEY,     /// Authentication mode
    AUTH,          /// Length of the authentication key
    AKEYLEN,       /// Authentication key
    AUTHKEY,       /// Length fo the initialization vector (IV)
    IVLEN,         /// Initializaton Vector (IV)
    IV,            /// Length of encryption salt
    SALTLEN,       /// Encryption salt
    SALT,          /// Number of bytes encrypted or decrypted by this flow
    BYTECNT,       /// Amount of time for this flow to exist
    LIFETIME,      /// Allow SEQNUM overflow during ENCAP
    SEQNUMOVRFLW,  /// Stateful FRAG bit
    STATEFULFRAG,  /// Enable bypass of the DONT FRAGMENT bit copy from inner to outer header
    BYPASSDF,      /// Enable bypass of copy from inner to outer header of DiffServices
    BYPASSDSCP,    /// Enable Network Address Translation (NAT) insertion
    NAT,           /// Enable NAT checksum generation and checking
    NCHK,          /// Bits for Diff Services/Congestion bits
    DSECN,         /// Time-to-Live field for the packet
    TTLHOP,        /// Flags field in the IPv4
    FLAGS,         /// Source port for NAT
    NATSRC,        /// Destination port for NAT
    NATDST,        /// Identification field for IPv4
    ID,            /// Label field for IPv6
    LABEL,         /// Fragment offset from first packet
    FRAGOFFSET,    /// Enable fragmentation of packet
    MOREFRAG,      /// Fragmentation ID for this segment in the overall packet
    FRAGID,        /// Maximum Transmission unit (MTU)
    MTU,           /// Source Address
    SOURCE,        /// Destination Address
    DESTINATION,   /// IPv6 Extension header(s)
    EXTHDR,        /// Next header in either the extension header or the payload
    NH,            /// Length of the AAD
    AADLEN,        /// Length of the ICV
    ICVLEN,        /// Length of the IP headeer
    HDRLEN,        /// Length of the Traffic flow Confidentiality (TFC) padding
    TFCLEN,        /// Use extended sequence number
    USEXT,         /// Use random IV rather than user IV
    RANDIV,        /// Nodal JUMBOGRAM support
    NODEJUMBO,     /// Enable audint of IP flow
    AUDIT,         /// Path to the audit log
    AUDITLOG,      /// Enable IPv4 header checksum
    CHECKSUM,      /// Length of the packet (IPv4) or length of the packet minus the standard IPv6 header
    LENGTH,        /// ICMP Type 
    TYPE,          /// ICMP SubType
    CODE,          /// Pointer to error in packet
    POINTER,       /// Identifier from the invoking message
    IDENTIFIER,    /// Gateway Internet Address
    GATEWAY,       /// Timestamp from the origination node
    ORIGTIMESTAMP, /// Receive timestamp
    RXTIMESTAMP,   /// Transmit timestamp
    TXTIMESTAMP,   /// Message to send
    MESSAGE,       /// Code to send
    ICMPCODE,      /// Data or Control bit
    DATACTRL,      /// Control PDU type field
    PDUTYPE,       /// Polling bit
    POLLBIT,       /// Extension bit
    EXTENSION,     /// Reset sequence number (RSN)
    RSN,           /// Sequence number length in bits
    SNLEN,         /// Header extension type field
    HDREXT,        /// Length indicator field
    LENGTHIND,     /// Hyper frame number indicator (HFNI)
    HFNI,          /// Super Field (SUFI)
    SUFI,          /// PDCP SN of the first Missing PDCP SDU (FMS)
    FMS,           /// Length of BitMap
    BITMAPLEN,     /// Bitmap for LTE
    BITMAP,        /// Five LSB(s) of PGK identity
    PGKINDEX,      /// PTK identity
    PTKINDENT,     /// PDCP SDU type (IP, ARP, PC5SIG, NONIP, RSVD)
    SDUTYPE,       /// Kd identity
    KDID,          /// Number of missing PDCP SDU(s) with associated COUNT value
    NMP,           /// PDCP SN of the PDCP SDU received on WLAN with highest associated PDCP COUNT value
    HRW,           /// Bearer value
    BEARER,        /// Fresh value for F9 modes
    FRESH,         /// Count value for F8/F9 modes
    COUNT,         /// Ethernet type
    ETHERTYPE,     /// Short length field
    SL,            /// TAG Control Information and Association Number
    TCIAN,         /// Packet number
    PN,            /// Extended packet number
    XPN,           /// Secure Channel Identifier
    SCI,           /// Short Secure Channel Identifier
    SSCI,          /// Security Association Key
    SAKEY,         /// Enable reception of packets
    ENRECEIVE,     /// Enable transmission of packets
    ENTRANSMIT,    /// Protect packets
    PROTECTFRAMES, /// MacSEC flow is in use (RX or TX)
    INUSE,         /// Time this MacSEC was created
    CREATETIME,    /// Time this MacSEC last enabled RX or TX
    STARTTIME,     /// Time this MacSEC last disabled RX or TX
    STOPTIME,      /// Padding field
    PADDING,       /// CSRC count field
    CC,            /// Marker field
    MARKER,        /// Payload type field
    PT,            /// Rollover Counter (ROC)
    ROC,           /// Timestamp field
    TIMESTAMP,     /// Synchronization source identifier (SSRC)
    SSRC,          /// Contributing source identifier (CSRC)
    CSRC,          /// Block size of the encryption cipher
    BLKSIZE,       /// MKI flag
    MKI,           /// MKI data length
    MKILEN,        /// MKI data
    MKIDATA,       /// Acknowledge number
    ACKNUM,        /// Data offset
    OFFSET,        /// Receive size window
    RCVWINDOW,     /// Urgent pointer
    URGENT,        /// TCP state of operation
    STATE,         /// OPTIONS
    OPTIONS,       /// SEGLEN
    SEGLEN,        /// PRECEDENCE
    PRECEDENCE,    /// SNDUNA
    SNDUNA,        /// SNDNXT
    SNDNXT,        /// SNDWND
    SNDWND,        /// SNDUP
    SNDUP,         /// SNDW1
    SNDW1,         /// SNDW2
    SNDW2,         /// ISS
    ISS,           /// RCVNXT
    RCVNXT,        /// RCVWND
    RCVWND,        /// RCVUP
    RCVUP,         /// IRS
    IRS,           /// TCPTIMEOUT
    TCPTIMEOUT,    /// Epoch number for DTLS
    EPOCH,         /// Ciphersuite for the TLS protocol
    CIPHERSUITE,   /// Encrypt-then-MAC the TLS packet
    ENCTHENMAC,    /// Implicit or Explicit IV for TLS
    IVEX,          /// Frame control sequence in entirety
    FRAMECTL,      /// Control Frame extension
    CTLEXT,        /// Protocol version
    PROTVER,       /// SubType
    SUBTYPE,       /// To Data Stream
    TDS,           /// From Data Stream
    FDS,           /// More fragmentation
    MFRAG,         /// Retry
    RETRY,         /// Power management
    PWRMGMT,       /// More data field
    MDATA,         /// Wireless Encryption Protection (WEP)
    WEP,           /// Order
    ORDER,         /// Key derivation function (KDF) algorithm
    KDFALG,        /// First address
    ADDR1,         /// Second address
    ADDR2,         /// Third address
    ADDR3,         /// Sequence control
    SEQCTL,        /// Fourth address
    ADDR4,         /// Quality of Service field
    QOSCTL,        /// HT control field
    HTCTL,         /// Extended IV flag
    EXTIV,         /// Key identification
    KEYID,         /// SPP Cap
    SPPCAP,        /// Enable CRC checking for packet
    FCS,           /// Header Type where zero for generic MAC header
    HT,            /// Encryption Control 0=no encryption 1=encryption
    EC,            /// Extended Subheader Field ESF=1 then ESF is present and follows MAC header
    ESF,           /// CRC Indicator 0=no CRC, 1=CRC present
    CI,            /// Encryption Key Sequence. Index of TEK and IV used to encrypt the payload
    EKS,           /// Connection Identifier
    CID,           /// Flow Identifier (AGHM header only)
    FID,           /// Extended Header Group Indicator (AGHM header only)
    EH,            /// Header Check Sequence 8-bit header checksum
    HCS,           /// IKE Conneciton Name
    IKECNXT,       /// IKE Exchange Type
    EXCHG,         /// IKE Next Payload Value
    NXTPYLD,       /// IKE Major Revision Number
    MAJOR_VERSION, /// IKE Minor Revision Number
    MINOR_VERSION, /// IKE Message Identifier when Initiator
    MSGIDINIT,     /// IKE Message Identifier when Responder
    MSGIDRESP,     /// IKE Initiator Security Parameter Index
    SPIi,          /// IKE Responder Security Parameter Index
    SPIr,          /// IKE Initiator Nonce
    Ni,            /// IKE Responder Nonce
    Nr,            /// IKE Child SA Key Generation Seed
    SKd,           /// IKE Initiator Encryption Key
    SKei,          /// IKE Responder Encryption Key
    SKer,          /// IKE Initiator Salt Value
    SKsi,          /// IKE Responder Salt Value
    SKsr,          /// IKE Integrity Algorithm
    INTEG,         /// IKE Initiator Integrity Algorithm Key
    SKai,          /// IKE Responder Integrity Algorithm Key
    SKar,          /// IKE Psuedo Random Function Algorithm
    PRF,           /// IKE Psuedo Random Total Key Length
    PRFLEN,        /// IKE Initiator Psuedo Random Key
    SKpi,          /// IKE Responder Psuedo Random Key
    SKpr,          /// IKE Diffie-Hellman Group ID
    DH,            /// IKE Signature Algorithm
    IKEAUTH,       /// IKE Hash Algorithm
    IKEHASH,       /// Size fo the Private Key
    BITSIZE,       /// RSA Padding type
    RSAPAD,        /// RSA Encrypt type
    RSAENC,        /// Key pair
    KEYPAIR,       /// Private Key
    PRVKEY,        /// Public Key
    PUBKEY,        /// Prime value for DSA (usually called "p")
    PRIME,         /// Subprime value for DSA (usually called "q")
    SUBPRIME,      /// Generator value for DSA (usually called "g")
    GENERATOR,     /// X-coordinate for the ECDSA curve
    GX,            /// Y-coordinate for the ECDSA curve
    GY,            /// Name of the current curve
    CURVE,         /// Hash function for ECDSA
    ECHASH,        /// Signature object for Ed25519
    SIGNER,        /// Verification object for Ed25519
    VERIFIER,      /// First 802.1Q VLAN tag
    VLANTAG1,      /// Second 802.1Q VLAN tag
    VLANTAG2,      /// Postprocessing flag
    POSTPROCESS,   /// Setup flag
    SETUP,         /// Size field
    STREAMSIZE,    /// Name of the stream object
    NAME,          /// Output address of the packet
    OUTADDR,       /// Output length of the packet
    OUTLEN,        /// Input length of the packet
    INLEN,         /// Output length of the packet
    OUTPUTLEN,     /// Expected length of the packet
    EXPLEN,        /// Name of the stream associated with this packet
    STREAM,        /// Previous packet to this one (set to "begin" if this is the first packet)
    PREVIOUS,      /// Status word for this packet
    STATUS,        /// INPUT data for this packet
    INPUT,         /// OUTPUT data for this packet
    OUTPUT,        /// EXPECT data for this packet
    EXPECT,        /// Block size for the block cipher
    BLOCKSIZE,     /// Zero initial value for CRC calculation
    ZEROINIT,      /// Swap input data before CRC calculation
    SWAPIN,        /// Swap output data before CRC calculation
    SWAPOUT,       /// Complement output CRC
    COMPOUT,       /// Polynomial for CRC
    POLYNOMIAL,    /// Testbench seed
    SEED,          /// Number of errors
    ERRORS,        /// Number of flows
    FLOWS,         /// Number of packets
    PACKETS,       /// Logging level
    LOGLVL,        /// Pointer size for testbench
    PTRSIZE,       /// Scatter-gather table entry size
    SGTSIZE,       /// Log to std::cout
    STDOUT,        /// Endianness for testbench
    ENDIAN,        /// Platform to run testbench with
    PLATFORM,      /// Color of debug messages into the testbench
    DEBUGCLR,      /// Color of information messages in the testbench
    INFOCLR,       /// Color of warning messages in the testbench
    WARNCLR,       /// Color of error messages in the testbench
    ERRCLR,        /// Color of fatal messages in the testbench
    FATALCLR,      /// Color of pass messages in the testbench
    PASSCLR,       /// Memory Blob Key Encryption Key (BKEK)
    BKEK,          /// Memory Blob Key Length (BKEKLEN)
    BKEKLEN,       /// Memory Blob Key
    BLOBKEY,       /// Memory Blob Key Length
    BLOBKEYLEN,    /// WOTS+ Algorithm
    WOTSALGO,      /// Address of the tree layer
    LAYERADDR,     /// Address in the binary tree
    TREEADDR,      /// Height of the binary tree
    TREEHEIGHT,    /// Value of the TYPE (0, 1, or 2)
    TYPEVAL,       /// One-Time Signature Address, LTREE address, or padding
    ADDRORPAD,     /// Chain Address or Tree Height
    CHAINHEIGHT,   /// Hash address in tree or Tree Index
    HASHORIDX,     /// Key and mask address
    KEYNMASK,      /// Convert OTS addresses to byte array
    BYTEARRAY,     /// Signature length
    SIGLEN,        /// Winternitz parameter
    WINTZ,         /// Stack in XMSS/LMS
    STACK,         /// XMSS Algorithm
    XMSSALG,       /// Push to the XMSS/LMS stack
    STACKPUSH,     /// Pop the top of the XMSS/LMS stack
    STACKPOP,      /// Return top of the XMSS/LMS stack
    STACKTOP,      /// Access index of the XMSS/LMS stack
    STACKIDX,      /// Height of the top node of the XMSS/LMS stack
    STACKLEN,      /// LMOTS value of 'q' parameter
    LMOTSQ,        /// LMOTS length of hash function
    LMOTSN,        /// LMOTS Winternitz parameter
    LMOTSP,        /// LMOTS number of w-bit elements in signature
    LMOTSW,        /// LMOTSLS number of left-shift bits on checksum calculation
    LMOTSLS,       /// LMOTSIGLEN signature length
    LMOTSIGLEN,    /// LMOTS key pair identifier
    LMOTSI,        /// LMOTS seed value
    LMOTSEED,      /// LMOTS c-array value
    LMOTSC,        /// LMOTS engine
    LMOTS,         /// LMS Algorithm value as jarray<uint8_t>
    LMSALGVAL,     /// LMOTS Algorithm value as jarray<uint8_t>
    LMOTSALGVAL
};

Begin_Enum_String(field_t) {    /// Direction of processing (ENCAP or DECAP)
    Enum_String(DIRECTION);      /// Version field for the packet either IPV4 or IPV6 (ICMP or ICMPV6) (SSL30, TLS10, TLS11, TLS12, TLS13, DTLS)
    Enum_String(VERSION);        /// Mode of operation either TUNNEL or TRANSPORT
    Enum_String(MODE);           /// Security parameter index (SPI)
    Enum_String(SPI);            /// Sequence number for the packet
    Enum_String(SEQNUM);         /// Extended sequence number
    Enum_String(EXTSEQNUM);      /// Length of the anti-replay window
    Enum_String(ARLEN);          /// Anti-Replay window represented as a byte array
    Enum_String(ARWIN);          /// Cipher for encryption
    Enum_String(CIPHER);         /// Length of the cipher key
    Enum_String(CKEYLEN);        /// Cipher key for encryption
    Enum_String(CIPHERKEY);      /// Authentication mode
    Enum_String(AUTH);           /// Length of the authentication key
    Enum_String(AKEYLEN);        /// Authentication key
    Enum_String(AUTHKEY);        /// Length fo the initialization vector (IV)
    Enum_String(IVLEN);          /// Initializaton Vector (IV)
    Enum_String(IV);             /// Length of encryption salt
    Enum_String(SALTLEN);        /// Encryption salt
    Enum_String(SALT);           /// Number of bytes encrypted or decrypted by this flow
    Enum_String(BYTECNT);        /// Amount of time for this flow to exist
    Enum_String(LIFETIME);       /// Allow SEQNUM overflow during ENCAP
    Enum_String(SEQNUMOVRFLW);   /// Stateful FRAG bit
    Enum_String(STATEFULFRAG);   /// Enable bypass of the DONT FRAGMENT bit copy from inner to outer header
    Enum_String(BYPASSDF);       /// Enable bypass of copy from inner to outer header of DiffServices
    Enum_String(BYPASSDSCP);     /// Enable Network Address Translation (NAT) insertion
    Enum_String(NAT);            /// Enable NAT checksum generation and checking
    Enum_String(NCHK);           /// Bits for Diff Services/Congestion bits
    Enum_String(DSECN);          /// Time-to-Live field for the packet
    Enum_String(TTLHOP);         /// Flags field in the IPv4
    Enum_String(FLAGS);          /// Source port for NAT
    Enum_String(NATSRC);         /// Destination port for NAT
    Enum_String(NATDST);         /// Identification field for IPv4
    Enum_String(ID);             /// Label field for IPv6
    Enum_String(LABEL);          /// Fragment offset from first packet
    Enum_String(FRAGOFFSET);     /// Enable fragmentation of packet
    Enum_String(MOREFRAG);       /// Fragmentation ID for this segment in the overall packet
    Enum_String(FRAGID);         /// Maximum Transmission unit (MTU)
    Enum_String(MTU);            /// Source Address
    Enum_String(SOURCE);         /// Destination Address
    Enum_String(DESTINATION);    /// IPv6 Extension header(s)
    Enum_String(EXTHDR);         /// Next header in either the extension header or the payload
    Enum_String(NH);             /// Length of the AAD
    Enum_String(AADLEN);         /// Length of the ICV
    Enum_String(ICVLEN);         /// Length of the IP headeer
    Enum_String(HDRLEN);         /// Length of the Traffic flow Confidentiality (TFC) padding
    Enum_String(TFCLEN);         /// Use extended sequence number
    Enum_String(USEXT);          /// Use random IV rather than user IV
    Enum_String(RANDIV);         /// Nodal JUMBOGRAM support
    Enum_String(NODEJUMBO);      /// Enable audint of IP flow
    Enum_String(AUDIT);          /// Path to the audit log
    Enum_String(AUDITLOG);       /// Enable IPv4 header checksum
    Enum_String(CHECKSUM);       /// Length of the packet (IPv4) or length of the packet minus the standard IPv6 header
    Enum_String(LENGTH);         /// ICMP Type 
    Enum_String(TYPE);           /// ICMP SubType
    Enum_String(CODE);           /// Pointer to error in packet
    Enum_String(POINTER);        /// Identifier from the invoking message
    Enum_String(IDENTIFIER);     /// Gateway Internet Address
    Enum_String(GATEWAY);        /// Timestamp from the origination node
    Enum_String(ORIGTIMESTAMP);  /// Receive timestamp
    Enum_String(RXTIMESTAMP);    /// Transmit timestamp
    Enum_String(TXTIMESTAMP);    /// Message to send
    Enum_String(MESSAGE);        /// Code to send
    Enum_String(ICMPCODE);       /// Data or Control bit
    Enum_String(DATACTRL);       /// Control PDU type field
    Enum_String(PDUTYPE);        /// Polling bit
    Enum_String(POLLBIT);        /// Extension bit
    Enum_String(EXTENSION);      /// Reset sequence number (RSN)
    Enum_String(RSN);            /// Sequence number length in bits
    Enum_String(SNLEN);          /// Header extension type field
    Enum_String(HDREXT);         /// Length indicator field
    Enum_String(LENGTHIND);      /// Hyper frame number indicator (HFNI)
    Enum_String(HFNI);           /// Super Field (SUFI)
    Enum_String(SUFI);           /// PDCP SN of the first Missing PDCP SDU (FMS)
    Enum_String(FMS);            /// Length of BitMap
    Enum_String(BITMAPLEN);      /// Bitmap for LTE
    Enum_String(BITMAP);         /// Five LSB(s) of PGK identity
    Enum_String(PGKINDEX);       /// PTK identity
    Enum_String(PTKINDENT);      /// PDCP SDU type (IP, ARP, PC5SIG, NONIP, RSVD)
    Enum_String(SDUTYPE);        /// Kd identity
    Enum_String(KDID);           /// Number of missing PDCP SDU(s) with associated COUNT value
    Enum_String(NMP);            /// PDCP SN of the PDCP SDU received on WLAN with highest associated PDCP COUNT value
    Enum_String(HRW);            /// Bearer value
    Enum_String(BEARER);         /// Fresh value for F9 modes
    Enum_String(FRESH);          /// Count value for F8/F9 modes
    Enum_String(COUNT);          /// Ethernet type
    Enum_String(ETHERTYPE);      /// Short length field
    Enum_String(SL);             /// TAG Control Information and Association Number
    Enum_String(TCIAN);          /// Packet number
    Enum_String(PN);             /// Extended packet number
    Enum_String(XPN);            /// Secure Channel Identifier
    Enum_String(SCI);            /// Short Secure Channel Identifier
    Enum_String(SSCI);           /// Security Association Key
    Enum_String(SAKEY);          /// Enable reception of packets
    Enum_String(ENRECEIVE);      /// Enable transmission of packets
    Enum_String(ENTRANSMIT);     /// Protect packets
    Enum_String(PROTECTFRAMES);  /// MacSEC flow is in use (RX or TX)
    Enum_String(INUSE);          /// Time this MacSEC was created
    Enum_String(CREATETIME);     /// Time this MacSEC last enabled RX or TX
    Enum_String(STARTTIME);      /// Time this MacSEC last disabled RX or TX
    Enum_String(STOPTIME);       /// Padding field
    Enum_String(PADDING);        /// CSRC count field
    Enum_String(CC);             /// Marker field
    Enum_String(MARKER);         /// Payload type field
    Enum_String(PT);             /// Rollover Counter (ROC)
    Enum_String(ROC);            /// Timestamp field
    Enum_String(TIMESTAMP);      /// Synchronization source identifier (SSRC)
    Enum_String(SSRC);           /// Contributing source identifier (CSRC)
    Enum_String(CSRC);           /// Block size of the encryption cipher
    Enum_String(BLKSIZE);        /// MKI flag
    Enum_String(MKI);            /// MKI data length
    Enum_String(MKILEN);         /// MKI data
    Enum_String(MKIDATA);        /// Acknowledge number
    Enum_String(ACKNUM);         /// Data offset
    Enum_String(OFFSET);         /// Receive size window
    Enum_String(RCVWINDOW);      /// Urgent pointer
    Enum_String(URGENT);         /// TCP state of operation
    Enum_String(STATE);          /// OPTIONS
    Enum_String(OPTIONS);        /// SEGLEN
    Enum_String(SEGLEN);         /// PRECEDENCE
    Enum_String(PRECEDENCE);     /// SNDUNA
    Enum_String(SNDUNA);         /// SNDNXT
    Enum_String(SNDNXT);         /// SNDWND
    Enum_String(SNDWND);         /// SNDUP
    Enum_String(SNDUP);          /// SNDW1
    Enum_String(SNDW1);          /// SNDW2
    Enum_String(SNDW2);          /// ISS
    Enum_String(ISS);            /// RCVNXT
    Enum_String(RCVNXT);         /// RCVWND
    Enum_String(RCVWND);         /// RCVUP
    Enum_String(RCVUP);          /// IRS
    Enum_String(IRS);            /// TCPTIMEOUT
    Enum_String(TCPTIMEOUT);     /// Epoch number for DTLS
    Enum_String(EPOCH);          /// Ciphersuite for the TLS protocol
    Enum_String(CIPHERSUITE);    /// Encrypt-then-MAC the TLS packet
    Enum_String(ENCTHENMAC);     /// Implicit or Explicit IV for TLS
    Enum_String(IVEX);           /// Frame control sequence in entirety
    Enum_String(FRAMECTL);       /// Control Frame extension
    Enum_String(CTLEXT);         /// Protocol version
    Enum_String(PROTVER);        /// SubType
    Enum_String(SUBTYPE);        /// To Data Stream
    Enum_String(TDS);            /// From Data Stream
    Enum_String(FDS);            /// More fragmentation
    Enum_String(MFRAG);          /// Retry
    Enum_String(RETRY);          /// Power management
    Enum_String(PWRMGMT);        /// More data field
    Enum_String(MDATA);          /// Wireless Encryption Protection (WEP)
    Enum_String(WEP);            /// Order
    Enum_String(ORDER);          /// Key derivation function (KDF) algorithm
    Enum_String(KDFALG);         /// First address
    Enum_String(ADDR1);          /// Second address
    Enum_String(ADDR2);          /// Third address
    Enum_String(ADDR3);          /// Sequence control
    Enum_String(SEQCTL);         /// Fourth address
    Enum_String(ADDR4);          /// Quality of Service field
    Enum_String(QOSCTL);         /// HT control field
    Enum_String(HTCTL);          /// Extended IV flag
    Enum_String(EXTIV);          /// Key identification
    Enum_String(KEYID);          /// SPP Cap
    Enum_String(SPPCAP);         /// Enable CRC checking for packet
    Enum_String(FCS);            /// Header Type where zero for generic MAC header
    Enum_String(HT);             /// Encryption Control 0=no encryption 1=encryption
    Enum_String(EC);             /// Extended Subheader Field ESF=1 then ESF is present and follows MAC header
    Enum_String(ESF);            /// CRC Indicator 0=no CRC, 1=CRC present
    Enum_String(CI);             /// Encryption Key Sequence. Index of TEK and IV used to encrypt the payload
    Enum_String(EKS);            /// Connection Identifier
    Enum_String(CID);            /// Flow Identifier (AGHM header only)
    Enum_String(FID);            /// Extended Header Group Indicator (AGHM header only)
    Enum_String(EH);             /// Header Check Sequence 8-bit header checksum
    Enum_String(HCS);            /// IKE Conneciton Name
    Enum_String(IKECNXT);        /// IKE Exchange Type
    Enum_String(EXCHG);          /// IKE Next Payload Value
    Enum_String(NXTPYLD);        /// IKE Major Revision Number
    Enum_String(MAJOR_VERSION);  /// IKE Minor Revision Number
    Enum_String(MINOR_VERSION);  /// IKE Message Identifier when Initiator
    Enum_String(MSGIDINIT);      /// IKE Message Identifier when Responder
    Enum_String(MSGIDRESP);      /// IKE Initiator Security Parameter Index
    Enum_String(SPIi);           /// IKE Responder Security Parameter Index
    Enum_String(SPIr);           /// IKE Initiator Nonce
    Enum_String(Ni);             /// IKE Responder Nonce
    Enum_String(Nr);             /// IKE Child SA Key Generation Seed
    Enum_String(SKd);            /// IKE Initiator Encryption Key
    Enum_String(SKei);           /// IKE Responder Encryption Key
    Enum_String(SKer);           /// IKE Initiator Salt Value
    Enum_String(SKsi);           /// IKE Responder Salt Value
    Enum_String(SKsr);           /// IKE Integrity Algorithm
    Enum_String(INTEG);          /// IKE Initiator Integrity Algorithm Key
    Enum_String(SKai);           /// IKE Responder Integrity Algorithm Key
    Enum_String(SKar);           /// IKE Psuedo Random Function Algorithm
    Enum_String(PRF);            /// IKE Psuedo Random Total Key Length
    Enum_String(PRFLEN);         /// IKE Initiator Psuedo Random Key
    Enum_String(SKpi);           /// IKE Responder Psuedo Random Key
    Enum_String(SKpr);           /// IKE Diffie-Hellman Group ID
    Enum_String(DH);             /// IKE Signature Algorithm
    Enum_String(IKEAUTH);        /// IKE Hash Algorithm
    Enum_String(IKEHASH);        /// Size fo the Private Key
    Enum_String(BITSIZE);        /// RSA Padding type
    Enum_String(RSAPAD);         /// RSA Encrypt type
    Enum_String(RSAENC);         /// Key pair
    Enum_String(KEYPAIR);        /// Private Key
    Enum_String(PRVKEY);         /// Public Key
    Enum_String(PUBKEY);         /// Prime value for DSA (usually called "p")
    Enum_String(PRIME);          /// Subprime value for DSA (usually called "q")
    Enum_String(SUBPRIME);       /// Generator value for DSA (usually called "g")
    Enum_String(GENERATOR);      /// X-coordinate for the ECDSA curve
    Enum_String(GX);             /// Y-coordinate for the ECDSA curve
    Enum_String(GY);             /// Hash function for ECDSA
    Enum_String(ECHASH);         /// Name of the current curve
    Enum_String(CURVE);          /// First 802.1Q VLAN tag
    Enum_String(VLANTAG1);       /// Second 802.1Q VLAN tag
    Enum_String(VLANTAG2);       /// Postprocessing flag
    Enum_String(POSTPROCESS);    /// Setup flag
    Enum_String(SETUP);          /// Size field
    Enum_String(STREAMSIZE);     /// Name of the stream object
    Enum_String(NAME);           /// Output address of the packet
    Enum_String(OUTADDR);        /// Output length of the packet
    Enum_String(OUTLEN);         /// Input length of the packet
    Enum_String(INLEN);          /// Output length of the packet
    Enum_String(OUTPUTLEN);      /// Expected length of the packet
    Enum_String(EXPLEN);         /// Name of the stream associated with this packet
    Enum_String(STREAM);         /// Previous packet to this one (set to "begin" if this is the first packet)
    Enum_String(PREVIOUS);       /// Status word for this packet
    Enum_String(STATUS);         /// INPUT data for this packet
    Enum_String(INPUT);          /// OUTPUT data for this packet
    Enum_String(OUTPUT);         /// EXPECT data for this packet
    Enum_String(EXPECT);         /// Size of the block cipher data
    Enum_String(BLOCKSIZE);      /// Zero initial value for CRC calculations
    Enum_String(ZEROINIT);       /// Swap input data before CRC calculation
    Enum_String(SWAPIN);         /// Swap output data before CRC calculation
    Enum_String(SWAPOUT);        /// Complement output CRC
    Enum_String(COMPOUT);        /// Polynomial for CRC
    Enum_String(POLYNOMIAL);     /// Testbench seed
    Enum_String(SEED);           /// Number of errors
    Enum_String(ERRORS);         /// Number of flows
    Enum_String(FLOWS);          /// Number of packets
    Enum_String(PACKETS);        /// Logging level
    Enum_String(LOGLVL);         /// Pointer size for testbench
    Enum_String(PTRSIZE);        /// Scatter-gather table entry size
    Enum_String(SGTSIZE);        /// Log to std::cout
    Enum_String(STDOUT);         /// Endianness for testbench
    Enum_String(ENDIAN);         /// Platform to run testbench with
    Enum_String(PLATFORM);       /// Color of debug messages in the testbench
    Enum_String(DEBUGCLR);       /// Color of information messages in the testbench
    Enum_String(INFOCLR);        /// Color of warning messages in the testbench
    Enum_String(WARNCLR);        /// Color of error messages in the testbench
    Enum_String(ERRCLR);         /// Color of fatal messages in the testbench
    Enum_String(FATALCLR);       /// Color of pass messages in the testbench
    Enum_String(PASSCLR);        /// Memory Blob Key Encryption Key (BKEK)
    Enum_String(BKEK);           /// Memory Blob Key Length (BKEKLEN)
    Enum_String(BKEKLEN);        /// Memory Blob Key
    Enum_String(BLOBKEY);        /// Memory Blob Key Length
    Enum_String(BLOBKEYLEN);     /// WOTS+ Algorithm
    Enum_String(WOTSALGO);       /// Address of the tree layer
    Enum_String(LAYERADDR);      /// Address in the binary tree
    Enum_String(TREEADDR);       /// Height of the binary tree
    Enum_String(TREEHEIGHT);     /// Value of the TYPE (Enum_String(0), Enum_String(1), or 2)
    Enum_String(TYPEVAL);        /// One-Time Signature Enum_String(Address), LTREE Enum_String(address), or padding
    Enum_String(ADDRORPAD);      /// Chain Address or Tree Height
    Enum_String(CHAINHEIGHT);    /// Hash address in tree or Tree Index
    Enum_String(HASHORIDX);      /// Key and mask address
    Enum_String(KEYNMASK);       /// Convert OTS addresses to byte array
    Enum_String(BYTEARRAY);      /// Signature length
    Enum_String(SIGLEN);         /// Stack in XMSS/LMS
    Enum_String(STACK);          /// Winternitz parameter
    Enum_String(WINTZ);          /// XMSS algorithm
    Enum_String(XMSSALG);        /// Push to the XMSS/LMS stack
    Enum_String(STACKPUSH);      /// Pop the top of the XMSS/LMS stack
    Enum_String(STACKPOP);       /// Return top of the XMSS/LMS stack
    Enum_String(STACKTOP);       /// Access index of the XMSS/LMS stack
    Enum_String(STACKIDX);       /// Height of the top node fo the XMSS/LMS stack
    Enum_String(STACKLEN);       /// LMOTSQ value of 'q' parameter
    Enum_String(LMOTSQ);         /// LMOTS length of hash function
    Enum_String(LMOTSN);         /// LMOTS Winternitz parameter
    Enum_String(LMOTSP);         /// LMOTS number of w-bit elements in signature
    Enum_String(LMOTSW);         /// LMOTS number of left-shift bits on checksum calculation
    Enum_String(LMOTSLS);        /// LMOTS signature length
    Enum_String(LMOTSIGLEN);     /// LMOTS key pair identifier
    Enum_String(LMOTSI);         /// LMOTS seed value
    Enum_String(LMOTSEED);       /// LMOTS c-array value
    Enum_String(LMOTSC);         /// LMOTS engine
    Enum_String(LMOTS);          /// LMS Algorithm value as jarray<uint8_t>
    Enum_String(LMSALGVAL);      /// LMOTS Algorithm value as jarray<uint8_t>
    Enum_String(LMOTSALGVAL);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Endian formatting for data. Endianness is within words, double
/// words, etc.
///
/// @param BIG - Big endian with formatting as b[3]b[2]b[1]b[0]
/// @param LITTLE - Little endian with formatting as b[0]b[1]b[2]b[3]
//////////////////////////////////////////////////////////////////////
enum endian_t { ///Big endian with formatting as b[3]b[2]b[1]b[0]
    BIG,        ///Little endian with formatting as b[0]b[1]b[2]b[3] 
    LITTLE
};

Begin_Enum_String(endian_t)
    {
        Enum_String(BIG);
        Enum_String(LITTLE);
    }
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Testbench platform, only used for jtestbench to define how
/// the software rings are accessed and how the security associations
/// are handled
/// @param WASP - Testbench uses jresponder to simulate a platform
///               to test against. Allows randomization of read, 
///               write and processing times
/// @param WASPDUT - Testbench with software rings to allow connecting
///                  a device-under-test (DUT) via the rings
/// @param SEC - Support for SEC block in QorIQ, Layerscape,
///              and iMX* processors from NXP/Qualcomm. This testbench
///              can program the address and size of the software
///              rings which SEC can then read
//////////////////////////////////////////////////////////////////////
enum platform_t {/// Testbench uses jresponder to simulate
    WASP,        /// Testbench with no responder to allow DUT to connect
    WASPDUT,     /// Support for SEC block
    SEC
};

Begin_Enum_String(platform_t)
    {
        Enum_String(WASP);
        Enum_String(WASPDUT);
        Enum_String(SEC);
    }
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// padding types to generate for packet padding
///
/// @param RANDOM - generate random string of bytes for padding
/// @param INCREMENT - generate a series of incrementing bytes for padding
/// @param ZER0 - generate a string of zeros for padding
/// @param SIZE - generate a string of bytes with a value equal to size
//////////////////////////////////////////////////////////////////////
enum pad_t {   ///Generate random string of bytes
    RANDOM,    ///Generate an incrementing string of bytes
    INCREMENT, ///Generate a string of zeros
    ZERO,      ///Generate a string of bytes with value of size
    SIZE,      ///Generate unknown padding
    UNKNWN
};

Begin_Enum_String(pad_t)
{
    Enum_String(RANDOM);
    Enum_String(INCREMENT);
    Enum_String(ZERO);
    Enum_String(SIZE);
    Enum_String(UNKNWN);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Protocols not found in the standard IANA values
///
/// @param ERRNONE - No error in protocol
/// @param PROTOCOL - Protocol++&reg; base class
/// @param MACSEC - IEEE802 Security protocol
/// @param WIFI - IEEE802.11 Wireless Protocol
/// @param WIGIG - IEEE802.11ad Wireless Protocol
/// @param WIMAX - IEEE802.16 Wireless Protocol
/// @param LTE - Long Term Evolution (LTE)/3GPP Protocols
/// @param RLC - Radio Link Control Protocol (RLC)
/// @param TLS - Transport Layer Security (TLS)
/// @param SRTP - Secure Real Time Protocol (SRTP)
/// @param UDPP - User Data Protocol (UDP)
/// @param TCPP - Transport Control Protocol (TCP)
/// @param ICMPP - Internet Control Message Protocol (ICMP)
/// @param IP - IP protocol
/// @param IPSEC - IPsec Protocol (ESP)
/// @param XMLPARSER - TinyXML2 parser
/// @param RINGDRIVER - Ring based driver
/// @param DIRECTDRIVER - Direct driver
/// @param DRIVER - Driver
/// @param LOOPBACK - Loopback mode for the Ethernet interface
/// @param ETHERNET - Ethernet interface
/// @param RSA - RSA Crypto System
/// @param DSA - Digital Signature Algorithm
/// @param ECDSAFP - Elliptic Curve Signature Algorithm in a Binary Field
/// @param ECDSAF2M - Elliptic Curve Signature Algorithm in a Galios Field
/// @param ECDSAED - Elliptic Curve Signature Algorithm for Ed25519
/// @param IKEV2 - Internet Key Exchange (IKE) version 2
/// @param INTEGRITY - Encryption algorithm
/// @param CONFIDENT - Authentication algorithm
/// @param XMSS - XMSS Signature Scheme
/// @param LMS - LMS Signature Scheme
/// @param NOPROTO - No protocol selected
//////////////////////////////////////////////////////////////////////
enum protocol_t { ///No Error
    ERRNONE,     ///JProtocol base class
    PROTOCOL,     ///Macsec protocol
    MACSEC,       ///Wifi protocol
    WIFI,         ///WiGig protocol
    WIGIG,        ///WiMax protocol
    WIMAX,        ///LTE/3GPP protocol
    LTE,          ///Radio Link Control
    RLC,          ///TLS/SSL protocol
    TLS,          ///Secure RTP protocol
    SRTP,         ///UDP
    UDPP,         ///TCP
    TCPP,         ///ICMP
    ICMPP,        ///IP
    IP,           ///IPsec
    IPSEC,        ///XML Parser
    XMLPARSER,    ///Ring Driver
    RINGDRIVER,   ///Direct Driver
    DIRECTDRIVER, ///Driver
    DRIVER,       ///Ethernet LoopBack mode
    LOOPBACK,     ///Ethernet
    ETHERNET,     ///RSA Crypto System
    RSA,          ///Digital Signature Algorithm
    DSA,          ///Elliptic Curve Digital Signature Algorithm in Binary field
    ECDSAFP,      ///Elliptic Curve Digital Signature Algorithm in Galios field
    ECDSAF2M,     ///Elliptic Curve Digital Signature Algorithm for Ed25519
    ECDSAED,      ///Internet Key Exchange (IKE) version 2
    IKEV2,        ///Encryption algorithm
    INTEGRITY,    ///Authentication algorithm
    CONFIDENT,    ///Memory BLOB
    BLOB,         ///XMSS Signature method
    XMSS,         ///LMS Signatrure method
    LMS,          ///TLS v1.3
    TLS13,        ///No protocol selected
    NOPROTO
};

Begin_Enum_String(protocol_t)
{
    Enum_String(ERRNONE);
    Enum_String(PROTOCOL);
    Enum_String(MACSEC);
    Enum_String(WIFI);
    Enum_String(WIGIG);
    Enum_String(WIMAX);
    Enum_String(LTE);
    Enum_String(RLC);
    Enum_String(TLS);
    Enum_String(SRTP);
    Enum_String(UDPP);
    Enum_String(TCPP);
    Enum_String(ICMPP);
    Enum_String(IP);
    Enum_String(IPSEC);
    Enum_String(XMLPARSER);
    Enum_String(RINGDRIVER);
    Enum_String(DIRECTDRIVER);
    Enum_String(DRIVER);
    Enum_String(LOOPBACK);
    Enum_String(RSA);
    Enum_String(DSA);
    Enum_String(ECDSAFP);
    Enum_String(ECDSAF2M);
    Enum_String(ECDSAED);
    Enum_String(IKEV2);
    Enum_String(INTEGRITY);
    Enum_String(CONFIDENT);
    Enum_String(BLOB);
    Enum_String(XMSS);
    Enum_String(LMS);
    Enum_String(TLS13);
    Enum_String(NOPROTO);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Ethernet ID Type for use with drivers
///
/// @param ETH_P_LOOP - Ethernet Loopback packet (0x0060)
/// @param ETH_P_PUP - Xerox PUP packet (0x0200)
/// @param ETH_P_PUPAT - Xerox PUP Addr Trans packet (0x0201)
/// @param ETH_P_IP - Internet Protocol packet (0x0800)
/// @param ETH_P_X25 - CCITT X.25 (0x0805)
/// @param ETH_P_ARP - Address Resolution packet (0x0806)
/// @param ETH_P_BPQ - G8BPQ AX.25 Ethernet Packet [ NOT AN OFFICIALLY REGISTERED ID ] (0x08FF)
/// @param ETH_P_IEEEPUP - Xerox IEEE802.3 PUP packet (0x0a00)
/// @param ETH_P_IEEEPUPAT - Xerox IEEE802.3 PUP Addr Trans packet (0x0a01)
/// @param ETH_P_BATMAN - B.A.T.M.A.N.-Advanced packet [ NOT AN OFFICIALLY REGISTERED ID ] (0x4305)
/// @param ETH_P_DEC - DEC Assigned proto (0x6000)
/// @param ETH_P_DNA_DL - DEC DNA Dump/Load (0x6001)
/// @param ETH_P_DNA_RC - DEC DNA Remote Console (0x6002)
/// @param ETH_P_DNA_RT - DEC DNA Routing (0x6003)
/// @param ETH_P_LAT - DEC LAT (0x6004)
/// @param ETH_P_DIAG - DEC Diagnostics (0x6005)
/// @param ETH_P_CUST - DEC Customer use (0x6006)
/// @param ETH_P_SCA - DEC Systems Comms Arch (0x6007)
/// @param ETH_P_TEB - Trans Ether Bridging (0x6558)
/// @param ETH_P_RARP - Reverse Addr Res packet (0x8035)
/// @param ETH_P_ATALK - Appletalk DDP (0x809B)
/// @param ETH_P_AARP - Appletalk AARP (0x80F3)
/// @param ETH_P_8021Q - 802.1Q VLAN Extended Header (0x8100)
/// @param ETH_P_IPX - IPX over DIX (0x8137)
/// @param ETH_P_IPV6 - IPv6 over bluebook (0x86DD)
/// @param ETH_P_PAUSE - IEEE Pause frames. See 802.3 31B (0x8808)
/// @param ETH_P_SLOW - Slow Protocol. See 802.3ad 43B (0x8809)
/// @param ETH_P_WCCP - Web-cache coordination protocol defined in draft-wilson-wrec-wccp-v2-00.txt (0x883E)
/// @param ETH_P_PPP_DISC - PPPoE discovery messages (0x8863)
/// @param ETH_P_PPP_SES - PPPoE session messages (0x8864)
/// @param ETH_P_MPLS_UC - MPLS Unicast traffic (0x8847)
/// @param ETH_P_MPLS_MC - MPLS Multicast traffic (0x8848)
/// @param ETH_P_ATMMPOA - MultiProtocol Over ATM (0x884c)
/// @param ETH_P_LINK_CTL - HPNA, wlan link local tunnel (0x886c)
/// @param ETH_P_ATMFATE - Frame-based ATM Transport over Ethernet (0x8884)
/// @param ETH_P_PAE - Port Access Entity (IEEE 802.1X) (0x888E)
/// @param ETH_P_AOE - ATA over Ethernet (0x88A2)
/// @param ETH_P_8021AD - 802.1ad Service VLAN (0x88A8)
/// @param ETH_P_802_EX1 - 802.1 Local Experimental 1. (0x88B5)
/// @param ETH_P_TIPC - TIPC (0x88CA)
/// @param ETH_P_MACSEC - 802.1ae MACsec (0x88E5)
/// @param ETH_P_8021AH - 802.1ah Backbone Service Tag (0x88E7)
/// @param ETH_P_MVRP - 802.1Q MVRP (0x88F5)
/// @param ETH_P_1588 - IEEE 1588 Timesync (0x88F7)
/// @param ETH_P_FCOE - Fibre Channel over Ethernet (0x8906)
/// @param ETH_P_IBOE - Infiniband over Ethernet (0x8915)
/// @param ETH_P_TDLS - TDLS (0x890D)
/// @param ETH_P_FIP - FCoE Initialization Protocol (0x8914)
/// @param ETH_P_80221 - IEEE 802.21 Media Independent Handover Protocol (0x8917)
/// @param ETH_P_NSH - Network Service Header (0x894F)
/// @param ETH_P_LOOPBACK - Ethernet loopback packet, per IEEE 802.3 (0x9000)
/// @param ETH_P_QINQ1 - deprecated QinQ VLAN [ NOT AN OFFICIALLY REGISTERED ID ] (0x9100)
/// @param ETH_P_QINQ2 - deprecated QinQ VLAN [ NOT AN OFFICIALLY REGISTERED ID ] (0x9200)
/// @param ETH_P_QINQ3 - deprecated QinQ VLAN [ NOT AN OFFICIALLY REGISTERED ID ] (0x9300)
/// @param ETH_P_EDSA - Ethertype DSA [ NOT AN OFFICIALLY REGISTERED ID ] (0xDADA)
/// @param ETH_P_IFE - ForCES inter-FE LFB type (0xED3E)
/// @param ETH_P_AF_IUCV - IBM af_iucv [ NOT AN OFFICIALLY REGISTERED ID ] (0xFBFB)
/// @param ETH_P_802_3_MIN - If the value in the ethernet type is less than this value then the frame is Ethernet II. Else it is 802.3 (0x0600)
/// @param ETH_P_802_3 - Dummy type for 802.3 frames (0x0001)
/// @param ETH_P_AX25 - Dummy protocol id for AX.25 (0x0002)
/// @param ETH_P_ALL - Every packet (0x0003)
/// @param ETH_P_802_2 - 802.2 frames (0x0004)
/// @param ETH_P_SNAP - Internal only (0x0005)
/// @param ETH_P_DDCMP - DEC DDCMP: Internal only (0x0006)
/// @param ETH_P_WAN_PPP - Dummy type for WAN PPP frames (0x0007)
/// @param ETH_P_PPP_MP - Dummy type for PPP MP frames (0x0008)
/// @param ETH_P_LOCALTALK - Localtalk pseudo type (0x0009)
/// @param ETH_P_CAN - CAN: Controller Area Network (0x000C)
/// @param ETH_P_CANFD - CANFD: CAN flexible data rate (0x000D)
/// @param ETH_P_PPPTALK - Dummy type for Atalk over PPP (0x0010)
/// @param ETH_P_TR_802_2 - 802.2 frames (0x0011)
/// @param ETH_P_MOBITEX - Mobitex (kaz@cafe.net) (0x0015)
/// @param ETH_P_CONTROL - Card specific control frames (0x0016)
/// @param ETH_P_IRDA - Linux-IrDA (0x0017)
/// @param ETH_P_ECONET - Acorn Econet (0x0018)
/// @param ETH_P_HDLC - HDLC frames (0x0019)
/// @param ETH_P_ARCNET - 1A for ArcNet (0x001A)
/// @param ETH_P_DSA - Distributed Switch Arch. (0x001B)
/// @param ETH_P_TRAILER - Trailer switch tagging (0x001C)
/// @param ETH_P_PHONET - Nokia Phonet frames (0x00F5)
/// @param ETH_P_IEEE802154 - IEEE802.15.4 frame (0x00F6)
/// @param ETH_P_CAIF - ST-Ericsson CAIF protocol (0x00F7)
/// @param ETH_P_XDSA - Multiplexed DSA protocol (0x00F8)
//////////////////////////////////////////////////////////////////////
enum ethid_t {                ///Ethernet Loopback packet
    ETH_P_LOOP = 0x0060,      ///Xerox PUP packet
    ETH_P_PUP = 0x0200,       ///Xerox PUP Addr Trans packet
    ETH_P_PUPAT = 0x0201,     ///Internet Protocol packet
    ETH_P_IP = 0x0800,        ///CCITT X.25
    ETH_P_X25 = 0x0805,       ///Address Resolution packet
    ETH_P_ARP = 0x0806,       ///G8BPQ AX.25 Ethernet Packet [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_BPQ = 0x08FF,       ///Xerox IEEE802.3 PUP packet
    ETH_P_IEEEPUP = 0x0a00,   ///Xerox IEEE802.3 PUP Addr Trans packet
    ETH_P_IEEEPUPAT = 0x0a01, ///B.A.T.M.A.N.-Advanced packet [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_BATMAN = 0x4305,    ///DEC Assigned proto
    ETH_P_DEC = 0x6000,       ///DEC DNA Dump/Load
    ETH_P_DNA_DL = 0x6001,    ///DEC DNA Remote Console
    ETH_P_DNA_RC = 0x6002,    ///DEC DNA Routing
    ETH_P_DNA_RT = 0x6003,    ///DEC LAT
    ETH_P_LAT = 0x6004,       ///DEC Diagnostics
    ETH_P_DIAG = 0x6005,      ///DEC Customer use
    ETH_P_CUST = 0x6006,      ///DEC Systems Comms Arch
    ETH_P_SCA = 0x6007,       ///Trans Ether Bridging
    ETH_P_TEB = 0x6558,       ///Reverse Addr Res packet
    ETH_P_RARP = 0x8035,      ///Appletalk DDP
    ETH_P_ATALK = 0x809B,     ///Appletalk AARP
    ETH_P_AARP = 0x80F3,      ///802.1Q VLAN Extended Header
    ETH_P_8021Q = 0x8100,     ///IPX over DIX
    ETH_P_IPX = 0x8137,       ///IPv6 over bluebook
    ETH_P_IPV6 = 0x86DD,      ///IEEE Pause frames. See 802.3 31B
    ETH_P_PAUSE = 0x8808,     ///Slow Protocol. See 802.3ad 43B
    ETH_P_SLOW = 0x8809,      ///Web-cache coordination protocol defined in draft-wilson-wrec-wccp-v2-00.txt
    ETH_P_WCCP = 0x883E,      ///PPPoE discovery messages
    ETH_P_PPP_DISC = 0x8863,  ///PPPoE session messages
    ETH_P_PPP_SES = 0x8864,   ///MPLS Unicast traffic
    ETH_P_MPLS_UC = 0x8847,   ///MPLS Multicast traffic
    ETH_P_MPLS_MC = 0x8848,   ///MultiProtocol Over ATM
    ETH_P_ATMMPOA = 0x884c,   ///HPNA wlan link local tunnel
    ETH_P_LINK_CTL = 0x886c,  ///Frame-based ATM Transport over Ethernet
    ETH_P_ATMFATE = 0x8884,   ///Port Access Entity (IEEE 802.1X)
    ETH_P_PAE = 0x888E,       ///ATA over Ethernet
    ETH_P_AOE = 0x88A2,       ///802.1ad Service VLAN
    ETH_P_8021AD = 0x88A8,    ///802.1 Local Experimental 1
    ETH_P_802_EX1 = 0x88B5,   ///TIPC
    ETH_P_TIPC = 0x88CA,      ///802.1ae MACsec
    ETH_P_MACSEC = 0x88E5,    ///802.1ah Backbone Service Tag
    ETH_P_8021AH = 0x88E7,    ///802.1Q MVRP
    ETH_P_MVRP = 0x88F5,      ///IEEE 1588 Timesync
    ETH_P_1588 = 0x88F7,      ///Fibre Channel over Ethernet
    ETH_P_FCOE = 0x8906,      ///Infiniband over Ethernet
    ETH_P_IBOE = 0x8915,      ///TDLS
    ETH_P_TDLS = 0x890D,      ///FCoE Initialization Protocol
    ETH_P_FIP = 0x8914,       ///IEEE 802.21 Media Independent Handover Protocol
    ETH_P_80221 = 0x8917,     ///Network Service Header
    ETH_P_NSH = 0x894F,       ///802.1Q Instance VLAN
    ETH_P_8021I = 0x8E87,     ///Ethernet loopback packet per IEEE 802.3
    ETH_P_LOOPBACK = 0x9000,  ///deprecated QinQ VLAN [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_QINQ1 = 0x9100,     ///deprecated QinQ VLAN [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_QINQ2 = 0x9200,     ///deprecated QinQ VLAN [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_QINQ3 = 0x9300,     ///Ethertype DSA [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_EDSA = 0xDADA,      ///forCES inter-FE LFB type
    ETH_P_IFE = 0xED3E,       ///IBM af_iucv [ NOT AN OFFICIALLY REGISTERED ID ]
    ETH_P_AF_IUCV = 0xFBFB,   ///If the value in the ethernet type is less than this value then the frame is Ethernet II else it is 802.3
    ETH_P_802_3_MIN = 0x0600, ///Dummy type for 802.3 frames
    ETH_P_802_3 = 0x0001,     ///Dummy protocol id for AX.25
    ETH_P_AX25 = 0x0002,      ///Every packet (be careful!!!)
    ETH_P_ALL = 0x0003,       ///802.2 frames
    ETH_P_802_2 = 0x0004,     ///Internal only
    ETH_P_SNAP = 0x0005,      ///DEC DDCMP: Internal only
    ETH_P_DDCMP = 0x0006,     ///Dummy type for WAN PPP frames
    ETH_P_WAN_PPP = 0x0007,   ///Dummy type for PP MP frames
    ETH_P_PPP_MP = 0x0008,    ///Localtalk psuedo type
    ETH_P_LOCALTALK = 0x0009, ///CAN: Controller Area Network
    ETH_P_CAN = 0x000C,       ///CANFD: CAN flexible data rate
    ETH_P_CANFD = 0x000D,     ///Dummy type for Atalk over PPP
    ETH_P_PPPTALK = 0x0010,   ///802.2 frames
    ETH_P_TR_802_2 = 0x0011,  ///Mobitex (kaz@cafe.net)
    ETH_P_MOBITEX = 0x0015,   ///Card specific control frames
    ETH_P_CONTROL = 0x0016,   ///Linux-IrDA
    ETH_P_IRDA = 0x0017,      ///Acorn Econet
    ETH_P_ECONET = 0x0018,    ///HDLC frames
    ETH_P_HDLC = 0x0019,      ///1A for ArcNet
    ETH_P_ARCNET = 0x001A,    ///Distributed Switch Arch
    ETH_P_DSA = 0x001B,       ///Trailer switch tagging
    ETH_P_TRAILER = 0x001C,   ///Nokia Phonet frames
    ETH_P_PHONET = 0x00F5,    ///IEEE802.15.4 frame
    ETH_P_IEEE802154 = 0x00F6,///ST-Ericsson CAIF protocol
    ETH_P_CAIF = 0x00F7,      ///Multiplexed DSA protocol
    ETH_P_XDSA = 0x00F8,      ///No Ethernet command
    ETH_P_NONE = 0xFFFF
};

Begin_Enum_String(ethid_t)
{
    Enum_String(ETH_P_LOOP);
    Enum_String(ETH_P_PUP);
    Enum_String(ETH_P_PUPAT);
    Enum_String(ETH_P_IP);
    Enum_String(ETH_P_X25);
    Enum_String(ETH_P_ARP);
    Enum_String(ETH_P_BPQ);
    Enum_String(ETH_P_IEEEPUP);
    Enum_String(ETH_P_IEEEPUPAT);
    Enum_String(ETH_P_BATMAN);
    Enum_String(ETH_P_DEC);
    Enum_String(ETH_P_DNA_DL);
    Enum_String(ETH_P_DNA_RC);
    Enum_String(ETH_P_DNA_RT);
    Enum_String(ETH_P_LAT);
    Enum_String(ETH_P_DIAG);
    Enum_String(ETH_P_CUST);
    Enum_String(ETH_P_SCA);
    Enum_String(ETH_P_TEB);
    Enum_String(ETH_P_RARP);
    Enum_String(ETH_P_ATALK);
    Enum_String(ETH_P_AARP);
    Enum_String(ETH_P_8021Q);
    Enum_String(ETH_P_IPX);
    Enum_String(ETH_P_IPV6);
    Enum_String(ETH_P_PAUSE);
    Enum_String(ETH_P_SLOW);
    Enum_String(ETH_P_WCCP);
    Enum_String(ETH_P_PPP_DISC);
    Enum_String(ETH_P_PPP_SES);
    Enum_String(ETH_P_MPLS_UC);
    Enum_String(ETH_P_MPLS_MC);
    Enum_String(ETH_P_ATMMPOA);
    Enum_String(ETH_P_LINK_CTL);
    Enum_String(ETH_P_ATMFATE);
    Enum_String(ETH_P_PAE);
    Enum_String(ETH_P_AOE);
    Enum_String(ETH_P_8021AD);
    Enum_String(ETH_P_802_EX1);
    Enum_String(ETH_P_TIPC);
    Enum_String(ETH_P_MACSEC);
    Enum_String(ETH_P_8021AH);
    Enum_String(ETH_P_MVRP);
    Enum_String(ETH_P_1588);
    Enum_String(ETH_P_FCOE);
    Enum_String(ETH_P_IBOE);
    Enum_String(ETH_P_TDLS);
    Enum_String(ETH_P_FIP);
    Enum_String(ETH_P_80221);
    Enum_String(ETH_P_NSH);
    Enum_String(ETH_P_8021I);
    Enum_String(ETH_P_LOOPBACK);
    Enum_String(ETH_P_QINQ1);
    Enum_String(ETH_P_QINQ2);
    Enum_String(ETH_P_QINQ3);
    Enum_String(ETH_P_EDSA);
    Enum_String(ETH_P_IFE);
    Enum_String(ETH_P_AF_IUCV);
    Enum_String(ETH_P_802_3_MIN);
    Enum_String(ETH_P_802_3);
    Enum_String(ETH_P_AX25);
    Enum_String(ETH_P_ALL);
    Enum_String(ETH_P_802_2);
    Enum_String(ETH_P_SNAP);
    Enum_String(ETH_P_DDCMP);
    Enum_String(ETH_P_WAN_PPP);
    Enum_String(ETH_P_PPP_MP);
    Enum_String(ETH_P_LOCALTALK);
    Enum_String(ETH_P_CAN);
    Enum_String(ETH_P_CANFD);
    Enum_String(ETH_P_PPPTALK);
    Enum_String(ETH_P_TR_802_2);
    Enum_String(ETH_P_MOBITEX);
    Enum_String(ETH_P_CONTROL);
    Enum_String(ETH_P_IRDA);
    Enum_String(ETH_P_ECONET);
    Enum_String(ETH_P_HDLC);
    Enum_String(ETH_P_ARCNET);
    Enum_String(ETH_P_DSA);
    Enum_String(ETH_P_TRAILER);
    Enum_String(ETH_P_PHONET);
    Enum_String(ETH_P_IEEE802154);
    Enum_String(ETH_P_CAIF);
    Enum_String(ETH_P_XDSA);
    Enum_String(ETH_P_NONE);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// processing direction
///
/// @param ENCAP - Encapsulation of data
/// @param DECAP - Decapsulation of data
/// @param ENC   - Encryption of data
/// @param DEC   - Decryption of data
/// @param DOWNLINK - For SNOW3G and ZUC tower to user
/// @param UPLINK - For SNOW3G and ZUC user to tower
/// @param NODIR - No direction selected
//////////////////////////////////////////////////////////////////////
enum direction_t {///Encapsulate the payload with protocol
    ENCAP,        ///Decapsulate the packet with the protocol
    DECAP,        ///Encrytion
    ENC,          ///Decryption
    DEC,          ///For SNOW3G and ZUC tower to user
    DOWNLINK,     ///For SNOW3G and ZUC user to tower
    UPLINK,       ///No direction selected
    NODIR
};

Begin_Enum_String(direction_t)
{
    Enum_String(ENCAP);
    Enum_String(DECAP);
    Enum_String(ENC);
    Enum_String(DEC);
    Enum_String(DOWNLINK);
    Enum_String(UPLINK);
    Enum_String(NODIR);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// encryption ciphers
///
/// @param NULL_CIPHER - No encryption present
/// @param DES_ECB - DES-ECB encryption mode
/// @param DES_CBC - DES-CBC encrytpion mode
/// @param DES40_CBC - DES-CBC encryption mode with 40-bit key
/// @param TDES_ECB - Triple-DES ECB encryption mode with 192-bit key
/// @param TDES_CBC - Triple-DES CBC encryption mode with 192-bit key
/// @param AES_ECB - AES-ECB encryption mode
/// @param AES_CBC - AES-CBC encryption mode
/// @param AES_CTR - AES-CTR encryption mode
/// @param AES_CCM - AES-CCM dual encryption and authentication mode
/// @param AES_GCM - AES-GCM dual encryption and authentication mode
/// @param SERPENT_ECB - SERPENT-ECB encryption mode
/// @param SERPENT_CBC - SERPENT-CBC encryption mode
/// @param SERPENT_CTR - SERPENT-CTR encryption mode
/// @param SERPENT_CCM - SERPENT-CCM dual encryption and authentication mode
/// @param SERPENT_GCM - SERPENT-GCM dual encryption and authentication mode
/// @param CHACHA20 - CHACHA20 stream cipher
/// @param CHACHA20_POLY1305 - CHACHA20 and POLY1305 AEAD dual mode
/// @param CAMELLIA_ECB - Camellia ECB encryption mode
/// @param CAMELLIA_CBC - Camellia CBC encryption mode
/// @param CAMELLIA_CTR - Camellia CTR mode
/// @param CAMELLIA_CCM - Camellia CCM AEAD mode
/// @param CAMELLIA_GCM - Camellia GCM AEAD mode
/// @param ARIA_ECB - Korean cipher ARIA in ECB mode
/// @param ARIA_CBC - Korean cipher ARIA in CBC mode
/// @param ARIA_CTR - Korean Cipher ARIA in CTR mode
/// @param ARIA_CCM - Korean Cipher ARIA in CCM mode
/// @param ARIA_GCM - Korean Cipher ARIA in GCM mode
/// @param SEED_ECB - Korean Block Cipher SEED in ECB mode
/// @param SEED_CBC - Korean Block Cipher SEED in CBC mode
/// @param SEED_CTR - Korean Block Cipher SEED in CTR mode
/// @param SEED_CCM - Korean Block Cipher SEED in CCM mode
/// @param SEED_GCM - Korean Block Cipher SEED in GCM mode
/// @param SM4_ECB - Chinese Block Cipher SM4 in ECB mode
/// @param SM4_CBC - Chinese Block Cipher SM4 in CBC mode
/// @param SM4_CTR - Chinese Block Cipher SM4 in CTR mode
/// @param SM4_CCM - Chinese Block Cipher SM4 in CCM mode
/// @param SM4_GCM - Chinese Block Cipher SM4 in GCM mode
/// @param ARC4 - ARC4 Stream Cipher (weak not recommended)
/// @param SNOWE - SNOW3G F8 encryption algorithm
/// @param SNOWV - SNOWV F8 stream encryption algorithm
/// @param SNOWV_GCM - SNOWV GCM AEAD encryption and authentication algorithm
/// @param ZUCE- ZUC F8 encryption algorithm
/// @param NONE_ENC - No encryption algorithm chosen
//////////////////////////////////////////////////////////////////////
enum cipher_t {  ///No encryption present
    NULL_CIPHER, ///DES-ECB encryption mode
    DES_ECB,     ///DES-CBC encryption mode
    DES_CBC,     ///DES-CBC encryption with 40-bit key
    DES40_CBC,   ///Triple-DES ECB encryption mode with 192-bit key
    TDES_ECB,    ///Triple-DES CBC encryption mode with 192-bit key
    TDES_CBC,    ///AES-ECB encryption mode
    AES_ECB,     ///AES-CBC encryption mode
    AES_CBC,     ///AES-CTR encryption mode
    AES_CTR,     ///AES-CCM dual encryption and authentication mode
    AES_CCM,     ///AES-GCM dual encryption and authentication mode
    AES_GCM,     ///SERPENT-ECB encryption mode
    SERPENT_ECB, ///SERPENT-CBC encryption mode
    SERPENT_CBC, ///SERPENT-CTR encryption mode
    SERPENT_CTR, ///SERPENT-CCM dual encryption and authentication mode
    SERPENT_CCM, ///SERPENT-GCM dual encryption and authentication mode
    SERPENT_GCM, ///CHACHA20 encryption mode
    CHACHA20,    ///CHACHA20 and POLY1305 AEAD dual mode
    CHACHA20_POLY1305, ///Camellia ECB encryption mode
    CAMELLIA_ECB,///Camellia CBC encryption mode
    CAMELLIA_CBC,///Camellia CTR mode
    CAMELLIA_CTR,///Camellia CCM AEAD mode
    CAMELLIA_CCM,///Camellia GCM AEAD mode
    CAMELLIA_GCM,///Korean cipher ARIA in ECB mode
    ARIA_ECB,    ///Korean cipher ARIA in CBC mode
    ARIA_CBC,    ///Korean Cipher ARIA in CTR mode
    ARIA_CTR,    ///Korean Cipher ARIA in CCM mode
    ARIA_CCM,    ///Korean Cipher ARIA in GCM mode
    ARIA_GCM,    ///Korean Block Cipher SEED in ECB mode
    SEED_ECB,    ///Korean Block Cipher SEED in CBC mode
    SEED_CBC,    ///Korean Block Cipher SEED in CTR mode
    SEED_CTR,    ///Korean Block Cipher SEED in CCM mode
    SEED_CCM,    ///Korean Block Cipher SEED in GCM mode
    SEED_GCM,    ///Chinese Block Cipher SM4 in ECB mode
    SM4_ECB,     ///Chinese Block Cipher SM4 in CBC mode
    SM4_CBC,     ///Chinese Block Cipher SM4 in CTR mode
    SM4_CTR,     ///Chinese Block Cipher SM4 in CCM mode
    SM4_CCM,     ///Chinese Block Cipher SM4 in GCM mode
    SM4_GCM,     ///ARC4 Stream Cipher (weak not recommended)
    ARC4,        ///SNOW3G F8 encryption algorithm
    SNOWE,       ///SNOWV F8 stream encryption algorithm
    SNOWV,       ///SNOWV GCM AEAD encryption and authentication algorithm
    SNOWV_GCM,   ///ZUC F8 encryption algorithm
    ZUCE,        ///No encryption algorithm chosen
    NONE_ENC
};

Begin_Enum_String(cipher_t)
{
    Enum_String(NULL_CIPHER);
    Enum_String(DES_ECB);
    Enum_String(DES_CBC);
    Enum_String(DES40_CBC);
    Enum_String(TDES_ECB);
    Enum_String(TDES_CBC);
    Enum_String(AES_ECB);
    Enum_String(AES_CBC);
    Enum_String(AES_CTR);
    Enum_String(AES_CCM);
    Enum_String(AES_GCM);
    Enum_String(SERPENT_ECB);
    Enum_String(SERPENT_CBC);
    Enum_String(SERPENT_CTR);
    Enum_String(SERPENT_CCM);
    Enum_String(SERPENT_GCM);
    Enum_String(CHACHA20);
    Enum_String(CHACHA20_POLY1305);
    Enum_String(CAMELLIA_ECB);
    Enum_String(CAMELLIA_CBC);
    Enum_String(CAMELLIA_CTR);
    Enum_String(CAMELLIA_CCM);
    Enum_String(CAMELLIA_GCM);
    Enum_String(ARIA_ECB);
    Enum_String(ARIA_CBC);
    Enum_String(ARIA_CTR);
    Enum_String(ARIA_CCM);
    Enum_String(ARIA_GCM);
    Enum_String(SEED_ECB);
    Enum_String(SEED_CBC);
    Enum_String(SEED_CTR);
    Enum_String(SEED_CCM);
    Enum_String(SEED_GCM);
    Enum_String(SM4_ECB);
    Enum_String(SM4_CBC);
    Enum_String(SM4_CTR);
    Enum_String(SM4_CCM);
    Enum_String(SM4_GCM);
    Enum_String(ARC4);
    Enum_String(SNOWE);
    Enum_String(SNOWV);
    Enum_String(SNOWV_GCM);
    Enum_String(ZUCE);
    Enum_String(NONE_ENC);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Authentication Types
///
/// @param NULL_AUTH - no authentication present
/// @param MD5 - authentication mode with 16 byte MAC
/// @param SHA1 - authentication mode with 20 byte MAC
/// @param SHA224 - authentication mode with 28 byte MAC
/// @param SHA256 - authentication mode with 32 byte MAC
/// @param SHA384 - authentication mode with 48 byte MAC
/// @param SHA512 - authentication mode with 64 byte MAC
/// @param SHA3_224 - authentication mode with 28 byte MAC
/// @param SHA3_256 - authentication mode with 32 byte MAC
/// @param SHA3_384 - authentication mode with 48 byte MAC
/// @param SHA3_512 - authentication mode with 64 byte MAC
/// @param SHAKE128 - authentication mode using Keccak with 16 byte MAC
/// @param SHAKE256 - authentication mode using Keccak with 32 byte MAC
/// @param HMAC_MD5 - keyed authentication mode with 16 byte MAC
/// @param HMAC_SHA1 - keyed authentication mode with 20 byte MAC
/// @param HMAC_SHA2_224 - keyed authentication mode with 28 byte MAC
/// @param HMAC_SHA2_256 - keyed authentication mode with 32 byte MAC
/// @param HMAC_SHA2_384 - keyed authentication mode with 48 byte MAC
/// @param HMAC_SHA2_512 - keyed authentication mode with 64 byte MAC
/// @param HMAC_SHA3_224 - keyed authentication mode with 28 byte MAC
/// @param HMAC_SHA3_256 - keyed authentication mode with 32 byte MAC
/// @param HMAC_SHA3_384 - keyed authentication mode with 48 byte MAC
/// @param HMAC_SHA3_512 - keyed authentication mode with 64 byte MAC
/// @param AES-XCBC-MAC - authentication mode with 12 byte MAC
/// @param POLY1305 - authentication mode with 16 byte MAC
/// @param AES-CMAC - authenticate only with 16 byte MAC
/// @param AES-GMAC - authenticate only with 16 byte MAC
/// @param SM3 - mode authentication
/// @param SNOWA - SNOW3g F9 mode authentication
/// @param SNOWVA - SNOWV GHASH F9 mode authentication
/// @param ZUCA - ZUC F9 mode authentication
/// @param CRC5 - polynomial with 5-bit output
/// @param CRC7 - polynomial with 7-bit output
/// @param CRC8 - polynomial with 8-bit output
/// @param CRC11 - polynomial with 11-bit output
/// @param CRC12 - polynomial with 12-bit output
/// @param CRC16 - polynomial with 16-bit output
/// @param CRC16_CCITT - CCITT polynomial with 16-bit output
/// @param CRC24 - polynomial with 24-bit output
/// @param CRC32_IETF - IETF polynomial with 32-bit output
/// @param CRC32_IEEE - IEEE polynomial with 32-bit output
/// @param CRC_POLY - CRC with user supplied polynomial
/// @param NONE_AUTH - None authentication
//////////////////////////////////////////////////////////////////////
enum auth_t {     ///NULL authentication - no authentication present
    NULL_AUTH,    ///MD5 authentication mode with 16 byte MAC
    MD5,          ///SHA1 authentication mode with 20 byte MAC
    SHA1,         ///SHA224 authentication mode with 28 byte MAC
    SHA224,       ///SHA256 authentication mode with 32 byte MAC
    SHA256,       ///SHA384 authentication mode with 48 byte MAC
    SHA384,       ///SHA512 authentication mode with 64 byte MAC
    SHA512,       ///SHA3_224 authentication mode with 28 byte MAC
    SHA3_224,     ///SHA3_256 authentication mode with 32 byte MAC
    SHA3_256,     ///SHA3_384 authentication mode with 48 byte MAC
    SHA3_384,     ///SHA3_512 authentication mode with 64 byte MAC
    SHA3_512,     ///SHAKE128 Keccak authentication mode with 16 byte MAC
    SHAKE128,     ///SHAKE256 Keccak authentication mode with 32 byte MAC
    SHAKE256,     ///HMAC_MD5 keyed authentication mode with 16 byte MAC
    HMAC_MD5,     ///HMAC_SHA1 keyed authentication mode with 20 byte MAC
    HMAC_SHA1,    ///HMAC_SHA2_224 keyed authentication mode with 28 byte MAC
    HMAC_SHA2_224,///HMAC_SHA2_256 keyed authentication mode with 32 byte MAC
    HMAC_SHA2_256,///HMAC_SHA2_384 keyed authentication mode with 48 byte MAC
    HMAC_SHA2_384,///HMAC_SHA2_512 keyed authentication mode with 64 byte MAC
    HMAC_SHA2_512,///HMAC_SHA3_224 keyed authentication mode with 28 byte MAC
    HMAC_SHA3_224,///HMAC_SHA3_256 keyed authentication mode with 32 byte MAC
    HMAC_SHA3_256,///HMAC_SHA3_384 keyed authentication mode with 48 byte MAC
    HMAC_SHA3_384,///HMAC_SHA3_512 keyed authentication mode with 64 byte MAC
    HMAC_SHA3_512,///AES_XCBC_MAC authentication mode with 12 byte MAC
    AES_XCBC_MAC, ///POLY1305 authentication mode with 16 byte MAC
    POLY1305,     ///AES-CMAC authenticate only with 16 byte MAC
    AES_CMAC,     ///AES-GMAC authenticate only with 16 byte MAC
    AES_GMAC,     ///SM3 mode authentication
    SM3,          ///SNOW3G F9 mode authentication
    SNOWA,        ///SNOWV F9 mode authentication
    SNOWVA,       ///ZUC F9 mode authentication
    ZUCA,         ///CRC5 polynomial with 5-bit output
    CRC5,         ///CRC7 polynomial with 7-bit output
    CRC7,         ///CRC8 polynomial with 8-bit output
    CRC8,         ///CRC11 polynomial with 11-bit output
    CRC11,        ///CRC12 polynomial with 12-bit output
    CRC12,        ///CRC16 polynomial with 16-bit output
    CRC16,        ///CRC16 CCITT polynomial with 16-bit output
    CRC16_CCITT,  ///CRC24 polynomial with 24-bit output
    CRC24,        ///CRC32 IETF polynomial with 32-bit output
    CRC32_IETF,   ///CRC32 IEEE polynomial with 32-bit output
    CRC32_IEEE,   ///CRC with user supplied polynomial
    CRC_POLY,     ///None authentication
    NONE_AUTH
};

Begin_Enum_String(auth_t)
{
    Enum_String(NULL_AUTH);
    Enum_String(MD5);
    Enum_String(SHA1);
    Enum_String(SHA224);
    Enum_String(SHA256);
    Enum_String(SHA384);
    Enum_String(SHA512);
    Enum_String(SHA3_224);
    Enum_String(SHA3_256);
    Enum_String(SHA3_384);
    Enum_String(SHA3_512);
    Enum_String(SHAKE128);
    Enum_String(SHAKE256);
    Enum_String(HMAC_MD5);
    Enum_String(HMAC_SHA1);
    Enum_String(HMAC_SHA2_224);
    Enum_String(HMAC_SHA2_256);
    Enum_String(HMAC_SHA2_384);
    Enum_String(HMAC_SHA2_512);
    Enum_String(HMAC_SHA3_224);
    Enum_String(HMAC_SHA3_256);
    Enum_String(HMAC_SHA3_384);
    Enum_String(HMAC_SHA3_512);
    Enum_String(AES_XCBC_MAC);
    Enum_String(POLY1305);
    Enum_String(AES_CMAC);
    Enum_String(AES_GMAC);
    Enum_String(SM3);
    Enum_String(SNOWA);
    Enum_String(SNOWVA);
    Enum_String(ZUCA);
    Enum_String(CRC5);
    Enum_String(CRC7);
    Enum_String(CRC8);
    Enum_String(CRC11);
    Enum_String(CRC12);
    Enum_String(CRC16);
    Enum_String(CRC16_CCITT);
    Enum_String(CRC24);
    Enum_String(CRC32_IETF);
    Enum_String(CRC32_IEEE);
    Enum_String(CRC_POLY);
    Enum_String(NONE_AUTH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IANA values for Internet communication
/// Value and their definitions can be found at www.iana.org
//////////////////////////////////////////////////////////////////////
enum iana_t { /// IPv6 Hop-by-Hop Option - 0
    HOPOPT,   /// Internet Control Message Protocol (ICMP) version 4 - 1
    ICMP,     /// Internet Group Management Protocol (IGMP) - 2
    IGMP,     /// Gateway-to-Gateway Protocol (GGP) - 3
    GGP,      /// IP version 4 - 4
    IPV4,     /// Internet Stream Protocol (ST) - 5
    ST,       /// Transmission Control Protocol (TCP) - 6
    TCP,      /// Core-base trees (CBT) - 7
    CBT,      /// Exterior Gateway Protocol (EGP) - 8
    EGP,      /// Interior Gateway Protocol (IGP) - 9
    IGP,         /// BBN RCC Monitoring (BBN_RCC_MON) - 10
    BBN_RCC_MON, /// Network Voice Protocol (NVP_II) - 11
    NVP_II,      /// Xerox PUP (PUP) - 12
    PUP,         /// ARGUS - 13
    ARGUS,       /// EMCON - 14
    EMCON,       /// Cross Net Debugger (XNET) - 15
    XNET,        /// Chaos - 16
    CHAOS,       /// User Datagram Protocol (UDP) - 17
    UDP,         /// Multiplexing (MUX) - 18
    MUX,         /// DCN Measurement Subsystems (DCN-MEAS) - 19
    DCN_MEAS,    /// Host Monitoring Protocol (HMP) - 20
    HMP,         /// Packet Radio Measurement (PRM) - 21
    PRM,         /// XEROX NS IDP (XNS-IDP) - 22
    XNS_IDP,     /// Trunk-1 - 23
    TRUNK_1,     /// Trunk-2 - 24
    TRUNK_2,     /// Leaf-1 - 25
    LEAF_1,      /// Leaf-2 - 26
    LEAF_2,      /// Reliable Data Protocol (RDP) - 27
    RDP,         /// Internet Reliable Transaction Protocol (IRTP) - 28
    IRTP,        /// ISO Transport Protocol Class 4 (ISO-TP4) - 29
    ISO_TP4,     /// Bulk Data Transfer Protocol (NETBLT) - 30
    NETBLT,      /// MFE Network Services Protocol (MFE-NSP) - 31
    MFE_NSP,     /// MERIT Internodal Protocol (MERIT-INP) - 32
    MERIT_INP,   /// Datagram Congestion Control Protocol (DCCP) - 33
    DCCP,        /// Third Party Connect Protocol (3PC) - 34
    THREE_PC,    /// Inter-Domain Policy Routing Protocol (IDPR) - 35
    IDPR,        /// Xpress Transport Protocol (XTP) - 36
    XTP,         /// Datagram Delivery Protocol (DDP) - 37
    DDP,         /// IDPR Control Message Transport Protocol (IDPR-CMTP) - 38
    IDPR_CMTP,   /// TP++ Transport Protocol (TP++) - 39
    TP_PLUS,     /// IL Transport Protocol (IL) - 40
    IL,          /// IP version 6 - 41
    IPV6,        /// Source Demand Routing Protocol (SDRP) - 42
    SDRP,        /// IPv6 Routing header - 43
    IPV6_ROUTE,  /// IPv6 Fragmentation header - 44
    IPV6_FRAG,   /// Inter-Domain Routing Protocol (IDRP) - 45
    IDRP,        /// Resource Reservation Protocol (RSVP) - 46
    RSVP,        /// Generic Routing Encapsulation (GRE) - 47
    GRE,         /// Dynamic Source Routing Protocol (DSR) - 48
    DSR,         /// Burroughs Network Architecture (BNA) - 49
    BNA,         /// Encapsulating Security Payload - 50
    ESP,         /// Authentication header - 51
    AH,          /// Integrated Net Layer Security Protocol (I-NLSP) - 52
    I_NLSP,      /// SwIPe (IP with Encryption) - 53
    SWIPE,       /// NBMA Address Resolution Protocol (NARP) - 54
    NARP,        /// IP Mobility (Min Encap) - 55
    MOBILE,      /// Transport Layer Security Protocol (using Kryptonet key management) - 56
    TLSP,        /// Simple Key-Management for Internet Protocol (SKIP) - 57
    SKIP,        /// ICMP version 6 - 58
    ICMPV6,      /// IPv6 No Next header - 59
    IPV6_NONXT,  /// IPv6 Options header - 60
    IPV6_OPTS,   /// Any host Internet Protocol - 61
    HOST_INT_PROT, /// CFTP - 62
    CFTP,          /// Any local network - 63
    LOCAL_NET,     /// SATNET and Backroom EXPAK (SAT-EXPAK) - 64
    SAT_EXPAK,     /// Kryptolan - 65
    KRYPTOLAN,     /// MIT Remote Virtual Disk Protocol (RVD) - 66
    RVD,           /// Internet Pluribus Packet Core (IPPC) - 67
    IPPC,          /// Any distributed file system - 68
    DFS,           /// SATNET Monitoring (SAT-MON) - 69
    SAT_MON,       /// VISA Protocol - 70
    VISA,          /// Internet Packet Core Utility (IPCV) - 71
    IPCV,          /// Computer Protocol Network Executive (CPNX) - 72
    CPNX,          /// Computer Protocol Heart Beat (CPHB) - 73
    CPHB,          /// Wang Span Network (WSN) - 74
    WSN,           /// Packet Video Protocol (PVP) - 75
    PVP,           /// Backroom SATNET Monitoring (BR-SAT-MON) - 76
    BR_SAT_MON,    /// SUN ND Protocol-Temporary (SUN-ND) - 77
    SUN_ND,        /// WIDEBAND Monitoring (WB-MON) - 78
    WB_MON,        /// WIDEBAND EXPAK (WB-EXPAK) - 79
    WB_EXPAK,      /// International Organization for Standardization Internet Protocol (ISO-IP) - 80
    ISO_IP,        /// Versatile Message Transaction Protocol (VMTP) - 81
    VMTP,          /// Secure Versatile Message Transaction Protocol (SECURE-VMTP) - 82
    SECURE_VMTP,   /// VINES - 83
    VINES,         /// TTP - 84
    TTP,           /// Internet Protocol Traffic Manager (IPTM) - 85
    IPTM,          /// NSFNET-IGP - 86
    NSFNET_IGP,    /// Dissimilar Gateway Protocol (DGP) - 87
    DGP,           /// TCF - 88
    TCF,           /// EIGRP - 89
    EIGRP,         /// Open Shortest Path First (OSPFIGP) - 90
    OSPFIGP,       /// Sprite RPC Protocol (Sprite-RPC) - 91
    SPRITE_RPC,    /// Locus Address Resolution Protocol (LARP) - 92
    LARP,          /// Multicast Transport Protocol (MTP) - 93
    MTP,           /// AX.25 - 94
    AX_25,         /// Mobile Internetworking Control Protocol (MICP) - 95
    MICP,          /// Semaphore Communications Security Protocol (SCC-SP) - 96
    SCC_SP,        /// Ethernet-within-IP Encapsulation (ETHERIP) - 97
    ETHERIP,       /// Encapsulation Header (ENCAP) - 98
    IENCAP,        /// Any private encryption scheme - 99
    PRIV_ENCRYPT,  /// GMTP - 100
    GMTP,          /// Ipsilon Flow Management Protocol (IFMP) - 101
    IFMP,          /// PNNI over IP (PNNI) - 102
    PNNI,          /// Protocol Independent Multicast (PIM) - 103
    PIM,           /// IBM's ARIS (Aggregate Route IP Switching) Protocol (SCPS) - 104
    ARIS,          /// SCPS (Space Communications Protocol Standards) - 105
    SCPS,          /// QNX - 106
    QNX,           /// Active Networks (A/N) - 107
    A_N,           /// IP Payload Compression Protocol (IPComp) - 108
    IPCOMP,        /// Sitara Networks Protocol (SNP) - 109
    SNP,           /// Compaq Peer Protocol (Compaq-Peer) - 110
    COMPAQ_PEER,   /// IPX in IP (IPX-in-IP) - 111
    IPX_IN_IP,     /// Virtual Router Redundancy Protocol, Common Address Redundancy Protocol (not IANA aasigned) - 112
    VRRP,          /// PGM Reliable Transport Protocol (PGM) - 113
    PGM,           /// Any 0-hop protocol - 114
    ZERO_HOP_PROT, /// Layer Two Tunneling Protocol Version 3 (L2TP) - 115
    L2TP,          /// D-II Data Exchange (DDX) - 116
    DDX,           /// Interactive Agent Transfer Protocol (IATP) - 117
    IATP,          /// Schedule Transfer Protocol (STP) - 118
    STP,           /// SpectraLink Radio Protocol (SRP) - 119
    SRP,           /// Universal Transport Interface Protocol (UTI) - 120
    UTI,           /// Simple Message Protocol (SMP) - 121
    SMP,           /// Simple Multicast Protocol (SM) - 122
    SM,            /// Performance Transparency Protocol (PTP) - 123
    PTP,           /// Intermediate System to Intermediate System (IS-IS) Protocol over IPv4 - 124
    ISIS_OVER_IPV4, /// Flexible Intra-AS Routing Environment (FIRE) - 125
    FIRE,          /// Combat Radio Transport Protocol (CRTP) - 126
    CRTP,          /// Combat Radio User Datagram (CRUDP) - 127
    CRUDP,         /// Servie-Specific Connection-Oriented Protocol in a Multilink and Connectionless Environment (SSCOPMCE) - 128
    SSCOPMCE,      /// IPLT - 129
    IPLT,          /// Secure Packet Shield (SPS) - 130
    SPS,           /// Private IP Encapsulation within IP (PIPE) - 131
    PIPE,          /// Stream Control Transmission Protocol (SCTP) - 132
    SCTP,          /// Fibre Channel (FC) - 133
    FC,            /// Reservation Protocol (RSVP) End-to-End Ignore - 134
    RSVP_E2E_IGNORE, /// Mobility Extension Header for IPv6 - 135
    MOBILITY_HEADER, /// UDP-Lite Protocol - 136
    UDPLITE,       /// Multiple Label Switching Encapsulated in IP (MPLS-in-IP) - 137
    MPLS_IN_IP,    /// MANET Protocols (MANET) - 138
    MANET,         /// Host Identity Protocol (HIP) - 139
    HIP,           /// Site Multihoming by IPv6 Intermediation (Shim6) - 140
    SHIM6,         /// Wrapped Encapsulating Security Protocol (WESP) - 141
    WESP,          /// Robust Header Compression (ROHC) - 142
    ROHC,          /// JUMBOGRAM extension header - 194
    JUMBOGRAM=194
};

Begin_Enum_String(iana_t)
{
    Enum_String(HOPOPT);
    Enum_String(ICMP);
    Enum_String(IGMP);
    Enum_String(GGP);
    Enum_String(IPV4);
    Enum_String(ST);
    Enum_String(TCP);
    Enum_String(CBT);
    Enum_String(EGP);
    Enum_String(IGP);
    Enum_String(BBN_RCC_MON);
    Enum_String(NVP_II);
    Enum_String(PUP);
    Enum_String(ARGUS);
    Enum_String(EMCON);
    Enum_String(XNET);
    Enum_String(CHAOS);
    Enum_String(UDP);
    Enum_String(MUX);
    Enum_String(DCN_MEAS);
    Enum_String(HMP);
    Enum_String(PRM);
    Enum_String(XNS_IDP);
    Enum_String(TRUNK_1);
    Enum_String(TRUNK_2);
    Enum_String(LEAF_1);
    Enum_String(LEAF_2);
    Enum_String(RDP);
    Enum_String(IRTP);
    Enum_String(ISO_TP4);
    Enum_String(NETBLT);
    Enum_String(MFE_NSP);
    Enum_String(MERIT_INP);
    Enum_String(DCCP);
    Enum_String(THREE_PC);
    Enum_String(IDPR);
    Enum_String(XTP);
    Enum_String(DDP);
    Enum_String(IDPR_CMTP);
    Enum_String(TP_PLUS);
    Enum_String(IL);
    Enum_String(IPV6);
    Enum_String(SDRP);
    Enum_String(IPV6_ROUTE);
    Enum_String(IPV6_FRAG);
    Enum_String(IDRP);
    Enum_String(RSVP);
    Enum_String(GRE);
    Enum_String(DSR);
    Enum_String(BNA);
    Enum_String(ESP);
    Enum_String(AH);
    Enum_String(I_NLSP);
    Enum_String(SWIPE);
    Enum_String(NARP);
    Enum_String(MOBILE);
    Enum_String(TLSP);
    Enum_String(SKIP);
    Enum_String(ICMPV6);
    Enum_String(IPV6_NONXT);
    Enum_String(IPV6_OPTS);
    Enum_String(HOST_INT_PROT);
    Enum_String(CFTP);
    Enum_String(LOCAL_NET);
    Enum_String(SAT_EXPAK);
    Enum_String(KRYPTOLAN);
    Enum_String(RVD);
    Enum_String(IPPC);
    Enum_String(DFS);
    Enum_String(SAT_MON);
    Enum_String(VISA);
    Enum_String(IPCV);
    Enum_String(CPNX);
    Enum_String(CPHB);
    Enum_String(WSN);
    Enum_String(PVP);
    Enum_String(BR_SAT_MON);
    Enum_String(SUN_ND);
    Enum_String(WB_MON);
    Enum_String(WB_EXPAK);
    Enum_String(ISO_IP);
    Enum_String(VMTP);
    Enum_String(SECURE_VMTP);
    Enum_String(VINES);
    Enum_String(TTP);
    Enum_String(IPTM);
    Enum_String(NSFNET_IGP);
    Enum_String(DGP);
    Enum_String(TCF);
    Enum_String(EIGRP);
    Enum_String(OSPFIGP);
    Enum_String(SPRITE_RPC);
    Enum_String(LARP);
    Enum_String(MTP);
    Enum_String(AX_25);
    Enum_String(MICP);
    Enum_String(SCC_SP);
    Enum_String(ETHERIP);
    Enum_String(IENCAP);
    Enum_String(PRIV_ENCRYPT);
    Enum_String(GMTP);
    Enum_String(IFMP);
    Enum_String(PNNI);
    Enum_String(PIM);
    Enum_String(ARIS);
    Enum_String(SCPS);
    Enum_String(QNX);
    Enum_String(A_N);
    Enum_String(IPCOMP);
    Enum_String(SNP);
    Enum_String(COMPAQ_PEER);
    Enum_String(IPX_IN_IP);
    Enum_String(VRRP);
    Enum_String(PGM);
    Enum_String(ZERO_HOP_PROT);
    Enum_String(L2TP);
    Enum_String(DDX);
    Enum_String(IATP);
    Enum_String(STP);
    Enum_String(SRP);
    Enum_String(UTI);
    Enum_String(SMP);
    Enum_String(SM);
    Enum_String(PTP);
    Enum_String(ISIS_OVER_IPV4);
    Enum_String(FIRE);
    Enum_String(CRTP);
    Enum_String(CRUDP);
    Enum_String(SSCOPMCE);
    Enum_String(IPLT);
    Enum_String(SPS);
    Enum_String(PIPE);
    Enum_String(SCTP);
    Enum_String(FC);
    Enum_String(RSVP_E2E_IGNORE);
    Enum_String(MOBILITY_HEADER);
    Enum_String(UDPLITE);
    Enum_String(MPLS_IN_IP);
    Enum_String(MANET);
    Enum_String(HIP);
    Enum_String(SHIM6);
    Enum_String(WESP);
    Enum_String(ROHC);
    Enum_String(JUMBOGRAM);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Status values for packet processing with format
///
/// <table>
/// <caption id="Format for Protocol++&reg; Status Word">Format for Protocol++&reg; Status Word</caption>
/// <tr><td>Protocol (8-bits)<td>Error (8-bits)<td colspan="2">Line Number (16-bits)
/// </table>
/// <BR>
/// @param ERR_NONE - No error
/// @param ERR_LATE - Anti-replay late packet error found
/// @param ERR_REPLAY - Anti-replay error found
/// @param ERR_ROLLOVER - Packet number rollover error
/// @param ERR_ROLLUNDER - Packet number rollunder error
/// @param ERR_PROGRAM - Programming error
/// @param ERR_ICV - ICV check failure
/// @param ERR_CRC - CRC check failure
/// @param ERR_READ_ENDOFILE - Read end of file
/// @param ERR_READ_FAILFILE - Read failed to input file handle
/// @param ERR_READ_BADFILE - Read of missing file handle
/// @param ERR_WRITE_FAILFILE - Write failed to file output
/// @param ERR_WRITE_BADFILE - Write error to file output
/// @param ERR_CHECKSUM - Checksum error
/// @param ERR_LISTEN - TCP server received packet while listening without SYN=1
/// @param ERR_ACKNUM - TCP received ACKNUM is incorrect
/// @param ERR_CLOSED - TCP session CLOSED during TX/RX
/// @param ERR_BITS - TCP header reserved bits error
/// @param ERR_TTL - TTL field of packet is zero
/// @param ERR_JUMBOGRAM_FORMAT - IPv6 JUMBOGRAM formatting error
/// @param WARN_DUMMY - Dummy packet warning
/// @param WARN_IPV6_ROUTE - IPv6 Route header but not for this destination
/// @param WARN_ZERO_DATA - Payload had zero length data
/// @param ERR_ICMP_HDR_EXT_LEN - Header extension length is ODD for ROUTE header
/// @param ERR_ICMP_SEGMENTS_LEFT - In ROUTE header, Segments left is larger than N
/// @param ERR_MULTICAST_EXT_HDR - In ROUTE header, Multicast address present
/// @param ERR_UNKNOWN_ROUTE_TYPE - In ROUTE header, Unknown route type (only type 0 is supported)
/// @param ERR_CIPHER_KEY_SIZE - For the cipher requested, the key size is incorrect
/// @param ERR_AUTH_KEY_SIZE - For the authentication requested, the key size is incorrect
/// @param ERR_IV_SIZE - For the initialization vector requested, the size is incorrect
/// @param ERR_SALT_SIZE - For the cipher salt requested, the size is incorrect
/// @param ERR_ICV_SIZE - For the authentication requested, the ICV size is incorrect
/// @param ERR_UNKNOWN_NXTHDR - For the IP packet, unknown NH value
/// @param ERR_FORMAT_ERROR - Malformed packet
/// @param WARN_INPUT_QUEUE_FULL - Send queue is full
/// @param WARN_OUTPUT_QUEUE_EMPTY - Receive queue is empty
/// @param ERR_SA_NOT_FOUND - Security Association not found
/// @param ERR_NO_KEY - The key specified is invalid or not found
/// @param ERR_KEY_EXPIRED - The key specified has expired
/// @param ERR_KEY_REVOKED - The key specified has been revoked
/// @param ERR_KEY_ACCESS - The key exists but is not readable by the calling process or cant be modified by the user
/// @param ERR_KEY_NOT_SUPP - The key type does not support reading of the payload data
/// @param ERR_KEY_QUOTA - The key quota for this user would be exceeded by creating this key
/// @param ERR_KEY_INVALID - The payload data was invalid
/// @param ERR_KEY_REJECTED - The attempt to generate a new key was rejected
/// @param ERR_KEY_NOMEM - Insufficient memory to create a key
/// @param ERR_KEY_INTR - The request was interrupted by a signal
/// @param ERR_RSA_INVALID_CODING - Coding of the RSA decrypted data was incorrect
/// @param ERR_RSA_MESSAGE_LENGTH - Decrypted RSA message length is incorrect
/// @param ERR_INVALID_SIGNATURE - Signature verification failed
/// @param WARN_NO_VLAN - VLAN tag did not match the Security Association
/// @param ERR_UNKNOWN - Unknown error
//////////////////////////////////////////////////////////////////////
enum err_t {            ///No error
    ERR_NONE,           ///Anti-replay late packet error found
    ERR_LATE,           ///Anti-replay error found
    ERR_REPLAY,         ///Packet number rollover error
    ERR_ROLLOVER,       ///Packet number rollunder error
    ERR_ROLLUNDER,      ///Programming error
    ERR_PROGRAM,        ///ICV check failure
    ERR_ICV,            ///CRC check failure
    ERR_CRC,            ///Read end of file
    ERR_READ_ENDOFILE,  ///Read failed to input file handle
    ERR_READ_FAILFILE,  ///Read of missing file handle
    ERR_READ_BADFILE,   ///Write failed to file output
    ERR_WRITE_FAILFILE, ///Write error to file output
    ERR_WRITE_BADFILE,  ///Checksum error
    ERR_CHECKSUM,       ///TCP server received packet while listening without SYN=1
    ERR_LISTEN,         ///TCP received ACKNUM is incorrect
    ERR_ACKNUM,         ///TCP session CLOSED during TX/RX
    ERR_CLOSED,         ///TCP header reserved bits error
    ERR_BITS,           ///TTL field of packet is zero
    ERR_TTL,            ///IPv6 JUMBOGRAM formatting error
    ERR_JUMBOGRAM_FORMAT,///Dummy packet warning
    WARN_DUMMY,         ///IPv6 Route header but not for this destination
    WARN_IPV6_ROUTE,    ///Payload had zero length data
    WARN_ZERO_DATA,     ///Header extension length is ODD for ROUTE header
    ERR_ICMP_HDR_EXT_LEN,///In ROUTE header, Segments left is larger than N     
    ERR_ICMP_SEGMENTS_LEFT,///In ROUTE header, Multicast address present
    ERR_MULTICAST_EXT_HDR, ///In ROUTE header, Unknown route type (only type 0 is supported)
    ERR_UNKNOWN_ROUTE_TYPE, ///Key size incorrect for cipher 
    ERR_CIPHER_KEY_SIZE,///Key size incorrect for authentication
    ERR_AUTH_KEY_SIZE,  ///Initialization vector size is incorrect
    ERR_IV_SIZE,        ///Salt size for cipher is incorrect
    ERR_SALT_SIZE,      ///ICV size is incorrect for authentication scheme
    ERR_ICV_SIZE,       ///For the IP packet, unknown NH value
    ERR_UNKNOWN_NXTHDR, ///Malformed packet
    ERR_FORMAT_ERROR,   ///Send queue is full
    WARN_INPUT_QUEUE_FULL, ///Receive queue is empty
    WARN_OUTPUT_QUEUE_EMPTY, ///Security Association not found
    ERR_SA_NOT_FOUND,   ///The key specified is invalid or not found
    ERR_KEY_NOKEY,      ///The key specified has expired
    ERR_KEY_EXPIRED,    ///The key specified has been revoked
    ERR_KEY_REVOKED,    ///The key exists but is not readable by the calling process or cant be modified by the user
    ERR_KEY_ACCESS,     ///The key type does not support reading of the payload data
    ERR_KEY_NOT_SUPP,   ///The key quota for this user would be exceeded by creating this key
    ERR_KEY_QUOTA,      ///The payload data was invalid
    ERR_KEY_INVALID,    ///THe attempt to generate a new key was rejected
    ERR_KEY_REJECTED,   ///Insufficient memory to create a key
    ERR_KEY_NOMEM,      ///The request was interrupted by a signal
    ERR_KEY_INTR,       ///Coding of RSA decrypted data was incorrect
    ERR_RSA_INVALID_CODING, ///Decrypted RSA message length was incorrect
    ERR_RSA_MESSAGE_LENGTH, ///Signature verification failed
    ERR_INVALID_SIGNATURE, ///VLAN tags did not match
    WARN_NO_VLAN,       ///Unknown error
    ERR_UNKNOWN
};

Begin_Enum_String(err_t)
{
    Enum_String(ERR_NONE);
    Enum_String(ERR_LATE);
    Enum_String(ERR_REPLAY);
    Enum_String(ERR_ROLLOVER);
    Enum_String(ERR_ROLLUNDER);
    Enum_String(ERR_PROGRAM);
    Enum_String(ERR_ICV);
    Enum_String(ERR_CRC);
    Enum_String(ERR_READ_ENDOFILE);
    Enum_String(ERR_READ_FAILFILE);
    Enum_String(ERR_READ_BADFILE);
    Enum_String(ERR_WRITE_FAILFILE);
    Enum_String(ERR_WRITE_BADFILE);
    Enum_String(ERR_CHECKSUM);
    Enum_String(ERR_LISTEN);
    Enum_String(ERR_ACKNUM);
    Enum_String(ERR_CLOSED);
    Enum_String(ERR_BITS);
    Enum_String(ERR_TTL);
    Enum_String(ERR_JUMBOGRAM_FORMAT);
    Enum_String(WARN_DUMMY);
    Enum_String(WARN_IPV6_ROUTE);
    Enum_String(WARN_ZERO_DATA);
    Enum_String(ERR_ICMP_HDR_EXT_LEN);
    Enum_String(ERR_ICMP_SEGMENTS_LEFT);
    Enum_String(ERR_MULTICAST_EXT_HDR);
    Enum_String(ERR_UNKNOWN_ROUTE_TYPE);
    Enum_String(ERR_CIPHER_KEY_SIZE);
    Enum_String(ERR_AUTH_KEY_SIZE);
    Enum_String(ERR_IV_SIZE);
    Enum_String(ERR_SALT_SIZE);
    Enum_String(ERR_ICV_SIZE);
    Enum_String(ERR_UNKNOWN_NXTHDR);
    Enum_String(ERR_FORMAT_ERROR);
    Enum_String(WARN_INPUT_QUEUE_FULL);
    Enum_String(WARN_OUTPUT_QUEUE_EMPTY);
    Enum_String(ERR_SA_NOT_FOUND);
    Enum_String(ERR_KEY_NOKEY);
    Enum_String(ERR_KEY_EXPIRED);
    Enum_String(ERR_KEY_REVOKED);
    Enum_String(ERR_KEY_ACCESS);
    Enum_String(ERR_KEY_NOT_SUPP);
    Enum_String(ERR_KEY_QUOTA);
    Enum_String(ERR_KEY_INVALID);
    Enum_String(ERR_KEY_REJECTED);
    Enum_String(ERR_KEY_NOMEM);
    Enum_String(ERR_KEY_INTR);
    Enum_String(ERR_RSA_INVALID_CODING);
    Enum_String(ERR_RSA_MESSAGE_LENGTH);
    Enum_String(ERR_INVALID_SIGNATURE);
    Enum_String(WARN_NO_VLAN);
    Enum_String(ERR_UNKNOWN);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Anti-Replay sequence number types
///
/// @param NORMAL - Sequence number incremented (seqnum = seqnum + 1)
/// @param SHIFT - Sequence number in the future (seqnum = seqnum + random("2..50"))
/// @param WINDOW - Sequence number found in the window
/// @param REPLAY - Sequence number is replay
/// @param LATE   - Sequence number is outside the window (LATE)
/// @param OVERFLOW - Sequence number overflow
/// @param UNDERFLOW - Sequence number underflow
//////////////////////////////////////////////////////////////////////
enum replay_t { /// Sequence number incremented (seqnum = seqnum + 1)
    NORMAL,     /// Sequence number in the future, shifts window left (seqnum = seqnum + random("2..31"))
    SHIFT,      /// Sequence number found in the window
    WINDOW,     /// Sequence number is replay
    REPLAY,     /// Sequence number is outside the window (LATE)
    LATE,       /// Sequence number overflow
    ROLLOVER,   /// Sequence number underflow
    ROLLUNDER
};
    
Begin_Enum_String(replay_t)
{
    Enum_String(NORMAL);
    Enum_String(SHIFT);
    Enum_String(WINDOW);
    Enum_String(REPLAY);
    Enum_String(LATE);
    Enum_String(ROLLOVER);
    Enum_String(ROLLUNDER);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IPsec mode of operation
///
/// @param TRANSPORT - Transport mode
/// @param TUNNEL - Tunnel mode
//////////////////////////////////////////////////////////////////////
enum ipmode_t { /// IP transport mode
    TRANSPORT,  /// IP tunnel mode
    TUNNEL
};
    
Begin_Enum_String(ipmode_t)
{
    Enum_String(TRANSPORT);
    Enum_String(TUNNEL);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// ICMP Message Types
/// @param  ECHORPLYMSG - Echo Reply
/// @param  RSVD1 - Reserved1
/// @param  RSVD2 - Reserved2
/// @param  DESTUNRCH - Destination Unreachable
/// @param  SRCQNCH - Source Quench
/// @param  RDIRMSG - Redirect Message
/// @param  ALTHOST - Alternate Host Address
/// @param  RSVD - Reserved7
/// @param  ECHORQST - Echo Request
/// @param  RTRADVERT - Router Advertisement
/// @param  RTRSOLCIT - Router Solicitation
/// @param  TIMEXCEED - Time Exceeded
/// @param  BADIPHDR - Parameter Problem : Bad IP header
/// @param  TIMESTMP - Timestamp
/// @param  TIMERPLY - Timestamp Reply
/// @param  INFORQST - Information Request
/// @param  INFORPLY - Information Reply
/// @param  ADMSKRQST - Address Mask Request
/// @param  ADMSKRPLY - Address Mask Reply
/// @param  TRACERTE - Traceroute (ICMPv6)
/// @param  NODEST - Destination Unreachable (ICMPv6)
/// @param  PKTBIG - Packet Too Big (ICMPv6)
/// @param  TIMEOUT - Time Exceeded (ICMPv6)
/// @param  PARAM - Parameter Problem (ICMPv6)
/// @param  PRVTE1 - Private Experimentation (ICMPv6)
/// @param  PRVTE2 - Private Experimentation (ICMPv6)
/// @param  RSVDE - Reserved for expansion of ICMPv6 error messages (ICMPv6)
/// @param  ECHORQSTV6 - Echo Request (ICMPv6)
/// @param  ECHORPLYV6 - Echo Reply (ICMPv6)
/// @param  PRVTI1 - Private Experimentation (ICMPv6)
/// @param  PRVTI2 - Private Experimentation (ICMPv6)
/// @param  RSVDI - Reserved for expansion of ICMPv6 info messages (ICMPv6)
//////////////////////////////////////////////////////////////////////
enum icmpmsg_t { /// ECHO REPLY - 0
    ECHORPLYMSG, /// RESERVED - 1
    RSVD1,       /// RESERVED - 2
    RSVD2,       /// DESTINATION UNREACHABLE - 3
    DESTUNRCH,   /// SOURCE QUENCH - 4
    SRCQNCH,     /// REDIRECT MESSAGE - 5
    RDIRMSG,     /// ALTERNATE HOST ADDRESS - 6
    ALTHOST,     /// RESERVED - 7
    RSVD,        /// ECHO REQUEST - 8
    ECHORQST,    /// ROUTER ADVERTISEMENT - 9
    RTRADVERT,   /// ROUTER SOLICITATION - 10
    RTRSOLCIT,   /// TIME EXCEEDED - 11
    TIMEXCEED,   /// PARAMETER PROBLEM : BAD IP HEADER - 12
    BADIPHDR,    /// TIMESTAMP - 13
    TIMESTMP,    /// TIMESTAMP REPLY - 14
    TIMERPLY,    /// INFORMATION REQUEST - 15
    INFORQST,    /// INFORMATION REPLY - 16
    INFORPLY,    /// ADDRESS MASK REQUEST - 17
    ADMSKRQST,   /// ADDRESS MASK REPLY - 18
    ADMSKRPLY,   /// TRACEROUTE - 30
    TRACERTE,    /// DESTINATION UNREACHABLE (ICMPv6) - 1
    NODEST,      /// PACKET TOO BIG (ICMPv6) - 2
    PKTBIG,      /// TIME EXCEEDED (ICMPv6) - 3
    TIMEOUT,     /// PARAMETER PROBLEM (ICMPv6) - 4
    PARAM,       /// PRIVATE EXPERIMENTATION (ICMPv6) - 100
    PRVTE1,      /// PRIVATE EXPERIMENTATION (ICMPv6) - 101
    PRVTE2,      /// RESERVED (ICMPv6) - 127
    RSVDE,       /// ECHO REQUEST (ICMPv6) - 128
    ECHORQSTV6,  /// ECHO REPLY (ICMPv6) - 129
    ECHORPLYV6,  /// PRIVATE EXPERIMENTATION (ICMPv6) - 200
    PRVTI1,      /// PRIVATE EXPERIMENTATION (ICMPv6) - 201
    PRVTI2,      /// RESERVED (ICMPv6) - 255
    RSVDI
};

Begin_Enum_String(icmpmsg_t)
{
    Enum_String(ECHORPLYMSG);
    Enum_String(RSVD1);
    Enum_String(RSVD2);
    Enum_String(DESTUNRCH);
    Enum_String(SRCQNCH);
    Enum_String(RDIRMSG);
    Enum_String(ALTHOST);
    Enum_String(RSVD);
    Enum_String(ECHORQST);
    Enum_String(RTRADVERT);
    Enum_String(RTRSOLCIT);
    Enum_String(TIMEXCEED);
    Enum_String(BADIPHDR);
    Enum_String(TIMESTMP);
    Enum_String(TIMERPLY);
    Enum_String(INFORQST);
    Enum_String(INFORPLY);
    Enum_String(ADMSKRQST);
    Enum_String(ADMSKRPLY);
    Enum_String(TRACERTE);
    Enum_String(NODEST);
    Enum_String(PKTBIG);
    Enum_String(TIMEOUT);
    Enum_String(PARAM);
    Enum_String(PRVTE1);
    Enum_String(PRVTE2);
    Enum_String(RSVDE);
    Enum_String(ECHORQSTV6);
    Enum_String(ECHORPLYV6);
    Enum_String(PRVTI1);
    Enum_String(PRVTI2);
    Enum_String(RSVDI);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// ICMP Codes
/// @param  ECHORPLY - Echo Reply
/// @param  NONETWRK - Destination network unreachable
/// @param  NOHOST - Destination host unreachable
/// @param  NOPROT - Destination protocol unreachable
/// @param  NOPORT - Destination port unreachable
/// @param  FRAGRQD - Fragmentation required and DF flag set
/// @param  RTEFAIL - Source route failed
/// @param  DSTUNKNWN - Destination network unknown
/// @param  DSTHSTUNKNWN - Destination host unknown
/// @param  SRCHSTISOLT - Source host isolated
/// @param  NETWRKPROHIB - Network administratively prohibited
/// @param  HOSTPROHIB - Host administratively prohibited
/// @param  NETWKNOTOS - Network unreachable for ToS
/// @param  COMMPROHIB - Communication administratively prohibited
/// @param  HOSTVILATE - Host Precedence Violation
/// @param  CUTOFF - Precedence cutoff in effect
/// @param  REDIRNETWK - Redirect Datagram for the Network
/// @param  REDIRHOST - Redirect Datagram for the Host
/// @param  REDIRTOSN - Redirect Datagram for the ToS and network
/// @param  REDIRTOSH - Redirect Datagram for the ToS and host
/// @param  TTLEXPIRE - TTL expired in transit
/// @param  FRAGEXPIRE - Fragment reassembly time exceeded
/// @param  PTRINDERR - Pointer indicates the error
/// @param  OPTERR - Missing a required option
/// @param  BADLENGTH - Bad length
/// @param  NOROUTE - No destination (ICMPv6)
/// @param  COMMPROHIBV6 - Communication with destination administratively prohibitied (ICMPv6)
/// @param  BYNDSRCADDR - Beyond scope of source address (ICMPv6)
/// @param  ADDRUNREACH - Address unreachable (ICMPv6)
/// @param  PORTUNREACH - Port unreachable (ICMPv6)
/// @param  SRCADDRPLCY - Source address failed ingree/egress policy (ICMPv6)
/// @param  REJECTDST - Reject route to destination (ICMPv6)
/// @param  HOPLMTEXCD - Hop limit exceeded in transit (ICMPv6)
/// @param  FRAGTIME - Fragment reassembly time exceeded (ICMPv6)
/// @param  ERRHDRFIELD - Erroneous header field encountered (ICMPv6)
/// @param  NXTHDRERR - Unrecognized Next Header type encountered (ICMPv6)
/// @param  IPV6OPTERR - Unrecognized IPv6 option encountered (ICMPv6)
/// @param  SEQNUMRST - Sequence number reset (ICMPv6) (ICMPv6)
//////////////////////////////////////////////////////////////////////
enum icmpcode_t {/// ECHO REPLY - 0
    ECHORPLY,    /// DESTINATION NETWORK UNREACHABLE - 0
    NONETWRK,    /// DESTINATION HOST UNREACHABLE - 1
    NOHOST,      /// DESTINATION PROTOCOL UNREACHABLE - 2
    NOPROT,      /// DESTINATION PORT UNREACHABLE - 3
    NOPORT,      /// FRAGMENTATION REQUIRED AND DF FLAG SET - 4
    FRAGRQD,     /// SOURCE ROUTE FAILED - 5
    RTEFAIL,     /// DESTINATION NETWORK UNKNOWN - 6
    DSTUNKNWN,   /// DESTINATION HOST UNKNOWN - 7
    DSTHSTUNKNWN,/// SOURCE HOST ISOLATED - 8
    SRCHSTISOLT, /// NETWORK ADMINISTRATIVELY PROHIBITED - 9
    NETWKPROHIB, /// HOST ADMINISTRATIVELY PROHIBITED - 10
    HOSTPROHIB,  /// NETWORK UNREACHABLE FOR ToS - 11
    NETWKNOTOS,  /// HOST UNREACHABLE FOR ToS - 12
    HOSTNOTOS,   /// COMMUNICATION ADMINISTRATIVELY PROHIBITED - 13
    COMMPROHIB,  /// HOST PRECEDENCE VIOLATION - 14
    HOSTVILATE,  /// PRECEDENCE CUTOFF IN EFFECT - 15
    CUTOFF,      /// REDIRECT DATAGRAM FOR THE NETWORK - 0
    REDIRNETWK,  /// REDIRECT DATAGRAM FOR THE HOST - 1
    REDIRHOST,   /// REDIRECT DATAGRAM FOR THE ToS AND NETWORK - 2
    REDIRTOSN,   /// REDIRECT DATAGRAM FOR THE ToS AND HOST - 3
    REDIRTOSH,   /// TTL EXPIRED IN TX - 0
    TTLEXPIRE,   /// FRAGMENT REASSEMBLY TIME EXPIRED - 1
    FRAGEXPIRE,  /// POINTER INDICATES THE ERROR - 0
    PTRINDERR,   /// MISSING A REQUIRED OPTION - 1
    OPTERR,      /// BAD LENGTH - 2
    BADLENGTH,   /// NO DESTINATION (ICMPv6) - 0
    NOROUTE,     /// COMMUNICATION WITH DEST ADMINISTRATIVELY PROHIBITED (ICMPv6) - 1 
    COMMPROHIBV6,/// BEYOND SCOPE OF SOURCE ADDR (ICMPv6) - 2
    BYNDSRCADDR, /// ADDRESS UNREADCHABLE (ICMPv6) - 3
    ADDRUNREACH, /// PORT UNREACHABLE (ICMPv6) - 4
    PORTUNREACH, /// SOURCE ADDRESS FAILED POLICY (ICMPv6) - 5
    SRCADDRPLCY, /// REJECT ROUTE TO DESTINATION (ICMPv6) - 6
    REJECTDST,   /// HOP LIMIT EXCEEDED IN TX (ICMPv6) - 0
    HOPLMTEXCD,  /// FRAGMENT REASSEMBLY EXCEEDED TIME (ICMPv6) - 1
    FRAGTIME,    /// ERRORONEOUS HEADER FIELD (ICMPv6) - 0
    ERRHDRFIELD, /// UNRECOGNIZED NEXT HEADER (ICMPv6) - 1
    NXTHDRERR,   /// UNRECOGNIZED IPv6 OPTION (ICMPv6) - 2
    IPV6OPTERR,  /// SEQUENCE NUMBER RESET (ICMPv6) - 255
    SEQNUMRST
};

Begin_Enum_String(icmpcode_t)
{
    Enum_String(ECHORPLY);
    Enum_String(NONETWRK);
    Enum_String(NOHOST);
    Enum_String(NOPROT);
    Enum_String(NOPORT);
    Enum_String(FRAGRQD);
    Enum_String(RTEFAIL);
    Enum_String(DSTUNKNWN);
    Enum_String(DSTHSTUNKNWN);
    Enum_String(SRCHSTISOLT);
    Enum_String(NETWKPROHIB);
    Enum_String(HOSTPROHIB);
    Enum_String(NETWKNOTOS);
    Enum_String(HOSTNOTOS);
    Enum_String(COMMPROHIB);
    Enum_String(HOSTVILATE);
    Enum_String(CUTOFF);
    Enum_String(REDIRNETWK);
    Enum_String(REDIRHOST);
    Enum_String(REDIRTOSN);
    Enum_String(REDIRTOSH);
    Enum_String(TTLEXPIRE);
    Enum_String(FRAGEXPIRE);
    Enum_String(PTRINDERR);
    Enum_String(OPTERR);
    Enum_String(BADLENGTH);
    Enum_String(NOROUTE);
    Enum_String(COMMPROHIBV6);
    Enum_String(BYNDSRCADDR);
    Enum_String(ADDRUNREACH);
    Enum_String(PORTUNREACH);
    Enum_String(SRCADDRPLCY);
    Enum_String(REJECTDST);
    Enum_String(HOPLMTEXCD);
    Enum_String(FRAGTIME);
    Enum_String(ERRHDRFIELD);
    Enum_String(NXTHDRERR);
    Enum_String(IPV6OPTERR);
    Enum_String(SEQNUMRST);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Versions for TLS/SSL
/// @param SSL30 - Secure Socket Layer v3.0
/// @param TLS10 - Transport Layer Security v1.0
/// @param TLS11 - Transport Layer Security v1.1
/// @param TLS12 - Transport Layer Security v1.2
/// @param DTLS  - Datagram Transport Layer Security
//////////////////////////////////////////////////////////////////////
enum tlsver_t {     /// Secure Socket Layer v3.0 - 0x3000
    SSL30 = 0x0300, /// Transport Layer Security v1.0 - 0x0301
    TLS10 = 0x0301, /// Transport Layer Security v1.1 - 0x0302
    TLS11 = 0x0302, /// Transport Layer Security v1.2 - 0x0303
    TLS12 = 0x0303, /// Datagram Transport Layer Security - 0xFFFE
    DTLS  = 0xFFFE
};

Begin_Enum_String(tlsver_t)
{
    Enum_String(SSL30);
    Enum_String(TLS10);
    Enum_String(TLS11);
    Enum_String(TLS12);
    Enum_String(DTLS);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Types of packets for TLS/SSL
/// @param CHG_CIPHER_SPEC - Change cipher spec
/// @param ALERT - Alert packet for TLS
/// @param HANDSHAKE - TLS handshake packet
/// @param APPLICATION - TLS application packet
/// @param HEARTBEAT - TLS keep alive packet
//////////////////////////////////////////////////////////////////////
enum tlstype_t {          /// Change Cipher Spec - 0x14
    CHG_CIPHER_SPEC = 20, /// Alert message - 0x15
    ALERT = 21,           /// Handshake message - 0x16
    HANDSHAKE = 22,       /// Application message - 0x17
    APPLICATION = 23,     /// Keep alive message - 0x18
    HEARTBEAT  = 24
};

Begin_Enum_String(tlstype_t)
{
    Enum_String(CHG_CIPHER_SPEC);
    Enum_String(ALERT);
    Enum_String(HANDSHAKE);
    Enum_String(APPLICATION);
    Enum_String(HEARTBEAT);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// ALERT level values for TLS/SSL
/// @param WARNING - Warning level of ALERT for TLS
/// @param FATAL - Fatal level of ALERT for TLS
//////////////////////////////////////////////////////////////////////
enum tlslvl_t {/// Reserved
    TLSLVL0,   /// Warning alert - 2
    WARNING,   /// Fatal alert - 2
    FATAL
};

Begin_Enum_String(tlslvl_t)
{
    Enum_String(TLSLVL0);
    Enum_String(WARNING);
    Enum_String(FATAL);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// HANDSHAKE types for TLS/SSL
/// @param HELLO_REQUEST - Server request to open connection
/// @param CLIENT_HELLO - Client request to open connection
/// @param SERVER_HELLO - Server request to open connection
/// @param NEW_SESSION_TICKET - Request to create new session
/// @param CERTIFICATE - Certificate exchange
/// @param SERVER_KEY_EXCHANGE - Server request to exchange keys
/// @param CERTIFICATE_REQUEST - Request for certificate
/// @param SERVER_HELLO_DONE - Server terminates connection request
/// @param CERTIFICATE_VERIFY - Request to verify certificate
/// @param CLIENT_KEY_EXCHANGE - Client request to exchange keys
/// @param FINISHED - Request to end connection
//////////////////////////////////////////////////////////////////////
enum tls_handshake_t {      /// Hello Request - 0
    HELLO_REQUEST=0,        /// Client Hello - 1
    CLIENT_HELLO=1,         /// Server Hello - 2
    SERVER_HELLO=2,         /// New Session Ticket - 4
    NEW_SESSION_TICKET=4,   /// Certificate - 11
    CERTIFICATE=11,         /// Server Key Exchange - 12
    SERVER_KEY_EXCHANGE=12, /// Certificate Request - 13
    CERTIFICATE_REQUEST=13, /// Server Hello Done - 14
    SERVER_HELLO_DONE=14,   /// Certificate Verify - 15
    CERTIFICATE_VERIFY=15,  /// Client Key Exchange - 16
    CLIENT_KEY_EXCHANGE=16, /// Finished - 20
    FINISHED=20
};

Begin_Enum_String(tls_handshake_t)
{
    Enum_String(HELLO_REQUEST);
    Enum_String(CLIENT_HELLO);
    Enum_String(SERVER_HELLO);
    Enum_String(NEW_SESSION_TICKET);
    Enum_String(CERTIFICATE);
    Enum_String(SERVER_KEY_EXCHANGE);
    Enum_String(CERTIFICATE_REQUEST);
    Enum_String(SERVER_HELLO_DONE);
    Enum_String(CERTIFICATE_VERIFY);
    Enum_String(CLIENT_KEY_EXCHANGE);
    Enum_String(FINISHED);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// ERROR types for TLS/SSL
/// @param  CLOSE - Close the connection
/// @param  MESSAGE FATAL - Message was fatal
/// @param  BAD RECORD MAC - MAC for record was incorrect
/// @param  DECRYPT_FATAL - Decryption error
/// @param  RECORD OVERFLOW - Record overflow
/// @param  DECOMPRESS FAIL - Decompression failed
/// @param  HANDSHAKE FAIL - Handshake failed 
/// @param  NO CERTIFICATE - Client has no certificate
/// @param  BAD CERTIFICATE - Client has bad certificate
/// @param  UNSUPPORTED CERTIFICATE - Wrong certificate type
/// @param  CERTIFICATE REVOKED - Certificate revoked
/// @param  CERTIFICATE EXPIRED - Certificate expired
/// @param  CERTIFICATE UNKNOWN - Unknown certificate used
/// @param  ILLEGAL PARAMETER - Illegal parameter in the packet
/// @param  UNKNOWN CA - Unknown certificate agency
/// @param  ACCESS DENIED - Access not allowed
/// @param  DECODE ERROR - Unable to decode the packet
/// @param  DECRYPT ERROR - Error during decryption
/// @param  EXPORT RESTRICTION - Export restriction on this packet
/// @param  PROTOCOL VERSION - Incorrect protocol version
/// @param  INSUFFICIENT SECURITY - Packet security was insufficient
/// @param  INTERNAL ERROR - Internal error during operation
/// @param  USER CANCELED - User cancelled connection
/// @param  NO RENEGOTIATION - Renegotiation failed
/// @param  UNSUPPORTED EXTENSION - Extension requested is unsupported
/// @param  CERTIFICATE UNOBTAINABLE - Required certificate was unobtainable
/// @param  UNRECOGINZED NAME - Unrecognized name
/// @param  BAD CERTIFICATE STATUS RESPONSE - Certificate status took too long
/// @param  BAD CERTIFICATE HASH VALUE - Certificate has been tampered with
/// @param  UNKNOWN PSK IDENTITY - ID unknown
/// @param  NO APPLICATION PROTOCOL - Incorrect Application protocol
//////////////////////////////////////////////////////////////////////
enum tls_error_t {                      /// 0
    CLOSE = 0,                          /// 10
    MESSAGE_FATAL=10,                   /// 20
    BAD_RECORD_MAC=20,                  /// 21
    DECRYPT_FATAL=21,                   /// 22
    RECORD_OVERFLOW=22,                 /// 30
    DECOMPRESS_FAIL=30,                 /// 40
    HANDSHAKE_FAIL=40,                  /// 41
    NO_CERTIFICATE=41,                  /// 42
    BAD_CERTIFICATE=42,                 /// 43
    UNSUPPORTED_CERTIFICATE=43,         /// 44
    CERTIFICATE_REVOKED=44,             /// 45
    CERTIFICATE_EXPIRED=45,             /// 46
    CERTIFICATE_UNKNOWN=46,             /// 47
    ILLEGAL_PARAMETER=47,               /// 48
    UNKNOWN_CA=48,                      /// 49
    ACCESS_DENIED=49,                   /// 50
    DECODE_ERROR=50,                    /// 51
    DECRYPT_ERROR=51,                   /// 60
    EXPORT_RESTRICTION=60,              /// 70
    PROTOCOL_VERSION=70,                /// 71
    INSUFFICIENT_SECURITY=71,           /// 80
    INTERNAL_ERROR=80,                  /// 90
    USER_CANCELED=90,                   /// 100
    NO_RENEGOTIATION=100,               /// 110
    UNSUPPORTED_EXTENSION=110,          /// 111
    CERTIFICATE_UNOBTAINABLE=111,       /// 112
    UNRECOGNIZED_NAME=112,              /// 113
    BAD_CERTIFICATE_STATUS_RESPONSE=113,/// 114
    BAD_CERTIFICATE_HASH_VALUE=114,     /// 115
    UNKNOWN_PSK_IDENTITY=115,           /// 120
    NO_APPLICATION_PROTOCOL=120
};

Begin_Enum_String(tls_error_t)
{
    Enum_String(CLOSE);
    Enum_String(MESSAGE_FATAL);
    Enum_String(BAD_RECORD_MAC);
    Enum_String(DECRYPT_FATAL);
    Enum_String(RECORD_OVERFLOW);
    Enum_String(DECOMPRESS_FAIL);
    Enum_String(HANDSHAKE_FAIL);
    Enum_String(NO_CERTIFICATE);
    Enum_String(BAD_CERTIFICATE);
    Enum_String(UNSUPPORTED_CERTIFICATE);
    Enum_String(CERTIFICATE_REVOKED);
    Enum_String(CERTIFICATE_EXPIRED);
    Enum_String(CERTIFICATE_UNKNOWN);
    Enum_String(ILLEGAL_PARAMETER);
    Enum_String(UNKNOWN_CA);
    Enum_String(ACCESS_DENIED);
    Enum_String(DECODE_ERROR);
    Enum_String(DECRYPT_ERROR);
    Enum_String(EXPORT_RESTRICTION);
    Enum_String(PROTOCOL_VERSION);
    Enum_String(INSUFFICIENT_SECURITY);
    Enum_String(INTERNAL_ERROR);
    Enum_String(USER_CANCELED);
    Enum_String(NO_RENEGOTIATION);
    Enum_String(UNSUPPORTED_EXTENSION);
    Enum_String(CERTIFICATE_UNOBTAINABLE);
    Enum_String(UNRECOGNIZED_NAME);
    Enum_String(BAD_CERTIFICATE_STATUS_RESPONSE);
    Enum_String(BAD_CERTIFICATE_HASH_VALUE);
    Enum_String(UNKNOWN_PSK_IDENTITY);
    Enum_String(NO_APPLICATION_PROTOCOL);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// SRTP ciphers
///
/// @param NULL_SRTP - Null encryption and authentication
/// @param AES_CTR_SHA1 - AES Counter mode encrytion with SHA1 authentication
/// @param AEAD_AES_128_GCM - AES Galois Counter Mode with 16-byte key and 16-byte ICV
/// @param AEAD_AES_256_GCM - AES Galois Counter Mode with 32-byte key and 16-byte ICV
/// @param AEAD_AES_128_GCM_8 - AES Galois Counter Mode with 16-byte key and 8-byte ICv
/// @param AEAD_AES_256_GCM_8 - AES Galois Counter Mode with 32-byte key and 8-byte ICV
/// @param AEAD_AES_128_GCM_12 - AES Galois Counter Mode with 16-byte key and 12-byte ICV
/// @param AEAD_AES_256_GCM_12 - AES Galois Counter Mode with 32-byte key and 12-byte ICV
/// @param AEAD_AES_128_CCM - AES CCM Mode with 16-byte key and 16-byte ICV
/// @param AEAD_AES_256_CCM - AES CCM Mode with 32-byte key and 16-byte ICV
/// @param AEAD_AES_128_CCM_8 - AES CCM Mode with 16-byte key and 8-byte ICv
/// @param AEAD_AES_256_CCM_8 - AES CCM Mode with 32-byte key and 8-byte ICV
/// @param AEAD_AES_128_CCM_12 - AES CCM Mode with 16-byte key and 12-byte ICV
/// @param AEAD_AES_256_CCM_12 - AES CCM Mode with 32-byte key and 12-byte ICV
/// @param ARIA_128_CTR_HMAC_SHA1_80 - ARIA-CTR with 16-byte key and 10-byte ICV
/// @param ARIA_128_CTR_HMAC_SHA1_32 - ARIA-CTR with 16-byte key and 4-byte ICV
/// @param ARIA_192_CTR_HMAC_SHA1_80 - ARIA-CTR with 24-byte key and 10-byte ICV
/// @param ARIA_192_CTR_HMAC_SHA1_32 - ARIA-CTR with 24-byte key and 4-byte ICV
/// @param ARIA_256_CTR_HMAC_SHA1_80 - ARIA-CTR with 32-byte key and 10-byte ICV
/// @param ARIA_256_CTR_HMAC_SHA1_32 - ARIA-CTR with 32-byte key and 4-byte ICV
/// @param AEAD_ARIA_128_GCM - ARIA Galois Counter Mode with 16-byte key and 16-byte ICV
/// @param AEAD_ARAI_256_GCM - ARIA Galois Counter Mode with 32-byte key and 16-byte ICV
//////////////////////////////////////////////////////////////////////
enum srtpcipher_t {       /// NULL encryption
    NULL_SRTP,            /// AES-CTR counter mode with 20-byte ICV
    AES_CTR_SHA1,         /// AES-GCM with 16-byte key and 16-byte ICV
    AEAD_AES_128_GCM,     /// AES-GCM with 32-byte key and 16-byte ICV
    AEAD_AES_256_GCM,     /// AES-GCM with 16-byte key and 8-byte ICV
    AEAD_AES_128_GCM_8,   /// AES-GCM with 32-byte key and 8-byte ICV
    AEAD_AES_256_GCM_8,   /// AES-GCM with 16-byte key and 12-byte ICV
    AEAD_AES_128_GCM_12,  /// AES-GCM with 32-byte key and 12-byte ICV
    AEAD_AES_256_GCM_12,  /// AES-CCM with 16-byte key and 16-byte ICV
    AEAD_AES_128_CCM,     /// AES-CCM with 32-byte key and 16-byte ICV
    AEAD_AES_256_CCM,     /// AES-CCM with 16-byte key and 8-byte ICV
    AEAD_AES_128_CCM_8,   /// AES-CCM with 32-byte key and 8-byte ICV
    AEAD_AES_256_CCM_8,   /// AES-CCM with 16-byte key and 12-byte ICV
    AEAD_AES_128_CCM_12,  /// AES-CCM with 32-byte key and 12-byte ICV
    AEAD_AES_256_CCM_12,  /// ARIA-CTR with 16-byte key and 10-byte ICV
    ARIA_128_CTR_HMAC_SHA1_80, /// ARIA-CTR with 16-byte key and 4-byte ICV
    ARIA_128_CTR_HMAC_SHA1_32, /// ARIA-CTR with 24-byte key and 10-byte ICV
    ARIA_192_CTR_HMAC_SHA1_80, /// ARIA-CTR with 24-byte key and 4-byte ICV
    ARIA_192_CTR_HMAC_SHA1_32, /// ARIA-CTR with 32-byte key and 10-byte ICV
    ARIA_256_CTR_HMAC_SHA1_80, /// ARIA-CTR with 32-byte key and 4-byte ICV
    ARIA_256_CTR_HMAC_SHA1_32, /// ARIA-GCM with 16-byte key and 16-byte ICV
    AEAD_ARIA_128_GCM,    /// ARIA-GCM with 32-byte key and 16-byte ICV
    AEAD_ARIA_256_GCM
};

Begin_Enum_String(srtpcipher_t)
{
    Enum_String(NULL_SRTP);
    Enum_String(AES_CTR_SHA1);
    Enum_String(AEAD_AES_128_GCM);
    Enum_String(AEAD_AES_256_GCM);
    Enum_String(AEAD_AES_128_GCM_8);
    Enum_String(AEAD_AES_256_GCM_8);
    Enum_String(AEAD_AES_128_GCM_12);
    Enum_String(AEAD_AES_256_GCM_12);
    Enum_String(AEAD_AES_128_CCM);
    Enum_String(AEAD_AES_256_CCM);
    Enum_String(AEAD_AES_128_CCM_8);
    Enum_String(AEAD_AES_256_CCM_8);
    Enum_String(AEAD_AES_128_CCM_12);
    Enum_String(AEAD_AES_256_CCM_12);
    Enum_String(ARIA_128_CTR_HMAC_SHA1_80);
    Enum_String(ARIA_128_CTR_HMAC_SHA1_32);
    Enum_String(ARIA_192_CTR_HMAC_SHA1_80);
    Enum_String(ARIA_192_CTR_HMAC_SHA1_32);
    Enum_String(ARIA_256_CTR_HMAC_SHA1_80);
    Enum_String(ARIA_256_CTR_HMAC_SHA1_32);
    Enum_String(AEAD_ARIA_128_GCM);
    Enum_String(AEAD_ARIA_256_GCM);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Ciphersuite values for TLS/SSL
///
/// @param TLS_NULL_WITH_NULL_NULL - 0x0000
/// @param TLS_RSA_WITH_NULL_MD5 - 0x0001
/// @param TLS_RSA_WITH_NULL_SHA - 0x0002
/// @param TLS_RSA_EXPORT_WITH_RC4_40_MD5 - 0x0003
/// @param TLS_RSA_WITH_RC4_128_MD5 - 0x0004
/// @param TLS_RSA_WITH_RC4_128_SHA - 0x0005
/// @param TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 - 0x0006
/// @param TLS_RSA_WITH_IDEA_CBC_SHA - 0x0007
/// @param TLS_RSA_EXPORT_WITH_DES40_CBC_SHA - 0x0008
/// @param TLS_RSA_WITH_DES_CBC_SHA - 0x0009
/// @param TLS_RSA_WITH_3DES_EDE_CBC_SHA - 0x000A
/// @param TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA - 0x000B
/// @param TLS_DH_DSS_WITH_DES_CBC_SHA - 0x000C
/// @param TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA - 0x000D
/// @param TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA - 0x000E
/// @param TLS_DH_RSA_WITH_DES_CBC_SHA - 0x000F
/// @param TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA - 0x0010
/// @param TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA - 0x0011
/// @param TLS_DHE_DSS_WITH_DES_CBC_SHA - 0x0012
/// @param TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA - 0x0013
/// @param TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA - 0x0014
/// @param TLS_DHE_RSA_WITH_DES_CBC_SHA - 0x0015
/// @param TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA - 0x0016
/// @param TLS_DH_ANON_EXPORT_WITH_RC4_40_MD5 - 0x0017
/// @param TLS_DH_ANON_WITH_RC4_128_MD5 - 0x0018
/// @param TLS_DH_ANON_EXPORT_WITH_DES40_CBC_SHA - 0x0019
/// @param TLS_DH_ANON_WITH_DES_CBC_SHA - 0x001A
/// @param TLS_DH_ANON_WITH_3DES_EDE_CBC_SHA - 0x001B
/// @param TLS_KRB5_WITH_DES_CBC_SHA - 0x001E
/// @param TLS_KRB5_WITH_3DES_EDE_CBC_SHA - 0x001F
/// @param TLS_KRB5_WITH_RC4_128_SHA - 0x0020
/// @param TLS_KRB5_WITH_IDEA_CBC_SHA - 0x0021
/// @param TLS_KRB5_WITH_DES_CBC_MD5 - 0x0022
/// @param TLS_KRB5_WITH_3DES_EDE_CBC_MD5 - 0x0023
/// @param TLS_KRB5_WITH_RC4_128_MD5 - 0x0024
/// @param TLS_KRB5_WITH_IDEA_CBC_MD5 - 0x0025
/// @param TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA - 0x0026
/// @param TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA - 0x0027
/// @param TLS_KRB5_EXPORT_WITH_RC4_40_SHA - 0x0028
/// @param TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 - 0x0029
/// @param TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 - 0x002A
/// @param TLS_KRB5_EXPORT_WITH_RC4_40_MD5 - 0x002B
/// @param TLS_PSK_WITH_NULL_SHA - 0x002C
/// @param TLS_DHE_PSK_WITH_NULL_SHA - 0x002D
/// @param TLS_RSA_PSK_WITH_NULL_SHA - 0x002E
/// @param TLS_RSA_WITH_AES_128_CBC_SHA - 0x002F
/// @param TLS_DH_DSS_WITH_AES_128_CBC_SHA - 0x0030
/// @param TLS_DH_RSA_WITH_AES_128_CBC_SHA - 0x0031
/// @param TLS_DHE_DSS_WITH_AES_128_CBC_SHA - 0x0032
/// @param TLS_DHE_RSA_WITH_AES_128_CBC_SHA - 0x0033
/// @param TLS_DH_ANON_WITH_AES_128_CBC_SHA - 0x0034
/// @param TLS_RSA_WITH_AES_256_CBC_SHA - 0x0035
/// @param TLS_DH_DSS_WITH_AES_256_CBC_SHA - 0x0036
/// @param TLS_DH_RSA_WITH_AES_256_CBC_SHA - 0x0037
/// @param TLS_DHE_DSS_WITH_AES_256_CBC_SHA - 0x0038
/// @param TLS_DHE_RSA_WITH_AES_256_CBC_SHA - 0x0039
/// @param TLS_DH_ANON_WITH_AES_256_CBC_SHA - 0x003A
/// @param TLS_RSA_WITH_NULL_SHA256 - 0x003B
/// @param TLS_RSA_WITH_AES_128_CBC_SHA256 - 0x003C
/// @param TLS_RSA_WITH_AES_256_CBC_SHA256 - 0x003D
/// @param TLS_DH_DSS_WITH_AES_128_CBC_SHA256 - 0x003E
/// @param TLS_DH_RSA_WITH_AES_128_CBC_SHA256 - 0x003F
/// @param TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 - 0x0040
/// @param TLS_RSA_WITH_CAMELLIA_128_CBC_SHA - 0x0041
/// @param TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA - 0x0042
/// @param TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA - 0x0043
/// @param TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA - 0x0044
/// @param TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA - 0x0045
/// @param TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA - 0x0046
/// @param TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 - 0x0067
/// @param TLS_DH_DSS_WITH_AES_256_CBC_SHA256 - 0x0068
/// @param TLS_DH_RSA_WITH_AES_256_CBC_SHA256 - 0x0069
/// @param TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 - 0x006A
/// @param TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 - 0x006B
/// @param TLS_DH_ANON_WITH_AES_128_CBC_SHA256 - 0x006C
/// @param TLS_DH_ANON_WITH_AES_256_CBC_SHA256 - 0x006D
/// @param TLS_RSA_WITH_CAMELLIA_256_CBC_SHA - 0x0084
/// @param TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA - 0x0085
/// @param TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA - 0x0086
/// @param TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA - 0x0087
/// @param TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA - 0x0088
/// @param TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA - 0x0089
/// @param TLS_PSK_WITH_RC4_128_SHA - 0x008A
/// @param TLS_PSK_WITH_3DES_EDE_CBC_SHA - 0x008B
/// @param TLS_PSK_WITH_AES_128_CBC_SHA - 0x008C
/// @param TLS_PSK_WITH_AES_256_CBC_SHA - 0x008D
/// @param TLS_DHE_PSK_WITH_RC4_128_SHA - 0x008E
/// @param TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA - 0x008F
/// @param TLS_DHE_PSK_WITH_AES_128_CBC_SHA - 0x0090
/// @param TLS_DHE_PSK_WITH_AES_256_CBC_SHA - 0x0091
/// @param TLS_RSA_PSK_WITH_RC4_128_SHA - 0x0092
/// @param TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA - 0x0093
/// @param TLS_RSA_PSK_WITH_AES_128_CBC_SHA - 0x0094
/// @param TLS_RSA_PSK_WITH_AES_256_CBC_SHA - 0x0095
/// @param TLS_RSA_WITH_SEED_CBC_SHA - 0x0096
/// @param TLS_DH_DSS_WITH_SEED_CBC_SHA - 0x0097
/// @param TLS_DH_RSA_WITH_SEED_CBC_SHA - 0x0098
/// @param TLS_DHE_DSS_WITH_SEED_CBC_SHA - 0x0099
/// @param TLS_DHE_RSA_WITH_SEED_CBC_SHA - 0x009A
/// @param TLS_DH_ANON_WITH_SEED_CBC_SHA - 0x009B
/// @param TLS_RSA_WITH_AES_128_GCM_SHA256 - 0x009C
/// @param TLS_RSA_WITH_AES_256_GCM_SHA384 - 0x009D
/// @param TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 - 0x009E
/// @param TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 - 0x009F
/// @param TLS_DH_RSA_WITH_AES_128_GCM_SHA256 - 0x00A0
/// @param TLS_DH_RSA_WITH_AES_256_GCM_SHA384 - 0x00A1
/// @param TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 - 0x00A2
/// @param TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 - 0x00A3
/// @param TLS_DH_DSS_WITH_AES_128_GCM_SHA256 - 0x00A4
/// @param TLS_DH_DSS_WITH_AES_256_GCM_SHA384 - 0x00A5
/// @param TLS_DH_ANON_WITH_AES_128_GCM_SHA256 - 0x00A6
/// @param TLS_DH_ANON_WITH_AES_256_GCM_SHA384 - 0x00A7
/// @param TLS_PSK_WITH_AES_128_GCM_SHA256 - 0x00A8
/// @param TLS_PSK_WITH_AES_256_GCM_SHA384 - 0x00A9
/// @param TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 - 0x00AA
/// @param TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 - 0x00AB
/// @param TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 - 0x00AC
/// @param TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 - 0x00AD
/// @param TLS_PSK_WITH_AES_128_CBC_SHA256 - 0x00AE
/// @param TLS_PSK_WITH_AES_256_CBC_SHA384 - 0x00AF
/// @param TLS_PSK_WITH_NULL_SHA256 - 0x00B0
/// @param TLS_PSK_WITH_NULL_SHA384 - 0x00B1
/// @param TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 - 0x00B2
/// @param TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 - 0x00B3
/// @param TLS_DHE_PSK_WITH_NULL_SHA256 - 0x00B4
/// @param TLS_DHE_PSK_WITH_NULL_SHA384 - 0x00B5
/// @param TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 - 0x00B6
/// @param TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 - 0x00B7
/// @param TLS_RSA_PSK_WITH_NULL_SHA256 - 0x00B8
/// @param TLS_RSA_PSK_WITH_NULL_SHA384 - 0x00B9
/// @param TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 - 0x00BA
/// @param TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 - 0x00BB
/// @param TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 - 0x00BC
/// @param TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 - 0x00BD
/// @param TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 - 0x00BE
/// @param TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA256 - 0x00BF
/// @param TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 - 0x00C0
/// @param TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 - 0x00C1
/// @param TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 - 0x00C2
/// @param TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 - 0x00C3
/// @param TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 - 0x00C4
/// @param TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA256 - 0x00C5
/// @param TLS_ECDH_ECDSA_WITH_NULL_SHA - 0xC001
/// @param TLS_ECDH_ECDSA_WITH_RC4_128_SHA - 0xC002
/// @param TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA - 0xC003
/// @param TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA - 0xC004
/// @param TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA - 0xC005
/// @param TLS_ECDHE_ECDSA_WITH_NULL_SHA - 0xC006
/// @param TLS_ECDHE_ECDSA_WITH_RC4_128_SHA - 0xC007
/// @param TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA - 0xC008
/// @param TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA - 0xC009
/// @param TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA - 0xC00A
/// @param TLS_ECDH_RSA_WITH_NULL_SHA - 0xC00B
/// @param TLS_ECDH_RSA_WITH_RC4_128_SHA - 0xC00C
/// @param TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA - 0xC00D
/// @param TLS_ECDH_RSA_WITH_AES_128_CBC_SHA - 0xC00E
/// @param TLS_ECDH_RSA_WITH_AES_256_CBC_SHA - 0xC00F
/// @param TLS_ECDHE_RSA_WITH_NULL_SHA - 0xC010
/// @param TLS_ECDHE_RSA_WITH_RC4_128_SHA - 0xC011
/// @param TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA - 0xC012
/// @param TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA - 0xC013
/// @param TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA - 0xC014
/// @param TLS_ECDH_ANON_WITH_NULL_SHA - 0xC015
/// @param TLS_ECDH_ANON_WITH_RC4_128_SHA - 0xC016
/// @param TLS_ECDH_ANON_WITH_3DES_EDE_CBC_SHA - 0xC017
/// @param TLS_ECDH_ANON_WITH_AES_128_CBC_SHA - 0xC018
/// @param TLS_ECDH_ANON_WITH_AES_256_CBC_SHA - 0xC019
/// @param TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA - 0xC01A
/// @param TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA - 0xC01B
/// @param TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA - 0xC01C
/// @param TLS_SRP_SHA_WITH_AES_128_CBC_SHA - 0xC01D
/// @param TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA - 0xC01E
/// @param TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA - 0xC01F
/// @param TLS_SRP_SHA_WITH_AES_256_CBC_SHA - 0xC020
/// @param TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA - 0xC021
/// @param TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA - 0xC022
/// @param TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 - 0xC023
/// @param TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 - 0xC024
/// @param TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 - 0xC025
/// @param TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 - 0xC026
/// @param TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 - 0xC027
/// @param TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 - 0xC028
/// @param TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 - 0xC029
/// @param TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 - 0xC02A
/// @param TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 - 0xC02B
/// @param TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 - 0xC02C
/// @param TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 - 0xC02D
/// @param TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 - 0xC02E
/// @param TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 - 0xC02F
/// @param TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 - 0xC030
/// @param TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 - 0xC031
/// @param TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 - 0xC032
/// @param TLS_ECDHE_PSK_WITH_RC4_128_SHA - 0xC033
/// @param TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA - 0xC034
/// @param TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA - 0xC035
/// @param TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA - 0xC036
/// @param TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 - 0xC037
/// @param TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 - 0xC038
/// @param TLS_ECDHE_PSK_WITH_NULL_SHA - 0xC039
/// @param TLS_ECDHE_PSK_WITH_NULL_SHA256 - 0xC03A
/// @param TLS_ECDHE_PSK_WITH_NULL_SHA384 - 0xC03B
/// @param TLS_RSA_WITH_ARIA_128_CBC_SHA256 - 0xC03C
/// @param TLS_RSA_WITH_ARIA_256_CBC_SHA384 - 0xC03D
/// @param TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 - 0xC03E
/// @param TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 - 0xC03F
/// @param TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 - 0xC040
/// @param TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 - 0xC041
/// @param TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 - 0xC042
/// @param TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 - 0xC043
/// @param TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 - 0xC044
/// @param TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 - 0xC045
/// @param TLS_DH_ANON_WITH_ARIA_128_CBC_SHA256 - 0xC046
/// @param TLS_DH_ANON_WITH_ARIA_256_CBC_SHA384 - 0xC047
/// @param TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 - 0xC048
/// @param TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 - 0xC049
/// @param TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 - 0xC04A
/// @param TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 - 0xC04B
/// @param TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 - 0xC04C
/// @param TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 - 0xC04D
/// @param TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 - 0xC04E
/// @param TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 - 0xC04F
/// @param TLS_RSA_WITH_ARIA_128_GCM_SHA256 - 0xC050
/// @param TLS_RSA_WITH_ARIA_256_GCM_SHA384 - 0xC051
/// @param TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 - 0xC052
/// @param TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 - 0xC053
/// @param TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 - 0xC054
/// @param TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 - 0xC055
/// @param TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 - 0xC056
/// @param TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 - 0xC057
/// @param TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 - 0xC058
/// @param TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 - 0xC059
/// @param TLS_DH_ANON_WITH_ARIA_128_GCM_SHA256 - 0xC05A
/// @param TLS_DH_ANON_WITH_ARIA_256_GCM_SHA384 - 0xC05B
/// @param TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 - 0xC05C
/// @param TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 - 0xC05D
/// @param TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 - 0xC05E
/// @param TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 - 0xC05F
/// @param TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 - 0xC060
/// @param TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 - 0xC061
/// @param TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 - 0xC062
/// @param TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 - 0xC063
/// @param TLS_PSK_WITH_ARIA_128_CBC_SHA256 - 0xC064
/// @param TLS_PSK_WITH_ARIA_256_CBC_SHA384 - 0xC065
/// @param TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 - 0xC066
/// @param TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 - 0xC067
/// @param TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 - 0xC068
/// @param TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 - 0xC069
/// @param TLS_PSK_WITH_ARIA_128_GCM_SHA256 - 0xC06A
/// @param TLS_PSK_WITH_ARIA_256_GCM_SHA384 - 0xC06B
/// @param TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 - 0xC06C
/// @param TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 - 0xC06D
/// @param TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 - 0xC06E
/// @param TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 - 0xC06F
/// @param TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 - 0xC070
/// @param TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 - 0xC071
/// @param TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 - 0xC072
/// @param TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 - 0xC073
/// @param TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 - 0xC074
/// @param TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 - 0xC075
/// @param TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 - 0xC076
/// @param TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 - 0xC077
/// @param TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 - 0xC078
/// @param TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 - 0xC079
/// @param TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC07A
/// @param TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC07B
/// @param TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC07C
/// @param TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC07D
/// @param TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC07E
/// @param TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC07F
/// @param TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 - 0xC080
/// @param TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 - 0xC081
/// @param TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 - 0xC082
/// @param TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 - 0xC083
/// @param TLS_DH_ANON_WITH_CAMELLIA_128_GCM_SHA256 - 0xC084
/// @param TLS_DH_ANON_WITH_CAMELLIA_256_GCM_SHA384 - 0xC085
/// @param TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC086
/// @param TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC087
/// @param TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC088
/// @param TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC089
/// @param TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC08A
/// @param TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC08B
/// @param TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 - 0xC08C
/// @param TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 - 0xC08D
/// @param TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 - 0xC08E
/// @param TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 - 0xC08F
/// @param TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 - 0xC090
/// @param TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 - 0xC091
/// @param TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 - 0xC092
/// @param TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 - 0xC093
/// @param TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 - 0xC094
/// @param TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 - 0xC095
/// @param TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 - 0xC096
/// @param TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 - 0xC097
/// @param TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 - 0xC098
/// @param TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 - 0xC099
/// @param TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 - 0xC09A
/// @param TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 - 0xC09B
/// @param TLS_RSA_WITH_AES_128_CCM - 0xC09C
/// @param TLS_RSA_WITH_AES_256_CCM - 0xC09D
/// @param TLS_DHE_RSA_WITH_AES_128_CCM - 0xC09E
/// @param TLS_DHE_RSA_WITH_AES_256_CCM - 0xC09F
/// @param TLS_RSA_WITH_AES_128_CCM_8 - 0xC0A0
/// @param TLS_RSA_WITH_AES_256_CCM_8 - 0xC0A1
/// @param TLS_DHE_RSA_WITH_AES_128_CCM_8 - 0xC0A2
/// @param TLS_DHE_RSA_WITH_AES_256_CCM_8 - 0xC0A3
/// @param TLS_PSK_WITH_AES_128_CCM - 0xC0A4
/// @param TLS_PSK_WITH_AES_256_CCM - 0xC0A5
/// @param TLS_DHE_PSK_WITH_AES_128_CCM - 0xC0A6
/// @param TLS_DHE_PSK_WITH_AES_256_CCM - 0xC0A7
/// @param TLS_PSK_WITH_AES_128_CCM_8 - 0xC0A8
/// @param TLS_PSK_WITH_AES_256_CCM_8 - 0xC0A9
/// @param TLS_PSK_DHE_WITH_AES_128_CCM_8 - 0xC0AA
/// @param TLS_PSK_DHE_WITH_AES_256_CCM_8 - 0xC0AB
/// @param TLS_ECDHE_ECDSA_WITH_AES_128_CCM - 0xC0AC
/// @param TLS_ECDHE_ECDSA_WITH_AES_256_CCM - 0xC0AD
/// @param TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 - 0xC0AE
/// @param TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 - 0xC0AF
/// @param TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 - 0xCCA8
/// @param TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 - 0xCCA9
/// @param TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 - 0xCCAA
/// @param TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 - 0xCCAB
/// @param TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 - 0xCCAC
/// @param TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 - 0xCCAD
/// @param TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 - 0xCCAE
/// @param TLS_AES_128_GCM_SHA256 - 0x1301
/// @param TLS_AES_256_GCM_SHA384 - 0x1302
/// @param TLS_CHACHA20_POLY1305_SHA256 - 0x1303
/// @param TLS_AES_128_CCM_SHA256 - 0x1304
/// @param TLS_AES_128_CCM_8_SHA256 - 0x1305
//////////////////////////////////////////////////////////////////////
enum tls_ciphersuite_t {                          /// NULL Encryption and NULL Authentication
    TLS_NULL_WITH_NULL_NULL=0x0000,               /// RSA Key Negotiation with NULL Encryption and MD5 Authentication and PRF 
    TLS_RSA_WITH_NULL_MD5=0x0001,                 /// RSA Key Negotiation with NULL Encryption and SHA1 Authentication and PRF
    TLS_RSA_WITH_NULL_SHA=0x0002,                 /// RSA Key Negotiation with RC4 Encryption 40-bit Key and MD5 Authentication PRF
    TLS_RSA_EXPORT_WITH_RC4_40_MD5=0x0003,        /// RSA Key Negotiation with RC4 Encryption 128-bit Key and MD5 Authentication PRF
    TLS_RSA_WITH_RC4_128_MD5=0x0004,              /// RSA Key Negotiation with RC4 Encryption 128-bit Key and SHA1 Authentication PRF
    TLS_RSA_WITH_RC4_128_SHA=0x0005,              /// RSA Key Negotiation with RC2-CBC Encryption 40-bit Key and MD5 Authentication PRF
//    TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5=0x0006,
//    TLS_RSA_WITH_IDEA_CBC_SHA=0x0007,
    TLS_RSA_EXPORT_WITH_DES40_CBC_SHA=0x0008,
    TLS_RSA_WITH_DES_CBC_SHA=0x0009,
    TLS_RSA_WITH_3DES_EDE_CBC_SHA=0x000A,
    TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA=0x000B,
    TLS_DH_DSS_WITH_DES_CBC_SHA=0x000C,
    TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA=0x000D,
    TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA=0x000E,
    TLS_DH_RSA_WITH_DES_CBC_SHA=0x000F,
    TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA=0x0010,
    TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA=0x0011,
    TLS_DHE_DSS_WITH_DES_CBC_SHA=0x0012,
    TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA=0x0013,
    TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA=0x0014,
    TLS_DHE_RSA_WITH_DES_CBC_SHA=0x0015,
    TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA=0x0016,
    TLS_DH_ANON_EXPORT_WITH_RC4_40_MD5=0x0017,
    TLS_DH_ANON_WITH_RC4_128_MD5=0x0018,
    TLS_DH_ANON_EXPORT_WITH_DES40_CBC_SHA=0x0019,
    TLS_DH_ANON_WITH_DES_CBC_SHA=0x001A,
    TLS_DH_ANON_WITH_3DES_EDE_CBC_SHA=0x001B,
    TLS_KRB5_WITH_DES_CBC_SHA=0x001E,
    TLS_KRB5_WITH_3DES_EDE_CBC_SHA=0x001F,
    TLS_KRB5_WITH_RC4_128_SHA=0x0020,
//    TLS_KRB5_WITH_IDEA_CBC_SHA=0x0021,
    TLS_KRB5_WITH_DES_CBC_MD5=0x0022,
    TLS_KRB5_WITH_3DES_EDE_CBC_MD5=0x0023,
    TLS_KRB5_WITH_RC4_128_MD5=0x0024,
//    TLS_KRB5_WITH_IDEA_CBC_MD5=0x0025,
    TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA=0x0026,
//    TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA=0x0027,
    TLS_KRB5_EXPORT_WITH_RC4_40_SHA=0x0028,
    TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5=0x0029,
//    TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5=0x002A,
    TLS_KRB5_EXPORT_WITH_RC4_40_MD5=0x002B,
    TLS_PSK_WITH_NULL_SHA=0x002C,
    TLS_DHE_PSK_WITH_NULL_SHA=0x002D,
    TLS_RSA_PSK_WITH_NULL_SHA=0x002E,
    TLS_RSA_WITH_AES_128_CBC_SHA=0x002F,
    TLS_DH_DSS_WITH_AES_128_CBC_SHA=0x0030,
    TLS_DH_RSA_WITH_AES_128_CBC_SHA=0x0031,
    TLS_DHE_DSS_WITH_AES_128_CBC_SHA=0x0032,
    TLS_DHE_RSA_WITH_AES_128_CBC_SHA=0x0033,
    TLS_DH_ANON_WITH_AES_128_CBC_SHA=0x0034,
    TLS_RSA_WITH_AES_256_CBC_SHA=0x0035,
    TLS_DH_DSS_WITH_AES_256_CBC_SHA=0x0036,
    TLS_DH_RSA_WITH_AES_256_CBC_SHA=0x0037,
    TLS_DHE_DSS_WITH_AES_256_CBC_SHA=0x0038,
    TLS_DHE_RSA_WITH_AES_256_CBC_SHA=0x0039,
    TLS_DH_ANON_WITH_AES_256_CBC_SHA=0x003A,
    TLS_RSA_WITH_NULL_SHA256=0x003B,
    TLS_RSA_WITH_AES_128_CBC_SHA256=0x003C,
    TLS_RSA_WITH_AES_256_CBC_SHA256=0x003D,
    TLS_DH_DSS_WITH_AES_128_CBC_SHA256=0x003E,
    TLS_DH_RSA_WITH_AES_128_CBC_SHA256=0x003F,
    TLS_DHE_DSS_WITH_AES_128_CBC_SHA256=0x0040,
    TLS_RSA_WITH_CAMELLIA_128_CBC_SHA=0x0041,
    TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA=0x0042,
    TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA=0x0043,
    TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA=0x0044,
    TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA=0x0045,
    TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA=0x0046,
    TLS_DHE_RSA_WITH_AES_128_CBC_SHA256=0x0067,
    TLS_DH_DSS_WITH_AES_256_CBC_SHA256=0x0068,
    TLS_DH_RSA_WITH_AES_256_CBC_SHA256=0x0069,
    TLS_DHE_DSS_WITH_AES_256_CBC_SHA256=0x006A,
    TLS_DHE_RSA_WITH_AES_256_CBC_SHA256=0x006B,
    TLS_DH_ANON_WITH_AES_128_CBC_SHA256=0x006C,
    TLS_DH_ANON_WITH_AES_256_CBC_SHA256=0x006D,
    TLS_RSA_WITH_CAMELLIA_256_CBC_SHA=0x0084,
    TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA=0x0085,
    TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA=0x0086,
    TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA=0x0087,
    TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA=0x0088,
    TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA=0x0089,
    TLS_PSK_WITH_RC4_128_SHA=0x008A,
    TLS_PSK_WITH_3DES_EDE_CBC_SHA=0x008B,
    TLS_PSK_WITH_AES_128_CBC_SHA=0x008C,
    TLS_PSK_WITH_AES_256_CBC_SHA=0x008D,
    TLS_DHE_PSK_WITH_RC4_128_SHA=0x008E,
    TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA=0x008F,
    TLS_DHE_PSK_WITH_AES_128_CBC_SHA=0x0090,
    TLS_DHE_PSK_WITH_AES_256_CBC_SHA=0x0091,
    TLS_RSA_PSK_WITH_RC4_128_SHA=0x0092,
    TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA=0x0093,
    TLS_RSA_PSK_WITH_AES_128_CBC_SHA=0x0094,
    TLS_RSA_PSK_WITH_AES_256_CBC_SHA=0x0095,
    TLS_RSA_WITH_SEED_CBC_SHA=0x0096,
    TLS_DH_DSS_WITH_SEED_CBC_SHA=0x0097,
    TLS_DH_RSA_WITH_SEED_CBC_SHA=0x0098,
    TLS_DHE_DSS_WITH_SEED_CBC_SHA=0x0099,
    TLS_DHE_RSA_WITH_SEED_CBC_SHA=0x009A,
    TLS_DH_ANON_WITH_SEED_CBC_SHA=0x009B,
    TLS_RSA_WITH_AES_128_GCM_SHA256=0x009C,
    TLS_RSA_WITH_AES_256_GCM_SHA384=0x009D,
    TLS_DHE_RSA_WITH_AES_128_GCM_SHA256=0x009E,
    TLS_DHE_RSA_WITH_AES_256_GCM_SHA384=0x009F,
    TLS_DH_RSA_WITH_AES_128_GCM_SHA256=0x00A0,
    TLS_DH_RSA_WITH_AES_256_GCM_SHA384=0x00A1,
    TLS_DHE_DSS_WITH_AES_128_GCM_SHA256=0x00A2,
    TLS_DHE_DSS_WITH_AES_256_GCM_SHA384=0x00A3,
    TLS_DH_DSS_WITH_AES_128_GCM_SHA256=0x00A4,
    TLS_DH_DSS_WITH_AES_256_GCM_SHA384=0x00A5,
    TLS_DH_ANON_WITH_AES_128_GCM_SHA256=0x00A6,
    TLS_DH_ANON_WITH_AES_256_GCM_SHA384=0x00A7,
    TLS_PSK_WITH_AES_128_GCM_SHA256=0x00A8,
    TLS_PSK_WITH_AES_256_GCM_SHA384=0x00A9,
    TLS_DHE_PSK_WITH_AES_128_GCM_SHA256=0x00AA,
    TLS_DHE_PSK_WITH_AES_256_GCM_SHA384=0x00AB,
    TLS_RSA_PSK_WITH_AES_128_GCM_SHA256=0x00AC,
    TLS_RSA_PSK_WITH_AES_256_GCM_SHA384=0x00AD,
    TLS_PSK_WITH_AES_128_CBC_SHA256=0x00AE,
    TLS_PSK_WITH_AES_256_CBC_SHA384=0x00AF,
    TLS_PSK_WITH_NULL_SHA256=0x00B0,
    TLS_PSK_WITH_NULL_SHA384=0x00B1,
    TLS_DHE_PSK_WITH_AES_128_CBC_SHA256=0x00B2,
    TLS_DHE_PSK_WITH_AES_256_CBC_SHA384=0x00B3,
    TLS_DHE_PSK_WITH_NULL_SHA256=0x00B4,
    TLS_DHE_PSK_WITH_NULL_SHA384=0x00B5,
    TLS_RSA_PSK_WITH_AES_128_CBC_SHA256=0x00B6,
    TLS_RSA_PSK_WITH_AES_256_CBC_SHA384=0x00B7,
    TLS_RSA_PSK_WITH_NULL_SHA256=0x00B8,
    TLS_RSA_PSK_WITH_NULL_SHA384=0x00B9,
    TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256=0x00BA,
    TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256=0x00BB,
    TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256=0x00BC,
    TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256=0x00BD,
    TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256=0x00BE,
    TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA256=0x00BF,
    TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256=0x00C0,
    TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256=0x00C1,
    TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256=0x00C2,
    TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256=0x00C3,
    TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256=0x00C4,
    TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA256=0x00C5,
    TLS_ECDH_ECDSA_WITH_NULL_SHA=0xC001,
    TLS_ECDH_ECDSA_WITH_RC4_128_SHA=0xC002,
    TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA=0xC003,
    TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA=0xC004,
    TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA=0xC005,
    TLS_ECDHE_ECDSA_WITH_NULL_SHA=0xC006,
    TLS_ECDHE_ECDSA_WITH_RC4_128_SHA=0xC007,
    TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA=0xC008,
    TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA=0xC009,
    TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA=0xC00A,
    TLS_ECDH_RSA_WITH_NULL_SHA=0xC00B,
    TLS_ECDH_RSA_WITH_RC4_128_SHA=0xC00C,
    TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA=0xC00D,
    TLS_ECDH_RSA_WITH_AES_128_CBC_SHA=0xC00E,
    TLS_ECDH_RSA_WITH_AES_256_CBC_SHA=0xC00F,
    TLS_ECDHE_RSA_WITH_NULL_SHA=0xC010,
    TLS_ECDHE_RSA_WITH_RC4_128_SHA=0xC011,
    TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA=0xC012,
    TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA=0xC013,
    TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA=0xC014,
    TLS_ECDH_ANON_WITH_NULL_SHA=0xC015,
    TLS_ECDH_ANON_WITH_RC4_128_SHA=0xC016,
    TLS_ECDH_ANON_WITH_3DES_EDE_CBC_SHA=0xC017,
    TLS_ECDH_ANON_WITH_AES_128_CBC_SHA=0xC018,
    TLS_ECDH_ANON_WITH_AES_256_CBC_SHA=0xC019,
    TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA=0xC01A,
    TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA=0xC01B,
    TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA=0xC01C,
    TLS_SRP_SHA_WITH_AES_128_CBC_SHA=0xC01D,
    TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA=0xC01E,
    TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA=0xC01F,
    TLS_SRP_SHA_WITH_AES_256_CBC_SHA=0xC020,
    TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA=0xC021,
    TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA=0xC022,
    TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256=0xC023,
    TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384=0xC024,
    TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256=0xC025,
    TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384=0xC026,
    TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256=0xC027,
    TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384=0xC028,
    TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256=0xC029,
    TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384=0xC02A,
    TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256=0xC02B,
    TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384=0xC02C,
    TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256=0xC02D,
    TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384=0xC02E,
    TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256=0xC02F,
    TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384=0xC030,
    TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256=0xC031,
    TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384=0xC032,
    TLS_ECDHE_PSK_WITH_RC4_128_SHA=0xC033,
    TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA=0xC034,
    TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA=0xC035,
    TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA=0xC036,
    TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256=0xC037,
    TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384=0xC038,
    TLS_ECDHE_PSK_WITH_NULL_SHA=0xC039,
    TLS_ECDHE_PSK_WITH_NULL_SHA256=0xC03A,
    TLS_ECDHE_PSK_WITH_NULL_SHA384=0xC03B,
    TLS_RSA_WITH_ARIA_128_CBC_SHA256=0xC03C,
    TLS_RSA_WITH_ARIA_256_CBC_SHA384=0xC03D,
    TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256=0xC03E,
    TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384=0xC03F,
    TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256=0xC040,
    TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384=0xC041,
    TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256=0xC042,
    TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384=0xC043,
    TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256=0xC044,
    TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384=0xC045,
    TLS_DH_ANON_WITH_ARIA_128_CBC_SHA256=0xC046,
    TLS_DH_ANON_WITH_ARIA_256_CBC_SHA384=0xC047,
    TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256=0xC048,
    TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384=0xC049,
    TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256=0xC04A,
    TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384=0xC04B,
    TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256=0xC04C,
    TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384=0xC04D,
    TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256=0xC04E,
    TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384=0xC04F,
    TLS_RSA_WITH_ARIA_128_GCM_SHA256=0xC050,
    TLS_RSA_WITH_ARIA_256_GCM_SHA384=0xC051,
    TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256=0xC052,
    TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384=0xC053,
    TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256=0xC054,
    TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384=0xC055,
    TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256=0xC056,
    TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384=0xC057,
    TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256=0xC058,
    TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384=0xC059,
    TLS_DH_ANON_WITH_ARIA_128_GCM_SHA256=0xC05A,
    TLS_DH_ANON_WITH_ARIA_256_GCM_SHA384=0xC05B,
    TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256=0xC05C,
    TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384=0xC05D,
    TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256=0xC05E,
    TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384=0xC05F,
    TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256=0xC060,
    TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384=0xC061,
    TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256=0xC062,
    TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384=0xC063,
    TLS_PSK_WITH_ARIA_128_CBC_SHA256=0xC064,
    TLS_PSK_WITH_ARIA_256_CBC_SHA384=0xC065,
    TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256=0xC066,
    TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384=0xC067,
    TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256=0xC068,
    TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384=0xC069,
    TLS_PSK_WITH_ARIA_128_GCM_SHA256=0xC06A,
    TLS_PSK_WITH_ARIA_256_GCM_SHA384=0xC06B,
    TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256=0xC06C,
    TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384=0xC06D,
    TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256=0xC06E,
    TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384=0xC06F,
    TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256=0xC070,
    TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384=0xC071,
    TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256=0xC072,
    TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384=0xC073,
    TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256=0xC074,
    TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384=0xC075,
    TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256=0xC076,
    TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384=0xC077,
    TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256=0xC078,
    TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384=0xC079,
    TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256=0xC07A,
    TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384=0xC07B,
    TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256=0xC07C,
    TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384=0xC07D,
    TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256=0xC07E,
    TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384=0xC07F,
    TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256=0xC080,
    TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384=0xC081,
    TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256=0xC082,
    TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384=0xC083,
    TLS_DH_ANON_WITH_CAMELLIA_128_GCM_SHA256=0xC084,
    TLS_DH_ANON_WITH_CAMELLIA_256_GCM_SHA384=0xC085,
    TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256=0xC086,
    TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384=0xC087,
    TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256=0xC088,
    TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384=0xC089,
    TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256=0xC08A,
    TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384=0xC08B,
    TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256=0xC08C,
    TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384=0xC08D,
    TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256=0xC08E,
    TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384=0xC08F,
    TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256=0xC090,
    TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384=0xC091,
    TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256=0xC092,
    TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384=0xC093,
    TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256=0xC094,
    TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384=0xC095,
    TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256=0xC096,
    TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384=0xC097,
    TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256=0xC098,
    TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384=0xC099,
    TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256=0xC09A,
    TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384=0xC09B,
    TLS_RSA_WITH_AES_128_CCM=0xC09C,
    TLS_RSA_WITH_AES_256_CCM=0xC09D,
    TLS_DHE_RSA_WITH_AES_128_CCM=0xC09E,
    TLS_DHE_RSA_WITH_AES_256_CCM=0xC09F,
    TLS_RSA_WITH_AES_128_CCM_8=0xC0A0,
    TLS_RSA_WITH_AES_256_CCM_8=0xC0A1,
    TLS_DHE_RSA_WITH_AES_128_CCM_8=0xC0A2,
    TLS_DHE_RSA_WITH_AES_256_CCM_8=0xC0A3,
    TLS_PSK_WITH_AES_128_CCM=0xC0A4,
    TLS_PSK_WITH_AES_256_CCM=0xC0A5,
    TLS_DHE_PSK_WITH_AES_128_CCM=0xC0A6,
    TLS_DHE_PSK_WITH_AES_256_CCM=0xC0A7,
    TLS_PSK_WITH_AES_128_CCM_8=0xC0A8,
    TLS_PSK_WITH_AES_256_CCM_8=0xC0A9,
    TLS_PSK_DHE_WITH_AES_128_CCM_8=0xC0AA,
    TLS_PSK_DHE_WITH_AES_256_CCM_8=0xC0AB,
    TLS_ECDHE_ECDSA_WITH_AES_128_CCM=0xC0AC,
    TLS_ECDHE_ECDSA_WITH_AES_256_CCM=0xC0AD,
    TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8=0xC0AE,
    TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8=0xC0AF,
    TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256=0xCCA8,
    TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256=0xCCA9,
    TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256=0xCCAA,
    TLS_PSK_WITH_CHACHA20_POLY1305_SHA256=0xCCAB,
    TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256=0xCCAC,
    TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256=0xCCAD,
    TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256=0xCCAE,
    TLS_AES_128_GCM_SHA256=0x1301,
    TLS_AES_256_GCM_SHA384=0x1302,
    TLS_CHACHA20_POLY1305_SHA256=0x1303,
    TLS_AES_128_CCM_SHA256=0x1304,
    TLS_AES_128_CCM_8_SHA256=0x1305,
    TLS_NO_CIPHERSUITE=0xFFFF
};
   
Begin_Enum_String(tls_ciphersuite_t)
{
    Enum_String(TLS_NULL_WITH_NULL_NULL);
    Enum_String(TLS_RSA_WITH_NULL_MD5);
    Enum_String(TLS_RSA_WITH_NULL_SHA);
    Enum_String(TLS_RSA_EXPORT_WITH_RC4_40_MD5);
    Enum_String(TLS_RSA_WITH_RC4_128_MD5);
    Enum_String(TLS_RSA_WITH_RC4_128_SHA);
//    Enum_String(TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5);
//    Enum_String(TLS_RSA_WITH_IDEA_CBC_SHA);
    Enum_String(TLS_RSA_EXPORT_WITH_DES40_CBC_SHA);
    Enum_String(TLS_RSA_WITH_DES_CBC_SHA);
    Enum_String(TLS_RSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_DES_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_DES_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_DES_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_DES_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_DH_ANON_EXPORT_WITH_RC4_40_MD5);
    Enum_String(TLS_DH_ANON_WITH_RC4_128_MD5);
    Enum_String(TLS_DH_ANON_EXPORT_WITH_DES40_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_DES_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_KRB5_WITH_DES_CBC_SHA);
    Enum_String(TLS_KRB5_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_KRB5_WITH_RC4_128_SHA);
//    Enum_String(TLS_KRB5_WITH_IDEA_CBC_SHA);
    Enum_String(TLS_KRB5_WITH_DES_CBC_MD5);
    Enum_String(TLS_KRB5_WITH_3DES_EDE_CBC_MD5);
    Enum_String(TLS_KRB5_WITH_RC4_128_MD5);
//    Enum_String(TLS_KRB5_WITH_IDEA_CBC_MD5);
    Enum_String(TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA);
//    Enum_String(TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA);
    Enum_String(TLS_KRB5_EXPORT_WITH_RC4_40_SHA);
    Enum_String(TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5);
//    Enum_String(TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5);
    Enum_String(TLS_KRB5_EXPORT_WITH_RC4_40_MD5);
    Enum_String(TLS_PSK_WITH_NULL_SHA);
    Enum_String(TLS_DHE_PSK_WITH_NULL_SHA);
    Enum_String(TLS_RSA_PSK_WITH_NULL_SHA);
    Enum_String(TLS_RSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_RSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_RSA_WITH_NULL_SHA256);
    Enum_String(TLS_RSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_RSA_WITH_AES_256_CBC_SHA256);
    Enum_String(TLS_DH_DSS_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_DH_RSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_RSA_WITH_CAMELLIA_128_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_DH_DSS_WITH_AES_256_CBC_SHA256);
    Enum_String(TLS_DH_RSA_WITH_AES_256_CBC_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_AES_256_CBC_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_AES_256_CBC_SHA256);
    Enum_String(TLS_DH_ANON_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_DH_ANON_WITH_AES_256_CBC_SHA256);
    Enum_String(TLS_RSA_WITH_CAMELLIA_256_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA);
    Enum_String(TLS_PSK_WITH_RC4_128_SHA);
    Enum_String(TLS_PSK_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_PSK_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_PSK_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_DHE_PSK_WITH_RC4_128_SHA);
    Enum_String(TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_DHE_PSK_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_DHE_PSK_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_RSA_PSK_WITH_RC4_128_SHA);
    Enum_String(TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_RSA_PSK_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_RSA_PSK_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_RSA_WITH_SEED_CBC_SHA);
    Enum_String(TLS_DH_DSS_WITH_SEED_CBC_SHA);
    Enum_String(TLS_DH_RSA_WITH_SEED_CBC_SHA);
    Enum_String(TLS_DHE_DSS_WITH_SEED_CBC_SHA);
    Enum_String(TLS_DHE_RSA_WITH_SEED_CBC_SHA);
    Enum_String(TLS_DH_ANON_WITH_SEED_CBC_SHA);
    Enum_String(TLS_RSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_RSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_DHE_RSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_DH_RSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_DH_RSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_DHE_DSS_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_DH_DSS_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_DH_DSS_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_DH_ANON_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_DH_ANON_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_PSK_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_PSK_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_PSK_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_PSK_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_PSK_WITH_NULL_SHA256);
    Enum_String(TLS_PSK_WITH_NULL_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_NULL_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_NULL_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_NULL_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_NULL_SHA384);
    Enum_String(TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256);
    Enum_String(TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256);
    Enum_String(TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256);
    Enum_String(TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_NULL_SHA);
    Enum_String(TLS_ECDH_ECDSA_WITH_RC4_128_SHA);
    Enum_String(TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_ECDHE_ECDSA_WITH_NULL_SHA);
    Enum_String(TLS_ECDHE_ECDSA_WITH_RC4_128_SHA);
    Enum_String(TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_ECDH_RSA_WITH_NULL_SHA);
    Enum_String(TLS_ECDH_RSA_WITH_RC4_128_SHA);
    Enum_String(TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_ECDH_RSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_ECDH_RSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_ECDHE_RSA_WITH_NULL_SHA);
    Enum_String(TLS_ECDHE_RSA_WITH_RC4_128_SHA);
    Enum_String(TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_ECDH_ANON_WITH_NULL_SHA);
    Enum_String(TLS_ECDH_ANON_WITH_RC4_128_SHA);
    Enum_String(TLS_ECDH_ANON_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_ECDH_ANON_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_ECDH_ANON_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_SRP_SHA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_SRP_SHA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256);
    Enum_String(TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_PSK_WITH_RC4_128_SHA);
    Enum_String(TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA);
    Enum_String(TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA);
    Enum_String(TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA);
    Enum_String(TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_PSK_WITH_NULL_SHA);
    Enum_String(TLS_ECDHE_PSK_WITH_NULL_SHA256);
    Enum_String(TLS_ECDHE_PSK_WITH_NULL_SHA384);
    Enum_String(TLS_RSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_RSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_DH_ANON_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_DH_ANON_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_RSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_RSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_DH_ANON_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_DH_ANON_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_PSK_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_PSK_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_PSK_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_PSK_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_DH_ANON_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_DH_ANON_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384);
    Enum_String(TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256);
    Enum_String(TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384);
    Enum_String(TLS_RSA_WITH_AES_128_CCM);
    Enum_String(TLS_RSA_WITH_AES_256_CCM);
    Enum_String(TLS_DHE_RSA_WITH_AES_128_CCM);
    Enum_String(TLS_DHE_RSA_WITH_AES_256_CCM);
    Enum_String(TLS_RSA_WITH_AES_128_CCM_8);
    Enum_String(TLS_RSA_WITH_AES_256_CCM_8);
    Enum_String(TLS_DHE_RSA_WITH_AES_128_CCM_8);
    Enum_String(TLS_DHE_RSA_WITH_AES_256_CCM_8);
    Enum_String(TLS_PSK_WITH_AES_128_CCM);
    Enum_String(TLS_PSK_WITH_AES_256_CCM);
    Enum_String(TLS_DHE_PSK_WITH_AES_128_CCM);
    Enum_String(TLS_DHE_PSK_WITH_AES_256_CCM);
    Enum_String(TLS_PSK_WITH_AES_128_CCM_8);
    Enum_String(TLS_PSK_WITH_AES_256_CCM_8);
    Enum_String(TLS_PSK_DHE_WITH_AES_128_CCM_8);
    Enum_String(TLS_PSK_DHE_WITH_AES_256_CCM_8);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_128_CCM);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_256_CCM);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8);
    Enum_String(TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8);
    Enum_String(TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_PSK_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_AES_128_GCM_SHA256);
    Enum_String(TLS_AES_256_GCM_SHA384);
    Enum_String(TLS_CHACHA20_POLY1305_SHA256);
    Enum_String(TLS_AES_128_CCM_SHA256);
    Enum_String(TLS_AES_128_CCM_8_SHA256);
    Enum_String(TLS_NO_CIPHERSUITE);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Wifi type field
/// @param WIFIMNG - Wifi Management frame type
/// @param WIFIDAT - Wifi Data frame type
/// @param WIFICTL - Wifi Control frame type
//////////////////////////////////////////////////////////////////////
enum wifitype_t { /// Management frame
    WIFIMNG,      /// Data frame
    WIFIDAT,      /// Control frame
    WIFICTL
};

Begin_Enum_String(wifitype_t)
{
    Enum_String(WIFIMNG);
    Enum_String(WIFIDAT);
    Enum_String(WIFICTL);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Wifi subtype field
/// NOTE : bit ordering is opposite to spec (i.e., B4_B5_B6_B7)
///        according to how they appear in the packet header such
///        that WIFI1=0x8, WIFI5=0x2, etc. For example, if it's
///        a management packet with ATM subtype you would use
///        WIFI9. A control packet with RTS subtype would use
///        WIFI11, etc
///
/// Due to the various meanings of the subtype based on the type,
/// generic enums are provided for the subtype field
///
/// @param WIFI0 - Management(WIFI0) Association Request / Control - RSVD / Data - Data
/// @param WIFI8 - Management(WIFI8) Beacon / Control - Block ACK Request (BlockAckReq) / Data - QoS Data
/// @param WIFI4 - Management(WIFI4) Probe Request / Control - RSVD / Data - Null (no data)
/// @param WIFI12 - Management(WIFI12) Deauthentication / Control - CTS / Data - QoS Null (no data)
/// @param WIFI2 - Management(WIFI2) Reassociation Request / Control - RSVD / Data - Data + CF-Poll
/// @param WIFI10 - Management(WIFI10) Disassociation / Control - PS-Poll / Data - QoS Data + CF-Poll
/// @param WIFI6 - Management(WIFI6) Timing Advertisement / Control - RSVD / Data - CF-Poll (no data)
/// @param WIFI14 - Management(WIFI14) Action No ACK / Control - CF-End / Data - QoS CF-Poll (no data)
/// @param WIFI1 - Management(WIFI1) Association Response / Control - RSVD / Data - Data + CF-Ack
/// @param WIFI9 - Management(WIFI9) ATM / Control - Block ACK (BlockAck) / Data - QoS Data + CF-Ack
/// @param WIFI5 - Management(WIFI5) Probe Response / Control - RSVD / Data - CF-Ack (no data)
/// @param WIFI13 - Management(WIFI13) Action / Control - ACK / Data - RSVD
/// @param WIFI3 - Management(WIFI3) Reassociation Response / Control - RSVD / Data - Data + CF-Ack + CF-Poll
/// @param WIFI11 - Management(WIFI11) Authentication / Control - RTS / Data - QoS Data + CF-Ack + CF-Poll
/// @param WIFI7 - Management(WIFI7) RSVD / Control - Control Wrapper / Data - CF-Ack + CF-Poll (no data)
/// @param WIFI15 - Management(WIFI15) RSVD / Control - CF-End + CF-Ack / Data - QoS CF-Ack + CF-Poll (no data)
//////////////////////////////////////////////////////////////////////
enum wifisub_t {/// Management(WIFI0)  - Association Request / Control - RSVD / Data - Data
    WIFI0,      /// Management(WIFI8)  - Beacon / Control - Block ACK Request (BlockAckReq) / Data - QoS Data
    WIFI8,      /// Management(WIFI4)  - Probe Request / Control - RSVD / Data - Null (no data)
    WIFI4,      /// Management(WIFI12) - Deauthentication / Control - CTS / Data - QoS Null (no data)
    WIFI12,     /// Management(WIFI2)  - Reassociation Request / Control - RSVD / Data - Data + CF-Poll
    WIFI2,      /// Management(WIFI10) - Disassociation / Control - PS-Poll / Data - QoS Data + CF-Poll
    WIFI10,     /// Management(WIFI6)  - Timing Advertisement / Control - RSVD / Data - CF-Poll (no data)
    WIFI6,      /// Management(WIFI14) - Action No ACK / Control - CF-End / Data - QoS CF-Poll (no data)
    WIFI14,     /// Management(WIFI1)  - Association Response / Control - RSVD / Data - Data + CF-Ack
    WIFI1,      /// Management(WIFI9)  - ATM / Control - Block ACK (BlockAck) / Data - QoS Data + CF-Ack
    WIFI9,      /// Management(WIFI5)  - Probe Response / Control - RSVD / Data - CF-Ack (no data)
    WIFI5,      /// Management(WIFI13) - Action / Control - ACK / Data - RSVD
    WIFI13,     /// Management(WIFI3)  - Reassociation Response / Control - RSVD / Data - Data + CF-Ack + CF-Poll
    WIFI3,      /// Management(WIFI11) - Authentication / Control - RTS / Data - QoS Data + CF-Ack + CF-Poll
    WIFI11,     /// Management(WIFI7)  - RSVD / Control - Control Wrapper / Data - CF-Ack + CF-Poll (no data)
    WIFI7,      /// Management(WIFI15) - RSVD / Control - CF-End + CF-Ack / Data - QoS CF-Ack + CF-Poll (no data)
    WIFI15
};

Begin_Enum_String(wifisub_t)
{
    Enum_String(WIFI0);
    Enum_String(WIFI8);
    Enum_String(WIFI4);
    Enum_String(WIFI12);
    Enum_String(WIFI2);
    Enum_String(WIFI10);
    Enum_String(WIFI6);
    Enum_String(WIFI14);
    Enum_String(WIFI1);
    Enum_String(WIFI9);
    Enum_String(WIFI5);
    Enum_String(WIFI13);
    Enum_String(WIFI3);
    Enum_String(WIFI11);
    Enum_String(WIFI7);
    Enum_String(WIFI15);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Wifi Control field extensions
/// @param WCTRL0 - Reserved
/// @param SSW - Wifi SSW extension
/// @param GRANT - Wifi GRANT extension
/// @param WCTRL3 - Reserved
/// @param POLL - Wifi POLL extension
/// @param SSWACK - Wifi SSWACK extension
/// @param DMGDTS - Wifi DMGDTS extension
/// @param WCTRL7 - Reserved
/// @param WCTRL8 - Reserved
/// @param SSWFDBCK - Wifi SSWFDBCK extension
/// @param DMGCTS - Wifi DMGCTS extension
/// @param WCTRL11 - Reserved
/// @param SPR - Wifi SPR extension
/// @param WCTRL13 - Reserved
/// @param GRANTACK - Wifi GRANTACK extension
//////////////////////////////////////////////////////////////////////
enum wifictlext_t { /// Reserved
    WCTRL0,         /// Wifi SSW extension
    SSW,            /// Wifi GRANT extension
    GRANT,          /// Reserved
    WCTRL3,         /// Wifi POLL extension
    POLL,           /// Wifi SSWACK extension
    SSWACK,         /// Wifi DMGDTS extension
    DMGDTS,         /// Reserved
    WCTRL7,         /// Reserved
    WCTRL8,         /// Wifi SSWFDBCK extension
    SSWFDBCK,       /// Wifi DMGCTS extension
    DMGCTS,         /// Reserved
    WCTRL11,        /// Wifi SPR extension
    SPR,            /// Reserved
    WCTRL13,        /// Wifi GRANTACK extension
    GRANTACK
};

Begin_Enum_String(wifictlext_t)
{
    Enum_String(WCTRL0);
    Enum_String(SSW);
    Enum_String(GRANT);
    Enum_String(WCTRL3);
    Enum_String(POLL);
    Enum_String(SSWACK);
    Enum_String(DMGDTS);
    Enum_String(WCTRL7);
    Enum_String(WCTRL8);
    Enum_String(SSWFDBCK);
    Enum_String(DMGCTS);
    Enum_String(WCTRL11);
    Enum_String(SPR);
    Enum_String(WCTRL13);
    Enum_String(GRANTACK);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// Wimax fields
/// @param OFDM - Orthogonal frequency division multiplexing
/// @param OFDMA - Orthogonal frequency division multiple access
/// @param AGMH_OFDM - Advanced GMH with OFDM
/// @param AGMH_OFDMA - Advanced GMH with OFDMA
//////////////////////////////////////////////////////////////////////
enum wimaxmode_t {/// Orthogonal frequency division multiplexing
    OFDM,         /// Orthogonal frequency division multiple access
    OFDMA,        /// Advanced GMH header with OFDM
    AGMH_OFDM,    /// Advanced GMH header with OFDMA
    AGMH_OFDMA
};

Begin_Enum_String(wimaxmode_t)
{
    Enum_String(OFDM);
    Enum_String(OFDMA);
    Enum_String(AGMH_OFDM);
    Enum_String(AGMH_OFDMA);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// MACSEC Encryption Modes of Operation
/// @param AES_GCM_128 - AES-GCM with 128-bit key
/// @param AES_GCM_256 - AES-GCM with 256-bit key
/// @param AES_GCM_XPN_128 - AES-GCM with extended packet number and 128-bit key
/// @param AES_GCM_XPN_256 - AES-GCM with extended packet number and 256-bit key
/// @param NULL_MACSEC - Authenticate only mode AES-GMAC
//////////////////////////////////////////////////////////////////////
enum macsecmode_t {  /// AES-GCM with 128-bit key
    AES_GCM_128,     /// AES-GCM with 256-bit key
    AES_GCM_256,     /// AES-GCM with extended packet number and 128-bit key
    AES_GCM_XPN_128, /// AES-GCM with extended packet number and 256-bit key
    AES_GCM_XPN_256, /// Authenticate only with AES-GMAC
    NULL_MACSEC
};

Begin_Enum_String(macsecmode_t)
{
    Enum_String(AES_GCM_128);
    Enum_String(AES_GCM_256);
    Enum_String(AES_GCM_XPN_128);
    Enum_String(AES_GCM_XPN_256);
    Enum_String(NULL_MACSEC);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 DIR_ID fields
/// @param DIR_IN - Direction of processing is into host
/// @param DIR_FWD - Forward packets on this stream
/// @param DIR_OUT - Direction of processing is out of the host
//////////////////////////////////////////////////////////////////////
enum dir_id_t {/// Direction of processing is into host
    DIR_IN,    /// Forward packets on this stream
    DIR_FWD,   /// Direction of processing is out of the host
    DIR_OUT
};

Begin_Enum_String(dir_id_t) {
    Enum_String(DIR_IN);
    Enum_String(DIR_FWD);
    Enum_String(DIR_OUT);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 ROLE_ID fields
/// @param ROLE_INITIATOR - Initiator role
/// @param ROLE_RESPONDER - Responder role
/// @param ROLE_ANY - Both an initiator and receiver
//////////////////////////////////////////////////////////////////////
enum role_id_t {         /// Initiator role
    ROLE_INITIATOR=0x08, /// Responder role
    ROLE_RESPONDER=0x20, /// Both an initiator and receiver
    ROLE_ANY=0x28
};

Begin_Enum_String(role_id_t) {
    Enum_String(ROLE_INITIATOR);
    Enum_String(ROLE_RESPONDER);
    Enum_String(ROLE_ANY);
}
End_Enum_String;


//////////////////////////////////////////////////////////////////////
/// IKEv2 IPSEC MODE fields
/// @param TRANSPORT_MODE - IPsec Transport Mode
/// @param TUNNEL_MODE - IPsec Tunnel Mode
//////////////////////////////////////////////////////////////////////
enum ipsec_mode_t { /// IPsec Transport Mode
    TRANSPORT_MODE, /// IPsec Tunnel Mode
    TUNNEL_MODE
};

Begin_Enum_String(ipsec_mode_t) {
    Enum_String(TRANSPORT_MODE);
    Enum_String(TUNNEL_MODE);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 Exchange Type fields
/// @param EXCHG_IKE_SA_INIT - IKE Security Association Initial Exchange
/// @param EXCHG_IKE_AUTH - IKE Authentication Exchange
/// @param EXCHG_CREATE_CHILD_SA - Create Child Security Association Exchange
/// @param EXCHG_INFORMATIONAL - INFORMATIONAL Exchange
/// @param EXCHG_IKE_SESSION_RESUME - IKE Session Resume Exchange
/// @param EXCHG_GSA_AUTH - GSA Authentication Exchange
/// @param EXCHG_GSA_REGISTRATION - GSA Registration Exchange
/// @param EXCHG_GSA_REKEY - GSA Rekey Exchange
/// @param EXCHG_IKE_PARSE - Parse the received packet
/// @param EXCHG_IKE_RESEND - Resend the packet
/// @param EXCHG_IKE_LISTEN - Set IKE in LISTEN mode on the socket
//////////////////////////////////////////////////////////////////////
enum exchg_t {                /// IKE Security Association Initial Exchange
    EXCHG_IKE_SA_INIT=34,     /// IKE Authentication Exchange
    EXCHG_IKE_AUTH,           /// Create Child Security Association Exchange
    EXCHG_CREATE_CHILD_SA,    /// INFORMATIONAL Exchange
    EXCHG_INFORMATIONAL,      /// IKE Session Resume Exchange
    EXCHG_IKE_SESSION_RESUME, /// GSA Authentication Exchange
    EXCHG_GSA_AUTH,           /// GSA Registration Exchange
    EXCHG_GSA_REGISTRATION,   /// GSA Rekey Exchange
    EXCHG_GSA_REKEY,          /// Parse the received packet
    EXCHG_IKE_PARSE=253,      /// Resend the packet
    EXCHG_IKE_RESEND,         /// Set IKE in LISTEN mode on the socket
    EXCHG_IKE_LISTEN
};

Begin_Enum_String(exchg_t) {
    Enum_String(EXCHG_IKE_SA_INIT);
    Enum_String(EXCHG_IKE_AUTH);
    Enum_String(EXCHG_CREATE_CHILD_SA);
    Enum_String(EXCHG_INFORMATIONAL);
    Enum_String(EXCHG_IKE_SESSION_RESUME);
    Enum_String(EXCHG_GSA_AUTH);
    Enum_String(EXCHG_GSA_REGISTRATION);
    Enum_String(EXCHG_GSA_REKEY);
    Enum_String(EXCHG_IKE_PARSE);
    Enum_String(EXCHG_IKE_RESEND);
    Enum_String(EXCHG_IKE_LISTEN);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 Payload Type fields
/// @param PYLD_NONE - No Next Payload 
/// @param PYLD_SA - Security Association  
/// @param PYLD_KE - Key Exchange
/// @param PYLD_IDI - Identification Initiator
/// @param PYLD_IDR - Identification Responder
/// @param PYLD_CERT - Certificate
/// @param PYLD_CERTREQ - Certificate Request
/// @param PYLD_AUTH - Authentication
/// @param PYLD_NINR - Nonce
/// @param PYLD_N - Notify
/// @param PYLD_D - Delete
/// @param PYLD_V - Vendor ID
/// @param PYLD_TSI - Traffic Selector Initiator
/// @param PYLD_TSR - Traffic Selector Responder
/// @param PYLD_SK - Encrypted and Authenticated
/// @param PYLD_CP - Configuration
/// @param PYLD_EAP - Extensible Authentication
/// @param PYLD_GSPM - Generic Secure Password Method
/// @param PYLD_IDG - Group Identification
/// @param PYLD_GSA - Group Security Association
/// @param PYLD_KD - Key Download
/// @param PYLD_SKF - Encrypted and Authenticated Fragment
/// @param PYLD_PS - Puzzle Solution
//////////////////////////////////////////////////////////////////////
enum ike_pyld_t { /// No Next Payload
    PYLD_NONE=0,  /// Security Association
    PYLD_SA=33,   /// Key Exchange  
    PYLD_KE,      /// Identification Initiator
    PYLD_IDI,     /// Identification Responder
    PYLD_IDR,     /// Certificate
    PYLD_CERT,    /// Certificate Request
    PYLD_CERTREQ, /// Authentication
    PYLD_AUTH,    /// Nonce
    PYLD_NINR,    /// Nofify
    PYLD_N,       /// Delete
    PYLD_D,       /// Vendor ID
    PYLD_V,       /// Traffic Selector Initiator
    PYLD_TSI,     /// Traffic Selector Responder
    PYLD_TSR,     /// Encrypted and Authenticated
    PYLD_SK,      /// Configuration
    PYLD_CP,      /// Extensible Authentication
    PYLD_EAP,     /// Generic Secure Password Method
    PYLD_GSPM,    /// Group Identification
    PYLD_IDG,     /// Group Security Association
    PYLD_GSA,     /// Key Download
    PYLD_KD,      /// Encrypted and Authenticated Fragment
    PYLD_SKF,     /// Puzzle Solution
    PYLD_PS
};

Begin_Enum_String(ike_pyld_t) {
    Enum_String(PYLD_NONE);
    Enum_String(PYLD_SA);
    Enum_String(PYLD_KE);
    Enum_String(PYLD_IDI);
    Enum_String(PYLD_IDR);
    Enum_String(PYLD_CERT);
    Enum_String(PYLD_CERTREQ);
    Enum_String(PYLD_AUTH);
    Enum_String(PYLD_NINR);
    Enum_String(PYLD_N);
    Enum_String(PYLD_D);
    Enum_String(PYLD_V);
    Enum_String(PYLD_TSI);
    Enum_String(PYLD_TSR);
    Enum_String(PYLD_SK);
    Enum_String(PYLD_CP);
    Enum_String(PYLD_EAP);
    Enum_String(PYLD_GSPM);
    Enum_String(PYLD_IDG);
    Enum_String(PYLD_GSA);
    Enum_String(PYLD_KD);
    Enum_String(PYLD_SKF);
    Enum_String(PYLD_PS);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 TRANSFORM TYPES fields
/// @param IKE_ENCR - Encryption transform
/// @param IKE_INTEG - Authentication transform
/// @param IKE_DH - Diffie-Hellman transform
/// @param IKE_PRF - Pseudo Random Function transform
/// @param IKE_ESN -  Extended Sequence Number transform
//////////////////////////////////////////////////////////////////////
enum transform_type_t {/// Encryption transform
    IKE_ENCR=1,        /// Psuedo Random Function transform
    IKE_PRF,           /// Authentication transform
    IKE_INTEG,         /// Diffie-Hellman transform
    IKE_DH,            /// Extended Sequence Number transform
    IKE_ESN
};

Begin_Enum_String(transform_type_t) {
    Enum_String(IKE_ENCR);
    Enum_String(IKE_PRF);
    Enum_String(IKE_INTEG);
    Enum_String(IKE_DH);
    Enum_String(IKE_ESN);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 TRANSFORM ATTRIBUTE TYPES fields
/// @param ATTR_KEY_LENGTH - Key Length Attribute
//////////////////////////////////////////////////////////////////////
enum transform_attr_t {/// Key Length Attribugte
    ATTR_KEY_LENGTH=14
};

Begin_Enum_String(transform_attr_t) {
    Enum_String(ATTR_KEY_LENGTH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 ENCR_ID fields
/// @param ENCR_DES_IV64 - Data Encryption Standard (DES) with 64-bit IV
/// @param ENCR_DES - Data Encryption Standard (DES)
/// @param ENCR_3DES - Triple DES with three separate keys
/// @param ENCR_RC5 - RC5 Encryption
/// @param ENCR_IDEA - IDEA Encryption
/// @param ENCR_CAST - Cast Encryption
/// @param ENCR_BLOWFISH - Blowfish encrytpion
/// @param ENCR_3IDEA - Three key IDEA
/// @param ENCR_DES_IV32 - Data Encryption Standard (DES) with 32-bit IV
/// @param ENCR_RSVD1 - Reserved
/// @param ENCR_NULL - NULL Encryption (NOT ALLOWED)
/// @param ENCR_AES_CBC - AES-CBC Encryption
/// @param ENCR_AES_CTR - AES-CTR Encryption
/// @param ENCR_AES_CCM_8 - AES-CCM Encryption with 8-byte ICV
/// @param ENCR_AES_CCM_12 - AES-CCM Encryption with 12-byte ICV
/// @param ENCR_AES_CCM_16 - AES-CCM Encryption with 16-byte ICV
/// @param ENCR_UNASSIGNED - Unassigned
/// @param ENCR_AES_GCM_8 - AES-GCM Encryption with 8-byte ICV
/// @param ENCR_AES_GCM_12 - AES-GCM Encrytion with 12-byte ICV
/// @param ENCR_AES_GCM_16 - AES-GCM Encryption with 16-byte ICV
/// @param ENCR_NULL_AUTH_AES_GMAC - Null Encryption with AES-GMAC Authentication (NOT ALLOWED)
/// @param ENCR_RSVD_AES_XTS - Reserved for IEEE P1619 XTS-AES
/// @param ENCR_CAMELLIA_CBC - Camellia-CBC Encryption
/// @param ENCR_CAMELLIA_CTR - Camellia-CTR Encryption
/// @param ENCR_CAMELLIA_CCM_8 - Camellia-CCM Encryption with 8-byte ICV
/// @param ENCR_CAMELLIA_CCM_12 - Camellia-CCM Encryption with 12-byte ICV
/// @param ENCR_CAMELLIA_CCM_16 - Camellia-CCM Encryption with 16-byte ICV
/// @param ENCR_CHACHA20_POLY1305 - CHACHA20 Encryption with POLY1305 Authentication and 16-byte ICV
/// @param ENCR_AES_CCM_8_IIV - AES-CCM Encryption with 8-byte ICV and Implicit IV
/// @param ENCR_AES_GCM_16_IIV - AES-GCM Encryption with 16-byte ICV and Implicit IV
/// @param ENCR_CHACHA20_POLY1305_IIV - CHACHA20 Encryption with POLY1305 Authentication and 16-byte ICV with Implicit IV
//////////////////////////////////////////////////////////////////////
enum encr_id_t {           /// Data Encryption Standard (DES) with 64-bit IV
    ENCR_DES_IV64=1,       /// Data Encrytpion Standard (DES)
    ENCR_DES,              /// Triple DES with separate keys
    ENCR_3DES,             /// RC5 Encryption
    ENCR_RC5,              /// IDEA Encryption
    ENCR_IDEA,             /// Cast Encryption
    ENCR_CAST,             /// Blowfish Encryption
    ENCR_BLOWFISH,         /// Three key IDEA Encryption
    ENCR_3IDEA,            /// Data Encryption Standard with 32-bit IV
    ENCR_DES_IV32,         /// Reserved
    ENCR_RSVD1,            /// Null Encryption (NOT ALLOWED)
    ENCR_NULL,             /// AES-CBC Encryption
    ENCR_AES_CBC,          /// AES-CTR Encryption
    ENCR_AES_CTR,          /// AES-CCM Encryption with 8-byte ICV
    ENCR_AES_CCM_8,        /// AES-CCM Encryption with 12-byte ICV
    ENCR_AES_CCM_12,       /// AES-CCM Encryption with 16-byte ICV
    ENCR_AES_CCM_16,       /// Unassigned
    ENCR_UNASSIGNED,       /// AES-GCM Encryption with 8-byte ICV
    ENCR_AES_GCM_8,        /// AES-GCM Encryption with 12-byte ICV
    ENCR_AES_GCM_12,       /// AES-GCM Encrytpion with 16-byte ICV
    ENCR_AES_GCM_16,       /// Null Encryption with AES-GMAC Authentication (NOT ALLOWED)
    ENCR_NULL_AUTH_AES_GMAC,/// Reserved for IEEE P1619 XTS-AES
    ENCR_RSVD_AES_XTS,     /// Camellia-CBC Encryption
    ENCR_CAMELLIA_CBC,     /// Camellia-CTR Encryption
    ENCR_CAMELLIA_CTR,     /// Camellia-CCM Encryption with 8-byte ICV
    ENCR_CAMELLIA_CCM_8,   /// Camellia-CCM Encryption with 12-byte ICV
    ENCR_CAMELLIA_CCM_12,  /// Camellia-CCM Encryption with 16-byte ICV
    ENCR_CAMELLIA_CCM_16,  /// CHACHA20 Encryption with POLY1305 Authentication and 16-byte ICV
    ENCR_CHACHA20_POLY1305,/// AES-CCM Encryption with 8-byte ICV and Implicit IV
    ENCR_AES_CCM_8_IIV,    /// AES-GCM Encryption with 16-byte ICV and Implicit IV
    ENCR_AES_GCM_16_IIV,   /// CHACHA20 Encryption with POLY1305 Authentication and 16-byte ICV with Implicit IV
    ENCR_CHACHA20_POLY1305_IIV
};

Begin_Enum_String(encr_id_t) {
    Enum_String(ENCR_DES_IV64);
    Enum_String(ENCR_DES);
    Enum_String(ENCR_3DES);
    Enum_String(ENCR_RC5);
    Enum_String(ENCR_IDEA);
    Enum_String(ENCR_CAST);
    Enum_String(ENCR_BLOWFISH);
    Enum_String(ENCR_3IDEA);
    Enum_String(ENCR_DES_IV32);
    Enum_String(ENCR_RSVD1);
    Enum_String(ENCR_NULL);
    Enum_String(ENCR_AES_CBC);
    Enum_String(ENCR_AES_CTR);
    Enum_String(ENCR_AES_CCM_8);
    Enum_String(ENCR_AES_CCM_12);
    Enum_String(ENCR_AES_CCM_16);
    Enum_String(ENCR_UNASSIGNED);
    Enum_String(ENCR_AES_GCM_8);
    Enum_String(ENCR_AES_GCM_12);
    Enum_String(ENCR_AES_GCM_16);
    Enum_String(ENCR_NULL_AUTH_AES_GMAC);
    Enum_String(ENCR_RSVD_AES_XTS);
    Enum_String(ENCR_CAMELLIA_CBC);
    Enum_String(ENCR_CAMELLIA_CTR);
    Enum_String(ENCR_CAMELLIA_CCM_8);
    Enum_String(ENCR_CAMELLIA_CCM_12);
    Enum_String(ENCR_CAMELLIA_CCM_16);
    Enum_String(ENCR_CHACHA20_POLY1305);
    Enum_String(ENCR_AES_CCM_8_IIV);
    Enum_String(ENCR_AES_GCM_16_IIV);
    Enum_String(ENCR_CHACHA20_POLY1305_IIV);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 PRF_ID fields
/// @param PRF_HMAC_MD5 - HMAC-MD5 Pseudo Random Function with 16-byte ICV
/// @param PRF_HMAC_SHA1 - HMAC-SHA1 Pseudo Random Function with 20-byte ICV
/// @param PRF_HMAC_TIGER - HMAC-TIGER Pseudo Random Function
/// @param PRF_AES128_XCBC - AES-XCBC Pseudo Random Function with 128-bit key and 16-byte ICV
/// @param PRF_HMAC_SHA2_256 - HMAC-SHA2-256 Authenticaiton with 32-byte ICV
/// @param PRF_HMAC_SHA2_384 - HMAC-SHA2-384 Pseudo Random Function with 48-byte ICV
/// @param PRF_HMAC_SHA2_512 - HMAC-SHA2-512 Pseudo Random Function with 64-byte ICV
/// @param PRF_AES128_CMAC - AES-CMAC Pseudo Random Function with 128-bit key and 16-byte ICV
//////////////////////////////////////////////////////////////////////
enum prf_id_t {        /// HMAC-MD5 Pseudo Random Function with 16-byte ICV
    PRF_HMAC_MD5=1,    /// HMAC-SHA1 Pseudo Random Function with 20-byte ICV
    PRF_HMAC_SHA1,     /// HMAC-TIGER Pseudo Random Function
    PRF_HMAC_TIGER,    /// AES-XCBC Pseudo Random Function with 128-bit key and 16-byte ICV
    PRF_AES128_XCBC,   /// HMAC-SHA2-256 Pseudo Random Function with 32-byte ICV
    PRF_HMAC_SHA2_256, /// HMAC-SHA2-384 Pseudo Random Function with 48-byte ICV
    PRF_HMAC_SHA2_384, /// HMAC-SHA2-512 Pseudo Random Function with 64-byte ICV
    PRF_HMAC_SHA2_512, /// AES-CMAC Psuedo Random Function with 128-bit key and 16-byte ICV
    PRF_AES128_CMAC
};

Begin_Enum_String(prf_id_t) {
    Enum_String(PRF_HMAC_MD5);
    Enum_String(PRF_HMAC_SHA1);
    Enum_String(PRF_HMAC_TIGER);
    Enum_String(PRF_AES128_XCBC);
    Enum_String(PRF_HMAC_SHA2_256);
    Enum_String(PRF_HMAC_SHA2_384);
    Enum_String(PRF_HMAC_SHA2_512);
    Enum_String(PRF_AES128_CMAC);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 INTEG_ID fields
/// @param AUTH_NONE - No Authentication
/// @param AUTH_HMAC_MD5_96 - HMAC-MD5-96 Authentication with 96-bit ICV
/// @param AUTH_HMAC_SHA1_96 - HMAC-SHA1-96 Authentication with 96-bit ICV
/// @param AUTH_DES_MAC - DES-MAC Authentication with 64-bit ICV
/// @param AUTH_KPDK_MD5 - KPDK_MD5 Authentication with 128-bit ICV
/// @param AUTH_AES_XCBC_96 - AES-XCBC-96 Authentication with 96-bit ICV
/// @param AUTH_HMAC_MD5_128 - HMAC-MD5-128 Authentication with 128-bit ICV
/// @param AUTH_HMAC_SHA1_160 - HMAC-SHA1-160 Authentication with 160-bit ICV
/// @param AUTH_AES_CMAC_95 - AES-CMAC-96 Authentication with 96-bit ICV
/// @param AUTH_AES_128_GMAC - AES-128-GMAC Authentication with 128-bit ICV
/// @param AUTH_AES_192_GMAC - AES-192-GMAC Authentication with 192-bit ICV
/// @param AUTH_AES_256_GMAC - AES-256-GMAC Authentication with 256-bit ICV
/// @param AUTH_HMAC_SHA2_256_128 - HMAC-SHA2-256 Authentication with 128-bit ICV
/// @param AUTH_HMAC_SHA2_384_192 - HMAC-SHA2-384 Authentication with 192-bit ICV
/// @param AUTH_HMAC_SHA2_512_256 - HMAC-SHA2-512 Authentication with 256-bit ICV
/// @param AUTH_NONE - No Authentication
//////////////////////////////////////////////////////////////////////
enum integ_id_t {           /// No Authentication
    AUTH_NONE,              /// HMAC-MD5-96 Authentication with 96-bit ICV
    AUTH_HMAC_MD5_96,       /// HMAC-SHA1-96 Authentication with 96-bit ICV
    AUTH_HMAC_SHA1_96,      /// DES-MAC Authentication with 64-bit ICV
    AUTH_DES_MAC,           /// KPDK_MD5 Authentication with 128-bit ICV
    AUTH_KPDK_MD5,          /// AES-XCBC-96 Authentication with 96-bit ICV
    AUTH_AES_XCBC_96,       /// HMAC-MD5-128 Authentication with 128-bit ICV
    AUTH_HMAC_MD5_128,      /// HMAC-SHA1-160 Authentication with 160-bit ICV
    AUTH_HMAC_SHA1_160,     /// AES-CMAC-96 Authentication with 96-bit ICV
    AUTH_AES_CMAC_96,       /// AES-128-GMAC Authentication with 128-bit ICV
    AUTH_AES_128_GMAC,      /// AES-192-GMAC Authentication with 192-bit ICV
    AUTH_AES_192_GMAC,      /// AES-256-GMAC Authentication with 256-bit ICV
    AUTH_AES_256_GMAC,      /// HMAC-SHA2-256 Authentication with 128-bit ICV
    AUTH_HMAC_SHA2_256_128, /// HMAC-SHA2-384 Authentication with 192-bit ICV
    AUTH_HMAC_SHA2_384_192, /// HMAC-SHA2-512 Authentication with 256-bit ICV
    AUTH_HMAC_SHA2_512_256
};

Begin_Enum_String(integ_id_t) {
    Enum_String(AUTH_NONE);
    Enum_String(AUTH_HMAC_MD5_96);
    Enum_String(AUTH_HMAC_SHA1_96);
    Enum_String(AUTH_DES_MAC);
    Enum_String(AUTH_KPDK_MD5);
    Enum_String(AUTH_AES_XCBC_96);
    Enum_String(AUTH_HMAC_MD5_128);
    Enum_String(AUTH_HMAC_SHA1_160);
    Enum_String(AUTH_AES_CMAC_96);
    Enum_String(AUTH_AES_128_GMAC);
    Enum_String(AUTH_AES_192_GMAC);
    Enum_String(AUTH_AES_256_GMAC);
    Enum_String(AUTH_HMAC_SHA2_256_128);
    Enum_String(AUTH_HMAC_SHA2_384_192);
    Enum_String(AUTH_HMAC_SHA2_512_256);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 DH_ID fields
/// @param DH_NONE - No Diffie-Hellman
/// @param DH_MODP_768 - Diffie-Hellman MODP Group 768-bit
/// @param DH_MODP_1024 - Diffie-Hellman MODP Group 1024-bit
/// @param DH_RSVD3 - Reserved
/// @param DH_RSVD4 - Reserved
/// @param DH_MODP_1536 - Diffie-Hellman MODP Group 1536-bit
/// @param DH_UNASSIGNED6 - Unassigned
/// @param DH_UNASSIGNED7 - Unassigned
/// @param DH_UNASSIGNED8 - Unassigned
/// @param DH_UNASSIGNED9 - Unassigned
/// @param DH_UNASSIGNED10 - Unassigned
/// @param DH_UNASSIGNED11 - Unassigned
/// @param DH_UNASSIGNED12 - Unassigned
/// @param DH_UNASSIGNED13 - Unassigned
/// @param DH_MODP_2048 - Diffie-Hellman MODP Group 2048-bit
/// @param DH_MODP_3072 - Diffie-Hellman MODP Group 3072-bit
/// @param DH_MODP_4096 - Diffie-Hellman MODP Group 4096-bit
/// @param DH_MODP_6144 - Diffie-Hellman MODP Group 6144-bit
/// @param DH_MODP_8192 - Diffie-Hellman MODP Group 8192-bit
/// @param DH_ECP_256 - Diffie-Hellman Elliptic Curve with 256-bit
/// @param DH_ECP_384 - Diffie-Hellman Elliptic Curve with 384-bit
/// @param DH_ECP_521 - Diffie-Hellman Elliptic Curve with 521-bit
/// @param DH_MODP_1024_160 - Diffie-Hellman MODP Group 1024-bit with 160-bit Subgroup
/// @param DH_MODP_2048_224 - Diffie-Hellman MODP Group 2048-bit with 224-bit Subgroup
/// @param DH_MODP_2048_256 - Diffie-Hellman MODP Group 2048-bit with 256-bit Subgroup
/// @param DH_ECP_192_RANDOM - Diffie-Hellman Elliptic Curve with 192-bit random curve
/// @param DH_ECP_224_RANDOM - Diffie-Hellman Elliptic Curve with 224-bit random curve
/// @param DH_BRAINPOOL_P224R1 - Diffie-Hellman BrainPool curve with 224-bit prime
/// @param DH_BRAINPOOL_P256R1 - Diffie-Hellman BrainPool curve with 256-bit prime
/// @param DH_BRAINPOOL_P384R1 - Diffie-Hellman BrainPool curve with 384-bit prime
/// @param DH_BRAINPOOL_P512R1 - Diffie-Hellman BrainPool curve with 512-bit prime
/// @param DH_CURVE_25519 - Diffie-Hellman Elliptic Curve 25519
/// @param DH_CURVE_448 - Diffie-Hellman Elliptic Curve 448
//////////////////////////////////////////////////////////////////////
enum dh_id_t {           /// No Diffie-Hellman
    DH_NONE,             /// Diffie-Hellman MODP Group 768-bit
    DH_MODP_768,         /// Diffie-Hellman MODP Group 1024-bit
    DH_MODP_1024,        /// Reserved
    DH_RSVD3,            /// Reserved
    DH_RSVD4,            /// Diffie-Hellman MODP Group 1536-bit
    DH_MODP_1536,        /// Unassigned
    DH_UNASSIGNED6,      /// Unassigned
    DH_UNASSIGNED7,      /// Unassigned
    DH_UNASSIGNED8,      /// Unassigned
    DH_UNASSIGNED9,      /// Unassigned
    DH_UNASSIGNED10,     /// Unassigned
    DH_UNASSIGNED11,     /// Unassigned
    DH_UNASSIGNED12,     /// Unassigned
    DH_UNASSIGNED13,     /// MODP Group 2048-bit
    DH_MODP_2048,        /// MODP Group 3072-bit
    DH_MODP_3072,        /// MODP Group 4096-bit
    DH_MODP_4096,        /// MODP Group 6144-bit
    DH_MODP_6144,        /// MODP Group 8192-bit
    DH_MODP_8192,        /// ECP Group 256-bit
    DH_ECP_256,          /// ECP Group 384-bit
    DH_ECP_384,          /// ECP Group 521-bit
    DH_ECP_521,          /// MODP Group 1024-bit with 160-bit Prime Order Subgroup
    DH_MODP_1024_160,    /// MODP Group 2048-bit with 224-bit Prime Order Subgroup
    DH_MODP_2048_224,    /// MODP Group 2048-bit with 256-bit Prime Order Subgroup
    DH_MODP_2048_256,    /// ECP Group 192-bit Random
    DH_ECP_192_RANDOM,   /// ECP Group 224-bit Random
    DH_ECP_224_RANDOM,   /// BrainPool P224R1
    DH_BRAINPOOL_P224R1, /// Brain Pool P256R1
    DH_BRAINPOOL_P256R1, /// BrainPool P384R1
    DH_BRAINPOOL_P384R1, /// BrainPool P512R1
    DH_BRAINPOOL_P512R1, /// Curve 25519
    DH_CURVE_25519,      /// Curve 448
    DH_CURVE_448
};

Begin_Enum_String(dh_id_t) {
    Enum_String(DH_NONE);
    Enum_String(DH_MODP_768);
    Enum_String(DH_MODP_1024);
    Enum_String(DH_RSVD3);
    Enum_String(DH_RSVD4);
    Enum_String(DH_MODP_1536);
    Enum_String(DH_UNASSIGNED6);
    Enum_String(DH_UNASSIGNED7);
    Enum_String(DH_UNASSIGNED8);
    Enum_String(DH_UNASSIGNED9);
    Enum_String(DH_UNASSIGNED10);
    Enum_String(DH_UNASSIGNED11);
    Enum_String(DH_UNASSIGNED12);
    Enum_String(DH_UNASSIGNED13);
    Enum_String(DH_MODP_2048);
    Enum_String(DH_MODP_3072);
    Enum_String(DH_MODP_4096);
    Enum_String(DH_MODP_6144);
    Enum_String(DH_MODP_8192);
    Enum_String(DH_ECP_256);
    Enum_String(DH_ECP_384);
    Enum_String(DH_ECP_521);
    Enum_String(DH_MODP_1024_160);
    Enum_String(DH_MODP_2048_224);
    Enum_String(DH_MODP_2048_256);
    Enum_String(DH_ECP_192_RANDOM);
    Enum_String(DH_ECP_224_RANDOM);
    Enum_String(DH_BRAINPOOL_P224R1);
    Enum_String(DH_BRAINPOOL_P256R1);
    Enum_String(DH_BRAINPOOL_P384R1);
    Enum_String(DH_BRAINPOOL_P512R1);
    Enum_String(DH_CURVE_25519);
    Enum_String(DH_CURVE_448);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 ESN_ID fields
/// @param ESN_NO - Disable Extended Sequence Number Use
/// @param ESN_YES - Enable Extended Sequence Number Use
//////////////////////////////////////////////////////////////////////
enum esn_id_t {/// Disable Extended Sequence Number Use
    ESN_NO,    /// Enable Extended Sequence Number Use
    ESN_YES
};

Begin_Enum_String(esn_id_t) {
    Enum_String(ESN_NO);
    Enum_String(ESN_YES);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 ID_TYPE fields
/// @param ID_IPV4_ADDR - IPv4 Address ID type
/// @param ID_FQDN - FQDN ID type
/// @param ID_RFC822_ADDR - RFC822 Address ID type
/// @param ID_UNASSIGNED4 - Unassigned
/// @param ID_IPV6_ADDR - IPv6 Adddress ID type
/// @param ID_UNASSIGNED6 - Unassigned
/// @param ID_UNASSIGNED7 - Unassigned
/// @param ID_UNASSIGNED8 - Unassigned
/// @param ID_DER_ASN1_DN - ASN1 DN ID type
/// @param ID_DER_ASN1_GN - ASN1 GN ID type
/// @param ID_KEY_ID - Key ID type
/// @param ID_FC_NAME - FC Name ID type
/// @param ID_NULL - NULL ID type
//////////////////////////////////////////////////////////////////////
enum id_type_t {    /// IPv4 Address ID type
    ID_IPV4_ADDR=1, /// FQDN ID type
    ID_FQDN,        /// RFC822 Address ID type
    ID_RFC822_ADDR, /// Unassigned
    ID_UNASSIGNED4, /// IPv6 Address ID type
    ID_IPV6_ADDR,   /// Unassigned
    ID_UNASSIGNED6, /// Unassigned
    ID_UNASSIGNED7, /// Unassigned
    ID_UNASSIGNED8, /// ASN1 DN ID type
    ID_DER_ASN1_DN, /// ASN1 GN ID type
    ID_DER_ASN1_GN, /// Key ID type
    ID_KEY_ID,      /// FC Name ID type
    ID_FC_NAME,     /// NULL ID type
    ID_NULL
};

Begin_Enum_String(id_type_t) {
    Enum_String(ID_IPV4_ADDR);
    Enum_String(ID_FQDN);
    Enum_String(ID_RFC822_ADDR);
    Enum_String(ID_UNASSIGNED4);
    Enum_String(ID_IPV6_ADDR);
    Enum_String(ID_UNASSIGNED6);
    Enum_String(ID_UNASSIGNED7);
    Enum_String(ID_UNASSIGNED8);
    Enum_String(ID_DER_ASN1_DN);
    Enum_String(ID_DER_ASN1_GN);
    Enum_String(ID_KEY_ID);
    Enum_String(ID_FC_NAME);
    Enum_String(ID_NULL);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 CERT ENCODING fields
/// @param CERT_X509_PKCS_7 - Certificate encoded as X509_PKCS_7
/// @param CERT_PGP - Certificate encoded as PGP
/// @param CERT_DNS - Certificate encoded as DNS
/// @param CERT_X509_SIGNATURE - Certificate encoded as X509_SIGNATURE
/// @param CERT_RESERVED5 - Certificate encoded as RESERVED5
/// @param CERT_KERBEROS - Certificate encoded as KERBEROS
/// @param CERT_CRL - Certificate encoded as CRL
/// @param CERT_ARL - Certificate encoded as ARL
/// @param CERT_SPKI - Certificate encoded as SPKI
/// @param CERT_RAW_RSA - Certificate encoded as RAW_RSA
/// @param CERT_X509_ATTRIBUTE - Certificate encoded as X509_ATTRIBUTE
/// @param CERT_HASH_URL - Certificate encoded as HASH_URL of X509
/// @param CERT_HASH_URL_BUNDLE - Certificate encoded as HASH_URL_BUNDLE of X509
/// @param CERT_OSCP_CONTENT - Certificate encoded as OSCP Content
/// @param CERT_RAW_PUBLIC_KEY - Certificate encoded as raw public key
//////////////////////////////////////////////////////////////////////
enum encoding_t {         /// Certificate encoded as X509 PKCS #7
    CERT_X509_PKCS_7=1,   /// Certificate encoded as PGP
    CERT_PGP,             /// Certificate encoded as DNS
    CERT_DNS,             /// Certificate encoded as X509 Signature
    CERT_X509_SIGNATURE,  /// Certificate encoded as RESERVED #5
    CERT_RESERVED5,       /// Certificate encoded as KERBEROS 
    CERT_KERBEROS,        /// Certificate encoded as CRL 
    CERT_CRL,             /// Certificate encoded as ARL 
    CERT_ARL,             /// Certificate encoded as SPKI 
    CERT_SPKI,            /// Certificate encoded as RAW RSA
    CERT_RAW_RSA,         /// Certificate encoded as X509_ATTRIBUTE
    CERT_X509_ATTRIBUTE,  /// Certificate encoded as HASH_URL
    CERT_HASH_URL,        /// Certificate encoded as HASH_URL_BUNDLE
    CERT_HASH_URL_BUNDLE, /// Certificate encoded as OCSP content
    CERT_OSCP_CONTENT,    /// Certificate encoded as raw public key
    CERT_RAW_PUBLIC_KEY
};

Begin_Enum_String(encoding_t) {
    Enum_String(CERT_X509_PKCS_7);
    Enum_String(CERT_PGP);
    Enum_String(CERT_DNS);
    Enum_String(CERT_X509_SIGNATURE);
    Enum_String(CERT_RESERVED5);
    Enum_String(CERT_KERBEROS);
    Enum_String(CERT_CRL);
    Enum_String(CERT_ARL);
    Enum_String(CERT_SPKI);
    Enum_String(CERT_RAW_RSA);
    Enum_String(CERT_X509_ATTRIBUTE);
    Enum_String(CERT_HASH_URL);
    Enum_String(CERT_HASH_URL_BUNDLE);
    Enum_String(CERT_OSCP_CONTENT);
    Enum_String(CERT_RAW_PUBLIC_KEY);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 AUTH METHOD fields
/// @param AUTH_RSA - RSA Authentication mode
/// @param AUTH_PSK - PSK Authentication mode
/// @param AUTH_DSS - DSS Authentication mode
/// @param AUTH_UNASSIGNED4 - Unassigned
/// @param AUTH_UNASSIGNED5 - Unassigned
/// @param AUTH_UNASSIGNED6 - Unassigned
/// @param AUTH_UNASSIGNED7 - Unassigned
/// @param AUTH_UNASSIGNED8 - Unassigned
/// @param AUTH_ECDSA_P256 - ECDSA with SHA-256 on the P-256 Curve
/// @param AUTH_ECDSA_P384 - ECDSA with SHA-384 on the P-384 Curve
/// @param AUTH_ECDSA_P512 - ECDSA with SHA-512 on the P-512 Curve
/// @param AUTH_GENERIC_SECURE_PASSWORD - Generic Secure Password Authentication Method
/// @param AUTH_NULL - No PRF Authentication mode
/// @param AUTH_DIGITAL_SIGNATURE - Digital Signature
//////////////////////////////////////////////////////////////////////
enum auth_method_t {  /// RSA Authentication
    AUTH_RSA=1,       /// PSK Authentication mode
    AUTH_PSK,         /// DSS Authentication mode
    AUTH_DSS,         /// Unassigned
    AUTH_UNASSIGNED4, /// Unassigned
    AUTH_UNASSIGNED5, /// Unassigned
    AUTH_UNASSIGNED6, /// Unassigned
    AUTH_UNASSIGNED7, /// Unassigned
    AUTH_UNASSIGNED8, /// ECDSA with SHA-256 on the P-256 Curve
    AUTH_ECDSA_P256,  /// ECDSA with SHA-384 on the P-384 Curve
    AUTH_ECDSA_P384,  /// ECDSA with SHA-512 on the P-512 Curve
    AUTH_ECDSA_P512,  /// Generic Secure Password Authentication Method
    AUTH_GENERIC_SECURE_PASSWORD, /// No PRF Authentication method
    AUTH_NULL,        /// Digital Signature
    AUTH_DIGITAL_SIGNATURE
};

Begin_Enum_String(auth_method_t) {
    Enum_String(AUTH_RSA);
    Enum_String(AUTH_PSK);
    Enum_String(AUTH_DSS);
    Enum_String(AUTH_UNASSIGNED4);
    Enum_String(AUTH_UNASSIGNED5);
    Enum_String(AUTH_UNASSIGNED6);
    Enum_String(AUTH_UNASSIGNED7);
    Enum_String(AUTH_UNASSIGNED8);
    Enum_String(AUTH_ECDSA_P256);
    Enum_String(AUTH_ECDSA_P384);
    Enum_String(AUTH_ECDSA_P512);
    Enum_String(AUTH_GENERIC_SECURE_PASSWORD);
    Enum_String(AUTH_NULL);
    Enum_String(AUTH_DIGITAL_SIGNATURE);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Notify Messages - Error Types
/// NERR_UNSUPPORTED_CRIT_PAYLD - Unsupported critical payload
/// NERR_RSVD2 - Unsupported critical payload
/// NERR_RSVD3 - Unsupported critical payload
/// NERR_INVALID_IKE_SPI - Invalid IKE Security Protocol Index (SPI)
/// NERR_INVALID_MAJOR_VERSION - Invalid IKE Major Version
/// NERR_RSVD6
/// NERR_INVALID_SYNTAX - Invalid syntax
/// NERR_RSVD8
/// NERR_INVALID_MESSAGE_ID - ID for this message is incorrect
/// NERR_RSVD10
/// NERR_INVALID_SPI - Invalid Security Protocol Index for ESP or AH
/// NERR_RSVD12
/// NERR_RSVD13
/// NERR_NO_PROPOSAL_CHOSEN - IKE or ESP proposal was not chosed from the selection
/// NERR_RSVD15
/// NERR_RSVD16
/// NERR_INVALID_KE_PAYLOAD - Key Exchange Payload is Invalid
/// NERR_RSVD18
/// NERR_RSVD19
/// NERR_RSVD20
/// NERR_RSVD21
/// NERR_RSVD22
/// NERR_RSVD23
/// NERR_AUTH_FAILED - Authentication of the payload failed
/// NERR_RSVD25
/// NERR_RSVD26
/// NERR_RSVD27
/// NERR_RSVD28
/// NERR_RSVD29
/// NERR_RSVD30
/// NERR_RSVD31
/// NERR_RSVD32
/// NERR_RSVD33
/// NERR_SINGLE_PAIR_REQUIRED - Single Pair Required
/// NERR_NO_ADDITIONAL_SAS - No Additional SAS
/// NERR_INTERNAL_ADDRESS_FAILURE - Requested Internal Address Failed
/// NERR_FAILED_CP_REQUIRED - Failed CP Required
/// NERR_TS_UNACCEPTABLE - Traffic Selector was not acceptable
/// NERR_INVALID_SELECTORS - Invalid Traffic Selectors
/// NERR_UNACCEPTABLE_ADDRESSES - Requested Addresses were not accepted
/// NERR_UNEXPECTED_NAT_DETECTED - NAT Transversal requested but not configured
/// NERR_USE_ASSIGNED_HOA - Use Assigned HOA
/// NERR_TEMPORARY_FAILURE - Temporary Failure
/// NERR_CHILD_SA_NOT_FOUND - For the connection, the Child Security Association (SA) was not found
/// NERR_INVALID_GROUP_ID - Invalid Diffie-Hellman Group ID was requested
/// NERR_AUTHORIZATION_FAILED - Authorization of the connection failed
//////////////////////////////////////////////////////////////////////
enum notify_err_t {
    NERR_UNSUPPORTED_CRIT_PAYLD=1,
    NERR_RSVD2,
    NERR_RSVD3,
    NERR_INVALID_IKE_SPI,
    NERR_INVALID_MAJOR_VERSION,
    NERR_RSVD6,
    NERR_INVALID_SYNTAX,
    NERR_RSVD8,
    NERR_INVALID_MESSAGE_ID,
    NERR_RSVD10,
    NERR_INVALID_SPI,
    NERR_RSVD12,
    NERR_RSVD13,
    NERR_NO_PROPOSAL_CHOSEN,
    NERR_RSVD15,
    NERR_RSVD16,
    NERR_INVALID_KE_PAYLOAD,
    NERR_RSVD18,
    NERR_RSVD19,
    NERR_RSVD20,
    NERR_RSVD21,
    NERR_RSVD22,
    NERR_RSVD23,
    NERR_AUTH_FAILED,
    NERR_RSVD25,
    NERR_RSVD26,
    NERR_RSVD27,
    NERR_RSVD28,
    NERR_RSVD29,
    NERR_RSVD30,
    NERR_RSVD31,
    NERR_RSVD32,
    NERR_RSVD33,
    NERR_SINGLE_PAIR_REQUIRED,
    NERR_NO_ADDITIONAL_SAS,
    NERR_INTERNAL_ADDRESS_FAILURE,
    NERR_FAILED_CP_REQUIRED,
    NERR_TS_UNACCEPTABLE,
    NERR_INVALID_SELECTORS,
    NERR_UNACCEPTABLE_ADDRESSES,
    NERR_UNEXPECTED_NAT_DETECTED,
    NERR_USE_ASSIGNED_HOA,
    NERR_TEMPORARY_FAILURE,
    NERR_CHILD_SA_NOT_FOUND,
    NERR_INVALID_GROUP_ID,
    NERR_AUTHORIZATION_FAILED
};

Begin_Enum_String(notify_err_t) {
    Enum_String(NERR_UNSUPPORTED_CRIT_PAYLD);
    Enum_String(NERR_RSVD2);
    Enum_String(NERR_RSVD3);
    Enum_String(NERR_INVALID_IKE_SPI);
    Enum_String(NERR_INVALID_MAJOR_VERSION);
    Enum_String(NERR_RSVD6);
    Enum_String(NERR_INVALID_SYNTAX);
    Enum_String(NERR_RSVD8);
    Enum_String(NERR_INVALID_MESSAGE_ID);
    Enum_String(NERR_RSVD10);
    Enum_String(NERR_INVALID_SPI);
    Enum_String(NERR_RSVD12);
    Enum_String(NERR_RSVD13);
    Enum_String(NERR_NO_PROPOSAL_CHOSEN);
    Enum_String(NERR_RSVD15);
    Enum_String(NERR_RSVD16);
    Enum_String(NERR_INVALID_KE_PAYLOAD);
    Enum_String(NERR_RSVD18);
    Enum_String(NERR_RSVD19);
    Enum_String(NERR_RSVD20);
    Enum_String(NERR_RSVD21);
    Enum_String(NERR_RSVD22);
    Enum_String(NERR_RSVD23);
    Enum_String(NERR_AUTH_FAILED);
    Enum_String(NERR_RSVD25);
    Enum_String(NERR_RSVD26);
    Enum_String(NERR_RSVD27);
    Enum_String(NERR_RSVD28);
    Enum_String(NERR_RSVD29);
    Enum_String(NERR_RSVD30);
    Enum_String(NERR_RSVD31);
    Enum_String(NERR_RSVD32);
    Enum_String(NERR_RSVD33);
    Enum_String(NERR_SINGLE_PAIR_REQUIRED);
    Enum_String(NERR_NO_ADDITIONAL_SAS);
    Enum_String(NERR_INTERNAL_ADDRESS_FAILURE);
    Enum_String(NERR_FAILED_CP_REQUIRED);
    Enum_String(NERR_TS_UNACCEPTABLE);
    Enum_String(NERR_INVALID_SELECTORS);
    Enum_String(NERR_UNACCEPTABLE_ADDRESSES);
    Enum_String(NERR_UNEXPECTED_NAT_DETECTED);
    Enum_String(NERR_USE_ASSIGNED_HOA);
    Enum_String(NERR_TEMPORARY_FAILURE);
    Enum_String(NERR_CHILD_SA_NOT_FOUND);
    Enum_String(NERR_INVALID_GROUP_ID);
    Enum_String(NERR_AUTHORIZATION_FAILED);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Notify Messages - Status Types
/// NSTAT_INITIAL_CONTACT [RFC7296]
/// NSTAT_SET_WINDOW_SIZE [RFC7296]
/// NSTAT_ADDITIONAL_TS_POSSIBLE [RFC7296]
/// NSTAT_IPCOMP_SUPPORTED [RFC7296]
/// NSTAT_NAT_DETECTION_SOURCE_IP [RFC7296]
/// NSTAT_NAT_DETECTION_DESTINATION_IP [RFC7296]
/// NSTAT_COOKIE [RFC7296]
/// NSTAT_USE_TRANSPORT_MODE [RFC7296]
/// NSTAT_HTTP_CERT_LOOKUP_SUPPORTED [RFC7296]
/// NSTAT_REKEY_SA [RFC7296]
/// NSTAT_ESP_TFC_PADDING_NOT_SUPPORTED [RFC7296]
/// NSTAT_NON_FIRST_FRAGMENTS_ALSO [RFC7296]
/// NSTAT_MOBIKE_SUPPORTED [RFC4555]
/// NSTAT_ADDITIONAL_IP4_ADDRESS [RFC4555]
/// NSTAT_ADDITIONAL_IP6_ADDRESS [RFC4555]
/// NSTAT_NO_ADDITIONAL_ADDRESSES [RFC4555]
/// NSTAT_UPDATE_SA_ADDRESSES [RFC4555]
/// NSTAT_COOKIE2 [RFC4555]
/// NSTAT_NO_NATS_ALLOWED [RFC4555]
/// NSTAT_AUTH_LIFETIME [RFC4478]
/// NSTAT_MULTIPLE_AUTH_SUPPORTED [RFC4739]
/// NSTAT_ANOTHER_AUTH_FOLLOWS [RFC4739]
/// NSTAT_REDIRECT_SUPPORTED [RFC5685]
/// NSTAT_REDIRECT [RFC5685]
/// NSTAT_REDIRECTED_FROM [RFC5685]
/// NSTAT_TICKET_LT_OPAQUE [RFC5723]
/// NSTAT_TICKET_REQUEST [RFC5723]
/// NSTAT_TICKET_ACK [RFC5723]
/// NSTAT_TICKET_NACK [RFC5723]
/// NSTAT_TICKET_OPAQUE [RFC5723]
/// NSTAT_LINK_ID [RFC5739]
/// NSTAT_USE_WESP_MODE [RFC5840]
/// NSTAT_ROHC_SUPPORTED [RFC5857]
/// NSTAT_EAP_ONLY_AUTHENTICATION [RFC5998]
/// NSTAT_CHILDLESS_IKEV2_SUPPORTED [RFC6023]
/// NSTAT_QUICK_CRASH_DETECTION [RFC6290]
/// NSTAT_IKEV2_MESSAGE_ID_SYNC_SUPPORTED [RFC6311]
/// NSTAT_IPSEC_REPLAY_COUNTER_SYNC_SUPPORTED [RFC6311]
/// NSTAT_IKEV2_MESSAGE_ID_SYNC [RFC6311]
/// NSTAT_IPSEC_REPLAY_COUNTER_SYNC [RFC6311]
/// NSTAT_SECURE_PASSWORD_METHODS [RFC6467]
/// NSTAT_PSK_PERSIST [RFC6631]
/// NSTAT_PSK_CONFIRM [RFC6631]
/// NSTAT_ERX_SUPPORTED [RFC6867]
/// NSTAT_IFOM_CAPABILITY [Frederic_Firmin][3GPP TS 24.303 v10.6.0 annex B.2]
/// NSTAT_SENDER_REQUEST_ID [draftyeunggikev2]
/// NSTAT_IKEV2_FRAGMENTATION_SUPPORTED [RFC7383]
/// NSTAT_SIGNATURE_HASH_ALGORITHMS [RFC7427]
/// NSTAT_CLONE_IKE_SA_SUPPORTED [RFC7791]
/// NSTAT_CLONE_IKE_SA [RFC7791]
/// NSTAT_PUZZLE [RFC8019]
/// NSTAT_USE_PPK [draftietfipsecmeqrikev2]
/// NSTAT_PPK_IDENTITY [draftietfipsecmeqrikev2]
/// NSTAT_NO_PPK_AUTH [draftietfipsecmeqrikev2]
//////////////////////////////////////////////////////////////////////
enum notify_status_t {
   NSTAT_INITIAL_CONTACT=16384,
   NSTAT_SET_WINDOW_SIZE,
   NSTAT_ADDITIONAL_TS_POSSIBLE,
   NSTAT_IPCOMP_SUPPORTED,
   NSTAT_NAT_DETECTION_SOURCE_IP,
   NSTAT_NAT_DETECTION_DESTINATION_IP,
   NSTAT_COOKIE,
   NSTAT_USE_TRANSPORT_MODE,
   NSTAT_HTTP_CERT_LOOKUP_SUPPORTED,
   NSTAT_REKEY_SA,
   NSTAT_ESP_TFC_PADDING_NOT_SUPPORTED,
   NSTAT_NON_FIRST_FRAGMENTS_ALSO,
   NSTAT_MOBIKE_SUPPORTED,
   NSTAT_ADDITIONAL_IP4_ADDRESS,
   NSTAT_ADDITIONAL_IP6_ADDRESS,
   NSTAT_NO_ADDITIONAL_ADDRESSES,
   NSTAT_UPDATE_SA_ADDRESSES,
   NSTAT_COOKIE2,
   NSTAT_NO_NATS_ALLOWED,
   NSTAT_AUTH_LIFETIME,
   NSTAT_MULTIPLE_AUTH_SUPPORTED,
   NSTAT_ANOTHER_AUTH_FOLLOWS,
   NSTAT_REDIRECT_SUPPORTED,
   NSTAT_REDIRECT,
   NSTAT_REDIRECTED_FROM,
   NSTAT_TICKET_LT_OPAQUE,
   NSTAT_TICKET_REQUEST,
   NSTAT_TICKET_ACK,
   NSTAT_TICKET_NACK,
   NSTAT_TICKET_OPAQUE,
   NSTAT_LINK_ID,
   NSTAT_USE_WESP_MODE,
   NSTAT_ROHC_SUPPORTED,
   NSTAT_EAP_ONLY_AUTHENTICATION,
   NSTAT_CHILDLESS_IKEV2_SUPPORTED,
   NSTAT_QUICK_CRASH_DETECTION,
   NSTAT_IKEV2_MESSAGE_ID_SYNC_SUPPORTED,
   NSTAT_IPSEC_REPLAY_COUNTER_SYNC_SUPPORTED,
   NSTAT_IKEV2_MESSAGE_ID_SYNC,
   NSTAT_IPSEC_REPLAY_COUNTER_SYNC,
   NSTAT_SECURE_PASSWORD_METHODS,
   NSTAT_PSK_PERSIST,
   NSTAT_PSK_CONFIRM,
   NSTAT_ERX_SUPPORTED,
   NSTAT_IFOM_CAPABILITY,
   NSTAT_SENDER_REQUEST_ID,
   NSTAT_IKEV2_FRAGMENTATION_SUPPORTED,
   NSTAT_SIGNATURE_HASH_ALGORITHMS,
   NSTAT_CLONE_IKE_SA_SUPPORTED,
   NSTAT_CLONE_IKE_SA,
   NSTAT_PUZZLE,
   NSTAT_USE_PPK,
   NSTAT_PPK_IDENTITY,
   NSTAT_NO_PPK_AUTH
};

Begin_Enum_String(notify_status_t) {
   Enum_String(NSTAT_INITIAL_CONTACT);
   Enum_String(NSTAT_SET_WINDOW_SIZE);
   Enum_String(NSTAT_ADDITIONAL_TS_POSSIBLE);
   Enum_String(NSTAT_IPCOMP_SUPPORTED);
   Enum_String(NSTAT_NAT_DETECTION_SOURCE_IP);
   Enum_String(NSTAT_NAT_DETECTION_DESTINATION_IP);
   Enum_String(NSTAT_COOKIE);
   Enum_String(NSTAT_USE_TRANSPORT_MODE);
   Enum_String(NSTAT_HTTP_CERT_LOOKUP_SUPPORTED);
   Enum_String(NSTAT_REKEY_SA);
   Enum_String(NSTAT_ESP_TFC_PADDING_NOT_SUPPORTED);
   Enum_String(NSTAT_NON_FIRST_FRAGMENTS_ALSO);
   Enum_String(NSTAT_MOBIKE_SUPPORTED);
   Enum_String(NSTAT_ADDITIONAL_IP4_ADDRESS);
   Enum_String(NSTAT_ADDITIONAL_IP6_ADDRESS);
   Enum_String(NSTAT_NO_ADDITIONAL_ADDRESSES);
   Enum_String(NSTAT_UPDATE_SA_ADDRESSES);
   Enum_String(NSTAT_COOKIE2);
   Enum_String(NSTAT_NO_NATS_ALLOWED);
   Enum_String(NSTAT_AUTH_LIFETIME);
   Enum_String(NSTAT_MULTIPLE_AUTH_SUPPORTED);
   Enum_String(NSTAT_ANOTHER_AUTH_FOLLOWS);
   Enum_String(NSTAT_REDIRECT_SUPPORTED);
   Enum_String(NSTAT_REDIRECT);
   Enum_String(NSTAT_REDIRECTED_FROM);
   Enum_String(NSTAT_TICKET_LT_OPAQUE);
   Enum_String(NSTAT_TICKET_REQUEST);
   Enum_String(NSTAT_TICKET_ACK);
   Enum_String(NSTAT_TICKET_NACK);
   Enum_String(NSTAT_TICKET_OPAQUE);
   Enum_String(NSTAT_LINK_ID);
   Enum_String(NSTAT_USE_WESP_MODE);
   Enum_String(NSTAT_ROHC_SUPPORTED);
   Enum_String(NSTAT_EAP_ONLY_AUTHENTICATION);
   Enum_String(NSTAT_CHILDLESS_IKEV2_SUPPORTED);
   Enum_String(NSTAT_QUICK_CRASH_DETECTION);
   Enum_String(NSTAT_IKEV2_MESSAGE_ID_SYNC_SUPPORTED);
   Enum_String(NSTAT_IPSEC_REPLAY_COUNTER_SYNC_SUPPORTED);
   Enum_String(NSTAT_IKEV2_MESSAGE_ID_SYNC);
   Enum_String(NSTAT_IPSEC_REPLAY_COUNTER_SYNC);
   Enum_String(NSTAT_SECURE_PASSWORD_METHODS);
   Enum_String(NSTAT_PSK_PERSIST);
   Enum_String(NSTAT_PSK_CONFIRM);
   Enum_String(NSTAT_ERX_SUPPORTED);
   Enum_String(NSTAT_IFOM_CAPABILITY);
   Enum_String(NSTAT_SENDER_REQUEST_ID);
   Enum_String(NSTAT_IKEV2_FRAGMENTATION_SUPPORTED);
   Enum_String(NSTAT_SIGNATURE_HASH_ALGORITHMS);
   Enum_String(NSTAT_CLONE_IKE_SA_SUPPORTED);
   Enum_String(NSTAT_CLONE_IKE_SA);
   Enum_String(NSTAT_PUZZLE);
   Enum_String(NSTAT_USE_PPK);
   Enum_String(NSTAT_PPK_IDENTITY);
   Enum_String(NSTAT_NO_PPK_AUTH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Compression Types
/// @param IPCOMP_OUI - OUI Compression
/// @param IPCOMP_DEFLATE - Deflation 
/// @param IPCOMP_LZS - LZS Compression
/// @param IPCOMP_LZJH - LZJH Compression
//////////////////////////////////////////////////////////////////////
enum ike_ipcomp_t { /// Configure an internal IPv4 Address
    IPCOMP_OUI=1,   /// Configure an internal IPv4 NETMASK
    IPCOMP_DEFLATE, /// Configure a IPv4 DNS setting
    IPCOMP_LZS,     /// Configure a IPv4 NBNS setting
    IPCOMP_LZJH
};

Begin_Enum_String(ike_ipcomp_t) {
    Enum_String(IPCOMP_OUI);
    Enum_String(IPCOMP_DEFLATE);
    Enum_String(IPCOMP_LZS);
    Enum_String(IPCOMP_LZJH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 ID PROTO fields
/// @param IP_PROTO_ANY - Any protocol
/// @param IP_PROTO_ICMP - ICMP protocol
/// @param IP_PROTO_TCP - Transport Control Protocol (TCP)
/// @param IP_PROTO_UDP - User Datagram Protocol (UDP)
/// @param IP_PROTO_ICMPV6 - ICMP protocol version 6
/// @param IP_PROTO_MH - MH Protocol
//////////////////////////////////////////////////////////////////////
enum ip_proto_t {    /// Any Protocol
    IP_PROTO_ANY,    /// ICMP Protocol
    IP_PROTO_ICMP,   /// Transport Control Protocol (TCP)
    IP_PROTO_TCP,    /// User Datagram Protocol (UDP)
    IP_PROTO_UDP,    /// ICMP protocol version 6
    IP_PROTO_ICMPV6, /// MH Protocol
    IP_PROTO_MH
};

Begin_Enum_String(ip_proto_t) {
    Enum_String(IP_PROTO_ANY);
    Enum_String(IP_PROTO_ICMP);
    Enum_String(IP_PROTO_TCP);
    Enum_String(IP_PROTO_UDP);
    Enum_String(IP_PROTO_ICMPV6);
    Enum_String(IP_PROTO_MH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKEv2 Protocol Identifiers
/// @param PROTO_IKE - Request Internet Key Exchange Protocol (IKE)
/// @param PROTO_AH - Request Authentication Header Protocol (AH)
/// @param PROTO_ESP - Request Encapsulating Security Protocol (ESP)
/// @param PROTO_FC_ESP_HDR - FC ESP Header
/// @param PROTO_FC_CT_AUTH - FC CT Authentication
//////////////////////////////////////////////////////////////////////
enum protocol_id_t {  /// Request Internet Key Exchange Protocol (IKE)
    PROTO_IKE=1,      /// Request Authentication Header Protocol (AH)
    PROTO_AH,         /// Request Encapsulating Security Protocol (ESP)
    PROTO_ESP,        /// FC ESP Header
    PROTO_FC_ESP_HDR, /// FC CT Authentication
    PROTO_FC_CT_AUTH
};

Begin_Enum_String(protocol_id_t)
{
    Enum_String(PROTO_IKE);
    Enum_String(PROTO_AH);
    Enum_String(PROTO_ESP);
    Enum_String(PROTO_FC_ESP_HDR);
    Enum_String(PROTO_FC_CT_AUTH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Traffic Selector Types
/// @param TS_IPV4_ADDR_RANGE - Traffic Selector with IPv4 Address Range
/// @param TS_IPV6_ADDR_RANGE - Traffic Selector with IPv6 Address Range
/// @param TS_FC_ADDR_RANGE - Traffic Selector with FC Address Range
//////////////////////////////////////////////////////////////////////
enum ike_ts_t {           /// Traffic Selector with IPv4 Address Range
    TS_IPV4_ADDR_RANGE=7, /// Traffic Selector with IPv6 Address Range
    TS_IPV6_ADDR_RANGE,   /// Traffic Selector with FC Address Range
    TS_FC_ADDR_RANGE
};

Begin_Enum_String(ike_ts_t) {
    Enum_String(TS_IPV4_ADDR_RANGE);
    Enum_String(TS_IPV6_ADDR_RANGE);
    Enum_String(TS_FC_ADDR_RANGE);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Configuration Payload CFG Types
/// @param CFG_REQUEST - Request the configuration
/// @param CFG_REPLY - Reply to a configuration request
/// @param CFG_SET - Set the configuration
/// @param CFG_ACK - Acknowledge the configuration request
//////////////////////////////////////////////////////////////////////
enum cfg_resp_t {  /// Request the configuration
    CFG_REQUEST=1, /// Reply to a configuration request
    CFG_REPLY,     /// Set the configuration
    CFG_SET,       /// Acknowledge the configuration request
    CFG_ACK
};

Begin_Enum_String(cfg_resp_t) {
    Enum_String(CFG_REQUEST);
    Enum_String(CFG_REPLY);
    Enum_String(CFG_SET);
    Enum_String(CFG_ACK);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Configuration Payload Attribute Types
/// @param CFG_INTERNAL_IP4_ADDRESS - Configure an internal IPv4 Address
/// @param CFG_INTERNAL_IP4_NETMASK - Configure an internal IPv4 NETMASK 
/// @param CFG_INTERNAL_IP4_DNS - Configure a IPv4 DNS setting
/// @param CFG_INTERNAL_IP4_NBNS - Configure a IPv4 NBNS setting
/// @param CFG_RSVD5 - Reserved Configuration
/// @param CFG_INTERNAL_IP4_DHCP - Configure a IPv4 DHCP setting
/// @param CFG_APPLICATION_VERSION - Configure Application Version
/// @param CFG_INTERNAL_IP6_ADDRESS - Configure an internal IPv6 Address
/// @param CFG_RSVD9 - Reserved Configuration
/// @param CFG_INTERNAL_IP6_DNS - Configure a IPv6 DNS setting
/// @param CFG_RSVD11 - Reserved Configuration
/// @param CFG_INTERNAL_IP6_DHCP 12 - Configure a IPv6 DHCP setting
/// @param CFG_INTERNAL_IP4_SUBNET - Configure an internal IPv4 SUBNET
/// @param CFG_SUPPORTED_ATTRIBUTES - Configure supported attributes
/// @param CFG_INTERNAL_IP6_SUBNET - Configure an internal IPv6 SUBNET
/// @param CFG_MIP6_HOME_PREFIX - MIP6 Home Prefix
/// @param CFG_INTERNAL_IP6_LINK - Internal IPv6 Link
/// @param CFG_INTERNAL_IP6_PREFIX - Internal IPv6 Prefix
/// @param CFG_HOME_AGENT_ADDR - Home Agent Address
/// @param CFG_P_CSCF_IP4_ADDR - P CSCF IPv4 Address
/// @param CFG_P_CSCF_IP6_ADDR - P CSCF IPv6 Address
/// @param CFG_FTT_KAT - FTT KAT
/// @param CFG_EXT_SRC_IP4_NAT - External Source IPv4 NAT Information
/// @param CFG_TIMEOUT_LIVENESS - Timeout Period for Liveness Check Number
/// @param CFG_INTERNAL_DNS_DOMAIN - Internal DNS Domain
/// @param CFG_INTERNAL_DNS_SEC_TA - Internal DNS SEC TA
//////////////////////////////////////////////////////////////////////
enum cfg_attr_t {              /// Configure an internal IPv4 Address
    CFG_INTERNAL_IP4_ADDRESS=1, /// Configure an internal IPv4 NETMASK
    CFG_INTERNAL_IP4_NETMASK, /// Configure a IPv4 DNS setting
    CFG_INTERNAL_IP4_DNS,     /// Configure a IPv4 NBNS setting
    CFG_INTERNAL_IP4_NBNS,    /// Reserved Configuration
    CFG_RSVD5,                /// Configure a IPv4 DHCP setting
    CFG_INTERNAL_IP4_DHCP,    /// Configure Application Version
    CFG_APPLICATION_VERSION,  /// Configure an internal IPv6 Address
    CFG_INTERNAL_IP6_ADDRESS, /// Reserved Configuration
    CFG_RSVD9,                /// Configure a IPv6 DNS setting
    CFG_INTERNAL_IP6_DNS,     /// Reserved Configuration
    CFG_RSVD11,               /// Configure a IPv6 DHCP setting
    CFG_INTERNAL_IP6_DHCP,    /// Configure an internal IPv4 SUBNET
    CFG_INTERNAL_IP4_SUBNET,  /// Configure supported attributes
    CFG_SUPPORTED_ATTRIBUTES, /// Configure an internal IPv6 SUBNET
    CFG_INTERNAL_IP6_SUBNET,  /// MIP6 Home Prefix
    CFG_MIP6_HOME_PREFIX,     /// Internal IPv6 Link
    CFG_INTERNAL_IP6_LINK,    /// Internal IPv6 Prefix
    CFG_INTERNAL_IP6_PREFIX,  /// Home Agent Address
    CFG_HOME_AGENT_ADDR,      /// P CSCF IPv4 Address
    CFG_P_CSCG_IP4_ADDR,      /// P CSCF IPv6 Address
    CFG_P_CSCF_IP6_ADDR,      /// FTT KAT
    CFG_FTT_KAT,              /// External Source IPv4 NAT Information
    CFG_EXT_SRC_IP4_NAT,      /// Timeout Period for Liveness Check Number
    CFG_TIMEOUT_LIVENESS,     /// Internal DNS Domain
    CFG_INTERNAL_DNS_DOMAIN,  /// Internal DNS SEC TA
    CFG_INTERNAL_DNS_SEC_TA
};

Begin_Enum_String(cfg_attr_t) {
    Enum_String(CFG_INTERNAL_IP4_ADDRESS);
    Enum_String(CFG_INTERNAL_IP4_NETMASK);
    Enum_String(CFG_INTERNAL_IP4_DNS);
    Enum_String(CFG_INTERNAL_IP4_NBNS);
    Enum_String(CFG_RSVD5);
    Enum_String(CFG_INTERNAL_IP4_DHCP);
    Enum_String(CFG_APPLICATION_VERSION);
    Enum_String(CFG_INTERNAL_IP6_ADDRESS);
    Enum_String(CFG_RSVD9);
    Enum_String(CFG_INTERNAL_IP6_DNS);
    Enum_String(CFG_RSVD11);
    Enum_String(CFG_INTERNAL_IP6_DHCP);
    Enum_String(CFG_INTERNAL_IP4_SUBNET);
    Enum_String(CFG_SUPPORTED_ATTRIBUTES);
    Enum_String(CFG_INTERNAL_IP6_SUBNET);
    Enum_String(CFG_MIP6_HOME_PREFIX);
    Enum_String(CFG_INTERNAL_IP6_LINK);
    Enum_String(CFG_INTERNAL_IP6_PREFIX);
    Enum_String(CFG_HOME_AGENT_ADDR);
    Enum_String(CFG_P_CSCG_IP4_ADDR);
    Enum_String(CFG_P_CSCF_IP6_ADDR);
    Enum_String(CFG_FTT_KAT);
    Enum_String(CFG_EXT_SRC_IP4_NAT);
    Enum_String(CFG_TIMEOUT_LIVENESS);
    Enum_String(CFG_INTERNAL_DNS_DOMAIN);
    Enum_String(CFG_INTERNAL_DNS_SEC_TA);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Gateway Identity  Types
/// @param GATEWAY_IPV4_ADDR - IPv4 Address of the VPN gateway
/// @param GATEWAY_IPV6_ADDR - IPv6 Address of the VPN gateway
/// @param GATEWAY_FQDN_ADDR - FQDN Address of the VPN gateway
//////////////////////////////////////////////////////////////////////
enum ike_gateway_t {         /// IPv4 Address of the VPN gateway
    GATEWAY_IPV4_VPN_ADDR=1, /// IPv6 Address of the VPN gateway
    GATEWAY_IPV6_VPN_ADDR,   /// FQDN Address of the VPN gateway
    GATEWAY_FQDN_VPN_ADDR
};

Begin_Enum_String(ike_gateway_t) {
    Enum_String(GATEWAY_IPV4_VPN_ADDR);
    Enum_String(GATEWAY_IPV6_VPN_ADDR);
    Enum_String(GATEWAY_FQDN_VPN_ADDR);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE ROHC Attribute Type
/// @param ROHC_MAX_CID - ROHC Maximum CID
/// @param ROHC_PROFILE - ROHC Profile
/// @param ROHC_INTEG - ROHC Integrity Algorithm
/// @param ROHC_ICV_LEN - ROHC ICV Length
/// @param ROHC_MRRU - ROHC MRRU
//////////////////////////////////////////////////////////////////////
enum rohc_attr_t {  /// ROHC Maximum CID
    ROHC_MAX_CID=1, /// ROHC Profile
    ROHC_PROFILE,   /// ROHC Integrity Algorithm
    ROHC_INTEG,     /// ROHC ICV Length
    ROHC_ICV_LEN,   /// ROHC MRRU
    ROHC_MRRU
};

Begin_Enum_String(rohc_attr_t) {
    Enum_String(ROHC_MAX_CID);
    Enum_String(ROHC_PROFILE);
    Enum_String(ROHC_INTEG);
    Enum_String(ROHC_ICV_LEN);
    Enum_String(ROHC_MRRU);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Secure Password Types
/// @param SECURE_PASSWORD_PACE - PACE Secure Password
/// @param SECURE_PASSW0RD_AUGPAKE - AugPAKE Secure Password
/// @param SECURE_PASSWORD_PSK_AUTH - Secure PSK Authentication
//////////////////////////////////////////////////////////////////////
enum ike_secpass_t {         /// PACE Secure Password
    SECURE_PASSWORD_PACE=1,  /// AugPAKE Secure Password
    SECURE_PASSW0RD_AUGPAKE, /// Secure PSK Authentication
    SECURE_PASSWORD_PSK_AUTH
};

Begin_Enum_String(ike_secpass_t) {
    Enum_String(SECURE_PASSWORD_PACE);
    Enum_String(SECURE_PASSW0RD_AUGPAKE);
    Enum_String(SECURE_PASSWORD_PSK_AUTH);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// IKE Hash Algorithms
/// @param HASH_SHA1 - SHA1 Hash Algorithm
/// @param HASH_SHA2_256 - SHA2_256 Hash Algorithm
/// @param HASH_SHA2_384 - SHA2_384 Hash Algorithm
/// @param HASH_SHA2_512 - SHA2_512 Hash Algorithm
/// @param HASH_IDENTITY - Identity Hash Algorithm
//////////////////////////////////////////////////////////////////////
enum ike_hash_t {  /// SHA1 Hash Algorithm
    HASH_SHA1,     /// SHA2_256 Hash Algorithm
    HASH_SHA2_256, /// SHA2_384 Hash Algorithm
    HASH_SHA2_384, /// SHA2_512 Hash Algorithm
    HASH_SHA2_512, /// Identity Hash Algorithm
    HASH_IDENTITY
};

Begin_Enum_String(ike_hash_t) {
    Enum_String(HASH_SHA1);
    Enum_String(HASH_SHA2_256);
    Enum_String(HASH_SHA2_384);
    Enum_String(HASH_SHA2_512);
    Enum_String(HASH_IDENTITY);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// RSA Pad formats
/// @param PKCS15 - PKCS v1.5 padding 
/// @param PSS - Secure padding
//////////////////////////////////////////////////////////////////////
enum rsapadtype_t {/// PKCS v1.5 padding
    PKCS15,        /// Secure padding
    PSS
};

Begin_Enum_String(rsapadtype_t) {
    Enum_String(PKCS15);
    Enum_String(PSS);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// RSA Encryption Schemes
/// @param PKCS - PKCS Encryption scheme 
/// @param OAEP_SHA - OAEP with SHA Encryption scheme
//////////////////////////////////////////////////////////////////////
enum rsaenc_t {/// PKCS Encryption scheme
    PKCS,      /// OAEP with SHA Encryption scheme
    OAEP_SHA 
};

Begin_Enum_String(rsaenc_t) {
    Enum_String(PKCS);
    Enum_String(OAEP_SHA);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// PKI modes of operation
/// @param GENKEYPAIR - Generate Key Pair
/// @param PKISIGN - Generate Signature
/// @param PKIVERIFY - Verify Signature
/// @param RSAENCRYPT - Encrypt data with RSA Key Pair
/// @param RSADECRYPT - Decrypt data with RSA Key Pair
//////////////////////////////////////////////////////////////////////
enum keymode_t {/// Generate Key Pair
    GENKEYPAIR, /// Generate Signature
    PKISIGN,    /// Verify Signature
    PKIVERIFY,  /// Encrypt data with RSA Key Pair
    RSAENCRYPT, /// Decrypt data with RSA Key Pair
    RSADECRYPT
};

Begin_Enum_String(keymode_t) {
    Enum_String(GENKEYPAIR);
    Enum_String(PKISIGN);
    Enum_String(PKIVERIFY);
    Enum_String(RSAENCRYPT);
    Enum_String(RSADECRYPT);
}
End_Enum_String;

//////////////////////////////////////////////////////////////////////
/// CRC initialization values
/// <table>
/// <caption id="crcInitValues">CRC Initial Values</caption>
/// <tr><th>Name<th>Polynomial<th>Reversed?<th>Init-value<th>XOR-out<th>Check
/// <tr><td>crc-5<td>0x07<td>False<td>0x00<td>0x00<td>0xF4
/// <tr><td>crc-7<td>0x07<td>False<td>0x00<td>0x00<td>0xF4
/// <tr><td>crc-8<td>0x07<td>False<td>0x00<td>0x00<td>0xF4
/// <tr><td>crc-11<td>0x07<td>False<td>0x00<td>0x00<td>0xF4
/// <tr><td>crc-12<td>0x07<td>False<td>0x00<td>0x00<td>0xF4
/// <tr><td>crc-16<td>0x8005<td>True<td>0x0000<td>0x0000<td>0xBB3D
/// <tr><td>crc-16-ccitt<td>0x1021<td>False<td>0xFFFF<td>0x0000<td>0x29B1
/// <tr><td>crc-24<td>0x864CFB<td>False<td>0xB704CE<td>0x000000<td>0x21CF02
/// <tr><td>crc-32-ieee<td>0x04C11DB7<td>True<td>0x00000000<td>0xFFFFFFFF<td>0xCBF43926
/// <tr><td>crc-32-ietf<td>0x1EDC6F41<td>True<td>0x00000000<td>0xFFFFFFFF<td>0xE3069283
/// </table>
//////////////////////////////////////////////////////////////////////
enum crcpoly_t {
    CRC5_POLY = 0x07,
    CRC7_POLY = 0x07,
    CRC8_POLY = 0x07,
    CRC11_POLY = 0x07,
    CRC12_POLY = 0x07,
    CRC16_POLY = 0x8005,
    CRC16_CCITT_POLY = 0x1021,
    CRC24_POLY = 0x864CFB,
    CRC32_IEEE_POLY = 0x04C11DB7,
    CRC32_IETF_POLY = 0x1EDC6F41
};

Begin_Enum_String(crcpoly_t) {
    Enum_String(CRC5_POLY);
    Enum_String(CRC7_POLY);
    Enum_String(CRC8_POLY);
    Enum_String(CRC11_POLY);
    Enum_String(CRC12_POLY);
    Enum_String(CRC16_POLY);
    Enum_String(CRC16_CCITT_POLY);
    Enum_String(CRC24_POLY);
    Enum_String(CRC32_IEEE_POLY);
    Enum_String(CRC32_IETF_POLY);
}
End_Enum_String;

////////////////////////////////////////////////////////
/// WOTS+ Address Types
///
/// OTSADDR - WOTS+ using SHA256 with n=32, w=16
/// LTREEADDR - WOTS+ using SHA512 with n=64, w=16
/// HASHADDR - WOTS+ using SHAKE256 with n=32, w=16
////////////////////////////////////////////////////////
enum ots_addrtype_t {       /// WOTS+ Address type
    OTSADDR   = 0x00000000, /// WOTS+ LTREE Address type
    LTREEADDR = 0x00000001, /// WOTS+ Hash tree Address type
    HASHADDR  = 0x00000002
};

Begin_Enum_String(ots_addrtype_t) {
    Enum_String(OTSADDR);
    Enum_String(LTREEADDR);
    Enum_String(HASHADDR);
} End_Enum_String;

////////////////////////////////////////////////////////
/// WOTS+ Algorithm
///
/// WOTSP_SHA2_256 - WOTS+ using SHA256 with n=32, w=16
/// WOTSP_SHA2_512 - WOTS+ using SHA512 with n=64, w=16
/// WOTSP_SHAKE_256 - WOTS+ using SHAKE256 with n=32, w=16
/// WOTSP_SHAKE_512 - WOTS+ using SHAKE512 with n=64, w=16
////////////////////////////////////////////////////////
enum ots_algorithm_t {            /// WOTS+ using SHA256 with n=32, w=16
    WOTSP_SHA2_256  = 0x00000001, /// WOTS+ using SHA512 with n=64, w=16
    WOTSP_SHA2_512  = 0x00000002, /// WOTS+ using SHAKE256 with n=32, w=16
    WOTSP_SHAKE_256 = 0x00000003, /// WOTS+ using SHAKE512 with n=64, w=16
    WOTSP_SHAKE_512 = 0x00000004
};

Begin_Enum_String(ots_algorithm_t) {
    Enum_String(WOTSP_SHA2_256);
    Enum_String(WOTSP_SHA2_512);
    Enum_String(WOTSP_SHAKE_256);
    Enum_String(WOTSP_SHAKE_512);
} End_Enum_String;

////////////////////////////////////////////////////////
/// LMOTS Algorithm
///
/// LMOTS_SHA256_N32_W1 - LMS One-Time Signature using SHA256 with n=32, w=1, p=256, ls=7, sig_len=8516
/// LMOTS_SHA256_N32_W2 - LMS One-Time Signature using SHA256 with n=32, w=2, p=133, ls=6, sig_len=4292
/// LMOTS_SHA256_N32_W4 - LMS One-Time Signature using SHA256 with n=32, w=4, p=67, ls=4, sig_len=2180
/// LMOTS_SHA256_N32_W8 - LMS One-Time Signature using SHA256 with n=32, w=8, p=34, ls=0, sig_len=1124
////////////////////////////////////////////////////////
enum lmots_algorithm_t {              /// LMS One-Time Signature using SHA256 with n=32, w=1, p=256, ls=7, sig_len=8516
    LMOTS_SHA256_N32_W1 = 0x00000001, /// LMS One-Time Signature using SHA256 with n=32, w=2, p=133, ls=6, sig_len=4292
    LMOTS_SHA256_N32_W2 = 0x00000002, /// LMS One-Time Signature using SHA256 with n=32, w=4, p=67, ls=4, sig_len=2180
    LMOTS_SHA256_N32_W4 = 0x00000003, /// LMS One-Time Signature using SHA256 with n=32, w=8, p=34, ls=0, sig_len=1124
    LMOTS_SHA256_N32_W8 = 0x00000004
};

Begin_Enum_String(lmots_algorithm_t) {
    Enum_String(LMOTS_SHA256_N32_W1);
    Enum_String(LMOTS_SHA256_N32_W2);
    Enum_String(LMOTS_SHA256_N32_W4);
    Enum_String(LMOTS_SHA256_N32_W8);
} End_Enum_String;

////////////////////////////////////////////////////////
/// XMSS Algorithm
///
/// XMSS_SHA2_10_256 - XMSS using SHA256 with n=32, w=16, and h=10
/// XMSS_SHA2_16_256 - XMSS using SHA256 with n=32, w=16, and h=16
/// XMSS_SHA2_20_256 - XMSS using SHA256 with n=32, w=16, and h=20
/// XMSS_SHA2_10_512 - XMSS using SHA512 with n=64, w=16, and h=10
/// XMSS_SHA2_16_512 - XMSS using SHA512 with n=64, w=16, and h=16
/// XMSS_SHA2_20_512 - XMSS using SHA512 with n=64, w=16, and h=20
/// XMSS_SHA2_10_192 - XMSS using SHA256 with n=24, w=16, and h=10
/// XMSS_SHA2_16_192 - XMSS using SHA256 with n=24, w=16, and h=16
/// XMSS_SHA2_20_192 - XMSS using SHA256 with n=24, w=16, and h=20
/// XMSS_SHAKE_10_256 - XMSS using SHAKE256 with n=32, w=16, and h=10
/// XMSS_SHAKE_16_256 - XMSS using SHAKE256 with n=32, w=16, and h=16
/// XMSS_SHAKE_20_256 - XMSS using SHAKE256 with n=32, w=16, and h=20
/// XMSS_SHAKE_10_512 - XMSS using SHAKE256 with n=64, w=16, and h=10
/// XMSS_SHAKE_16_512 - XMSS using SHAKE256 with n=64, w=16, and h=16
/// XMSS_SHAKE_20_512 - XMSS using SHAKE256 with n=64, w=16, and h=20
/// XMSS_SHAKE_10_192 - XMSS using SHAKE256 with n=24, w=16, and h=10
/// XMSS_SHAKE_16_192 - XMSS using SHAKE256 with n=24, w=16, and h=16
/// XMSS_SHAKE_20_192 - XMSS using SHAKE256 with n=24, w=16, and h=20
////////////////////////////////////////////////////////
enum xmss_algorithm_t {             /// XMSS using SHA256 with n=32, w=16, and h=10
    XMSS_SHA2_10_256  = 0x00000001, /// XMSS using SHA256 with n=32, w=16, and h=16
    XMSS_SHA2_16_256  = 0x00000002, /// XMSS using SHA256 with n=32, w=16, and h=20
    XMSS_SHA2_20_256  = 0x00000003, /// XMSS using SHA512 with n=64, w=16, and h=10
    XMSS_SHA2_10_512  = 0x00000004, /// XMSS using SHA512 with n=64, w=16, and h=16
    XMSS_SHA2_16_512  = 0x00000005, /// XMSS using SHA512 with n=64, w=16, and h=20
    XMSS_SHA2_20_512  = 0x00000006, /// XMSS using SHA256 with n=24, w=16, and h=10
    XMSS_SHA2_10_192  = 0x0000000D, /// XMSS using SHA256 with n=24, w=16, and h=16
    XMSS_SHA2_16_192  = 0x0000000E, /// XMSS using SHA256 with n=24, w=16, and h=20
    XMSS_SHA2_20_192  = 0x0000000F, /// XMSS using SHAKE256 with n=32, w=16, and h=16
    XMSS_SHAKE_10_256 = 0x00000010, /// XMSS using SHAKE256 with n=32, w=16, and h=16
    XMSS_SHAKE_16_256 = 0x00000011, /// XMSS using SHAKE256 with n=32, w=16, and h=20
    XMSS_SHAKE_20_256 = 0x00000012, /// XMSS using SHAKE512 with n=64, w=16, and h=10
    XMSS_SHAKE_10_512 = 0x0000000A, /// XMSS using SHAKE512 with n=64, w=16, and h=16
    XMSS_SHAKE_16_512 = 0x0000000B, /// XMSS using SHAKE512 with n=64, w=16, and h=20
    XMSS_SHAKE_20_512 = 0x0000000C, /// XMSS using SHAKE256 with n=24, w=16, and h=10
    XMSS_SHAKE_10_192 = 0x00000013, /// XMSS using SHAKE256 with n=24, w=16, and h=16
    XMSS_SHAKE_16_192 = 0x00000014, /// XMSS using SHAKE256 with n=24, w=16, and h=20
    XMSS_SHAKE_20_192 = 0x00000015
};

Begin_Enum_String(xmss_algorithm_t) {
    Enum_String(XMSS_SHA2_10_256);
    Enum_String(XMSS_SHA2_16_256);
    Enum_String(XMSS_SHA2_20_256);
    Enum_String(XMSS_SHA2_10_512);
    Enum_String(XMSS_SHA2_16_512);
    Enum_String(XMSS_SHA2_20_512);
    Enum_String(XMSS_SHA2_10_192);
    Enum_String(XMSS_SHA2_16_192);
    Enum_String(XMSS_SHA2_20_192);
    Enum_String(XMSS_SHAKE_10_256);
    Enum_String(XMSS_SHAKE_16_256);
    Enum_String(XMSS_SHAKE_20_256);
    Enum_String(XMSS_SHAKE_10_512);
    Enum_String(XMSS_SHAKE_16_512);
    Enum_String(XMSS_SHAKE_20_512);
    Enum_String(XMSS_SHAKE_10_192);
    Enum_String(XMSS_SHAKE_16_192);
    Enum_String(XMSS_SHAKE_20_192);
} End_Enum_String;

////////////////////////////////////////////////////////
/// LMS Signature Algorithm
///
/// LMS_SHA256_M32_H5 - LMS One-Time Signature using SHA256 with m=32, h=5
/// LMS_SHA256_M32_H10 - LMS One-Time Signature using SHA256 with m=32, h=10
/// LMS_SHA256_M32_H15 - LMS One-Time Signature using SHA256 with m=32, h=15
/// LMS_SHA256_M32_H20 - LMS One-Time Signature using SHA256 with m=32, h=20
/// LMS_SHA256_M32_H25 - LMS One-Time Signature using SHA256 with m=32, h=25
////////////////////////////////////////////////////////
enum lms_algorithm_t {               /// LMS Signature using SHA256 with m=32, h=5
    LMS_SHA256_M32_H5  = 0x00000005, /// LMS Signature using SHA256 with m=32, h=10
    LMS_SHA256_M32_H10 = 0x00000006, /// LMS Signature using SHA256 with m=32, h=15
    LMS_SHA256_M32_H15 = 0x00000007, /// LMS Signature using SHA256 with m=32, h=20
    LMS_SHA256_M32_H20 = 0x00000008, /// LMS Signature using SHA256 with m=32, h=25
    LMS_SHA256_M32_H25 = 0x00000009
};

Begin_Enum_String(lms_algorithm_t) {
    Enum_String(LMS_SHA256_M32_H5);
    Enum_String(LMS_SHA256_M32_H10);
    Enum_String(LMS_SHA256_M32_H15);
    Enum_String(LMS_SHA256_M32_H20);
    Enum_String(LMS_SHA256_M32_H25);
} End_Enum_String;

////////////////////////////////////////////////////////
/// XMSSMT Signature
///
/// XMSSMT_SHA2_20_2_256 - XMSSMT using SHA256 with n=32, w=16, h=20, and d=2
/// XMSSMT_SHA2_20_4_256 - XMSSMT using SHA256 with n=32, w=16, h=20, and d=4
/// XMSSMT_SHA2_40_2_256 - XMSSMT using SHA256 with n=32, w=16, h=40, and d=2
/// XMSSMT_SHA2_40_4_256 - XMSSMT using SHA256 with n=32, w=16, h=40, and d=4
/// XMSSMT_SHA2_40_8_256 - XMSSMT using SHA256 with n=32, w=16, h=40, and d=8
/// XMSSMT_SHA2_60_3_256 - XMSSMT using SHA256 with n=32, w=16, h=60, and d=3
/// XMSSMT_SHA2_60_6_256 - XMSSMT using SHA256 with n=32, w=16, h=60, and d=6
/// XMSSMT_SHA2_60_12_256 - XMSSMT using SHA256 with n=32, w=16, h=60, and d=12
/// XMSSMT_SHA2_20_2_512 - XMSSMT using SHA512 with n=64, w=16, h=20, and d=2
/// XMSSMT_SHA2_20_4_512 - XMSSMT using SHA512 with n=64, w=16, h=20, and d=4
/// XMSSMT_SHA2_40_2_512 - XMSSMT using SHA512 with n=64, w=16, h=40, and d=2
/// XMSSMT_SHA2_40_4_512 - XMSSMT using SHA512 with n=64, w=16, h=40, and d=4
/// XMSSMT_SHA2_40_8_512 - XMSSMT using SHA512 with n=64, w=16, h=40, and d=8
/// XMSSMT_SHA2_60_3_512 - XMSSMT using SHA512 with n=64, w=16, h=60, and d=3
/// XMSSMT_SHA2_60_6_512 - XMSSMT using SHA512 with n=64, w=16, h=60, and d=6
/// XMSSMT_SHA2_60_12_512 - XMSSMT using SHA512 with n=64, w=16, h=60, and d=12
/// XMSSMT_SHAKE_20_2_256 - XMSSMT using SHAKE256 with n=32, w=16, h=20, and d=2
/// XMSSMT_SHAKE_20_4_256 - XMSSMT using SHAKE256 with n=32, w=16, h=20, and d=4
/// XMSSMT_SHAKE_40_2_256 - XMSSMT using SHAKE256 with n=32, w=16, h=40, and d=2
/// XMSSMT_SHAKE_40_4_256 - XMSSMT using SHAKE256 with n=32, w=16, h=40, and d=4
/// XMSSMT_SHAKE_40_8_256 - XMSSMT using SHAKE256 with n=32, w=16, h=40, and d=8
/// XMSSMT_SHAKE_60_3_256 - XMSSMT using SHAKE256 with n=32, w=16, h=60, and d=3
/// XMSSMT_SHAKE_60_6_256 - XMSSMT using SHAKE256 with n=32, w=16, h=60, and d=6
/// XMSSMT_SHAKE_60_12_256 - XMSSMT using SHAKE256 with n=32, w=16, h=60, and d=12
/// XMSSMT_SHAKE_20_2_512 - XMSSMT using SHAKE512 with n=64, w=16, h=20, and d=2
/// XMSSMT_SHAKE_20_4_512 - XMSSMT using SHAKE512 with n=64, w=16, h=20, and d=4
/// XMSSMT_SHAKE_40_2_512 - XMSSMT using SHAKE512 with n=64, w=16, h=40, and d=2
/// XMSSMT_SHAKE_40_4_512 - XMSSMT using SHAKE512 with n=64, w=16, h=40, and d=4
/// XMSSMT_SHAKE_40_8_512 - XMSSMT using SHAKE512 with n=64, w=16, h=40, and d=8
/// XMSSMT_SHAKE_60_3_512 - XMSSMT using SHAKE512 with n=64, w=16, h=60, and d=3
/// XMSSMT_SHAKE_60_6_512 - XMSSMT using SHAKE512 with n=64, w=16, h=60, and d=6
/// XMSSMT_SHAKE_60_12_512 - XMSSMT using SHAKE512 with n=64, w=16, h=60, and d=12
////////////////////////////////////////////////////////
enum xmssmt_algorithm_t { /// XMSSMT using SHA256 with n=32, w=16, h=20, and d=2
    XMSSMT_SHA2_20_2_256 = 0x00000001, /// XMSSMT using SHA256 with n=32, w=16, h=20, and d=4
    XMSSMT_SHA2_20_4_256 = 0x00000002, /// XMSSMT using SHA256 with n=32, w=16, h=40, and d=2
    XMSSMT_SHA2_40_2_256 = 0x00000003, /// XMSSMT using SHA256 with n=32, w=16, h=40, and d=4
    XMSSMT_SHA2_40_4_256 = 0x00000004, /// XMSSMT using SHA256 with n=32, w=16, h=40, and d=8
    XMSSMT_SHA2_40_8_256 = 0x00000005, /// XMSSMT using SHA256 with n=32, w=16, h=60, and d=3
    XMSSMT_SHA2_60_3_256 = 0x00000006, /// XMSSMT using SHA256 with n=32, w=16, h=60, and d=6
    XMSSMT_SHA2_60_6_256 = 0x00000007, /// XMSSMT using SHA256 with n=32, w=16, h=60, and d=12
    XMSSMT_SHA2_60_12_256 = 0x00000008, /// XMSSMT using SHA512 with n=64, w=16, h=20, and d=2
    XMSSMT_SHA2_20_2_512 = 0x00000009, /// XMSSMT using SHA512 with n=64, w=16, h=20, and d=4
    XMSSMT_SHA2_20_4_512 = 0x0000000A, /// XMSSMT using SHA512 with n=64, w=16, h=40, and d=2
    XMSSMT_SHA2_40_2_512 = 0x0000000B, /// XMSSMT using SHA512 with n=64, w=16, h=40, and d=4
    XMSSMT_SHA2_40_4_512 = 0x0000000C, /// XMSSMT using SHA512 with n=64, w=16, h=40, and d=8
    XMSSMT_SHA2_40_8_512 = 0x0000000D, /// XMSSMT using SHA512 with n=64, w=16, h=60, and d=3
    XMSSMT_SHA2_60_3_512 = 0x0000000E, /// XMSSMT using SHA512 with n=64, w=16, h=60, and d=6
    XMSSMT_SHA2_60_6_512 = 0x0000000F, /// XMSSMT using SHA512 with n=64, w=16, h=60, and d=12
    XMSSMT_SHA2_60_12_512 = 0x00000010, /// XMSSMT using SHAKE256 with n=32, w=16, h=20, and d=2
    XMSSMT_SHAKE_20_2_256 = 0x00000011, /// XMSSMT using SHAKE256 with n=32, w=16, h=20, and d=4
    XMSSMT_SHAKE_20_4_256 = 0x00000012, /// XMSSMT using SHAKE256 with n=32, w=16, h=40, and d=2
    XMSSMT_SHAKE_40_2_256 = 0x00000013, /// XMSSMT using SHAKE256 with n=32, w=16, h=40, and d=4
    XMSSMT_SHAKE_40_4_256 = 0x00000014, /// XMSSMT using SHAKE256 with n=32, w=16, h=40, and d=8
    XMSSMT_SHAKE_40_8_256 = 0x00000015, /// XMSSMT using SHAKE256 with n=32, w=16, h=60, and d=3
    XMSSMT_SHAKE_60_3_256 = 0x00000016, /// XMSSMT using SHAKE256 with n=32, w=16, h=60, and d=6
    XMSSMT_SHAKE_60_6_256 = 0x00000017, /// XMSSMT using SHAKE256 with n=32, w=16, h=60, and d=12
    XMSSMT_SHAKE_60_12_256 = 0x00000018, /// XMSSMT using SHAKE512 with n=64, w=16, h=20, and d=2
    XMSSMT_SHAKE_20_2_512 = 0x00000019, /// XMSSMT using SHAKE512 with n=64, w=16, h=20, and d=4
    XMSSMT_SHAKE_20_4_512 = 0x0000001A, /// XMSSMT using SHAKE512 with n=64, w=16, h=40, and d=2
    XMSSMT_SHAKE_40_2_512 = 0x0000001B, /// XMSSMT using SHAKE512 with n=64, w=16, h=40, and d=4
    XMSSMT_SHAKE_40_4_512 = 0x0000001C, /// XMSSMT using SHAKE512 with n=64, w=16, h=40, and d=8
    XMSSMT_SHAKE_40_8_512 = 0x0000001D, /// XMSSMT using SHAKE512 with n=64, w=16, h=60, and d=3
    XMSSMT_SHAKE_60_3_512 = 0x0000001E, /// XMSSMT using SHAKE512 with n=64, w=16, h=60, and d=6
    XMSSMT_SHAKE_60_6_512 = 0x0000001F, /// XMSSMT using SHAKE512 with n=64, w=16, h=60, and d=12
    XMSSMT_SHAKE_60_12_512 = 0x00000020
};

Begin_Enum_String(xmssmt_algorithm_t) {
    Enum_String(XMSSMT_SHA2_20_2_256);
    Enum_String(XMSSMT_SHA2_20_4_256);
    Enum_String(XMSSMT_SHA2_40_2_256);
    Enum_String(XMSSMT_SHA2_40_4_256);
    Enum_String(XMSSMT_SHA2_40_8_256);
    Enum_String(XMSSMT_SHA2_60_3_256);
    Enum_String(XMSSMT_SHA2_60_6_256);
    Enum_String(XMSSMT_SHA2_60_12_256);
    Enum_String(XMSSMT_SHA2_20_2_512);
    Enum_String(XMSSMT_SHA2_20_4_512);
    Enum_String(XMSSMT_SHA2_40_2_512);
    Enum_String(XMSSMT_SHA2_40_4_512);
    Enum_String(XMSSMT_SHA2_40_8_512);
    Enum_String(XMSSMT_SHA2_60_3_512);
    Enum_String(XMSSMT_SHA2_60_6_512);
    Enum_String(XMSSMT_SHA2_60_12_512);
    Enum_String(XMSSMT_SHAKE_20_2_256);
    Enum_String(XMSSMT_SHAKE_20_4_256);
    Enum_String(XMSSMT_SHAKE_40_2_256);
    Enum_String(XMSSMT_SHAKE_40_4_256);
    Enum_String(XMSSMT_SHAKE_40_8_256);
    Enum_String(XMSSMT_SHAKE_60_3_256);
    Enum_String(XMSSMT_SHAKE_60_6_256);
    Enum_String(XMSSMT_SHAKE_60_12_256);
    Enum_String(XMSSMT_SHAKE_20_2_512);
    Enum_String(XMSSMT_SHAKE_20_4_512);
    Enum_String(XMSSMT_SHAKE_40_2_512);
    Enum_String(XMSSMT_SHAKE_40_4_512);
    Enum_String(XMSSMT_SHAKE_40_8_512);
    Enum_String(XMSSMT_SHAKE_60_3_512);
    Enum_String(XMSSMT_SHAKE_60_6_512);
    Enum_String(XMSSMT_SHAKE_60_12_512);
} End_Enum_String;

}

#endif //JENUM_H
