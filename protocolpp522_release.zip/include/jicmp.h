#ifndef JPROTOCOL_JICMP_H_
#define JPROTOCOL_JICMP_H_

///
///\class jicmp jicmp.h "include/jicmp.h"
///
///\section ICMP_Class Internet Control Message Protocol (ICMP)
///
/// See https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol
///
/// The Internet Control Message Protocol (ICMP) is one of the main protocols of the internet protocol
/// suite. It is used by network devices, like routers, to send error messages indicating, for example,
/// that a requested service is not available or that a host or router could not be reached. ICMP can
/// also be used to relay query messages.[1] It is assigned protocol number 1.[2] ICMP[3] differs from
/// transport protocols such as TCP and UDP in that it is not typically used to exchange data between
/// systems, nor is it regularly employed by end-user network applications (with the exception of some
/// diagnostic tools like ping and traceroute)
///
/// <B>ICMP_STRUCT ICMP datagram structure</B>
///
/// <B>Header</B>
///
/// The ICMP header starts after the IPv4 header and is identified by IP protocol number '1'. All ICMP
/// packets have an 8-byte header and variable-sized data section. The first 4 bytes of the header
/// have fixed format, while the last 4 bytes depend on the type/code of that ICMP packet
///
///\image html ICMP_Header.png "ICMP Version 4 Header [1]"
///\image latex ICMP_Header.eps "ICMP Version 4 Header [1]" width=15cm
///
/// <B>Type</B> 
///
/// ICMP type, see Control messages
///
/// <B>Code</B> 
///
/// ICMP subtype, see Control messages
///
/// <B>ICMP Version 4 Message Types</B>
///
/// <table>
/// <caption id="ICMP MSG TYPE">Summary of Message Types</caption>
/// <tr><th colspan="2">Summary of ICMP Version 4 Message Types
/// <tr><th col>Message Value<th>Message Name
/// <tr><td>0<td>Echo Reply
/// <tr><td>3<td>Destination Unreachable
/// <tr><td>4<td>Source Quench
/// <tr><td>5<td>Redirect
/// <tr><td>8<td>Echo
/// <tr><td>11<td>Time Exceeded
/// <tr><td>12<td>Parameter Problem
/// <tr><td>13<td>Timestamp
/// <tr><td>14<td>Timestamp Reply
/// <tr><td>15<td>Information Request
/// <tr><td>16<td>Information Reply
/// </table>
///
/// <B>Checksum</B> 
///
/// Error checking data, calculated from the ICMP header and data, with value 0 substituted for this
/// field. The Internet Checksum is used, specified in RFC 1071
///
/// <B>Rest of Header</B> 
///
/// Four-bytes field, contents vary based on the ICMP type and code
///
/// <B>Data</B>
///
/// ICMP error messages contain a data section that includes the entire IPv4 header, plus the first
/// eight bytes of data from the IPv4 packet that caused the error message. The ICMP packet is then
/// encapsulated in a new IPv4 packet.[1] This data is used by the host to match the message to the
/// appropriate process. If a higher level protocol uses port numbers, they are assumed to be in the
/// first 64 data bits of the original datagram's data
///
/// The variable size of the ICMP packet data section has been exploited. In the "Ping of death",
/// large or fragmented ping packets are used for denial-of-service attacks. ICMP can also be used
/// to create covert channels for communication. These channels are known as ICMP tunnels
///
/// <B>Control Messages</B>
///
///\image html ICMP_Message1.png
///\image latex ICMP_Message1.eps "" width=15cm
///
///\image html ICMP_Message2.png "ICMP Control Message Values [2]"
///\image latex ICMP_Message2.eps "ICMP Control Message Values [2]" width=15cm
///
///
///\subsection ICMPv6 Internet Control Message Protocol version 6
///
/// See https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol_version_6
///
/// Internet Control Message Protocol version 6 (ICMPv6) is the implementation of the Internet
/// Control Message Protocol (ICMP) for Internet Protocol version 6 (IPv6). ICMPv6 is defined in
/// RFC 4443.[1] ICMPv6 is an integral part of IPv6 and performs error reporting and diagnostic
/// functions (e.g., ping), and has a framework for extensions to implement future changes
///
/// Several extensions have been published, defining new ICMPv6 message types as well as new options
/// for existing ICMPv6 message types. Neighbor Discovery Protocol (NDP) is a node discovery protocol
/// in IPv6 which replaces and enhances functions of ARP.[2] Secure Neighbor Discovery (SEND) is an
/// extension of NDP with extra security. Multicast Router Discovery (MRD) allows discovery of multicast 
/// routers
///
/// <B>Technical details</B>
///
/// ICMPv6 messages may be classified into two categories: error messages and information messages.
/// ICMPv6 messages are transported by IPv6 packets in which the IPv6 Next Header value for ICMPv6 is
/// set to 58
///
/// <B>Packet format</B>
///
/// The ICMPv6 packet consists of a header and the protocol payload. The header contains only three
/// fields:
///
/// * type (8 bits) - Type specifies the type of the message. Values in the range from 0 to 127
///                   (high-order bit is 0) indicate an error message, while values in the range from
///                   128 to 255 (high-order bit is 1) indicate an information message
///
/// * code (8 bits) - The code field value depends on the message type and provides an additional
///                   level of message granularity
///
/// * checksum (16 bits) - The checksum field provides a minimal level of integrity verification
///                        for the ICMP message
///
///\image html ICMPv6_Packet.png "ICMP Version 6 Header [3]"
///\image latex ICMPv6_Packet.eps "ICMP Version 6 Header [3]" width=15cm
///
///
/// <B>Message checksum</B>
///
/// ICMPv6 provides a minimal level of message integrity verification by the inclusion of a 16-bit
/// checksum in its header. The checksum is calculated starting with a pseudo-header of IPv6 header
/// fields according to the IPv6 standard,[3] which consists of the source and destination addresses,
/// the packet length and the next header field, the latter of which is set to the value 58. Following
/// this pseudo header, the checksum is continued with the ICMPv6 message in which the checksum is
/// initially set to zero. The checksum computation is performed according to Internet protocol
/// standards using 16-bit ones' complement summation, followed by complementing the checksum itself
/// and inserting it into the checksum field.[4] Note that this differs from the way it is calculated
/// for IPv4 in ICMP, but is similar to the calculation done in TCP
///
///\image html ICMPv6_Checksum.png "ICMP Version 6 Psuedo Header for Checksum Calculation [4]"
///\image latex ICMPv6_Checksum.eps "ICMP Version 6 Psuedo Header for Checksum Calculation [4]" width=15cm
///
/// <B>Message processing</B>
///
/// When an ICMPv6 node receives a packet, it must undertake actions that depend on the type of message.
/// The ICMPv6 protocol must limit the number of error messages sent to the same destination to avoid
/// network overloading. For example, if a node continues to forward erroneous packets, ICMP will signal
/// the error to the first packet and then do so periodically, with a fixed minimum period or with a
/// fixed network maximum load. An ICMP error message must never be sent in response to another ICMP
/// error message
///
/// 1. https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol
/// 2. https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol
/// 3. https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol_version_6
/// 4. https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol_version_6
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jarray
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jicmpsa.h"
#include "jprotocol.h"

namespace ProtocolPP {

class jicmp : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// constructor for ICMP and ICMPv6 
    /// @param security - Parameters necessary to setup ICMP flow such
    ///                   as DIRECTION, VERSION, MSG, CODE, SRC, DST
    //////////////////////////////////////////////////////////////////////
    explicit jicmp(std::shared_ptr<jicmpsa>& security);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jicmp() {}

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without
    /// a file handle. Encap will produce a packet with the payload
    /// passed in
    /// @param input - payload to encapsulate with IP
    /// @param output - IP encapsulated packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without
    /// a file handle. Decap will produce a payload from the packet
    /// passed in.
    /// @param input - IP encapsulated packet to decapsulate
    /// @param output - decapsulated payload
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the header
    /// @param hdr - new ICMP header
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the IP header
    /// @param field - field to update the IP header with
    /// @param value - value to update the IP header with
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to retrieve the header
    /// @return full ICMP header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr();

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the IP header
    /// @param field - field to retrieve from the IP header
    /// @param header - ICMP header to retrieve field from
    /// @return version field of the IP header
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& header);

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jicmpsa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol as an XML object
    /// @param myxml - XMLPrinter object to print with
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

    //////////////////////////////////////////////////////////////////////
    /// Converts ICMP message code to unsigned int
    /// @param msg - ICMP message code to convert
    /// @return - Unsigned int for ICMP message
    //////////////////////////////////////////////////////////////////////
    uint8_t convmsg(icmpmsg_t msg);

    //////////////////////////////////////////////////////////////////////
    /// Converts ICMP code to unsigned int
    /// @param code - ICMP code to convert
    /// @return - Unsigned int for ICMP code
    //////////////////////////////////////////////////////////////////////
    uint8_t convcode(icmpcode_t code);

private:

    // don't use these
    jicmp() = delete;
    jicmp(jicmp& jicmp) = delete;
    jicmp(const jicmp& jicmp) = delete;

    // initialization routine
    void init();
    
    // member variables
    std::shared_ptr<jicmpsa> m_sec;
    jarray<uint8_t> m_icmphdr;
};

}

#endif // JPROTOCOL_JICMP_H_
