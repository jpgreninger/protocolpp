#ifndef JIPSECSA_H_
#define JIPSECSA_H_

///
///\class jipsecsa jipsecsa.h "include/jipsecsa.h"
///   
///
///\section ESPSASA Encapsulating Security Payload (ESP) Security Association
///
/// (See RFC4303 for complete details)
///
///   The (outer) protocol header (IPv4, IPv6, or Extension) that
///   immediately precedes the ESP header SHALL contain the value 50 in its
///   Protocol (IPv4) or Next Header (IPv6, Extension) field (see IANA web
///   page at http://www.iana.org/assignments/protocol-numbers).  Figure 1
///   illustrates the top-level format of an ESP packet.  The packet begins
///   with two 4-byte fields (Security Parameters Index (SPI) and Sequence
///   Number).  Following these fields is the Payload Data, which has
///   substructure that depends on the choice of encryption algorithm and
///   mode, and on the use of TFC padding, which is examined in more detail
///   later.  Following the Payload Data are Padding and Pad Length fields,
///   and the Next Header field.  The optional Integrity Check Value (ICV)
///   field completes the packet.
///
///\code
///
/// 0               1               2               3
/// 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7
///+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ ----
///|               Security Parameters Index (SPI)                 | ^Int.
///+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ |Cov-
///|                      Sequence Number                          | |ered
///+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ | ----
///|                    Payload Data* (variable)                   | |   ^
///~                                                               ~ |   |
///|                                                               | |Conf.
///+               +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ |Cov-
///|               |     Padding (0-255 bytes)                     | |ered*
///+-+-+-+-+-+-+-+-+               +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ |   |
///|                               |  Pad Length   | Next Header   | v   v
///+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ ------
///|         Integrity Check Value-ICV   (variable)                |
///~                                                               ~
///|                                                               |
///+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
///
///            Figure 1.  Top-Level Format of an ESP Packet
///
///    * If included in the Payload field, cryptographic synchronization
///      data, e.g., an Initialization Vector (IV, see Section 2.3),
///      usually is not encrypted per se, although it often is referred
///      to as being part of the ciphertext.
///
///\endcode
///
///
///   The (transmitted) ESP trailer consists of the Padding, Pad Length,
///   and Next Header fields.  Additional, implicit ESP trailer data (which
///   is not transmitted) is included in the integrity computation, as
///   described below.
///
///   If the integrity service is selected, the integrity computation
///   encompasses the SPI, Sequence Number, Payload Data, and the ESP
///   trailer (explicit and implicit).
///
///   If the confidentiality service is selected, the ciphertext consists
///   of the Payload Data (except for any cryptographic synchronization
///   data that may be included) and the (explicit) ESP trailer.
///
///   As noted above, the Payload Data may have substructure.  An
///   encryption algorithm that requires an explicit Initialization Vector
///   (IV), e.g., Cipher Block Chaining (CBC) mode, often prefixes the
///   Payload Data to be protected with that value.  Some algorithm modes
///   combine encryption and integrity into a single operation; this
///   document refers to such algorithm modes as "combined mode
///   algorithms".  Accommodation of combined mode algorithms requires that
///   the algorithm explicitly describe the payload substructure used to
///   convey the integrity data.
///
///   Some combined mode algorithms provide integrity only for data that is
///   encrypted, whereas others can provide integrity for some additional
///   data that is not encrypted for transmission.  Because the SPI and
///   Sequence Number fields require integrity as part of the integrity
///   service, and they are not encrypted, it is necessary to ensure that
///   they are afforded integrity whenever the service is selected,
///   regardless of the style of combined algorithm mode employed.
///
///   When any combined mode algorithm is employed, the algorithm itself is
///   expected to return both decrypted plaintext and a pass/fail
///   indication for the integrity check.  For combined mode algorithms,
///   the ICV that would normally appear at the end of the ESP packet (when
///   integrity is selected) may be omitted.  When the ICV is omitted and
///   integrity is selected, it is the responsibility of the combined mode
///   algorithm to encode within the Payload Data an ICV-equivalent means
///   of verifying the integrity of the packet.
///
///   If a combined mode algorithm offers integrity only to data that is
///   encrypted, it will be necessary to replicate the SPI and Sequence
///   Number as part of the Payload Data.
///
///   Finally, a new provision is made to insert padding for traffic flow
///   confidentiality after the Payload Data and before the ESP trailer.
///   Figure 2 illustrates this substructure for Payload Data.  (Note: This
///   diagram shows bits-on-the-wire.  So even if extended sequence numbers
///   are being used, only 32 bits of the Sequence Number will be
///   transmitted (see Section 2.2.1).)
///
///\code
///
///    0               1               2               3
///    0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
///   |               Security Parameters Index (SPI)                 |
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
///   |                      Sequence Number                          |
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+---
///   |                    IV (optional)                              | ^ p
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ | a
///   |                    Rest of Payload Data  (variable)           | | y
///   ~                                                               ~ | l
///   |                                                               | | o
///   +               +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ | a
///   |               |         TFC Padding * (optional, variable)    | v d
///   +-+-+-+-+-+-+-+-+         +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+---
///   |                         |        Padding (0-255 bytes)        |
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
///   |                               |  Pad Length   | Next Header   |
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
///   |         Integrity Check Value-ICV   (variable)                |
///   ~                                                               ~
///   |                                                               |
///   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
///
///               Figure 2. Substructure of Payload Data
///
///         * If tunnel mode is being used, then the IPsec implementation
///           can add Traffic Flow Confidentiality (TFC) padding (see
///           Section 2.4)  after the Payload Data and before the Padding
///           (0-255 bytes) field.
///
///\endcode
///
///   If a combined algorithm mode is employed, the explicit ICV shown in
///   Figures 1 and 2 may be omitted (see Section 3.3.2.2 below).  Because
///   algorithms and modes are fixed when an SA is established, the
///   detailed format of ESP packets for a given SA (including the Payload
///   Data substructure) is fixed, for all traffic on the SA.
///
///   The tables below refer to the fields in the preceding figures and
///   illustrate how several categories of algorithmic options, each with a
///   different processing model, affect the fields noted above.  The
///   processing details are described in later sections.
///
///\code
///          Table 1. Separate Encryption and Integrity Algorithms
///
///                                            What    What    What
///                          # of     Requ'd  Encrypt Integ    is
///                          bytes      [1]   Covers  Covers  Xmtd
///                          ------   ------  ------  ------  ------
///   SPI                       4        M              Y     plain
///   Seq# (low-order bits)     4        M              Y     plain       p
///                                                                ------ a
///   IV                     variable    O              Y     plain     | y
///   IP datagram [2]        variable  M or D    Y      Y     cipher[3] |-l
///   TFC padding [4]        variable    O       Y      Y     cipher[3] | o
///                                                                ------ a
///   Padding                 0-255      M       Y      Y     cipher[3]   d
///   Pad Length                1        M       Y      Y     cipher[3]
///   Next Header               1        M       Y      Y     cipher[3]
///   Seq# (high-order bits)    4     if ESN [5]        Y     not xmtd
///   ICV Padding            variable if need           Y     not xmtd
///   ICV                    variable   M [6]                 plain
///
///           [1] M = mandatory; O = optional; D = dummy
///           [2] If tunnel mode -> IP datagram
///               If transport mode -> next header and data
///           [3] ciphertext if encryption has been selected
///           [4] Can be used only if payload specifies its "real" length
///           [5] See section 2.2.1
///           [6] mandatory if a separate integrity algorithm is used
///
///
///
///                  Table 2. Combined Mode Algorithms
///
///                                             What    What    What
///                            # of     Requ'd  Encrypt Integ    is
///                            bytes      [1]   Covers  Covers  Xmtd
///                            ------   ------  ------  ------  ------
///    SPI                        4        M                    plain
///    Seq# (low-order bits)      4        M                    plain    p
///                                                                  --- a
///    IV                      variable    O              Y     plain  | y
///    IP datagram [2]         variable  M or D    Y      Y     cipher |-l
///    TFC padding [3]         variable    O       Y      Y     cipher | o
///                                                                  --- a
///    Padding                  0-255      M       Y      Y     cipher   d
///    Pad Length                 1        M       Y      Y     cipher
///    Next Header                1        M       Y      Y     cipher
///    Seq# (high-order bits)     4     if ESN [4]        Y     [5]
///    ICV Padding             variable if need           Y     [5]
///    ICV                     variable    O [6]                plain
///
///            [1] M = mandatory; O = optional; D = dummy
///            [2] If tunnel mode -> IP datagram
///                If transport mode -> next header and data
///            [3] Can be used only if payload specifies its "real" length
///            [4] See Section 2.2.1
///            [5] The algorithm choices determines whether these are
///                transmitted, but in either case, the result is invisible
///                to ESP
///            [6] The algorithm spec determines whether this field is
///                present
///\endcode
///
///   The following subsections describe the fields in the header format.
///   "Optional" means that the field is omitted if the option is not
///   selected, i.e., it is present in neither the packet as transmitted
///   nor as formatted for computation of an ICV (see Section 2.7).
///   Whether or not an option is selected is determined as part of
///   Security Association (SA) establishment.  Thus, the format of ESP
///   packets for a given SA is fixed, for the duration of the SA.  In
///   contrast, "mandatory" fields are always present in the ESP packet
///   format, for all SAs.
///
///   Note: All of the cryptographic algorithms used in IPsec expect their
///   input in canonical network byte order (see Appendix of RFC 791
///   [Pos81]) and generate their output in canonical network byte order.
///   IP packets are also transmitted in network byte order.
///
///
///   ESP does not contain a version number, therefore if there are
///   concerns about backward compatibility, they MUST be addressed by
///   using a signaling mechanism between the two IPsec peers to ensure
///   compatible versions of ESP (e.g., Internet Key Exchange (IKEv2)
///   [Kau05]) or an out-of-band configuration mechanism.
///
///
/// <B>Security Parameters Index (SPI)</B>
///
///   The SPI is an arbitrary 32-bit value that is used by a receiver to
///   identify the SA to which an incoming packet is bound.  The SPI field
///   is mandatory.
///
///   For a unicast SA, the SPI can be used by itself to specify an SA, or
///   it may be used in conjunction with the IPsec protocol type (in this
///   case ESP).  Because the SPI value is generated by the receiver for a
///   unicast SA, whether the value is sufficient to identify an SA by
///   itself or whether it must be used in conjunction with the IPsec
///   protocol value is a local matter.  This mechanism for mapping inbound
///   traffic to unicast SAs MUST be supported by all ESP implementations.
///
///   If an IPsec implementation supports multicast, then it MUST support
///   multicast SAs using the algorithm below for mapping inbound IPsec
///   datagrams to SAs.  Implementations that support only unicast traffic
///   need not implement this de-multiplexing algorithm.
///
///   In many secure multicast architectures (e.g., [RFC3740]), a central
///   Group Controller/Key Server unilaterally assigns the group security
///   association's SPI.  This SPI assignment is not negotiated or
///   coordinated with the key management (e.g., IKE) subsystems that
///   reside in the individual end systems that comprise the group.
///   Consequently, it is possible that a group security association and a
///   unicast security association can simultaneously use the same SPI.  A
///   multicast-capable IPsec implementation MUST correctly de-multiplex
///   inbound traffic even in the context of SPI collisions.
///
///   Each entry in the Security Association Database (SAD) [Ken-Arch] must
///   indicate whether the SA lookup makes use of the destination, or
///   destination and source, IP addresses, in addition to the SPI.  For
///   multicast SAs, the protocol field is not employed for SA lookups.
///   For each inbound, IPsec-protected packet, an implementation must
///   conduct its search of the SAD such that it finds the entry that
///   matches the "longest" SA identifier.  In this context, if two or more
///   SAD entries match based on the SPI value, then the entry that also
///   matches based on destination, or destination and source, address
///   comparison (as indicated in the SAD entry) is the "longest" match.
///   This implies a logical ordering of the SAD search as follows:
///
///   1. Search the SAD for a match on {SPI, destination address,
///      source address}.  If an SAD entry matches, then process the
///      inbound ESP packet with that matching SAD entry.  Otherwise,
///      proceed to step 2.
///
///   2. Search the SAD for a match on {SPI, destination address}.
///      If the SAD entry matches, then process the inbound ESP
///      packet with that matching SAD entry.  Otherwise, proceed to
///      step 3.
///
///   3. Search the SAD for a match on only {SPI} if the receiver has
///      chosen to maintain a single SPI space for AH and ESP, or on
///      {SPI, protocol} otherwise.  If an SAD entry matches, then
///      process the inbound ESP packet with that matching SAD entry.
///      Otherwise, discard the packet and log an auditable event.
///
///   In practice, an implementation MAY choose any method to accelerate
///   this search, although its externally visible behavior MUST be
///   functionally equivalent to having searched the SAD in the above
///   order.  For example, a software-based implementation could index into
///   a hash table by the SPI.  The SAD entries in each hash table bucket's
///   linked list are kept sorted to have those SAD entries with the
///   longest SA identifiers first in that linked list.  Those SAD entries
///   having the shortest SA identifiers are sorted so that they are the
///   last entries in the linked list.  A hardware-based implementation may
///   be able to effect the longest match search intrinsically, using
///   commonly available Ternary Content-Addressable Memory (TCAM)
///   features.
///
///   The indication of whether source and destination address matching is
///   required to map inbound IPsec traffic to SAs MUST be set either as a
///   side effect of manual SA configuration or via negotiation using an SA
///   management protocol, e.g., IKE or Group Domain of Interpretation
///   (GDOI) [RFC3547].  Typically, Source-Specific Multicast (SSM) [HC03]
///   groups use a 3-tuple SA identifier composed of an SPI, a destination
///   multicast address, and source address.  An Any-Source Multicast group
///   SA requires only an SPI and a destination multicast address as an
///   identifier.
///
///   The set of SPI values in the range 1 through 255 are reserved by the
///   Internet Assigned Numbers Authority (IANA) for future use; a reserved
///   SPI value will not normally be assigned by IANA unless the use of the
///   assigned SPI value is specified in an RFC.  The SPI value of zero (0)
///   is reserved for local, implementation-specific use and MUST NOT be
///   sent on the wire.  (For example, a key management implementation
///   might use the zero SPI value to mean "No Security Association Exists"
///   during the period when the IPsec implementation has requested that
///   its key management entity establish a new SA, but the SA has not yet
///   been established.)
///
/// <B>Sequence Number</B>
///
///   This unsigned 32-bit field contains a counter value that increases by
///   one for each packet sent, i.e., a per-SA packet sequence number.  For
///   a unicast SA or a single-sender multicast SA, the sender MUST
///   increment this field for every transmitted packet.  Sharing an SA
///   among multiple senders is permitted, though generally not
///   recommended.  ESP provides no means of synchronizing packet counters
///   among multiple senders or meaningfully managing a receiver packet
///   counter and window in the context of multiple senders.  Thus, for a
///   multi-sender SA, the anti-replay features of ESP are not available
///   (see Sections 3.3.3 and 3.4.3.)
///
///   The field is mandatory and MUST always be present even if the
///   receiver does not elect to enable the anti-replay service for a
///   specific SA.  Processing of the Sequence Number field is at the
///   discretion of the receiver, but all ESP implementations MUST be
///   capable of performing the processing described in Sections 3.3.3 and
///   3.4.3. Thus, the sender MUST always transmit this field, but the
///   receiver need not act upon it (see the discussion of Sequence Number
///   Verification in the "Inbound Packet Processing" section (3.4.3)
///   below).
///
///   The sender's counter and the receiver's counter are initialized to 0
///   when an SA is established.  (The first packet sent using a given SA
///   will have a sequence number of 1; see Section 3.3.3 for more details
///   on how the sequence number is generated.)  If anti-replay is enabled
///   (the default), the transmitted sequence number must never be allowed
///   to cycle.  Thus, the sender's counter and the receiver's counter MUST
///   be reset (by establishing a new SA and thus a new key) prior to the
///   transmission of the 2^32nd packet on an SA.
///
/// <B>Extended (64-bit) Sequence Number</B>
///
///   To support high-speed IPsec implementations, Extended Sequence
///   Numbers (ESNs) SHOULD be implemented, as an extension to the current,
///   32-bit sequence number field.  Use of an ESN MUST be negotiated by an
///   SA management protocol.  Note that in IKEv2, this negotiation is
///   implicit; the default is ESN unless 32-bit sequence numbers are
///   explicitly negotiated.  (The ESN feature is applicable to multicast
///   as well as unicast SAs.)
///
///   The ESN facility allows use of a 64-bit sequence number for an SA.
///   (See Appendix A, "Extended (64-bit) Sequence Numbers", for details.)
///   Only the low-order 32 bits of the sequence number are transmitted in
///   the plaintext ESP header of each packet, thus minimizing packet
///   overhead.  The high-order 32 bits are maintained as part of the
///   sequence number counter by both transmitter and receiver and are
///   included in the computation of the ICV (if the integrity service is
///   selected).  If a separate integrity algorithm is employed, the high
///   order bits are included in the implicit ESP trailer, but are not
///   transmitted, analogous to integrity algorithm padding bits.  If a
///   combined mode algorithm is employed, the algorithm choice determines
///   whether the high-order ESN bits are transmitted or are included
///   implicitly in the computation.  See Section 3.3.2.2 for processing
///   details.
///
/// <B>Payload Data</B>
///
///   Payload Data is a variable-length field containing data (from the
///   original IP packet) described by the Next Header field.  The Payload
///   Data field is mandatory and is an integral number of bytes in length.
///   If the algorithm used to encrypt the payload requires cryptographic
///   synchronization data, e.g., an Initialization Vector (IV), then this
///   data is carried explicitly in the Payload field, but it is not called
///   out as a separate field in ESP, i.e., the transmission of an explicit
///   IV is invisible to ESP.  (See Figure 2.)  Any encryption algorithm
///   that requires such explicit, per-packet synchronization data MUST
///   indicate the length, any structure for such data, and the location of
///   this data as part of an RFC specifying how the algorithm is used with
///   ESP.  (Typically, the IV immediately precedes the ciphertext.  See
///   Figure 2.)  If such synchronization data is implicit, the algorithm
///   for deriving the data MUST be part of the algorithm definition RFC.
///   (If included in the Payload field, cryptographic synchronization
///   data, e.g., an Initialization Vector (IV), usually is not encrypted
///   per se (see Tables 1 and 2), although it sometimes is referred to as
///   being part of the ciphertext.)
///
///   Note that the beginning of the next layer protocol header MUST be
///   aligned relative to the beginning of the ESP header as follows.  For
///   IPv4, this alignment is a multiple of 4 bytes.  For IPv6, the
///   alignment is a multiple of 8 bytes.
///
///   With regard to ensuring the alignment of the (real) ciphertext in the
///   presence of an IV, note the following:
///
///      * For some IV-based modes of operation, the receiver treats
///        the IV as the start of the ciphertext, feeding it into the
///        algorithm directly.  In these modes, alignment of the start
///        of the (real) ciphertext is not an issue at the receiver.
///
///      * In some cases, the receiver reads the IV in separately from
///        the ciphertext.  In these cases, the algorithm specification
///        MUST address how alignment of the (real) ciphertext is to be
///        achieved.
///
///
/// <B>Padding (for Encryption)</B>
///
///   Two primary factors require or motivate use of the Padding field.
///
///      * If an encryption algorithm is employed that requires the
///        plaintext to be a multiple of some number of bytes, e.g.,
///        the block size of a block cipher, the Padding field is used
///        to fill the plaintext (consisting of the Payload Data,
///        Padding, Pad Length, and Next Header fields) to the size
///        required by the algorithm.
///
///      * Padding also may be required, irrespective of encryption
///        algorithm requirements, to ensure that the resulting
///        ciphertext terminates on a 4-byte boundary.  Specifically,
///        the Pad Length and Next Header fields must be right aligned
///        within a 4-byte word, as illustrated in the ESP packet
///        format figures above, to ensure that the ICV field (if
///        present) is aligned on a 4-byte boundary.
///
///   Padding beyond that required for the algorithm or alignment reasons
///   cited above could be used to conceal the actual length of the
///   payload, in support of TFC.  However, the Padding field described is
///   too limited to be effective for TFC and thus should not be used for
///   that purpose.  Instead, the separate mechanism described below (see
///   Section 2.7) should be used when TFC is required.
///
///   The sender MAY add 0 to 255 bytes of padding.  Inclusion of the
///   Padding field in an ESP packet is optional, subject to the
///   requirements noted above, but all implementations MUST support
///   generation and consumption of padding.
///
///      * For the purpose of ensuring that the bits to be encrypted
///        are a multiple of the algorithm's block size (first bullet
///        above), the padding computation applies to the Payload Data
///        exclusive of any IV, but including the ESP trailer
///        fields.  If a combined algorithm mode requires transmission
///        of the SPI and Sequence Number to effect integrity, e.g.,
///        replication of the SPI and Sequence Number in the Payload
///        Data, then the replicated versions of these data items, and
///        any associated, ICV-equivalent data, are included in the
///        computation of the pad length.  (If the ESN option is
///        selected, the high-order 32 bits of the ESN also would enter
///        into the computation, if the combined mode algorithm
///        requires their transmission for integrity.)
///
///      * For the purposes of ensuring that the ICV is aligned on a
///        4-byte boundary (second bullet above), the padding
///        computation applies to the Payload Data inclusive of the IV,
///        the Pad Length, and Next Header fields.  If a combined mode
///        algorithm is used, any replicated data and ICV-equivalent
///        data are included in the Payload Data covered by the padding
///        computation.
///
///   If Padding bytes are needed but the encryption algorithm does not
///   specify the padding contents, then the following default processing
///   MUST be used.  The Padding bytes are initialized with a series of
///   (unsigned, 1-byte) integer values.  The first padding byte appended
///   to the plaintext is numbered 1, with subsequent padding bytes making
///   up a monotonically increasing sequence: 1, 2, 3, ....  When this
///   padding scheme is employed, the receiver SHOULD inspect the Padding
///   field.  (This scheme was selected because of its relative simplicity,
///   ease of implementation in hardware, and because it offers limited
///   protection against certain forms of "cut and paste" attacks in the
///   absence of other integrity measures, if the receiver checks the
///   padding values upon decryption.)
///
///   If an encryption or combined mode algorithm imposes constraints on
///   the values of the bytes used for padding, they MUST be specified by
///   the RFC defining how the algorithm is employed with ESP.  If the
///   algorithm requires checking of the values of the bytes used for
///   padding, this too MUST be specified in that RFC.
///
/// <B>Pad Length</B>
///
///   The Pad Length field indicates the number of pad bytes immediately
///   preceding it in the Padding field.  The range of valid values is 0 to
///   255, where a value of zero indicates that no Padding bytes are
///   present.  As noted above, this does not include any TFC padding
///   bytes.  The Pad Length field is mandatory.
///
/// <B>Next Header</B>
///
///   The Next Header is a mandatory, 8-bit field that identifies the type
///   of data contained in the Payload Data field, e.g., an IPv4 or IPv6
///   packet, or a next layer header and data.  The value of this field is
///   chosen from the set of IP Protocol Numbers defined on the web page of
///   the IANA, e.g., a value of 4 indicates IPv4, a value of 41 indicates
///   IPv6, and a value of 6 indicates TCP.
///
///   To facilitate the rapid generation and discarding of the padding
///   traffic in support of traffic flow confidentiality (see Section 2.4),
///   the protocol value 59 (which means "no next header") MUST be used to
///   designate a "dummy" packet.  A transmitter MUST be capable of
///   generating dummy packets marked with this value in the next protocol
///   field, and a receiver MUST be prepared to discard such packets,
///   without indicating an error.  All other ESP header and trailer fields
///   (SPI, Sequence Number, Padding, Pad Length, Next Header, and ICV)
///   MUST be present in dummy packets, but the plaintext portion of the
///   payload, other than this Next Header field, need not be well-formed,
///   e.g., the rest of the Payload Data may consist of only random bytes.
///   Dummy packets are discarded without prejudice.
///
///   Implementations SHOULD provide local management controls to enable
///   the use of this capability on a per-SA basis.  The controls should
///   allow the user to specify if this feature is to be used and also
///   provide parametric controls; for example, the controls might allow an
///   administrator to generate random-length or fixed-length dummy
///   packets.
///
///   DISCUSSION: Dummy packets can be inserted at random intervals to mask
///   the absence of actual traffic.  One can also "shape" the actual
///   traffic to match some distribution to which dummy traffic is added as
///   dictated by the distribution parameters.  As with the packet length
///   padding facility for Traffic Flow Security (TFS), the most secure
///   approach would be to generate dummy packets at whatever rate is
///   needed to maintain a constant rate on an SA.  If packets are all the
///   same size, then the SA presents the appearance of a constant bit rate
///   data stream, analogous to what a link crypto would offer at layer 1
///   or 2.  However, this is unlikely to be practical in many contexts,
///   e.g., when there are multiple SAs active, because it would imply
///   reducing the allowed bandwidth for a site, based on the number of
///   SAs, and that would undermine the benefits of packet switching.
///   Implementations SHOULD provide controls to enable local
///   administrators to manage the generation of dummy packets for TFC
///   purposes.
///
/// <B>Traffic Flow Confidentiality (TFC) Padding</B>
///
///   As noted above, the Padding field is limited to 255 bytes in length.
///   This generally will not be adequate to hide traffic characteristics
///   relative to traffic flow confidentiality requirements.  An optional
///   field, within the payload data, is provided specifically to address
///   the TFC requirement.
///
///   An IPsec implementation SHOULD be capable of padding traffic by
///   adding bytes after the end of the Payload Data, prior to the
///   beginning of the Padding field.  However, this padding (hereafter
///   referred to as TFC padding) can be added only if the Payload Data
///   field contains a specification of the length of the IP datagram.
///   This is always true in tunnel mode, and may be true in transport mode
///   depending on whether the next layer protocol (e.g., IP, UDP, ICMP)
///   contains explicit length information.  This length information will
///   enable the receiver to discard the TFC padding, because the true
///   length of the Payload Data will be known.  (ESP trailer fields are
///   located by counting back from the end of the ESP packet.)
///   Accordingly, if TFC padding is added, the field containing the
///   specification of the length of the IP datagram MUST NOT be modified
///   to reflect this padding.  No requirements for the value of this
///   padding are established by this standard.
///
///   In principle, existing IPsec implementations could have made use of
///   this capability previously, in a transparent fashion.  However,
///   because receivers may not have been prepared to deal with this
///   padding, the SA management protocol MUST negotiate this service prior
///   to a transmitter employing it, to ensure backward compatibility.
///   Combined with the convention described in Section 2.6 above, about
///   the use of protocol ID 59, an ESP implementation is capable of
///   generating dummy and real packets that exhibit much greater length
///   variability, in support of TFC.
///
///   Implementations SHOULD provide local management controls to enable
///   the use of this capability on a per-SA basis.  The controls should
///   allow the user to specify if this feature is to be used and also
///   provide parametric controls for the feature.
///
/// <B>Integrity Check Value (ICV)</B>
///
///   The Integrity Check Value is a variable-length field computed over
///   the ESP header, Payload, and ESP trailer fields.  Implicit ESP
///   trailer fields (integrity padding and high-order ESN bits, if
///   applicable) are included in the ICV computation.  The ICV field is
///   optional.  It is present only if the integrity service is selected
///   and is provided by either a separate integrity algorithm or a
///   combined mode algorithm that uses an ICV.  The length of the field is
///   specified by the integrity algorithm selected and associated with the
///   SA.  The integrity algorithm specification MUST specify the length of
///   the ICV and the comparison rules and processing steps for validation.
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jipsec
/// @see ProtocolPP::jipsecsa
/// @see ProtocolPP::jicmp
/// @see ProtocolPP::jicmpsa
/// @see ProtocolPP::jmodes
///
/// <B>For Additional Documentation:</B>
/// @see jsecass
/// @see jprotocol
/// @see jipsec
/// @see jipsecsa
/// @see jicmp
/// @see jicmpsa
/// @see jmodes
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///
    
#include "jsecass.h"

namespace ProtocolPP {

class jipsecsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor with defaults
    ///
    /// <table>
    /// <caption id="IPsec Defaults">IPsec Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::DECAP
    /// <tr><td>ver<td>iana_t::IPV4
    /// <tr><td>mode<td>ipmode_t::TUNNEL
    /// <tr><td>spi<td>0
    /// <tr><td>seqnum<td>0
    /// <tr><td>extseqnum<td>0
    /// <tr><td>arlen<td>0
    /// <tr><td>arwin<td>0
    /// <tr><td>cipher<td>cipher_t::AES_CBC
    /// <tr><td>ckeylen<td>16
    /// <tr><td>auth<td>auth_t::HMAC_SHA2_256
    /// <tr><td>akeylen<td>32
    /// <tr><td>ivlen<td>16
    /// <tr><td>saltlen<td>0
    /// <tr><td>bytecnt<td>0
    /// <tr><td>lifetime<td>0xFFFFFFFFFFFFFFFF
    /// <tr><td>seqnumovrflw<td>false
    /// <tr><td>statefulfrag<td>false
    /// <tr><td>bypassdf<td>false
    /// <tr><td>bypassdscp<td>false
    /// <tr><td>nat<td>false
    /// <tr><td>nchk<td>false
    /// <tr><td>natsrc<td>0
    /// <tr><td>natdst<td>0
    /// <tr><td>dsecn<td>0
    /// <tr><td>ttl<td>0
    /// <tr><td>flags<td>0x02
    /// <tr><td>id<td>0x00000001
    /// <tr><td>label<td>0
    /// <tr><td>fragoff<td>0
    /// <tr><td>morefrag<td>false
    /// <tr><td>fragid<td>0
    /// <tr><td>mtu<td>1500
    /// <tr><td>src<td>0
    /// <tr><td>dst<td>0
    /// <tr><td>exthdr<td>0
    /// <tr><td>nh<td>iana_t::ESP
    /// <tr><td>icvlen<td>32
    /// <tr><td>hdrlen<td>20
    /// <tr><td>tfclen<td>0
    /// <tr><td>usext<td>true
    /// <tr><td>randiv<td>false
    /// <tr><td>jumbogram<td>true
    /// <tr><td>audit<td>false
    /// <tr><td>auditlog<td>"./ipsec_audit.log"
    /// </table>
    //////////////////////////////////////////////////////////////////////
    jipsecsa();

    //////////////////////////////////////////////////////////////////////
    /// See RFC4301 for required fields and their meanings (Section 4.4.2.1)
    ///
    /// Security Association for IPsec. Initialization Vectors are
    /// generated randomly using the Mersenne Twister algorithm or are
    /// passed to the SA during key negotiation depending on the randiv setting
    ///
    /// Required fields:
    ///
    /// @param dir - Direction of processing (ENCAP or DECAP)
    /// @param ver - Version of IPsec (IPV4 or IPV6)
    /// @param spi - Security parameters index
    /// @param seqnum - Initial sequence number
    /// @param extseqnum - Initial value of the extended sequence number
    /// @param arlen - Number of packets to track in replay window
    /// @param arwin - Anti-replay window for tracking packets
    /// @param cipher - Encryption algorithm to use with IPsec
    /// @param ckeylen - Length of the cipher key
    /// @param cipherkey - Key for the encryption algorithm
    /// @param auth - Authentication algorithm to use with IPsec
    /// @param akeylen - Length of the authentication key
    /// @param authkey - Key for the authentication algorithm
    /// @param ivlen - Length of the initialization vector (IV)
    /// @param iv - Passed in initializaton vector (IV)
    /// @param saltlen - Length of the IPsec salt material
    /// @param salt - IPsec salt material
    /// @param bytecnt - Lifetime implementation of encrypted bytes
    /// @param lifetime - Time for this SA to live before it expires
    /// @param mode - Mode of operation, either TUNNEL or TRANSPORT
    /// @param seqnumovrflw - Allow sequence number overflow in ENCAP
    /// @param statefulfrag - Indicates whether stateful fragment checking applies to this SA
    /// @param bypassdf - Do not copy the DF bit from inner to outer header (both IPv4)
    /// @param bypassdscp - Do not copy the DSCP field from inner to outer header
    /// @param nat - Perform NAT-T on packets
    /// @param nchk - Update the UDP checksum if NAT-T is enabled
    /// @param natsrc - Source port for NAT-T
    /// @param natdst - Destination port for NAT-T
    /// @param dsecn - Traffic class bits (DS and ECN)
    /// @param ttl - Time-To-Live (or HOP limit)
    /// @param flags - Flags for IPv4
    /// @param id - Identification field for IPv4
    /// @param label - Flow label for IPv6
    /// @param fragoff - Fragment offset for IPv4
    /// @param morefrag - More fragments flag in IPV6_FRAG extension header 1-more fragments after this one, 0-last fragment
    /// @param fragid - ID for the fragmentation segment
    /// @param mtu - Maximum Transmission Unit (MTU) for the path
    /// @param src - Source address
    /// @param dst - Destination address
    /// @param exthdr - Extension headers for IPv6
    /// @param audit - Enable auditing
    /// @param auditlog - path to the audit log
    ///
    /// Fields required for this implementation:
    ///
    /// @param nh     - Next Header (NH) value for the payload
    /// @param icvlen - Length of the ICV tag
    /// @param hdrlen - Length of the IP header
    /// @param tfclen - Length of the TFC padding, if any
    /// @param usext  - Use extended sequence number (default=TRUE)
    /// @param randiv - Use a random IV instead of the passed in one
    /// @param jumbogram - Nodal support for IPv6 JUMBOGRAMs
    //////////////////////////////////////////////////////////////////////
    jipsecsa(direction_t dir,
             iana_t ver, 
             ipmode_t mode,
             uint32_t spi,
             uint32_t seqnum,
             uint32_t extseqnum,
             unsigned int arlen,
             jarray<uint8_t> arwin,
             cipher_t cipher,
             unsigned int ckeylen,
             std::shared_ptr<jarray<uint8_t>> cipherkey,
             auth_t auth,
             unsigned int akeylen,
             std::shared_ptr<jarray<uint8_t>> authkey,
             unsigned int ivlen,
             std::shared_ptr<jarray<uint8_t>> iv,
             unsigned int saltlen,
             std::shared_ptr<jarray<uint8_t>> salt,
             uint64_t bytecnt,
             uint64_t lifetime,
             bool seqnumovrflw,
             bool statefulfrag,
             bool bypassdf,
             bool bypassdscp,
             bool nat,
             bool nchk,
             uint8_t dsecn,
             uint8_t ttl,
             uint8_t flags,
             uint16_t natsrc,
             uint16_t natdst,
             uint16_t id,
             uint32_t label,
             uint16_t fragoff,
             bool morefrag,
             uint32_t fragid,
             unsigned int mtu,
             jarray<uint8_t> src,
             jarray<uint8_t> dst,
             jarray<uint8_t> exthdr,
             iana_t nh,
             unsigned int icvlen,
             unsigned int hdrlen,
             unsigned int tfclen,
             bool usext,
             bool randiv,
             bool jumbogram,
             bool audit,
             std::string auditlog);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for IPsec
    /// @param rhs - Security association (SA) for this IPsec flow
    //////////////////////////////////////////////////////////////////////
    jipsecsa(jipsecsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for IPsec
    /// @param rhs - Security association (SA) for this IPsec flow
    //////////////////////////////////////////////////////////////////////
    explicit jipsecsa(std::shared_ptr<jipsecsa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    /// flush and close the auditlog if present
    //////////////////////////////////////////////////////////////////////
    virtual ~jipsecsa() {
        if (!m_cipherkey.empty()) {
            m_cipherkey.serase();
        }
        if (!m_authkey.empty()) {
            m_authkey.serase();
        }
        if (!m_iv.empty()) {
            m_iv.serase();
        }
        if (!m_salt.empty()) {
            m_salt.serase();
        }
    }

    //////////////////////////////////////////////////////////////////////
    /// Update IPSec field with the new value
    ///
    /// <table>
    /// <caption id="IPSec Set Fields">IPSec Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::DECAP)
    /// <tr><td>iana_t<td>VERSION<td>set_field<iana_t>(field_t::VERSION, iana_t::IPV4)
    /// <tr><td><td>NH<td>set_field<iana_t>(field_t::NH, iana_t::UDP)
    /// <tr><td>ipmode_t<td>MODE<td>set_field<ipmode_t>(field_t::MODE, ipmode_t::TUNNEL)
    /// <tr><td>cipher_t<td>CIPHER<td>set_field<cipher_t>(field_t::CIPHER, cipher_t::CAMELLIA_CBC)
    /// <tr><td>auth_t<td>AUTH<td>set_field<auth_t>(field_t::AUTH, auth_t::HMAC_SHA2_256)
    /// <tr><td>jarray<uint8_t><td>SOURCE<td>set_field<jarray<uint8_t>>(field_t::SOURCE, jarray<uint8_t>("CCEE1144"))
    /// <tr><td><td>DESTINATION<td>set_field<jarray<uint8_t>>(field_t::DESTINATION, jarray<uint8_t>("4433AABB"))
    /// <tr><td><td>EXTHDR<td>set_field<jarray<uint8_t>>(field_t::EXTHDR, jarray<uint8_t>("50000104"))
    /// <tr><td><td>ARWIN<td>set_field<jarray<uint8_t>>(field_t::ARWIN, jarray<uint8_t>("00000001"))
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, std::make_shared<jarray<uint8_t>>(16))
    /// <tr><td><td>AUTHKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY, std::make_shared<jarray<uint8_t>>(16))
    /// <tr><td><td>IV<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::IV, std::make_shared<jarray<uint8_t>>(16))
    /// <tr><td><td>SALT<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT, std::make_shared<jarray<uint8_t>>(4))
    /// <tr><td>uint8_t<td>DSECN<td>set_field<uint8_t>(field_t::DSECN, 0x11)
    /// <tr><td><td>TTLHOP<td>set_field<uint8_t>(field_t::TTLHOP, 0xFF)
    /// <tr><td><td>FLAGS<td>set_field<uint8_t>(field_t::FLAGS, 0x01)
    /// <tr><td>uint16_t<td>FRAGOFFSET<td>set_field<uint16_t>(field_t::FRAGOFFSET, 0x0010)
    /// <tr><td><td>ID<td>set_field<uint16_t>(field_t::ID, 0xFFEE)
    /// <tr><td><td>NATSRC<td>set_field<uint16_t>(field_t::NATSRC, 0x10BB)
    /// <tr><td><td>NATDST<td>set_field<uint16_t>(field_t::NATDST, 0xCCBB)
    /// <tr><td>uint32_t<td>LABEL<td>set_field<uint32_t>(field_t::LABEL, 0xAABB1155)
    /// <tr><td><td>SPI<td>set_field<uint32_t>(field_t::SPI, 0x00000040)
    /// <tr><td><td>SEQNUM<td>set_field<uint32_t>(field_t::SEQNUM, 0x00000040)
    /// <tr><td><td>EXTSEQNUM<td>set_field<uint32_t>(field_t::EXTSEQNUM, 0x00000040)
    /// <tr><td><td>ARLEN<td>set_field<uint32_t>(field_t::ARLEN, 2048)
    /// <tr><td><td>CKEYLEN<td>set_field<uint32_t>(field_t::CKEYLEN, 16)
    /// <tr><td><td>AKEYLEN<td>set_field<uint32_t>(field_t::AKEYLEN, 16)
    /// <tr><td><td>IVLEN<td>set_field<uint32_t>(field_t::IVLEN, 12)
    /// <tr><td><td>SALTLEN<td>set_field<uint32_t>(field_t::SALTLEN, 4)
    /// <tr><td><td>ICVLEN<td>set_field<uint32_t>(field_t::ICVLEN, 12)
    /// <tr><td><td>HDRLEN<td>set_field<uint32_t>(field_t::HDRLEN, 20)
    /// <tr><td><td>TFCLEN<td>set_field<uint32_t>(field_t::TFCLEN, 96)
    /// <tr><td><td>FRAGID<td>set_field<uint32_t>(field_t::FRAGID, 0x10000010)
    /// <tr><td><td>MTU<td>set_field<uint32_t>(field_t::MTU, 0x00000040)
    /// <tr><td>uint64_t<td>BYTECNT<td>set_field<uint64_t>(field_t::BYTECNT, 0xFFFFFFFFAAAAAAAA)
    /// <tr><td><td>LIFETIME<td>set_field<uint64_t>(field_t::LIFETIME, 0xFFFFFFFFAAAAAAAA)
    /// <tr><td>bool<td>MODEJUMBO<td>set_field<bool>(field_t::MODEJUMBO, true)
    /// <tr><td><td>SEQNUMOVRFLW<td>set_field<bool>(field_t::SEQNUMOVRFLW, false)
    /// <tr><td><td>STATEFULFRAG<td>set_field<bool>(field_t::STATEFULFRAG, false)
    /// <tr><td><td>BYPASSDF<td>set_field<bool>(field_t::BYPASSDF, true)
    /// <tr><td><td>BYPASSDSCP<td>set_field<bool>(field_t::BYPASSDSCP, true)
    /// <tr><td><td>NAT<td>set_field<bool>(field_t::NAT, true)
    /// <tr><td><td>NCHK<td>set_field<bool>(field_t::NCHK, true)
    /// <tr><td><td>MOREFRAG<td>set_field<bool>(field_t::MOREFRAG, false)
    /// <tr><td><td>USEXT<td>set_field<bool>(field_t::USEXT, true)
    /// <tr><td><td>RANDIV<td>set_field<bool>(field_t::RANDIV, true)
    /// <tr><td><td>AUDIT<td>set_field<bool>(field_t::AUDIT, false)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in jip
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    ///
    /// @param field - field to update
    /// @param fieldval - new value for the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the field from the IPSec security association
    ///
    /// <table>
    /// <caption id="IPSec Get Fields">IPSec Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>iana_t<td>VERSION<td>iana_t myver = get_field<iana_t>(field_t::VERSION)
    /// <tr><td><td>NH<td>iana_t mynh = get_field<iana_t>(field_t::NH)
    /// <tr><td>ipmode_t<td>MODE<td>ipmode_t mymode = get_field<ipmode_t>(field_t::MODE)
    /// <tr><td>cipher_t<td>CIPHER<td>cipher_t mycipher = get_field<cipher_t>(field_t::CIPHER)
    /// <tr><td>auth_t<td>AUTH<td>auth_t myauth = get_field<auth_t>(field_t::AUTH)
    /// <tr><td>jarray<uint8_t><td>SOURCE<td>jarray<uint8_t> mysrc = get_field<jarray<uint8_t>>(field_t::SOURCE)
    /// <tr><td><td>DESTINATION<td>jarray<uint8_t> mydst = get_field<jarray<uint8_t>>(field_t::DESTINATION)
    /// <tr><td><td>EXTHDR<td>jarray<uint8_t> myexthdr = get_field<jarray<uint8_t>>(field_t::EXTHDR)
    /// <tr><td><td>ARWIN<td>jarray<uint8_t> myarwin = get_field<jarray<uint8_t>>(field_t::ARWIN)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>std::shared_ptr<jarray<uint8_t>> mycipherkey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY)
    /// <tr><td><td>AUTHKEY<td>std::shared_ptr<jarray<uint8_t>> myauthkey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY)
    /// <tr><td><td>IV<td>std::shared_ptr<jarray<uint8_t>> myiv = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::IV)
    /// <tr><td><td>SALT<td>std::shared_ptr<jarray<uint8_t>> mysalt = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT)
    /// <tr><td>uint8_t<td>DSECN<td>uint8_t mydsecn = get_field<uint8_t>(field_t::DSECN)
    /// <tr><td><td>TTLHOP<td>uint8_t myttl = get_field<uint8_t>(field_t::TTLHOP)
    /// <tr><td><td>FLAGS<td>uint8_t myflags = get_field<uint8_t>(field_t::FLAGS)
    /// <tr><td>uint16_t<td>FRAGOFFSET<td>uint16_t myoffset = get_field<uint16_t>(field_t::FRAGOFFSET)
    /// <tr><td><td>ID<td>uint16_t myid = get_field<uint16_t>(field_t::ID)
    /// <tr><td><td>NATSRC<td>uint16_t mynatsrc = get_field<uint16_t>(field_t::NATSRC)
    /// <tr><td><td>NATDST<td>uint16_t mynatdst = get_field<uint16_t>(field_t::NATDST)
    /// <tr><td>uint32_t<td>LABEL<td>uint32_t mylabel = get_field<uint32_t>(field_t::LABEL)
    /// <tr><td><td>SPI<td>uint32_t myspi = get_field<uint32_t>(field_t::SPI)
    /// <tr><td><td>SEQNUM<td>uint32_t myseqnum = get_field<uint32_t>(field_t::SEQNUM)
    /// <tr><td><td>EXTSEQNUM<td>uint32_t myextnum = get_field<uint32_t>(field_t::EXTSEQNUM)
    /// <tr><td><td>ARLEN<td>uint32_t myarlen = get_field<uint32_t>(field_t::ARLEN)
    /// <tr><td><td>CKEYLEN<td>uint32_t myckeylen = get_field<uint32_t>(field_t::CKEYLEN)
    /// <tr><td><td>AKEYLEN<td>uint32_t myakeylen = get_field<uint32_t>(field_t::AKEYLEN)
    /// <tr><td><td>IVLEN<td>uint32_t myivlen = get_field<uint32_t>(field_t::IVLEN)
    /// <tr><td><td>SALTLEN<td>uint32_t mysaltlen = get_field<uint32_t>(field_t::SALTLEN)
    /// <tr><td><td>ICVLEN<td>uint32_t myicvlen = get_field<uint32_t>(field_t::ICVLEN)
    /// <tr><td><td>HDRLEN<td>uint32_t myhdrlen = get_field<uint32_t>(field_t::HDRLEN)
    /// <tr><td><td>TFCLEN<td>uint32_t mytfclen = get_field<uint32_t>(field_t::TFCLEN)
    /// <tr><td><td>FRAGID<td>uint32_t myfragid = get_field<uint32_t>(field_t::FRAGID)
    /// <tr><td><td>MTU<td>uint32_t mymtu = get_field<uint32_t>(field_t::MTU)
    /// <tr><td>uint64_t<td>BYTECNT<td>uint64_t mybytecnt = get_field<uint64_t>(field_t::BYTECNT)
    /// <tr><td><td>LIFETIME<td>uint64_t mylifetime = get_field<uint64_t>(field_t::LIFETIME)
    /// <tr><td>bool<td>MODEJUMBO<td>bool myjumbo = get_field<uint32_t>(field_t::MODEJUMBO)
    /// <tr><td><td>SEQNUMOVRFLW<td>bool myovflw = get_field<bool>(field_t::SEQNUMOVRFLW)
    /// <tr><td><td>STATEFULFRAG<td>bool mystateful = get_field<bool>(field_t::STATEFULFRAG)
    /// <tr><td><td>BYPASSDF<td>bool mybypassdf = get_field<bool>(field_t::BYPASSDF)
    /// <tr><td><td>BYPASSDSCP<td>bool mybypassdscp = get_field<bool>(field_t::BYPASSDSCP)
    /// <tr><td><td>NAT<td>bool mynat = get_field<bool>(field_t::NAT)
    /// <tr><td><td>NCHK<td>bool mynchk = get_field<bool>(field_t::NCHK)
    /// <tr><td><td>MOREFRAG<td>bool mymfrag = get_field<bool>(field_t::MOREFRAG)
    /// <tr><td><td>USEXT<td>bool myusext = get_field<bool>(field_t::USEXT)
    /// <tr><td><td>RANDIV<td>bool myrandiv = get_field<bool>(field_t::RANDIV)
    /// <tr><td><td>AUDIT<td>bool myaudit = get_field<bool>(field_t::AUDIT)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in jip
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    ///
    /// @param field - field to return from the secuirty association
    /// @return value of the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Return the protocol and security fields as XML
    /// @param myxml - XMLPrinter object
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jipsecsa(const jipsecsa& jipsec) = delete;

    // member variables
    direction_t m_dir;
    iana_t m_ver; 
    ipmode_t m_mode;
    uint32_t m_spi;
    uint32_t m_seqnum;
    uint32_t m_extseqnum;
    unsigned int m_arlen;
    jarray<uint8_t> m_arwin;
    cipher_t m_cipher;
    unsigned int m_ckeylen;
    jarray<uint8_t> m_cipherkey;
    auth_t m_auth;
    unsigned int m_akeylen;
    jarray<uint8_t> m_authkey;
    unsigned int m_ivlen;
    jarray<uint8_t> m_iv;
    unsigned int m_saltlen;
    jarray<uint8_t> m_salt;
    uint64_t m_bytecnt;
    uint64_t m_lifetime;
    bool m_seqnumovrflw;
    bool m_statefulfrag;
    bool m_bypassdf;
    bool m_bypassdscp;
    bool m_nat;
    bool m_nchk;
    uint8_t m_dsecn;
    uint8_t m_ttl;
    uint8_t m_flags;
    uint16_t m_natsrc;
    uint16_t m_natdst;
    uint16_t m_id;
    uint32_t m_label;
    uint16_t m_fragoff;
    bool m_morefrag;
    uint32_t m_fragid;
    unsigned int m_mtu;
    jarray<uint8_t> m_src;
    jarray<uint8_t> m_dst;
    jarray<uint8_t> m_exthdr;
    iana_t m_nh;
    unsigned int m_icvlen;
    unsigned int m_hdrlen;
    unsigned int m_tfclen;
    bool m_usext;
    bool m_randiv;
    bool m_jumbogram;
    bool m_audit;
    std::string m_auditlog;
};

}

#endif /* JIPSECSA_H_ */
