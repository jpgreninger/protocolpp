#ifndef SFMTST_H
#define SFMTST_H

///
///\class SFMT SFMT.h "include/SFMT.h"
///
/// @brief SIMD oriented Fast Mersenne Twister(SFMT) pseudorandom
/// number generator using C structure.
///
/// @author Mutsuo Saito (Hiroshima University)
/// @author Makoto Matsumoto (The University of Tokyo)
///
/// Copyright (C) 2006, 2007 Mutsuo Saito, Makoto Matsumoto and Hiroshima
/// University.
/// Copyright (C) 2012 Mutsuo Saito, Makoto Matsumoto, Hiroshima
/// University and The University of Tokyo.
/// All rights reserved.
///
/// The 3-clause BSD License is applied to this software, see
/// LICENSE.txt
///
/// @note We assume that your system has inttypes.h.  If your system
/// doesn't have inttypes.h, you have to typedef uint32_t and uint64_t,
/// and you have to define PRIu64 and PRIx64 in this file as follows:
///
/// @verbatim
/// typedef unsigned int uint32_t
/// typedef unsigned long long uint64_t
/// #define PRIu64 "llu"
/// #define PRIx64 "llx"
/// @endverbatim
///
/// uint32_t must be exactly 32-bit unsigned integer type (no more, no
/// less), and uint64_t must be exactly 64-bit unsigned integer type.
/// PRIu64 and PRIx64 are used for printf function to print 64-bit
/// unsigned int and 64-bit unsigned int in hexadecimal format.
///
/// <center>ported to C++ by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <stdio.h>
#include <string.h>
#include <assert.h>

namespace ProtocolPP {

#define SFMT_MEXP 19937

#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 199901L)
  #include <inttypes.h>
#elif defined(_MSC_VER) || defined(__BORLANDC__)
  typedef unsigned char uint8_t;
  typedef unsigned short uint16_t;
  typedef unsigned int uint32_t;
  typedef unsigned __int64 uint64_t;
  #define inline __inline
#else
  #include <inttypes.h>
  #if defined(__GNUC__)
    #define inline __inline__
  #endif
#endif

#ifndef PRIu64
  #if defined(_MSC_VER) || defined(__BORLANDC__)
    #define PRIu64 "I64u"
    #define PRIx64 "I64x"
  #else
    #define PRIu64 "llu"
    #define PRIx64 "llx"
  #endif
#endif

#include "SFMT-params.h"

/*------------------------------------------
  128-bit SIMD like data type for standard C
  ------------------------------------------*/
#if defined(HAVE_ALTIVEC)
  #if !defined(__APPLE__)
    #include <altivec.h>
  #endif
/** 128-bit data structure */
union W128_T {
    vector unsigned int s;
    uint32_t u[4];
    uint64_t u64[2];
};
#elif defined(HAVE_NEON)
  #include <arm_neon.h>

/** 128-bit data structure */
union W128_T {
    uint32_t u[4];
    uint64_t u64[2];
    uint32x4_t si;
};
#elif defined(HAVE_SSE2)
  #include <emmintrin.h>

/** 128-bit data structure */
union W128_T {
    uint32_t u[4];
    uint64_t u64[2];
    __m128i si;
};
#else
/** 128-bit data structure */
union W128_T {
    uint32_t u[4];
    uint64_t u64[2];
};
#endif

/** 128-bit data type */
typedef union W128_T w128_t;

class sfmt {

public:

    /////////////////////////////////////////////////////////
    /// Standard constructor for SFMT that initializes with 
    /// a value of 0x01234567
    /////////////////////////////////////////////////////////
    sfmt();

    /////////////////////////////////////////////////////////
    /// Standard constructor for SFMT that initializes with 
    /// a value of seed
    /// @param seed - seed to initialize SFMT with
    /////////////////////////////////////////////////////////
    explicit sfmt(uint32_t seed);

    /////////////////////////////////////////////////////////
    /// Standard constructor for SFMT that initializes with 
    /// a value of init_key
    /// @param init_key - array of uint32_t to initialize SFMT with
    /// @param key_length - size of the seed array
    /////////////////////////////////////////////////////////
    sfmt(uint32_t* init_key, int key_length);

    /////////////////////////////////////////////////////////
    /// Standard deconstructor 
    /////////////////////////////////////////////////////////
    virtual ~sfmt() {};

    /////////////////////////////////////////////////////////
    /// @fn sfmt_fill_array8
    /// Fills the user specified array with uint8_t values
    /// from the underlying w128_t array
    /// @param array - array to fill with uint8_t
    /// @param size - number of uint8_t values requested
    /////////////////////////////////////////////////////////
    void sfmt_fill_array8(uint8_t * array, int size);

    /////////////////////////////////////////////////////////
    /// @fn sfmt_fill_array16
    /// Fills the user specified array with uint16_t values
    /// from the underlying w128_t array
    /// @param array - array to fill with uint16_t
    /// @param size - number of uint16_t values requested
    /////////////////////////////////////////////////////////
    void sfmt_fill_array16(uint16_t * array, int size);

    /////////////////////////////////////////////////////////
    /// @fn sfmt_fill_array32
    /// Fills the user specified array with uint32_t values
    /// from the underlying w128_t array
    /// @param array - array to fill with uint32_t
    /// @param size - number of uint32_t values requested
    /////////////////////////////////////////////////////////
    void sfmt_fill_array32(uint32_t * array, int size);

    /////////////////////////////////////////////////////////
    /// @fn sfmt_fill_array64
    /// Fills the user specified array with uint64_t values
    /// from the underlying w128_t array
    /// @param array - array to fill with uint64_t
    /// @param size - number of uint64_t values requested
    /////////////////////////////////////////////////////////
    void sfmt_fill_array64(uint64_t * array, int size);

    /////////////////////////////////////////////////////////
    /// @fn sfmt_init_gen_rand
    /// Reseeds the random number generator with the uint32_t
    /// @param seed - new seed
    /////////////////////////////////////////////////////////
    void sfmt_init_gen_rand(uint32_t seed);

    /////////////////////////////////////////////////////////
    /// @fn sfmt_init_by_array
    /// Reseeds the random number generator with the uint32_t
    /// array
    /// @param init_key - array to initilize with
    /// @param key_length - length of the init array
    /////////////////////////////////////////////////////////
    void sfmt_init_by_array(uint32_t * init_key, int key_length);

    /////////////////////////////////////////////////////////
    /// @fn sfmt_get_idstring
    /// Returns unique identifier for this SFMT including
    /// internal state values
    /// @return string representation of this SFMT
    /////////////////////////////////////////////////////////
    const char * sfmt_get_idstring();

    /////////////////////////////////////////////////////////
    /// @fn sfmt_get_min_array_size8
    /// This function returns the minimum size of array used
    /// for fill_array8() function
    /// @return minimum size of array used for fill_array8() function.
    /////////////////////////////////////////////////////////
    int sfmt_get_min_array_size8();

    /////////////////////////////////////////////////////////
    /// @fn sfmt_get_min_array_size16
    /// This function returns the minimum size of array used
    /// for fill_array16() function
    /// @return minimum size of array used for fill_array16() function.
    /////////////////////////////////////////////////////////
    int sfmt_get_min_array_size16();

    /////////////////////////////////////////////////////////
    /// @fn sfmt_get_min_array_size32
    /// This function returns the minimum size of array used
    /// for fill_array32() function
    /// @return minimum size of array used for fill_array32() function.
    /////////////////////////////////////////////////////////
    int sfmt_get_min_array_size32();

    /////////////////////////////////////////////////////////
    /// @fn sfmt_get_min_array_size64
    /// This function returns the minimum size of array used
    /// for fill_array64() function
    /// @return minimum size of array used for fill_array64() function.
    /////////////////////////////////////////////////////////
    int sfmt_get_min_array_size64();

    /////////////////////////////////////////////////////////
    /// This function fills the internal state array with
    /// pseudorandom integers
    /////////////////////////////////////////////////////////
    void sfmt_gen_rand_all();

    #ifndef ONLY64
    /////////////////////////////////////////////////////////
    /// This function generates and returns 32-bit pseudorandom number.
    /// init_gen_rand or init_by_array must be called before this function.
    /// @return 32-bit pseudorandom number
    /////////////////////////////////////////////////////////
    inline uint32_t sfmt_genrand_uint32() {
        uint32_t r;
        uint32_t * psfmt32 = &m_state[0].u[0];
    
        if (m_idx >= SFMT_N32) {
            sfmt_gen_rand_all();
            m_idx = 0;
        }
        r = psfmt32[m_idx++];
        return r;
    }
    #endif

    /////////////////////////////////////////////////////////
    /// This function generates and returns 64-bit pseudorandom number.
    /// init_gen_rand or init_by_array must be called before this function.
    /// The function gen_rand64 should not be called after gen_rand32,
    /// unless an initialization is again executed.
    /// @return 64-bit pseudorandom number
    /////////////////////////////////////////////////////////
    inline uint64_t sfmt_genrand_uint64() {
    #if defined(BIG_ENDIAN64) && !defined(ONLY64)
        uint32_t * psfmt32 = &m_state[0].u[0];
        uint32_t r1, r2;
    #else
        uint64_t r;
    #endif
        uint64_t * psfmt64 = &m_state[0].u64[0];
        assert(m_idx % 2 == 0);
    
        if (m_idx >= SFMT_N32) {
            sfmt_gen_rand_all();
            m_idx = 0;
        }
    #if defined(BIG_ENDIAN64) && !defined(ONLY64)
        r1 = psfmt32[m_idx];
        r2 = psfmt32[m_idx + 1];
        m_idx += 2;
        return ((uint64_t)r2 << 32) | r1;
    #else
        r = psfmt64[m_idx / 2];
        m_idx += 2;
        return r;
    #endif
    }

    //=================================================
    //   The following real versions are due to Isaku Wada
    //=================================================
    /////////////////////////////////////////////////////////
    /// converts an unsigned 32-bit number to a double on [0,1]-real-interval.
    /// @param v 32-bit unsigned integer
    /// @return double on [0,1]-real-interval
    /////////////////////////////////////////////////////////
    inline double sfmt_to_real1(uint32_t v)
    {
        return v * (1.0/4294967295.0);
        /* divided by 2^32-1 */
    }
    
    /////////////////////////////////////////////////////////
    /// generates a random number on [0,1]-real-interval
    /// @return double on [0,1]-real-interval
    /////////////////////////////////////////////////////////
    inline double sfmt_genrand_real1()
    {
        return sfmt_to_real1(sfmt_genrand_uint32());
    }
    
    /////////////////////////////////////////////////////////
    /// converts an unsigned 32-bit integer to a double on [0,1)-real-interval.
    /// @param v 32-bit unsigned integer
    /// @return double on [0,1)-real-interval
    /////////////////////////////////////////////////////////
    inline double sfmt_to_real2(uint32_t v)
    {
        return v * (1.0/4294967296.0);
        /* divided by 2^32 */
    }
    
    /////////////////////////////////////////////////////////
    /// generates a random number on [0,1)-real-interval
    /// @return double on [0,1)-real-interval
    /////////////////////////////////////////////////////////
    inline double sfmt_genrand_real2()
    {
        return sfmt_to_real2(sfmt_genrand_uint32());
    }
    
    /////////////////////////////////////////////////////////
    /// converts an unsigned 32-bit integer to a double on (0,1)-real-interval.
    /// @param v 32-bit unsigned integer
    /// @return double on (0,1)-real-interval
    /////////////////////////////////////////////////////////
    inline double sfmt_to_real3(uint32_t v)
    {
        return (((double)v) + 0.5)*(1.0/4294967296.0);
        /* divided by 2^32 */
    }
    
    /////////////////////////////////////////////////////////
    /// generates a random number on (0,1)-real-interval
    /// @return double on (0,1)-real-interval
    /////////////////////////////////////////////////////////
    inline double sfmt_genrand_real3()
    {
        return sfmt_to_real3(sfmt_genrand_uint32());
    }
    
    /////////////////////////////////////////////////////////
    /// converts an unsigned 32-bit integer to double on [0,1)
    /// with 53-bit resolution.
    /// @param v 32-bit unsigned integer
    /// @return double on [0,1)-real-interval with 53-bit resolution.
    /////////////////////////////////////////////////////////
    inline double sfmt_to_res53(uint64_t v)
    {
        return (v >> 11) * (1.0/9007199254740992.0);
    }
    
    /////////////////////////////////////////////////////////
    /// generates a random number on [0,1) with 53-bit resolution
    /// @return double on [0,1) with 53-bit resolution
    /////////////////////////////////////////////////////////
    inline double sfmt_genrand_res53()
    {
        return sfmt_to_res53(sfmt_genrand_uint64());
    }
    
    //=================================================
    // The following functions are added by Saito.
    //=================================================
    /////////////////////////////////////////////////////////
    /// generates a random number on [0,1) with 53-bit resolution from two
    /// 32 bit integers
    /// @param x - first uint32_t
    /// @param y - second uint32_t
    /// @return random number on [0,1] with 53-bit resolution
    /////////////////////////////////////////////////////////
    inline double sfmt_to_res53_mix(uint32_t x, uint32_t y)
    {
        return sfmt_to_res53(x | ((uint64_t)y << 32));
    }
    
    /////////////////////////////////////////////////////////
    /// generates a random number on [0,1) with 53-bit resolution
    /// using two 32bit integers.
    /// @return double on [0,1) with 53-bit resolution
    /////////////////////////////////////////////////////////
    inline double sfmt_genrand_res53_mix()
    {
        uint32_t x, y;
    
        x = sfmt_genrand_uint32();
        y = sfmt_genrand_uint32();
        return sfmt_to_res53_mix(x, y);
    }

    /////////////////////////////////////////////////////////
    /// This function simulate a 64-bit index of LITTLE ENDIAN
    /// in BIG ENDIAN machine.
    /// @param i - index to value
    /////////////////////////////////////////////////////////
    inline int idxof(int i);

    /////////////////////////////////////////////////////////
    /// This function fills the user-specified array with pseudorandom
    /// integers
    /// @param array an 128-bit array to be filled by pseudorandom numbers
    /// @param size number of 128-bit pseudorandom numbers to be generated
    /////////////////////////////////////////////////////////
    inline void gen_rand_array(w128_t *array, int size);

    /////////////////////////////////////////////////////////
    /// This function represents a function used in the initialization
    /// by init_by_array
    /// @param x 32-bit integer
    /// @return 32-bit integer
    /////////////////////////////////////////////////////////
    inline uint32_t func1(uint32_t x);

    /////////////////////////////////////////////////////////
    /// This function represents a function used in the initialization
    /// by init_by_array
    /// @param x 32-bit integer
    /// @return 32-bit integer
    /////////////////////////////////////////////////////////
    inline uint32_t func2(uint32_t x);

    /////////////////////////////////////////////////////////
    /// This function represents a function used in the initialization
    /// by init_by_array
    /// @return 32-bit integer
    /////////////////////////////////////////////////////////
    void period_certification();

    /////////////////////////////////////////////////////////
    /// This function swaps the array
    /// @param array - pointer to array to swap
    /// @param size - size of array to swap
    /////////////////////////////////////////////////////////
    #if defined(BIG_ENDIAN64) && !defined(ONLY64)
    inline void swap(w128_t *array, int size);
    #endif

private:

    // dont use these
    sfmt(sfmt& rhs) = delete;
    sfmt(const sfmt& rhs) = delete;

    static const w128_t sse2_param_mask;

    /** the 128-bit internal state array */
    w128_t m_state[SFMT_N];

    /** index counter to the 32-bit internal state array */
    int m_idx;
};

}

#endif
