#ifndef JTCPSA_H_
#define JTCPSA_H_

///
///\class jtcpsa jtcpsa.h "include/jtcpsa.h"
///
///\section TCPSASA Transport Control Protocol Security Association (TCP)
///
/// See https://en.wikipedia.org/wiki/Transmission_Control_Protocol
///
/// The Transmission Control Protocol (TCP) is a core protocol of the Internet
/// protocol suite. It originated in the initial network implementation in which
/// it complemented the Internet Protocol (IP). Therefore, the entire suite is
/// commonly referred to as TCP/IP. TCP provides reliable, ordered, and
/// error-checked delivery of a stream of octets between applications running
/// on hosts communicating over an IP network. Major Internet applications such
/// as the World Wide Web, email, remote administration and file transfer rely
/// on TCP. Applications that do not require reliable data stream service may
/// use the User Datagram Protocol (UDP), which provides a connectionless
/// datagram service that emphasizes reduced latency over reliability
///
/// TCP segments are sent as internet datagrams.  The Internet Protocol
/// header carries several information fields, including the source and
/// destination host addresses [2].  A TCP header follows the internet
/// header, supplying information specific to the TCP protocol.  This
/// division allows for the existence of host level protocols other than
/// TCP (See RFC 793)
///
/// <B>TCP Header Format [1]</B>
///
///\image html TCP_headers.png "Transmission Control Protocol (TCP) Header Format"
///\image latex TCP_headers.eps "Transmission Control Protocol (TCP) Header Format" width=15cm
///
/// * Source Port:  16 bits
/// 
///   The source port number
///
/// * Destination Port:  16 bits
///
///   The destination port number
///
/// * Sequence Number:  32 bits
///
///   The sequence number of the first data octet in this segment (except
///   when SYN is present). If SYN is present the sequence number is the
///   initial sequence number (ISN) and the first data octet is ISN+1
///
/// * Acknowledgment Number:  32 bits
///
///   If the ACK control bit is set this field contains the value of the
///   next sequence number the sender of the segment is expecting to
///   receive.  Once a connection is established this is always sent
///
/// * Data Offset:  4 bits
///
///   The number of 32 bit words in the TCP Header.  This indicates where
///   the data begins.  The TCP header (even one including options) is an
///   integral number of 32 bits long.
///
/// * Reserved:  6 bits
///
///   Reserved for future use.  Must be zero
///
/// * Flags:  6 bits (from left to right):
///
///   * URG:  Urgent Pointer field significant
///   * ACK:  Acknowledgment field significant
///   * PSH:  Push Function
///   * RST:  Reset the connection
///   * SYN:  Synchronize sequence numbers
///   * FIN:  No more data from sender
///
/// * Window:  16 bits
///
///   The number of data octets beginning with the one indicated in the
///   acknowledgment field which the sender of this segment is willing to
///   accept
/// 
/// * Checksum:  16 bits
///
///   The checksum field is the 16 bit one’s complement of the one’s
///   complement sum of all 16 bit words in the header and text.  If a
///   segment contains an odd number of header and text octets to be
///   checksummed, the last octet is padded on the right with zeros to
///   form a 16 bit word for checksum purposes.  The pad is not
///   transmitted as part of the segment.  While computing the checksum,
///   the checksum field itself is replaced with zeros
///
///   The checksum also covers a 96 bit pseudo header conceptually
///   prefixed to the TCP header.  This pseudo header contains the Source
///   Address, the Destination Address, the Protocol, and TCP length.
///   This gives the TCP protection against misrouted segments.  This
///   information is carried in the Internet Protocol and is transferred
///   across the TCP/Network interface in the arguments or results of
///   calls by the TCP on the IP
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jtcpsa
/// @see ProtocolPP::jtcp
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jarray
/// @see jrand
/// @see jtcpsa
/// @see jtcp
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class jtcpsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor using default values
    ///
    /// <table>
    /// <caption id="TCP Defaults">TCP Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::ENCAP
    /// <tr><td>mtu<td>1500
    /// <tr><td>src<td>0xDEAD
    /// <tr><td>dst<td>0xBEEF
    /// <tr><td>seqnum<td>0x00000001
    /// <tr><td>acknum<td>0x00000001
    /// <tr><td>doffset<td>0
    /// <tr><td>flags<td>0
    /// <tr><td>window<td>1500
    /// <tr><td>urgpointer<td>0
    /// <tr><td>timeout<td>0
    /// </table>
    //////////////////////////////////////////////////////////////////////
    jtcpsa();

    //////////////////////////////////////////////////////////////////////
    /// TCP security association needed to setup a flow
    ///
    /// @param dir - direction. Because TCP is bi-directional in all cases,
    ///              this parameter is mainly used to decide if a file
    ///              is being read from or written to (ENCAP or DECAP) and
    ///              it keeps the interface consistent with other protocols
    /// @param mtu - Maximum Transmission Unit
    /// @param src - Source Port
    /// @param dst - Destination Port
    /// @param seqnum - Sequence Number
    /// @param acknum - Acknowledgement Number
    /// @param doffset - offset to where data begins
    /// @param flags - header flags in following order (RSVD, RSVD, URG, ACK, PSH, RST, SYN, FIN)
    /// @param window - size of the receive window
    /// @param urgpointer - points to the octet following urgent data
    /// @param timeout - Time to wait before closing idle socket
    //////////////////////////////////////////////////////////////////////
    jtcpsa(direction_t dir,
           unsigned int mtu,
           uint16_t src,
           uint16_t dst,
           uint32_t seqnum,
           uint32_t acknum,
           uint8_t doffset,
           uint8_t flags,
           uint16_t window,
           uint16_t urgpointer,
           unsigned int timeout);

    //////////////////////////////////////////////////////////////////////
    /// Standard copy constructor
    //////////////////////////////////////////////////////////////////////
    jtcpsa(jtcpsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard copy constructor from shared pointer
    //////////////////////////////////////////////////////////////////////
    explicit jtcpsa(std::shared_ptr<jtcpsa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Sets a boolean field in the security association. If the function
    /// is called with a field that is not boolean, this function prints
    /// an error to the screen
    ///
    /// <table>
    /// <caption id="TCP Set Fields">TCP Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP)
    /// <tr><td>uint32_t<td>MTU<td>set_field<uint32_t>(field_t::MTU, 1500)
    /// <tr><td><td>SEQNUM<td>set_field<uint32_t>(field_t::SEQNUM, 0x00000001)
    /// <tr><td><td>ACKNUM<td>set_field<uint32_t>(field_t::ACKNUM, 0x00000001)
    /// <tr><td><td>TIMEOUT<td>set_field<uint32_t>(field_t::TIMEOUT, 0x00000001)
    /// <tr><td>uint16_t<td>SOURCE<td>set_field<uint16_t>(field_t::SOURCE, 0xDEAD)
    /// <tr><td><td>DESTINATION<td>set_field<uint16_t>(field_t::DESTINATION, 0xBEEF)
    /// <tr><td><td>WINDOW<td>set_field<uint16_t>(field_t::WINDOW, 0x1000)
    /// <tr><td><td>URGPOINTER<td>set_field<uint16_t>(field_t::URGPOINTER, 0x1000)
    /// <tr><td>uint8_t<td>DOFFSET<td>set_field<uint8_t>(field_t::DOFFSET, 0x10)
    /// <tr><td><td>FLAGS<td>set_field<uint8_t>(field_t::FLAGS, 0x10)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in jtcp
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    /// * STATE
    ///   * LISTEN
    ///   * SYN_SENT
    ///   * SYN_RCVD
    ///   * FIN_WAIT_1
    ///   * FIN_WAIT_2
    ///   * CLOSE_WAIT
    ///   * LAST_ACK
    ///   * TIME_WAIT
    ///   * CLOSED
    /// * SNDUNA
    /// * SNDNXT
    /// * SNDWND
    /// * SNDUP
    /// * SNDW1
    /// * SNDW2
    /// * ISS
    /// * RCVNXT
    /// * RCVWND
    /// * RCVUP
    /// * IRS
    ///
    /// @param field - field to set
    /// @param fieldval - boolean value for the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves a boolean value from the field requested. If the
    /// function is called with a field that is not a boolean, this
    /// function prints an error to the screen
    ///
    /// <table>
    /// <caption id="TCP Get Fields">TCP Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>uint32_t<td>MTU<td>uint32_t mymtu = get_field<uint32_t>(field_t::MTU)
    /// <tr><td><td>SEQNUM<td>uint32_t myseqnum = get_field<uint32_t>(field_t::SEQNUM)
    /// <tr><td><td>ACKNUM<td>uint32_t myacknum = get_field<uint32_t>(field_t::ACKNUM)
    /// <tr><td><td>TIMEOUT<td>uint32_t mytimeout = get_field<uint32_t>(field_t::TIMEOUT)
    /// <tr><td>uint16_t<td>SOURCE<td>uint16_t mysrc = get_field<uint16_t>(field_t::SOURCE)
    /// <tr><td><td>DESTINATION<td>uint16_t mydst = get_field<uint16_t>(field_t::DESTINATION)
    /// <tr><td><td>WINDOW<td>uint16_t mywin = get_field<uint16_t>(field_t::WINDOW)
    /// <tr><td><td>URGPOINTER<td>uint16_t myptr = get_field<uint16_t>(field_t::URGPOINTER)
    /// <tr><td>uint8_t<td>DOFFSET<td>uint8_t myoff = get_field<uint8_t>(field_t::DOFFSET)
    /// <tr><td><td>FLAGS<td>uint8_t myflags = get_field<uint8_t>(field_t::FLAGS)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in jtcp
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    /// * STATE
    ///   * LISTEN
    ///   * SYN_SENT
    ///   * SYN_RCVD
    ///   * FIN_WAIT_1
    ///   * FIN_WAIT_2
    ///   * CLOSE_WAIT
    ///   * LAST_ACK
    ///   * TIME_WAIT
    ///   * CLOSED
    /// * SNDUNA
    /// * SNDNXT
    /// * SNDWND
    /// * SNDUP
    /// * SNDW1
    /// * SNDW2
    /// * ISS
    /// * RCVNXT
    /// * RCVWND
    /// * RCVUP
    /// * IRS
    ///
    /// @param field - field to set
    /// @return - boolean value from the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// print the protocol and security objects as XML
    /// @param myxml - object to print to
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jtcpsa(const jtcpsa& jtcpsa) = delete;

    // member variables
    direction_t m_dir;
    unsigned int m_mtu;
    uint16_t m_src;
    uint16_t m_dst;
    uint32_t m_seqnum;
    uint32_t m_acknum;
    uint8_t m_doffset;
    uint8_t m_flags;
    uint16_t m_window;
    uint16_t m_urgpointer;
    unsigned int m_timeout;

    // current variables
    uint32_t m_seglen;
    uint16_t m_precedence;

    // send variables
    uint32_t m_snduna;
    uint32_t m_sndnxt;
    uint16_t m_sndwnd;
    uint16_t m_sndup;
    uint32_t m_sndw1;
    uint32_t m_sndw2;
    uint32_t m_iss;

    // receive variables
    uint32_t m_rcvnxt;
    uint16_t m_rcvwnd;
    uint16_t m_rcvup;
    uint32_t m_irs;
};

}

#endif

