#ifndef JPROTOCOL_JIP_H_
#define JPROTOCOL_JIP_H_

///
///\class jip jip.h "include/jip.h"
///
///\section IP_Class Internet Protocol (IP)
///
/// See https://en.wikipedia.org/wiki/Internet_Protocol
///
/// The Internet Protocol (IP) is the principal communications protocol
/// in the Internet protocol suite for relaying datagrams across network
/// boundaries. Its routing function enables internetworking, and
/// essentially establishes the Internet.
///
/// IP has the task of delivering packets from the source host to the
/// destination host solely based on the IP addresses in the packet headers.
/// For this purpose, IP defines packet structures that encapsulate the data
/// to be delivered. It also defines addressing methods that are used to label
/// the datagram with source and destination information.
///
/// Historically, IP was the connectionless datagram service in the original
/// Transmission Control Program introduced by Vint Cerf and Bob Kahn in 1974;
/// the other being the connection-oriented Transmission Control Protocol (TCP).
/// The Internet protocol suite is therefore often referred to as TCP/IP.
///
/// The first major version of IP, Internet Protocol Version 4 (IPv4), is the
/// dominant protocol of the Internet. Its successor is Internet Protocol V6
///
/// The header for IPv4 is configured as follows (See RFC 791) [1]
///
///\image html IP_version4_hdr2.png "IP Version 4 Header"
///\image latex IP_version4_hdr2.eps "IP Version 4 Header" width=15cm
///
///
/// * Version:  4 bits
///
///    The Version field indicates the format of the internet header
///
/// * IHL:  4 bits
///
///    Internet Header Length is the length of the internet header in 32
///    bit words, and thus points to the beginning of the data.  Note that
///    the minimum value for a correct header is 5.
///
/// * Type of Service:  8 bits
///    
///    The Type of Service provides an indication of the abstract
///    parameters of the quality of service desired. These parameters are
///    to be used to guide the selection of the actual service parameters
///    when transmitting a datagram through a particular network.  Several
///    networks offer service precedence, which somehow treats high
///    precedence traffic as more important than other traffic (generally
///    by accepting only traffic above a certain precedence at time of high
///    load).  The major choice is a three way tradeoff between low-delay,
///    high-reliability, and high-throughput.
///
///\image html IPsecPrecedence50.png "IP Version 4 ToS"
///\image latex IPsecPrecedence50.eps "IP Version 4 ToS" width=15cm
///
///   The use of the Delay, Throughput, and Reliability indications may
///   increase the cost (in some sense) of the service.  In many networks
///   better performance for one of these parameters is coupled with worse
///   performance on another.  Except for very unusual cases at most two
///   of these three indications should be set.
///
///   The type of service is used to specify the treatment of the datagram
///   during its transmission through the internet system.  Example mappings
///   of the internet type of service to the actual service provided on
///   networks such as AUTODIN II, ARPANET, SATNET, and PRNET is given in
///   "Service Mappings"
///
///   The Network Control precedence designation is intended to be used
///   within a network only.  The actual use and control of that
///   designation is up to each network. The Internetwork Control
///   designation is intended for use by gateway control originators only.
///   If the actual use of these precedence designations is of concern to
///   a particular network, it is the responsibility of that network to
///   control the access to, and use of, those precedence designations.
///
/// * Total Length:  16 bits
///
///   Total Length is the length of the datagram, measured in octets,
///   including internet header and data.  This field allows the length of
///   a datagram to be up to 65,535 octets.  Such long datagrams are
///   impractical for most hosts and networks.  All hosts must be prepared
///   to accept datagrams of up to 576 octets (whether they arrive whole
///   or in fragments).  It is recommended that hosts only send datagrams
///   larger than 576 octets if they have assurance that the destination
///   is prepared to accept the larger datagrams.
///
///   The number 576 is selected to allow a reasonable sized data block to
///   be transmitted in addition to the required header information.  For
///   example, this size allows a data block of 512 octets plus 64 header
///   octets to fit in a datagram.  The maximal internet header is 60
///   octets, and a typical internet header is 20 octets, allowing a
///   margin for headers of higher level protocols.
///
/// * Identification:  16 bits
///
///   An identifying value assigned by the sender to aid in assembling the
///   fragments of a datagram.
///
/// * Flags:  3 bits
///
///\image html DFBit75.png "IP Version 4 Control Flags"
///\image latex DFBit75.eps "IP Version 4 Control Flags" width=15cm
///
/// * Fragment Offset:  13 bits
///
///   This field indicates where in the datagram this fragment belongs
///   The fragment offset is measured in units of 8 octets (64 bits).  The
///   first fragment has offset zero.
///
/// * Time to Live:  8 bits
///
///   This field indicates the maximum time the datagram is allowed to
///   remain in the internet system.  If this field contains the value
///   zero, then the datagram must be destroyed.  This field is modified
///   in internet header processing.  The time is measured in units of
///   seconds, but since every module that processes a datagram must
///   decrease the TTL by at least one even if it process the datagram in
///   less than a second, the TTL must be thought of only as an upper
///   bound on the time a datagram may exist.  The intention is to cause
///   undeliverable datagrams to be discarded, and to bound the maximum
///   datagram lifetime.
///
/// * Protocol:  8 bits
///
///   This field indicates the next level protocol used in the data
///   portion of the internet datagram.  The values for various protocols
///   are specified in "Assigned Numbers"
///
/// * Header Checksum:  16 bits
///
///   A checksum on the header only.  Since some header fields change
///   (e.g., time to live), this is recomputed and verified at each point
///   that the internet header is processed.  The checksum algorithm is:
///
///   The checksum field is the 16 bit one’s complement of the one’s
///   complement sum of all 16 bit words in the header.  For purposes of
///   computing the checksum, the value of the checksum field is zero.
///
///   This is a simple to compute checksum and experimental evidence
///   indicates it is adequate, but it is provisional and may be replaced
///   by a CRC procedure, depending on further experience.
///
/// * Source Address:  32 bits
///
///   The source address.  See section 3.2.
///      
/// * Destination Address:  32 bits
///
///   The destination address.  See section 3.2.
///
/// The header for IPv6 is configured as follows (see RFC 2460) [2]
///
///\image html IPv6Header50.png "IP Version 6 Header"
///\image latex IPv6Header50.eps "IP Version 6 Header" width=15cm
///
/// * Version:              
///
///    4-bit Internet Protocol version number = 6.
///
/// * Traffic Class:
///
///    8-bit traffic class field.  See section 7.
///
/// * Flow Label:
///
///    20-bit flow label.  See section 6.
///
/// * Payload Length:
///    
///   16-bit unsigned integer.  Length of the IPv6
///   payload, i.e., the rest of the packet following
///   this IPv6 header, in octets.  (Note that any
///   extension headers present are considered part
///   of the payload, i.e., included in the length count.)
///
/// * Next Header:
///
///   8-bit selector.  Identifies the type of header
///   immediately following the IPv6 header.  Uses the
///   same values as the IPv4 Protocol field [RFC-1700 et seq.]
///
/// * Hop Limit:
///
///   8-bit unsigned integer.  Decremented by 1 by each node
///   that forwards the packet. The packet is discarded if
///   Hop Limit is decremented to zero.
///
/// * Source Address:
///
///   128-bit address of the originator of the packet
///
/// * Destination Address:
///
///   128-bit address of the intended recipient of the packet
///   (possibly not the ultimate recipient, if a Routing header is present)
///
///
/// <B>IPv4 vs IPv6 Header Comparison [3]</B>
///
///\image html IP_hdr_comp.png "Comparison of IPv4 and IPv6 Header Fields"
///\image latex IP_hdr_comp.eps "Comparison of IPv4 and IPv6 Header Fields" width=15cm
///
///
/// <B>IPv6 Extension Headers</B>
///
///   In IPv6, optional internet-layer information is encoded in separate
///   headers that may be placed between the IPv6 header and the upper
///   layer header in a packet.  There are a small number of such extension
///   headers, each identified by a distinct Next Header value.  As
///   illustrated in these examples, an IPv6 packet may carry zero, one, or
///   more extension headers, each identified by the Next Header field of
///   the preceding header:
///
///\image html IPv6Headers1.png "IPv6 Extension Headers"
///\image latex IPv6Headers1.eps "IPv6 Extension Headers" width=15cm
///
///   With one exception, extension headers are not examined or processed
///   by any node along a packet’s delivery path, until the packet reaches
///   the node (or each of the set of nodes, in the case of multicast)
///   identified in the Destination Address field of the IPv6 header.
///   There, normal demultiplexing on the Next Header field of the IPv6
///   header invokes the module to process the first extension header, or
///   the upper-layer header if no extension header is present.  The
///   contents and semantics of each extension header determine whether or
///   not to proceed to the next header.  Therefore, extension headers must
///   be processed strictly in the order they appear in the packet; a
///   receiver must not, for example, scan through a packet looking for a
///   particular kind of extension header and process that header prior to
///   processing all preceding ones.
///
///   The exception referred to in the preceding paragraph is the Hop-by
///   Hop Options header, which carries information that must be examined
///   and processed by every node along a packet’s delivery path, including
///   the source and destination nodes.  The Hop-by-Hop Options header,
///   when present, must immediately follow the IPv6 header.  Its presence
///   is indicated by the value zero in the Next Header field of the IPv6
///   header. If, as a result of processing a header, a node is required to
///   proceed to the next header but the Next Header value in the current
///   header is unrecognized by the node, it should discard the packet and
///   send an ICMP Parameter Problem message to the source of the packet, with
///   an ICMP Code value of 1 ("unrecognized Next Header type encountered")
///   and the ICMP Pointer field containing the offset of the unrecognized
///   value within the original packet.  The same action should be taken if
///   a node encounters a Next Header value of zero in any header other
///   than an IPv6 header. Each extension header is an integer multiple of 8
///   octets long, in order to retain 8-octet alignment for subsequent headers.
///   Multi octet fields within each extension header are aligned on their
///   natural boundaries, i.e., fields of width n octets are placed at an
///   integer multiple of n octets from the start of the header, for n = 1,
///   2, 4, or 8. A full implementation of IPv6 includes implementation of the
///   following extension headers:
///
///   Hop-by-Hop Options (including Jumbogram [RFC-2675])
///   Routing (Type 0)
///   Fragment
///   Destination Options
///   Authentication (RFC-2402)
///   Encapsulating Security Payload (RFC-2406)
///
///
/// <B>Extension Header Order</B>
///
///   When more than one extension header is used in the same packet, it is
///   recommended that those headers appear in the following order:
///
///   * IPv6 header
///   * Hop-by-Hop Options header
///   * Destination Options header
///   * Routing header
///   * Fragment header
///   * Authentication header
///   * Encapsulating Security Payload header
///   * Destination Options header
///   * upper-layer header
///
///
/// <B>Extension Header Formats</B>
///
/// <B>Hop-by-Hop Options Header</B>
///
///   The Hop-by-Hop Options header is used to carry optional information
///   that must be examined by every node along a packet’s delivery path.
///   The Hop-by-Hop Options header is identified by a Next Header value of
///   0 in the IPv6 header, and has the following format:
///
///\image html IPHeadersOptions75.png "IPv6 Options Header"
///\image latex IPHeadersOptions75.eps "IPv6 Options Header" width=15cm
///
/// * Next Header          8-bit selector
///
///   Identifies the type of header immediately following the Hop-by-Hop
///   Options header.  Uses the same values as the IPv4 Protocol field
///
/// * Hdr Ext Len          8-bit unsigned integer
///
///   Length of the Hop-by-Hop Options header in 8-octet units, not
///   including the first 8 octets.
///
/// * Options              Variable-length field
///
///   Length such that the complete Hop-by-Hop Options header is an integer
///   multiple of 8 octets long.  Contains one or more TLV-encoded options
///
/// <B>Jumbo Payload Option</B>
///
///   The Jumbo Payload option is carried in an IPv6 Hop-by-Hop Options
///   header, immediately following the IPv6 header.  This option has an
///   alignment requirement of 4n + 2.  (See [IPv6, Section 4.2] for
///   discussion of option alignment.)  The option has the following
///   format:
///
///\image html IPHeadersJumbo75.png "IPv6 Jumbogram Header"
///\image latex IPHeadersJumbo75.eps "IPv6 Jumbogram Header" width=15cm
///
/// * Option Type           8-bit value of 0xC2 (hexadecimal)
///
/// * Opt Data Len          8-bit value of 0x04
///
/// * Jumbo Payload Length  32-bit unsigned integer
///
///   Length of the IPv6 packet in octets, excluding the IPv6 header
///   but including the Hop-by-Hop Options header and any other extension
///   headers present. Must be greater than 65,535.
///
///
/// <B>Routing Options Header</B>
///
///   The Routing header is used by an IPv6 source to list one or more
///   intermediate nodes to be "visited" on the way to a packet’s
///   destination.  This function is very similar to IPv4’s Loose Source
///   and Record Route option
///
///   The Routing header is identified by a Next Header value of 43 in the
///   immediately preceding header, and has the following format:
///
///\image html IPHeadersRoute75.png "IPv6 Routing Header"
///\image latex IPHeadersRoute75.eps "IPv6 Routing Header" width=15cm
///
/// * Next Header          8-bit selector
///
///   Identifies the type of header immediately following the Routing header
///   Uses the same values as the IPv4 Protocol field
///
/// * Hdr Ext Len          8-bit unsigned integer
///
///   Length of the Routing header in 8-octet units, not including the first 8 octets.
///
/// * Routing Type         8-bit identifier
///
///   Identifies a particular Routing header variant
///
/// * Segments Left        8-bit unsigned integer
///
///   Number of route segments remaining, i.e., number of explicitly listed
///   intermediate nodes still to be visited before reaching the final destination.
///
/// * type-specific data   Variable-length field
///
///   Format determined by the Routing Type, and of length such that the complete
///   Routing header is an integer multiple of 8 octets long
///
/// If, while processing a received packet, a node encounters a Routing header with
/// an unrecognized Routing Type value, the required behavior of the node depends on
/// the value of the Segments Left field, as follows:
///
/// If Segments Left is zero, the node must ignore the Routing header and proceed
/// to process the next header in the packet, whose type is identified by the Next
/// Header field in the Routing header. If Segments Left is non-zero, the node must
/// discard the packet and send an ICMP Parameter Problem, Code 0, message to the
/// packet’s Source Address, pointing to the unrecognized Routing Type. If, after
/// processing a Routing header of a received packet, an intermediate node determines
/// that the packet is to be forwarded onto a link whose link MTU is less than the
/// size of the packet, the node must discard the packet and send an ICMP Packet
/// Too Big message to the packet’s Source Address
///
/// The Type 0 Routing header has the following format:
///
///\image html IPHeadersRoute075.png "IPv6 Routing Type 0 Header"
///\image latex IPHeadersRoute075.eps "IPv6 Routing Type 0 Header" width=15cm
///
/// Multicast addresses must not appear in a Routing header of Type 0, or in the
/// IPv6 Destination Address field of a packet carrying a Routing header of Type 0
///
/// A Routing header is not examined or processed until it reaches the node
/// identified in the Destination Address field of the IPv6 header. In that node,
/// dispatching on the Next Header field of the immediately preceding header causes
/// the Routing header module to be invoked, which, in the case of Routing Type 0,
/// performs the following algorithm:
///
///\code
/// if Segments Left = 0 {
///     proceed to process the next header in the packet, whose type is
///     identified by the Next Header field in the Routing header
/// }
/// else if Hdr Ext Len is odd {
///     send an ICMP Parameter Problem, Code 0, message to the Source
///     Address, pointing to the Hdr Ext Len field, and discard the
///     packet
/// }
/// else {
///     compute n, the number of addresses in the Routing header, by
///     dividing Hdr Ext Len by 2
///
///     if Segments Left is greater than n {
///         send an ICMP Parameter Problem, Code 0, message to the Source
///         Address, pointing to the Segments Left field, and discard the
///         packet
///     }
///     else {
///         decrement Segments Left by 1;
///         compute i, the index of the next address to be visited in
///         the address vector, by subtracting Segments Left from n
///
///         if Address [i] or the IPv6 Destination Address is multicast {
///             discard the packet
///         }
///         else {
///             swap the IPv6 Destination Address and Address[i]
///
///             if the IPv6 Hop Limit is less than or equal to 1 {
///                 send an ICMP Time Exceeded -- Hop Limit Exceeded in
///                 Transit message to the Source Address and discard the
///                 packet
///             }
///             else {
///                 decrement the Hop Limit by 1
///
///                 resubmit the packet to the IPv6 module for transmission
///                 to the new destination
///             }
///         }
///     }
/// }
///\endcode
///
/// <B>Fragment Options Header</B>
///
///   The Fragment header is used by an IPv6 source to send a packet larger
///   than would fit in the path MTU to its destination.  (Note: unlike IPv4,
///   fragmentation in IPv6 is performed only by source nodes, not by routers
///   along a packet’s delivery path -- see section 5.)  The Fragment header is
///   identified by a Next Header value of 44 in the immediately preceding
///   header, and has the following format:
///
///\image html IPHeadersFrag75.png "IPv6 Fragmentation Header"
///\image latex IPHeadersFrag75.eps "IPv6 Fragmentation Header" width=15cm
///
/// * Next Header          8-bit selector
///
///   Identifies the initial header type of the Fragmentable Part of
///   the original packet (defined below).  Uses the same values as
///   the IPv4 Protocol field
///
/// * Reserved             8-bit reserved field
///
///   Initialized to zero for transmission; ignored on reception
///
/// * Fragment Offset      13-bit unsigned integer
///
///   The offset, in 8-octet units, of the data following this header,
///   relative to the start of the Fragmentable Part of the original packet.
///
/// * Res                  2-bit reserved field.
///
///   Initialized to zero for transmission; ignored on reception.
///
/// * M flag               1 = more fragments; 0 = last fragment
///
/// * Identification       32 bits
///
///
/// <B>Destination Options Header</B>
///
///   The Destination Options header is used to carry optional information
///   that need be examined only by a packet’s destination node(s).  The
///   Destination Options header is identified by a Next Header value of 60
///   in the immediately preceding header, and has the following format:
///
///\image html IPHeadersOptions75.png "IPv6 Destinations Options Header"
///\image latex IPHeadersOptions75.eps "IPv6 Destinations Options Header"
///
/// * Next Header          8-bit selector
///
///   Identifies the type of header immediately following the Destination Options
///   header. Uses the same values as the IPv4 Protocol field
///
/// * Hdr Ext Len          8-bit unsigned integer
///
///   Length of the Destination Options header in 8-octet units, not
///   including the first 8 octets
///
/// * Options              Variable-length field
///
///   Length such that the complete Destination Options header is an integer
///   multiple of 8 octets long.  Contains one or  more TLV-encoded options,
///   as described in section 4.2
///
/// [1] http://orm-chimera-prod.s3.amazonaws.com/1230000000545/ch03.html
///
/// [2] https://www.petri.com/ipv6-header-vs-ipv4
///
/// [3] http://help.mysonicwall.com/sw/eng/5505/ui2/25560/IPv6.html
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jip
/// @see ProtocolPP::jipsa
/// @see ProtocolPP::jicmp
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jip
/// @see jipsa
/// @see jicmp
/// @see jarray
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jipsa.h"
#include "jprotocol.h"

namespace ProtocolPP {

class jip : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal IP
    ///
    /// @param security - parameters necessary to setup and IP flow such
    ///                   as NH, SRC, DST, DSECN, TTL, FLAGS(IPv4),
    ///                   ID(IPv4), and LABEL(IPv6)
    //////////////////////////////////////////////////////////////////////
    explicit jip(std::shared_ptr<jipsa>& security);

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal IP with file containing input data
    ///
    /// @param security - parameters necessary to setup and IP flow such
    ///                   as NH, SRC, DST, DSECN, TTL, FLAGS(IPv4),
    ///                   ID(IPv4), and LABEL(IPv6)
    /// @param file - File containing input data
    //////////////////////////////////////////////////////////////////////
    jip(std::shared_ptr<jipsa>& security,
        std::string& file);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jip() {}

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor with
    /// a file handle. Encap will produce a packet with a payload
    /// from the file handle passed in
    ///
    /// @param output - IP encapsulated packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without
    /// a file handle. Encap will produce a packet with the payload
    /// passed in
    ///
    /// @param input - payload to encapsulate with IP
    /// @param output - IP encapsulated packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor with
    /// a file handle. Decap will produce a payload from the packet
    /// passed in and write it to the output file
    ///
    /// @param input - IP encapsulated packet to decapsulate
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without
    /// a file handle. Decap will produce a payload from the packet
    /// passed in.
    ///
    /// @param input - IP encapsulated packet to decapsulate
    /// @param output - decapsulated payload
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the IP header with their own header
    /// Note : This function will NOT save the previous header. If it is
    /// desired to keep the current header the user would need to use
    /// the get_iphdr() function and save the current header before
    /// updating the IP header with a custom header. The header would then
    /// need to be restored when the custom header is no longer needed
    ///
    /// @param hdr - new IP header to use
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the IP extension header with their own header
    /// @param exthdr - new extension header to use
    //////////////////////////////////////////////////////////////////////
    void set_exthdr(jarray<uint8_t>& exthdr);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the IP header
    ///
    /// @param field - field to update the IP header with
    /// @param value - value to update the IP header with
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Adds extension headers to the packet
    ///
    /// @param extension - extension type to add to IP header
    /// @param nh - Next Header (NH) for this extension header
    /// @param data - Data necessary for the extension header (32-bit length for JUMBOGRAM, Route header, Identifcation for Fragment, etc.)
    /// @param type_offset - Type (8-bits) for Routing header, offset (13-bits) for Fragment header
    /// @param segments - Number of segments left for Routing header (8-bits), "More" bit for Fragment header (1-bit)
    /// @return the formatted extension header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> format_exthdr(iana_t extension,
                                  iana_t nh,
                                  jarray<uint8_t>& data,
                                  uint16_t type_offset=0,
                                  uint8_t segments=0);

    //////////////////////////////////////////////////////////////////////
    /// Returns the complete IP header
    ///
    /// @return current IP header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr();

    //////////////////////////////////////////////////////////////////////
    /// Returns the extension header
    ///
    /// @return current extension header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_exthdr();

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the IP header
    ///
    /// @param field - field to retrieve from the IP header
    /// @param iphdr - header to retrieve the field from
    /// @return version field of the IP header
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& iphdr);

    //////////////////////////////////////////////////////////////////////
    /// Returns the field from the security association
    ///
    /// @param field - field to retrieve from the security association
    /// @return field from the security association
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field);

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jipsa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jip() = delete;
    jip(jip& jip) = delete;
    jip(const jip& jip) = delete;

    // initialization routine
    void init(); 
    
    // member variables
    jarray<uint8_t> m_iphdr;
    unsigned int m_hdrlen;
    std::shared_ptr<jipsa> m_sec;
};

}

#endif // JPROTOCOL_JIP_H_
