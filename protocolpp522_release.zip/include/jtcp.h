#ifndef JPROTOCOL_JTCP_H_
#define JPROTOCOL_JTCP_H_

///
///\class jtcp jtcp.h "include/jtcp.h"
///
///\section TCP_Class Transport Control Protocol (TCP)
///
/// See https://en.wikipedia.org/wiki/Transmission_Control_Protocol
///
/// The Transmission Control Protocol (TCP) is a core protocol of the Internet
/// protocol suite. It originated in the initial network implementation in which
/// it complemented the Internet Protocol (IP). Therefore, the entire suite is
/// commonly referred to as TCP/IP. TCP provides reliable, ordered, and
/// error-checked delivery of a stream of octets between applications running
/// on hosts communicating over an IP network. Major Internet applications such
/// as the World Wide Web, email, remote administration and file transfer rely
/// on TCP. Applications that do not require reliable data stream service may
/// use the User Datagram Protocol (UDP), which provides a connectionless
/// datagram service that emphasizes reduced latency over reliability
///
/// TCP segments are sent as internet datagrams.  The Internet Protocol
/// header carries several information fields, including the source and
/// destination host addresses [2].  A TCP header follows the internet
/// header, supplying information specific to the TCP protocol.  This
/// division allows for the existence of host level protocols other than
/// TCP (See RFC 793)
///
/// <B>TCP Header Format [1]</B>
///
///\image html TCP_headers.png "Transport Control Protocol (TCP) Header Format"
///\image latex TCP_headers.eps "Transport Control Protocol (TCP) Header Format" width=15cm
///
/// * Source Port:  16 bits
/// 
///   The source port number
///
/// * Destination Port:  16 bits
///
///   The destination port number
///
/// * Sequence Number:  32 bits
///
///   The sequence number of the first data octet in this segment (except
///   when SYN is present). If SYN is present the sequence number is the
///   initial sequence number (ISN) and the first data octet is ISN+1
///
/// * Acknowledgment Number:  32 bits
///
///   If the ACK control bit is set this field contains the value of the
///   next sequence number the sender of the segment is expecting to
///   receive.  Once a connection is established this is always sent
///
/// * Data Offset:  4 bits
///
///   The number of 32 bit words in the TCP Header.  This indicates where
///   the data begins.  The TCP header (even one including options) is an
///   integral number of 32 bits long.
///
/// * Reserved:  6 bits
///
///   Reserved for future use.  Must be zero
///
/// * Flags:  6 bits (from left to right):
///
///   * URG:  Urgent Pointer field significant
///   * ACK:  Acknowledgment field significant
///   * PSH:  Push Function
///   * RST:  Reset the connection
///   * SYN:  Synchronize sequence numbers
///   * FIN:  No more data from sender
///
/// * Window:  16 bits
///
///   The number of data octets beginning with the one indicated in the
///   acknowledgment field which the sender of this segment is willing to
///   accept
/// 
/// * Checksum:  16 bits
///
///   The checksum field is the 16 bit one’s complement of the one’s
///   complement sum of all 16 bit words in the header and text.  If a
///   segment contains an odd number of header and text octets to be
///   checksummed, the last octet is padded on the right with zeros to
///   form a 16 bit word for checksum purposes.  The pad is not
///   transmitted as part of the segment.  While computing the checksum,
///   the checksum field itself is replaced with zeros
///
///   The checksum also covers a 96 bit pseudo header conceptually
///   prefixed to the TCP header.  This pseudo header contains the Source
///   Address, the Destination Address, the Protocol, and TCP length.
///   This gives the TCP protection against misrouted segments.  This
///   information is carried in the Internet Protocol and is transferred
///   across the TCP/Network interface in the arguments or results of
///   calls by the TCP on the IP
///
///\code
///
///     +--------+--------+--------+--------+
///     |           Source Address          |
///     +--------+--------+--------+--------+
///     |         Destination Address       |
///     +--------+--------+--------+--------+
///     |  zero  |  PTCL  |    TCP Length   |
///     +--------+--------+--------+--------+
///
///\endcode
///
///   The TCP Length is the TCP header length plus the data length in
///   octets (this is not an explicitly transmitted quantity, but is
///   computed), and it does not count the 12 octets of the pseudo
///   header
///
/// * Urgent Pointer:  16 bits
///
///   This field communicates the current value of the urgent pointer as a
///   positive offset from the sequence number in this segment.  The
///   urgent pointer points to the sequence number of the octet following
///   the urgent data.  This field is only be interpreted in segments with
///   the URG control bit set
///
/// * Options (Variable 0–320 bits, divisible by 32)
///
///   The length of this field is determined by the data offset field. Options have
///   up to three fields: Option-Kind (1 byte), Option-Length (1 byte), Option-Data
///   (variable). The Option-Kind field indicates the type of option, and is the only
///   field that is not optional. Depending on what kind of option we are dealing with,
///   the next two fields may be set: the Option-Length field indicates the total length
///   of the option, and the Option-Data field contains the value of the option, if
///   applicable. For example, an Option-Kind byte of 0x01 indicates that this is a No-Op
///   option used only for padding, and does not have an Option-Length or Option-Data byte
///   following it. An Option-Kind byte of 0 is the End Of Options option, and is also only
///   one byte. An Option-Kind byte of 0x02 indicates that this is the Maximum Segment Size
///   option, and will be followed by a byte specifying the length of the MSS field (should
///   be 0x04). Note that this length is the total length of the given options field,
///   including Option-Kind and Option-Length bytes. So while the MSS value is typically
///   expressed in two bytes, the length of the field will be 4 bytes (+2 bytes of kind
///   and length). In short, an MSS option field with a value of 0x05B4 will show up as
///   (0x02 0x04 0x05B4) in the TCP options section
///
/// Some options may only be sent when SYN is set; they are indicated below as [SYN].
/// Option-Kind and standard lengths given as (Option-Kind,Option-Length)
///
/// * 0 (8 bits) – End of options list
///
/// * 1 (8 bits) – No operation (NOP, Padding) This may be used to align option fields on
///                32-bit boundaries for better performance
///
/// * 2,4,SS (32 bits) – Maximum segment size (see maximum segment size) [SYN]
///
/// * 3,3,S (24 bits) – Window scale (see window scaling for details) [SYN][6]
///
/// * 4,2 (16 bits) – Selective Acknowledgement permitted. [SYN] (See selective acknowledgments for details)[7]
///
/// * 5,N,BBBB,EEEE,... (variable bits, N is either 10, 18, 26, or 34)- Selective ACKnowledgement (SACK)[8]
///                     These first two bytes are followed by a list of 1–4 blocks being selectively acknowledged,
///                     specified as 32-bit begin/end pointers
///
/// * 8,10,TTTT,EEEE (80 bits)- Timestamp and echo of previous timestamp (see TCP timestamps for details)[9]
///
/// (The remaining options are historical, obsolete, experimental, not yet standardized, or unassigned)
///
/// <B>Options:  variable</B>
///
/// Options may occupy space at the end of the TCP header and are a
/// multiple of 8 bits in length.  All options are included in the
/// checksum.  An option may begin on any octet boundary.  There are two
/// cases for the format of an option:
///
/// * Case 1:  A single octet of option-kind
///
/// * Case 2:  An octet of option-kind, an octet of option-length, and
///            the actual option-data octets.
///
/// The option-length counts the two octets of option-kind and
/// option-length as well as the option-data octets
///
/// Note that the list of options may be shorter than the data offset
/// field might imply.  The content of the header beyond the
/// End-of-Option option must be header padding (i.e., zero)
///                                                            
/// A TCP must implement all options.
///
/// Currently defined options include (kind indicated in octal):
///
///\code
///
///     Kind     Length    Meaning
///     ----     ------    ------
///      0         -       End of option list
///      1         -       No-Operation
///      2         4       Maximum Segment Size.
///
///\endcode
///
///
/// <B>Specific Option Definitions</B>
///
///\code
///
///     End of Option List
///
///     +--------+
///     |00000000|
///     +--------+
///       Kind=0
///
///\endcode
///
/// This option code indicates the end of the option list.  This
/// might not coincide with the end of the TCP header according to
/// the Data Offset field.  This is used at the end of all options
/// not the end of each option, and need only be used if the end of
/// the options would not otherwise coincide with the end of the TCP
/// header
///
///\code
///
///     No-Operation
///
///     +--------+
///     |00000001|
///     +--------+
///       Kind=1
///
///\endcode
///
/// This option code may be used between options, for example, to
/// align the beginning of a subsequent option on a word boundary.
/// There is no guarantee that senders will use this option, so
/// receivers must be prepared to process options even if they do
/// not begin on a word boundary
///
///\code
///
///     Maximum Segment Size
///
///     +--------+--------+---------+--------+
///     |00000010|00000100|   max seg size   |
///     +--------+--------+---------+--------+
///      Kind=2   Length=4
///
///\endcode
///
/// * Maximum Segment Size Option Data:  16 bits
///
/// If this option is present, then it communicates the maximum
/// receive segment size at the TCP which sends this segment.
/// This field must only be sent in the initial connection request
/// (i.e., in segments with the SYN control bit set).  If this
/// option is not used, any segment size is allowed
///
/// <B>Padding</B>
///
/// The TCP header padding is used to ensure that the TCP header ends and data begins on
/// a 32 bit boundary. The padding is composed of zeros[10]
///
/// <B>Protocol operation</B>
///
/// TCP protocol operations may be divided into three phases. Connections must be
/// properly established in a multi-step handshake process (connection establishment)
/// before entering the data transfer phase. After data transmission is completed,
/// the connection termination closes established virtual circuits and releases all
/// allocated resources
///
///\image html Tcp_state_diagram.png "Transmission Control Protocol (TCP) State Transition Diagram [2]"
///\image latex Tcp_state_diagram.eps "Transmission Control Protocol (TCP) State Transition Diagram [2]" width=15cm
///
/// A TCP connection is managed by an operating system through a programming interface that
/// represents the local end-point for communications, the Internet socket. During the
/// lifetime of a TCP connection the local end-point undergoes a series of state changes:[11]
///
/// LISTEN 
/// * (server) represents waiting for a connection request from any remote TCP and port
///
/// SYN-SENT 
/// * (client) represents waiting for a matching connection request after having sent a connection request
///
/// SYN-RECEIVED 
/// * (server) represents waiting for a confirming connection request acknowledgment after
///   having both received and sent a connection request
///
/// ESTABLISHED 
/// * (both server and client) represents an open connection, data received can be delivered
///   to the user. The normal state for the data transfer phase of the connection
///
/// FIN-WAIT-1 
/// * (both server and client) represents waiting for a connection termination request from
///   the remote TCP, or an acknowledgment of the connection termination request previously sent
///
/// FIN-WAIT-2 
/// * (both server and client) represents waiting for a connection termination request from the remote TCP
///
/// CLOSE-WAIT 
/// * (both server and client) represents waiting for a connection termination request from the local user
///
/// CLOSING 
/// * (both server and client) represents waiting for a connection termination request
///   acknowledgment from the remote TCP
///
/// LAST-ACK 
/// *  (both server and client) represents waiting for an acknowledgment of the connection
///    termination request previously sent to the remote TCP (which includes an acknowledgment
///    of its connection termination request)
///
/// TIME-WAIT 
/// * (either server or client) represents waiting for enough time to pass to be sure the
///   remote TCP received the acknowledgment of its connection termination request.
///   [According to RFC 793 a connection can stay in TIME-WAIT for a maximum of four minutes
///   known as two MSL (maximum segment lifetime).]
///
/// CLOSED 
/// * (both server and client) represents no connection state at all
///
/// <B>Connection establishment</B>
///
/// To establish a connection, TCP uses a three-way handshake. Before a client attempts
/// to connect with a server, the server must first bind to and listen at a port to open
/// it up for connections: this is called a passive open. Once the passive open is
/// established, a client may initiate an active open. To establish a connection, the
/// three-way (or 3-step) handshake occurs:
///
/// * 1.SYN: The active open is performed by the client sending a SYN to the server. The
///          client sets the segment's sequence number to a random value A
///
/// * 2.SYN-ACK: In response, the server replies with a SYN-ACK. The acknowledgment number
///              is set to one more than the received sequence number i.e. A+1, and the
///              sequence number that the server chooses for the packet is another random number, B
///
/// * 3.ACK: Finally, the client sends an ACK back to the server. The sequence number is
///          set to the received acknowledgement value i.e. A+1, and the acknowledgement
///          number is set to one more than the received sequence number i.e. B+1
///
/// At this point, both the client and server have received an acknowledgment of the connection.
/// The steps 1, 2 establish the connection parameter (sequence number) for one direction and it
/// is acknowledged. The steps 2, 3 establish the connection parameter (sequence number) for the
/// other direction and it is acknowledged. With these, a full-duplex communication is established
///
/// <B>Connection termination</B>
///
/// The connection termination phase uses a four-way handshake, with each side of the connection
/// terminating independently. When an endpoint wishes to stop its half of the connection, it
/// transmits a FIN packet, which the other end acknowledges with an ACK. Therefore, a typical
/// tear-down requires a pair of FIN and ACK segments from each TCP endpoint. After the side
/// that sent the first FIN has responded with the final ACK, it waits for a timeout before
/// finally closing the connection, during which time the local port is unavailable for new
/// connections; this prevents confusion due to delayed packets being delivered during subsequent
/// connections
///
///\image html TCP_CLOSE.png "Transmission Control Protocol (TCP) Closing Procedure [3]"
///\image latex TCP_CLOSE.eps "Transmission Control Protocol (TCP) Closing Procedure [3]" width=15cm
///
/// A connection can be "half-open", in which case one side has terminated its end, but the other
/// has not. The side that has terminated can no longer send any data into the connection, but
/// the other side can. The terminating side should continue reading the data until the other
/// side terminates as well
///
/// It is also possible to terminate the connection by a 3-way handshake, when host A sends a
/// FIN and host B replies with a FIN & ACK (merely combines 2 steps into one) and host A replies
/// with an ACK.[12]
///
/// Some host TCP stacks may implement a half-duplex close sequence, as Linux or HP-UX do. If such
/// a host actively closes a connection but still has not read all the incoming data the stack
/// already received from the link, this host sends a RST instead of a FIN (Section 4.2.2.13 in RFC
/// 1122). This allows a TCP application to be sure the remote application has read all the data the
/// former sent—waiting the FIN from the remote side, when it actively closes the connection. But
/// the remote TCP stack cannot distinguish between a Connection Aborting RST and Data Loss RST.
/// Both cause the remote stack to lose all the data received
///
/// <B>TCP checksum for IPv4</B>
///
/// When TCP runs over IPv4, the method used to compute the checksum is defined in RFC 793:
///
/// The checksum field is the 16 bit one's complement of the one's complement sum of all
/// 16-bit words in the header and text. If a segment contains an odd number of header and
/// text octets to be checksummed, the last octet is padded on the right with zeros to form
/// a 16-bit word for checksum purposes. The pad is not transmitted as part of the segment.
/// While computing the checksum, the checksum field itself is replaced with zeros.
///
/// In other words, after appropriate padding, all 16-bit words are added using one's
/// complement arithmetic. The sum is then bitwise complemented and inserted as the checksum
/// field. A pseudo-header that mimics the IPv4 packet header used in the checksum computation
/// is shown in the table below.
///
/// <B>TCP pseudo-header for checksum computation (IPv4) [3]</B>
///
///\image html TCP_IPv4_Psuedo_Header.png "Transmission Control Protocol (TCP) Psuedo Header for IPv4 Checksum Calculation"
///\image latex TCP_IPv4_Psuedo_Header.eps "Transmission Control Protocol (TCP) Psuedo Header for IPv4 Checksum Calculation" width=15cm
///
/// * The source and destination addresses are those of the IPv4 header
///
/// * The protocol value is 6 for TCP (cf. List of IP protocol numbers)
///
/// * The TCP length field is the length of the TCP header and data (measured in octets).
///
/// <B>TCP checksum for IPv6</B>
///
/// When TCP runs over IPv6, the method used to compute the checksum is changed, as per RFC 2460: 
///
/// Any transport or other upper-layer protocol that includes the addresses from the IP header in
/// its checksum computation must be modified for use over IPv6, to include the 128-bit IPv6
/// addresses instead of 32-bit IPv4 addresses.
///
/// A pseudo-header that mimics the IPv6 header for computation of the checksum is shown below
///
/// <B>TCP pseudo-header for checksum computation (IPv6) [4]</B>
///
///\image html TCP_IPv6_Psuedo_Header.png "Transmission Control Protocol (TCP) Psuedo Header for IPv6 Checksum Calculation"
///\image latex TCP_IPv6_Psuedo_Header.eps "Transmission Control Protocol (TCP) Psuedo Header for IPv6 Checksum Calculation" width=15cm
///
/// * Source address – the one in the IPv6 header
///
/// * Destination address – the final destination; if the IPv6 packet doesn't contain a Routing
///   header, TCP uses the destination address in the IPv6 header, otherwise, at the originating
///   node, it uses the address in the last element of the Routing header, and, at the receiving
///   node, it uses the destination address in the IPv6 header
///
/// * TCP length – the length of the TCP header and data
///
/// * Next Header – the protocol value for TCP
///
/// <B>Checksum offload</B>
///
/// Many TCP/IP software stack implementations provide options to use hardware assistance to
/// automatically compute the checksum in the network adapter prior to transmission onto the
/// network or upon reception from the network for validation. This may relieve the OS from
/// using precious CPU cycles calculating the checksum. Hence, overall network performance
/// is increased
///
/// This feature may cause packet analyzers detecting outbound network traffic upstream of the
/// network adapter that are unaware or uncertain about the use of checksum offload to report
/// invalid checksum in outbound packets
///
/// [1] http://microchip.wikidot.com/tcpip:tcp-vs-udp
///
/// [2] https://en.wikipedia.org/wiki/Transmission_Control_Protocol
///
/// [3] https://en.wikipedia.org/wiki/Transmission_Control_Protocol
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jtcpsa
/// @see ProtocolPP::jtcp
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jarray
/// @see jrand
/// @see jtcpsa
/// @see jtcp
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jtcpsa.h"
#include "jprotocol.h"

namespace ProtocolPP {

class jtcp : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// Options that TCP may add to the standard header
    //////////////////////////////////////////////////////////////////////
    enum tcpopt_t { ///This option code indicates the end of the option list. This might not coincide with the end of the TCP header according to the Data Offset field. This is used at the end of all options not the end of each option, and need only be used if the end of the options would not otherwise coincide with the end of the TCP header 
        END,       ///This option code may be used between options, for example, to align the beginning of a subsequent option on a word boundary. There is no guarantee that senders will use this option, so receivers must be prepared to process options even if they do not begin on a word boundary 
        NOP,       ///If this option is present, then it communicates the maximum receive segment size at the TCP which sends this segment. This field must only be sent in the initial connection request (i.e., in segments with the SYN control bit set).  If this option is not used, any segment size is allowed

        MSS,       ///Resize the window
        WINSCALE,  ///Select acknowledge
        SELACK,    ///Acknowledge
        SACK,      ///Timestamp
        TIMESTAMP
    };

    //////////////////////////////////////////////////////////////////////
    /// TCP states of operation
    //////////////////////////////////////////////////////////////////////
    enum tcpstate_t { /// (Server) Waiting for connection request
        LISTEN,       /// (Client) Connection request sent, waiting for server request
        SYN_SENT,     /// (Server) waiting for a confirming connection request acknowledgment having both received and sent a connection request
        SYN_RCVD,     /// (BOTH) Open connection with data flowing. Normal state for a data connection
        ESTABLISHED,  /// (BOTH) represents waiting for a connection termination request from the remote TCP, or an acknowledgment of the connection termination request previously sent
        FIN_WAIT_1,   /// (BOTH) represents waiting for a connection termination request from the remote TCP
        FIN_WAIT_2,   /// (BOTH) represents waiting for a connection termination request from the local user
        CLOSE_WAIT,   /// (BOTH) represents waiting for an acknowledgment of the connection termination request previously sent to the remote TCP (which includes an acknowledgment of its connection termination request)
        LAST_ACK,     /// (BOTH) represents waiting for enough time to pass to be sure the remote TCP received the acknowledgment of its connection termination request. [According to RFC 793 a connection can stay in TIME-WAIT for a maximum of four minutes known as two MSL (maximum segment lifetime).]
        TIME_WAIT,    /// (BOTH) represents no connection state at all
        CLOSED
    };

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal TCP containing all necessary fields to
    /// setup and run a TCP connection. All fields are accessible with
    /// the set_field() and get_field() functions
    ///
    /// @param state - Initial state of the engine (either LISTEN for SERVER or SYN_SENT for CLIENT). Can be ESTABLISHED
    /// @param security - Parameters to setup a TCP flow
    //////////////////////////////////////////////////////////////////////
    jtcp(tcpstate_t state,
         std::shared_ptr<jtcpsa>& security);

    //////////////////////////////////////////////////////////////////////
    /// constructor for normal TCP with file input containing all
    /// necessary fields to setup and run a TCP connection. All fields
    /// are accessible with the set_field() and get_field() functions
    ///
    /// @param state - Initial state of the engine (either LISTEN for SERVER or SYN_SENT for CLIENT). Can be ESTABLISHED
    /// @param security - Parameters to setup a TCP flow
    /// @param file - path to file to use to source packet payloads
    //////////////////////////////////////////////////////////////////////
    jtcp(tcpstate_t state,
         std::shared_ptr<jtcpsa>& security,
         std::string& file);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jtcp() {}

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without a file
    /// handle. Encap will produce a packet from the payload passed in
    ///
    /// @param input - payload to encapsulate with TCP
    /// @param output - encapsulated TCP packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// This function is for use with the constructor without a file
    /// handle. Decap will produce a payload from the packet passed in
    /// check the flags, and update the window
    ///
    /// @param input - TCP packet to decapsulate
    /// @param output - decapsulated payload
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update a field in the header
    ///
    /// @param field - field to update in the TCP header
    /// @param value - new value to add to the TCP header
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update complete TCP header
    ///
    /// @param hdr - new header to add to the TCP header
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to add options to the TCP header
    ///
    /// @param OPT - option to add to the TCP header
    /// @param value - value of the option to add to the TCP header
    //////////////////////////////////////////////////////////////////////
    void add_option(tcpopt_t OPT, jarray<uint8_t>& value);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the field from the TCP header
    ///
    /// @param field - field from TCP header to retrieve
    /// @param header - TCP header to retrieve field from
    /// @return field from the TCP header
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& header);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the field from the TCP security association
    ///
    /// @param field - field from TCP security association to retrieve
    /// @return field from the TCP association
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Retrieves the complete TCP header
    ///
    /// @return TCP header
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr();

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jtcpsa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Writes the XML protocol and security objects to XML
    /// @param myxml - XMLPrinter object
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jtcp() = delete;
    jtcp(jtcp& jtcp) = delete;
    jtcp(const jtcp& jtcp) = delete;

    void init();

    // array for TCP header
    std::shared_ptr<jtcpsa> m_sec;
    tcpstate_t m_state;
    jarray<uint8_t> m_tcphdr;
};

}

#endif // JPROTOCOL_JTCP_H_
