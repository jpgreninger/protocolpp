#ifndef JDSA_H_
#define JDSA_H_

///
///\class jdsa jdsa.h "include/jdsa.h"
///
///\section DSA Digital Signature Algorithm
///
/// see https://en.wikipedia.org/wiki/Digital_Signature_Algorithm
///
/// The Digital Signature Algorithm (DSA) is a Federal Information Processing Standard for digital signatures, based
/// on the mathematical concept of modular exponentiations and the discrete logarithm problem. 
///
/// In August 1991 the National Institute of Standards and Technology (NIST) proposed DSA for use in their Digital
/// Signature Standard (DSS) and adopted it as FIPS 186 in 1994. Four revisions to the initial specification have been
/// released: FIPS 186-1 in 1996, FIPS 186-2 in 2000, FIPS 186-3 in 2009, and FIPS 186-4 in 2013 
///
/// <B>DSA: How does it work?</B>
///
/// The DSA algorithm works in the framework of public-key cryptosystems and is based on the algebraic properties of the
/// modular exponentiations, together with the discrete logarithm problem (which is considered to be computationally
/// intractable). Messages are signed by the signer's private key and the signatures are verified by the signer's corresponding
/// public key. The digital signature provides message authentication, integrity and non-repudiation 
///
/// <B>Key generation</B>
///
/// Key generation has two phases. The first phase is a choice of algorithm parameters which may be shared between
/// different users of the system, while the second phase computes public and private keys for a single user 
///
/// <B>Parameter generation</B>
///
/// Choose an approved cryptographic hash function H. In the original DSS, H was always SHA-1, but the stronger SHA-2 hash
/// functions are approved for use in the current DSS. The hash output may be truncated to the size of a key pair
///
/// Decide on a key length L and N (the cryptographic strength of the L bit long key). The original DSS constrained L to be a
/// multiple of 64 between 512 and 1,024 (inclusive). NIST 800-57 recommends lengths of 2,048 (or 3,072) for keys with security
/// lifetimes extending beyond 2010 (or 2030), using correspondingly longer N. FIPS 186-3 specifies L and N length pairs of (1,024, 160),
/// (2,048, 224), (2,048, 256), and (3,072, 256). N must be less than or equal to the output length of the hash H
///
/// Choose an \f$ N\f$-bit prime \f$ q\f$
///
/// Choose an \f$ L\f$-bit prime \f$ p\f$ such that \f$ p - 1\f$ is a multiple of \f$ q\f$
///
/// Choose g, a number whose multiplicative order modulo p is q. This means that q is the smallest positive integer such that gq=1 mod p.
/// This may be done by setting \f$ g = {h}^{(p - 1)/q} mod p\f$ for some arbitrary \f$ h (1 < h < p - 1)\f$, and trying again
/// with a different \f$ h\f$ if the result comes out as 1. Most choices of \f$ h\f$  will lead to a usable \f$ g\f$; commonly \f$ h = 2\f$ is used
///
/// The algorithm parameters \f$ (p, q, g)\f$ may be shared between different users of the system 
///
/// <B>Per-user keys</B>
///
/// Given a set of parameters, the second phase computes private and public keys for a single user: 
///
/// * Choose a secret private key \f$ x\f$ by some random method, where \f$ 0 < x < q\f$
///
/// * Calculate the public key \f$ y = {g}^{x} mod p\f$
///
/// There exist efficient algorithms for computing the modular exponentiations \f$ {h}^{ \frac{p - 1}{q}} mod p\f$ and
/// \f$ {g}^{x} mod p\f$, such as exponentiation by squaring 
///
/// <B>Signing</B>
///
/// * Let H be the hashing function and m the message: 
///
/// * Generate a random per-message value \f$ k\f$ where \f$ 1 < k < q\f$ 
///
/// * Calculate \f$ r = ({g}^{k} mod p) mod q\f$ 
///
/// * In the unlikely case that \f$ r = 0\f$, start again with a different random \f$ k\f$ 
///
/// * Calculate \f$ s = {k}^{-1} (H(m) + xr) mod q\f$ 
///
/// * In the unlikely case that \f$ s = 0\f$, start again with a different random \f$ k\f$
///
/// * The signature is \f$ (r, s)\f$ 
///
/// The first two steps amount to creating a new per-message key. The modular exponentiation here is the most computationally
/// expensive part of the signing operation, and it may be computed before the message hash is known. The modular inverse 
///
/// \f$ {k}^{-1} mod q\f$
///
/// is the second most expensive part, and it may also be computed before the message hash is known. It may be computed
/// using the extended Euclidean algorithm or using Fermat's little theorem as 
///
/// \f$ {k}^{q - 2} mod q\f$ 
///
/// <B>Verifying</B>
///
/// * Reject the signature if \f$ 0 < r < q\f$ or \f$ 0 < s < q\f$ is not satisfied
///
/// * Calculate \f$ w = {s}^{-1} mod q\f$ 
///
/// * Calculate \f$ u_1 = H(m) \cdot w mod q\f$
///
/// * Calculate \f$ u_2 = r \cdot w mod q\f$
///
/// * Calculate \f$ v = ({g}^{u_1} {y}^{u_2} mod p ) mod q\f$
///
/// * The signature is valid if and only if \f$ v = r\f$
///
/// <B>For API information:</B>
///
/// @see ProtocolPP::jdsa
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jprotocolpp
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
///
/// @see jdsa
/// @see jprotocol
/// @see jprotocolpp
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#include <sys/types.h>
//#include <unistd.h>
//#include <crypt.h>
#include <cstring>
#include <memory>
#include "jlogger.h"
#include "jenum.h"
#include "jarray.h"
#include "jdsasa.h"

#include "nbtheory.h"
using CryptoPP::ModularExponentiation;

#include "osrng.h"
using CryptoPP::AutoSeededRandomPool;

#include "dh.h"
using CryptoPP::DH;

#include "sha.h"
using CryptoPP::SHA1;
using CryptoPP::SHA256;
using CryptoPP::SHA384;
using CryptoPP::SHA512;

#include "secblock.h"
using CryptoPP::SecByteBlock;

#include "integer.h"
using CryptoPP::Integer;

namespace ProtocolPP {

class jdsa : public jprotocol {

public:

  	//////////////////////////////////////////////////////////////////////
    /// Digital Signature Constructor from bitsize
    /// @param bitsize - size of the key
    /// @param logger - logging object
  	//////////////////////////////////////////////////////////////////////
    jdsa(int bitsize,
         std::shared_ptr<InterfacePP::jlogger>& logger);

  	//////////////////////////////////////////////////////////////////////
    /// Digital Signature Constructor from domain parameters
    /// @param bitsize - size of the key
    /// @param p - Product (Prime) domain parameter
    /// @param q - Quotient (SubPrime) domain parameter 
    /// @param g - Generator domain parameter 
    /// @param logger - logging object
  	//////////////////////////////////////////////////////////////////////
    jdsa(int bitsize,
         CryptoPP::Integer p,
         CryptoPP::Integer q,
         CryptoPP::Integer g,
         std::shared_ptr<InterfacePP::jlogger>& logger);

  	//////////////////////////////////////////////////////////////////////
    /// Digital Signature Constructor from private and public key
    /// @param bitsize - size of the key
    /// @param PRVKey - Private key
    /// @param PUBKey - Public key
    /// @param logger - logging object
  	//////////////////////////////////////////////////////////////////////
    jdsa(int bitsize,
         CryptoPP::DSA::PrivateKey& PRVKey,
         CryptoPP::DSA::PublicKey& PUBKey,
         std::shared_ptr<InterfacePP::jlogger>& logger);

  	//////////////////////////////////////////////////////////////////////
    /// Digital Signature Constructor from private and public key pair
    /// @param bitsize - size of the key
    /// @param keypair - Private/Public key pair as std::pair()
    /// @param logger - logging object
  	//////////////////////////////////////////////////////////////////////
    jdsa(int bitsize,
         std::pair<CryptoPP::DSA::PrivateKey,CryptoPP::DSA::PublicKey>& keypair,
         std::shared_ptr<InterfacePP::jlogger>& logger);

  	//////////////////////////////////////////////////////////////////////
    /// Digital Signature Constructor from security association
    /// @param security - security associtiation
  	//////////////////////////////////////////////////////////////////////
    explicit jdsa(std::shared_ptr<jdsasa>& security);

  	//////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
  	//////////////////////////////////////////////////////////////////////
    ~jdsa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field Diffie-Hellman object
    ///
    /// <table>
    /// <caption id="DSA Set Fields">DSA Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>int <td>BITSIZE<td>set_field<int>(field_t::BITSIZE, size)
    /// <tr><td>keymode_t<td>MODE<td>set_field<keymode_t>(field_t::MODE, keymode_t::GENKEYPAIR)
    /// <tr><td>CryptoPP::Integer <td>GENERATOR<td>set_field<CryptoPP::Integer>(field_t::GENERATOR, g)
    /// <tr><td>CryptoPP::Integer <td>QUOTIENT<td>set_field<CryptoPP::Integer>(field_t::QUOTIENT, q)
    /// <tr><td>CryptoPP::Integer <td>PRODUCT<td>set_field<CryptoPP::Integer>(field_t::PRODUCT, p)
    /// <tr><td>CryptoPP::DSA::PublicKey <td>PUBKEY<td>set_field<CryptoPP::DSA::PublicKey>(field_t::PUBKEY, pubkey)
    /// <tr><td>CryptoPP::DSA::PrivateKey <td>PRVKEY<td>set_field<CryptoPP::DSA::PrivateKey>(field_t::PRVKEY, prvkey)
    /// </table>
    ///
    /// @param field - field to update the DSA security association
    /// @param fieldval - value to update the DSA security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the DSA security association
    ///
    /// <table>
    /// <caption id="DSA Get Fields">DSA Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>int<td>BITSIZE<td>int size = get_field<int>(field_t::BITSIZE)
    /// <tr><td>keymode_t<td>MODE<td>keymode_t mode = get_field<keymode_t>(field_t::MODE)
    /// <tr><td>CryptoPP::Integer <td>GENERATOR<td>CryptoPP::Integer generator = get_field<CryptoPP::Integer>(field_t::GENERATOR)
    /// <tr><td>CryptoPP::Integer <td>QUOTIENT<td>CryptoPP::Integer quotient = get_field<CryptoPP::Integer>(field_t::QUOTIENT)
    /// <tr><td>CryptoPP::Integer <td>PRODUCT<td>CryptoPP::Integer product = get_field<CryptoPP::Integer>(field_t::PRODUCT)
    /// <tr><td>CryptoPP::DSA::PublicKey <td>PUBKEY<td>CryptoPP::DSA::PublicKey pubkey = get_field<CryptoPP::DSA::PublicKey>(field_t::PUBKEY)
    /// <tr><td>CryptoPP::DSA::PrivateKey <td>PRVKEY<td>CryptoPP::DSA::PrivateKey prvkey = get_field<CryptoPP::DSA::PrivateKey>(field_t::PRVKEY)
    /// </table>
    ///
    /// @param field - field to retrieve from the DSA security association
    /// @return field of the DSA security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

  	//////////////////////////////////////////////////////////////////////
    /// Generate a new key pair which modifies this object's key pair
    /// retrieve the keypair using the accessor functions
  	//////////////////////////////////////////////////////////////////////
    void gen_keypair();

  	//////////////////////////////////////////////////////////////////////
    /// Generate a signature
    /// @param data - data to sign
    /// @param signature - Signature generated from private key and data
  	//////////////////////////////////////////////////////////////////////
    void sign(std::shared_ptr<jarray<uint8_t>>& data,
              std::shared_ptr<jarray<uint8_t>>& signature);

  	//////////////////////////////////////////////////////////////////////
    /// Verify the signature using the received public key
    /// @param data - data and signature concatenated to verify (data || signature)
    /// @return Signature verification
  	//////////////////////////////////////////////////////////////////////
    void verify(std::shared_ptr<jarray<uint8_t>>& data);

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jdsasa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param hdr - header of the packet
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param field - field to update
    /// @param value - new value of the field
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @return empty array
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr(); 

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @return 0
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param input - data to encapsulate
    /// @param output - encapsulated packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param input - encapsulated data
    /// @param output - decapsulated packet
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

private:

    // don't use these
    jdsa(jdsa& jdsa) = delete;
    jdsa(const jdsa& jdsa) = delete;

    // member variables
    std::shared_ptr<jdsasa> m_sec;
    std::shared_ptr<InterfacePP::jlogger> m_logger;

    // Seeded random number generator
    CryptoPP::AutoSeededRandomPool m_rng;
};

}

#endif /* JDSA_H_ */

