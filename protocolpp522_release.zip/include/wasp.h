#ifndef JPROTOCOL_WASP_H_
#define JPROTOCOL_WASP_H_

///
///\class wasp wasp.h "include/wasp.h"
///
///\section WASP W.A.S.P XML Parser and Randomizer for Protocol++&reg; (ProtocolPP&reg;)
///
/// W.A.S.P is an interface to Protocol++&reg; to allow it to connect to a testbench and generate XML files with Protocol++&reg; data. W.A.S.P
/// accepts two input types either PPP (constraint file for random generation of packets) or PROTPP (data file containing packets
/// to be driven into a testbench).
///
///\subsection PPP PPP Format
/// The PPP format (i.e., input.ppp) contains only stream, protocol, and security information. W.A.S.P interprets this type of
/// file as either generating an output PROTPP file if the output is provided, or as generating random descriptors for
/// the testbench that will subsequently be driven into the bench after generation.
///
/// The PPP has three possible formats as follows. NOTE: For all of these formats, any values not provided by the user are randomized
///
/// * FORMAT1 - Format #1 allows full randomization of seed, streams, packets, datalen, protocol, and security association run
///
///\code
///
///  <?xml version='1.0' encoding='UTF-8'?>
///  <protocolpp ver='1.0' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation='../schema/wasp.xsd'> 
///    <general/>
///    <stream count='5' packets='3' datalen='1500..8192'>
///  </protocolpp>
///\endcode
///
/// * FORMAT2 - Format #2 allows randomization of streams, packets, datalen, and security association for the protocol(s) specified
///
///\code
///
///  <?xml version='1.0' encoding='UTF-8'?>
///  <protocolpp ver='1.0' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation='../schema/wasp.xsd'> 
///    <general seed='0x00112233'/>
///    <stream count='3..5' packets='3..10' datalen='1..50'>
///      <protocol prot='IPV4:SRTP:WIFI' dir='encap'>
///      </protocol>
///    </stream>
///  </protocolpp>
///\endcode
///
/// * FORMAT3 - Format #3 allows randomization of streams, packets, and datalen for the protocol and security association specified
///
///\code
///
///  <?xml version='1.0' encoding='UTF-8'?>
///  <protocolpp ver='1.0' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation='../schema/wasp.xsd'> 
///    <general seed='0x00112233'/>
///    <stream name='test1' count='1' packets='2025' datalen='390'>
///      <protocol name='ipsec'>
///        <security
///          name='ipsecsa'
///          ver='IPV4'
///          dir='ENCAP'
///          mode='tunnel'
///          cipher='aes_cbc'
///          auth='hmac_sha1'
///          icvlen='16'
///          usext='false'
///          audit='false'
///          source='44332211'
///          dest='99887766'
///          spi='55331177'
///          seqnum='55331177'
///          hdrlen='80'
///          tfclen='22'
///          ckeylen='16'
///          cipherkey='AAAABBBBCCCCDDDDEEEEFFFF00001111'
///          akeylen='16'
///          authkey='AAAABBBBCCCCDDDDEEEEFFFF00001111'
///          ivlen='16'
///          iv='AAAABBBBCCCCDDDDEEEEFFFF00001111'>
///        </security>
///      </protocol>
///    </stream>
///  </protocolpp>
///\endcode
///
///\subsection PROTPP PROTPP Format
/// The PROTPP formation (i.e., input.protpp) contains stream, protocol, security, input, output, and expected values. W.A.S.P
/// interpretes this type of input as the user wants to drive the testbench with the input file.
///
/// The PRTOPP format is as follows :
///\code
///
///  <?xml version='1.0' encoding='UTF-8'?>
///  <protocolpp ver="1.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../schema/wasp.xsd">
///    <general seed="1475990354"/>
///    <stream name="test1"/>
///    <protocol prot="TLS" file="">
///      <security
///        name="tlsa"
///        dir='ENCAP'
///        ciphersuite="TLS_PSK_WITH_AES_128_CBC_SHA"
///        version="DTLS"
///        type="APPLICATION"
///        epoch="3251"
///        seqnum="15521080929407598078"
///        icvlen="20"
///        ivlen="16"
///        iv="AABBCCDDFFEEDDCC0011223344556677"
///        ckeylen="16"
///        cipherkey="AAAABBBBCCCCDDDDEEEEFFFF00001111"
///        akeylen="16"
///        authkey="AAAABBBBCCCCDDDDEEEEFFFF00001111"
///        arlen="0"
///        arwin=""
///        randomiv="0"
///        ivex="1"
///        encthenmac="0"/>
///    </protocol>
///    <input name="nahdskdnac" stream="test1" prev="begin" write="vsmubmflmq">
///      <data width="1" len="44">
///         8FD8D2EC_4B637CB1_2B59B4DF_C50D5DA2
///         E8D169BD_0762A0E9_CD6BA43B_C90EAF87
///         E78ACA85_FE4B40EF_98AD9251
///      </data>
///    </input>
///    <output name="vsmubmflmq" stream="test1" len="109"/>
///    <expect name="qmripfhnmo" stream="test1" read="vsmubmflmq" status="0">
///      <data width="1" len="109">
///         17FFFE00_500CB3F4_DEFF6DFD_FEAABBCC
///         DDFFEEDD_CC001122_33445566_77D4199E
///         07F9B4C6_749D98D2_EA73A81A_1F39DE73
///         557849F4_5DA8480A_70AD9E93_1B25AF6D
///         5523F111_E821E61F_36D369C8_30A9A8CE
///         BE027F04_7C825383_1A177A2E_8F279575
///         B6D4EC0F_6D649AAA_038CA855_16
///      </data>
///    </expect>
///    <input name="lrmgetesdc" stream="test1" prev="nahdskdnac" write="jmivnieulm">
///      <data width="1" len="35">
///         A42933AE_5CC6C4ED_49B7E367_B837A204
///         0DA6C60B_B6040E27_921DA379_7FDE8843
///         F8DF3E
///      </data>
///    </input>
///    <output name="jmivnieulm" stream="test1" len="93"/>
///    <expect name="drqtlqemmf" stream="test1" read="jmivnieulm" status="0">
///      <data width="1" len="93">
///         17FFFE00_400CB3F4_DEFF6DFD_FFAABBCC
///         DDFFEEDD_CC001122_33445566_77F2297D
///         60F8AD09_07578912_A4263A5B_E899EB93
///         42629E24_22ED9B61_4C0C789D_96CCC43B
///         06C571B2_937EEE32_92D1DBBF_8926B254
///         0911F141_2E5377D7_6729B466_F3
///      </data>
///    </expect>
///    <input name="xbadryuyhd" stream="test1" prev="lrmgetesdc" write="qjwsjajebf">
///      <data width="1" len="5">
///         491F4ACD_60
///      </data>
///    </input>
///    <output name="qjwsjajebf" stream="test1" len="61"/>
///    <expect name="cafhfwghrk" stream="test1" read="qjwsjajebf" status="0">
///      <data width="1" len="61">
///         17FFFE00_200CB3F4_DEFF6DFE_00AABBCC
///         DDFFEEDD_CC001122_33445566_772AD038
///         5EB41522_EAF1BF81_0CC4D40B_E95758A5
///         D309BFB1_4D1654C1_7E2DAA51_CC
///      </data>
///    </expect>
///  </protocolpp>
///\endcode
///
///\subsection USEWASP Using W.A.S.P
///
/// To use W.A.S.P, you can use one of the three constructs to pass in the XML input. W.A.S.P will parse the input and either
/// 
/// * If the input is a PPP file and no output file is passed, will generate random descriptors and then run them
///
/// * If the input is a PPP file and output file is passed, will generate a output.protpp file
///
/// * In the input is PROTPP file, will run the parsed input
///
/// Usage : 
///
/// wasp mywasp(input, output, seed);
///
/// * input  - either a character string reprenting an XML file, a string representing a filename, or an XMLDocument
///
/// * output - a string representing a filename for the output
///
/// * seed   - seed for the random number generator to reproduce results
///
///\subsection WASPSCH W.A.S.P Supported Schema
///
/// The W.A.S.P parser and randomizer supports the following schema
///\code
///
///
///\class protocolpp protocolpp.xsd "schema/protocolpp.xsd"
///
///\section ProtocolPPSchema Protocol++&reg; (ProtocolPP&reg;) Configuration Schema
///
/// ProtocolPP&reg; (Protocol++&reg;) supports the following schema
///
///\code
///
/// <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
///     <xs:element name="protocolpp">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="general"  type="xs:string"/>
///                 <xs:element name="stream"   type="xs:string"/>
///                 <xs:element name="protocol" type="xs:string"/>
///                 <xs:element name="security" type="xs:string"/>
///                 <xs:element name="input"    type="xs:string"/>
///                 <xs:element name="output"   type="xs:string"/>
///                 <xs:element name="expect"   type="xs:string"/>
///                 <xs:element name="data"     type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="ver"    type="xs:string"/>
///             <xs:attribute name="format"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="ppp|protpp"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="general">
///         <xs:complexType>
///             <xs:attribute name="seed"    type="xs:unsignedLong"/>
///             <xs:attribute name="debugclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="infoclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="warnclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="fatalclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="passclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ptrsize">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:pattern value="8|16"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="sgtsize">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:pattern value="8|16"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="stream">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="protocol"  type="xs:string"/>
///                 <xs:element name="security"  type="xs:string"/>
///                 <xs:element name="input"     type="xs:string"/>
///                 <xs:element name="output"    type="xs:string"/>
///                 <xs:element name="expect"    type="xs:string"/>
///                 <xs:element name="data"      type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="name"    type="xs:string"/>
///             <xs:attribute name="number"  type="xs:string"/>
///             <xs:attribute name="packets" type="xs:string"/>
///             <xs:attribute name="datalen" type="xs:string"/>
///             <xs:attribute name="postproc">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="protocol">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="security"  type="xs:string"/>
///                 <xs:element name="protocol"  type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="prot">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="UDPP"/>
///                         <xs:enumeration value="TCPP"/>
///                         <xs:enumeration value="ICMP"/>
///                         <xs:enumeration value="IP"/>
///                         <xs:enumeration value="IPSEC"/>
///                         <xs:enumeration value="SRTP"/>
///                         <xs:enumeration value="MACSEC"/>
///                         <xs:enumeration value="WIFI"/>
///                         <xs:enumeration value="WIGIG"/>
///                         <xs:enumeration value="WIMAX"/>
///                         <xs:enumeration value="LTE"/>
///                         <xs:enumeration value="RLC"/>
///                         <xs:enumeration value="INTEGRITY"/>
///                         <xs:enumeration value="CONFIDENT"/>
///                         <xs:enumeration value="BLOB"/>
///                         <xs:enumeration value="XMSS"/>
///                         <xs:enumeration value="LMS"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="dir">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="ENCAP"/>
///                         <xs:enumeration value="DECAP"/>
///                         <xs:enumeration value="ENC"/>
///                         <xs:enumeration value="DEC"/>
///                         <xs:enumeration value="UPLINK"/>
///                         <xs:enumeration value="DOWNLINK"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="replay">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="NORMAL"/>
///                         <xs:enumeration value="SHIFT"/>
///                         <xs:enumeration value="WINDOW"/>
///                         <xs:enumeration value="REPLAY"/>
///                         <xs:enumeration value="LATE"/>
///                         <xs:enumeration value="ROLLOVER"/>
///                         <xs:enumeration value="ROLLUNDER"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="file"    type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="security">
///         <xs:complexType>
///             <xs:attribute name="name"    type="xs:string"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:string value="udpsa"/>
///                         <xs:string value="tcpsa"/>
///                         <xs:string value="ipsa"/>
///                         <xs:string value="icmpsa"/>
///                         <xs:string value="tlsa"/>
///                         <xs:string value="macsecsa"/>
///                         <xs:string value="ltesa"/>
///                         <xs:string value="srtpsa"/>
///                         <xs:string value="wifisa"/>
///                         <xs:string value="wimaxsa"/>
///                         <xs:string value="rsasa"/>
///                         <xs:string value="dsasa"/>
///                         <xs:string value="ecdsaedsa"/>
///                         <xs:string value="ecdsafpsa"/>
///                         <xs:string value="ecdsaf2msa"/>
///                         <xs:string value="integritysa"/>
///                         <xs:string value="confidentsa"/>
///                         <xs:string value="memblobsa"/>
///                         <xs:string value="xmssa"/>
///                         <xs:string value="lmsa"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             <xs:attribute name="dir">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="ENCAP"/>
///                         <xs:enumeration value="DECAP"/>
///                         <xs:enumeration value="ENC"/>
///                         <xs:enumeration value="DEC"/>
///                         <xs:enumeration value="UPLINK"/>
///                         <xs:enumeration value="DOWNLINK"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="cipher">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="NULL_CIPHER"/>
///                         <xs:enumeration value="DES_ECB"/>
///                         <xs:enumeration value="DES_CBC"/>
///                         <xs:enumeration value="TDES_ECB"/>
///                         <xs:enumeration value="TDES_CBC"/>
///                         <xs:enumeration value="AES_ECB"/>
///                         <xs:enumeration value="AES_CBC"/>
///                         <xs:enumeration value="AES_CTR"/>
///                         <xs:enumeration value="AES_CCM"/>
///                         <xs:enumeration value="AES_GCM"/>
///                         <xs:enumeration value="CHACHA20"/>
///                         <xs:enumeration value="CHACHA20_POLY1305"/>
///                         <xs:enumeration value="CAMELLIA_ECB"/>
///                         <xs:enumeration value="CAMELLIA_CBC"/>
///                         <xs:enumeration value="CAMELLIA_CTR"/>
///                         <xs:enumeration value="CAMELLIA_CCM"/>
///                         <xs:enumeration value="CAMELLIA_GCM"/>
///                         <xs:enumeration value="ARIA_ECB"/>
///                         <xs:enumeration value="ARIA_CBC"/>
///                         <xs:enumeration value="ARIA_CTR"/>
///                         <xs:enumeration value="ARIA_GCM"/>
///                         <xs:enumeration value="SEED_ECB"/>
///                         <xs:enumeration value="SEED_CBC"/>
///                         <xs:enumeration value="SEED_CTR"/>
///                         <xs:enumeration value="SEED_GCM"/>
///                         <xs:enumeration value="SM4_ECB"/>
///                         <xs:enumeration value="SM4_CBC"/>
///                         <xs:enumeration value="SM4_CTR"/>
///                         <xs:enumeration value="SM4_GCM"/>
///                         <xs:enumeration value="SM4_CCM"/>
///                         <xs:enumeration value="ARC4"/>
///                         <xs:enumeration value="SNOWE"/>
///                         <xs:enumeration value="ZUCE"/>
///                         <xs:enumeration value="NONE_ENC"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="auth">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="NULL_AUTH"/>
///                         <xs:enumeration value="MD5"/>
///                         <xs:enumeration value="SHA1"/>
///                         <xs:enumeration value="SHA224"/>
///                         <xs:enumeration value="SHA256"/>
///                         <xs:enumeration value="SHA384"/>
///                         <xs:enumeration value="SHA512"/>
///                         <xs:enumeration value="SHA3_224"/>
///                         <xs:enumeration value="SHA3_256"/>
///                         <xs:enumeration value="SHA3_384"/>
///                         <xs:enumeration value="SHA3_512"/>
///                         <xs:enumeration value="AES_XCBC_MAC"/>
///                         <xs:enumeration value="POLY1305"/>
///                         <xs:enumeration value="AES_CMAC"/>
///                         <xs:enumeration value="AES_GMAC"/>
///                         <xs:enumeration value="SM3"/>
///                         <xs:enumeration value="SNOWA"/>
///                         <xs:enumeration value="ZUCA"/>
///                         <xs:enumeration value="CRC5"/>
///                         <xs:enumeration value="CRC7"/>
///                         <xs:enumeration value="CRC8"/>
///                         <xs:enumeration value="CRC11"/>
///                         <xs:enumeration value="CRC12"/>
///                         <xs:enumeration value="CRC16"/>
///                         <xs:enumeration value="CRC16_CCITT"/>
///                         <xs:enumeration value="CRC24"/>
///                         <xs:enumeration value="CRC32_IETF"/>
///                         <xs:enumeration value="CRC32_IEEE"/>
///                         <xs:enumeration value="XMSS_SHA2_10_256"/>
///                         <xs:enumeration value="XMSS_SHA2_16_256"/>
///                         <xs:enumeration value="XMSS_SHA2_20_256"/>
///                         <xs:enumeration value="XMSS_SHA2_10_512"/>
///                         <xs:enumeration value="XMSS_SHA2_16_512"/>
///                         <xs:enumeration value="XMSS_SHA2_20_512"/>
///                         <xs:enumeration value="XMSS_SHAKE_10_256"/>
///                         <xs:enumeration value="XMSS_SHAKE_16_256"/>
///                         <xs:enumeration value="XMSS_SHAKE_20_256"/>
///                         <xs:enumeration value="XMSS_SHAKE_10_512"/>
///                         <xs:enumeration value="XMSS_SHAKE_16_512"/>
///                         <xs:enumeration value="XMSS_SHAKE_20_512"/>
///                         <xs:enumeration value="LMS_SHA256_M32_H5"/>
///                         <xs:enumeration value="LMS_SHA256_M32_H10"/>
///                         <xs:enumeration value="LMS_SHA256_M32_H15"/>
///                         <xs:enumeration value="LMS_SHA256_M32_H20"/>
///                         <xs:enumeration value="LMS_SHA256_M32_H25"/>
///                         <xs:enumeration value="NONE_AUTH"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ivlen"   type="xs:unsignedInt"/>
///             <xs:attribute name="ckeylen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:pattern value="0|8|16|24|32"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="akeylen"    type="xs:unsignedInt"/>
///             <xs:attribute name="polynomial" type="xs:unsignedInt"/>
///             <xs:attribute name="icvlen"     type="xs:unsignedInt"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="64"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="blobkeylen"     type="xs:unsignedInt"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="64"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="bkeklen"     type="xs:unsignedInt"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="64"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="seqnum"    type="xs:unsignedLong"/>
///             <xs:attribute name="extseqnum" type="xs:unsignedLong"/>
///             <xs:attribute name="arlen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedLong">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="2048"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="arwin"     type="xs:string"/>
///             <xs:attribute name="cipherkey" type="xs:string"/>
///             <xs:attribute name="authkey"   type="xs:string"/>
///             <xs:attribute name="iv"        type="xs:string"/>
///             <xs:attribute name="usext">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="jumbogram">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="zeroinit">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="swapin">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="swapout">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="compout">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="msg">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="ECHORPLYMSG"/>
///                         <xs:enumeration value="RSVD1"/>
///                         <xs:enumeration value="RSVD2"/>
///                         <xs:enumeration value="DESTUNRCH"/>
///                         <xs:enumeration value="SRCQNCH"/>
///                         <xs:enumeration value="RDIRMSG"/>
///                         <xs:enumeration value="ALTHOST"/>
///                         <xs:enumeration value="RSVD"/>
///                         <xs:enumeration value="ECHORQST"/>
///                         <xs:enumeration value="RTRADVERT"/>
///                         <xs:enumeration value="RTRSOLCIT"/>
///                         <xs:enumeration value="TIMEXCEED"/>
///                         <xs:enumeration value="BADIPHDR"/>
///                         <xs:enumeration value="TIMESTMP"/>
///                         <xs:enumeration value="TIMERPLY"/>
///                         <xs:enumeration value="INFORQST"/>
///                         <xs:enumeration value="INFORPLY"/>
///                         <xs:enumeration value="ADMSKRQST"/>
///                         <xs:enumeration value="ADMSKRPLY"/>
///                         <xs:enumeration value="TRACERTE"/>
///                         <xs:enumeration value="NODEST"/>
///                         <xs:enumeration value="PKTBIG"/>
///                         <xs:enumeration value="TIMEOUT"/>
///                         <xs:enumeration value="PARAM"/>
///                         <xs:enumeration value="PRVTE1"/>
///                         <xs:enumeration value="PRVTE2"/>
///                         <xs:enumeration value="RSVDE"/>
///                         <xs:enumeration value="ECHORQSTV6"/>
///                         <xs:enumeration value="ECHORPLYV6"/>
///                         <xs:enumeration value="PRVTI1"/>
///                         <xs:enumeration value="PRVTI2"/>
///                         <xs:enumeration value="RSVDI"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="code">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="ECHORPLY"/>
///                         <xs:enumeration value="NONETWRK"/>
///                         <xs:enumeration value="NOHOST"/>
///                         <xs:enumeration value="NOPROT"/>
///                         <xs:enumeration value="NOPORT"/>
///                         <xs:enumeration value="FRAGRQD"/>
///                         <xs:enumeration value="RTEFAIL"/>
///                         <xs:enumeration value="DSTUNKNWN"/>
///                         <xs:enumeration value="DSTHSTUNKNWN"/>
///                         <xs:enumeration value="SRCHSTISOLT"/>
///                         <xs:enumeration value="NETWKPROHIB"/>
///                         <xs:enumeration value="HOSTPROHIB"/>
///                         <xs:enumeration value="NETWKNOTOS"/>
///                         <xs:enumeration value="HOSTNOTOS"/>
///                         <xs:enumeration value="COMMPROHIB"/>
///                         <xs:enumeration value="HOSTVILATE"/>
///                         <xs:enumeration value="CUTOFF"/>
///                         <xs:enumeration value="REDIRNETWK"/>
///                         <xs:enumeration value="REDIRHOST"/>
///                         <xs:enumeration value="REDIRTOSN"/>
///                         <xs:enumeration value="REDIRTOSH"/>
///                         <xs:enumeration value="TTLEXPIRE"/>
///                         <xs:enumeration value="FRAGEXPIRE"/>
///                         <xs:enumeration value="PTRINDERR"/>
///                         <xs:enumeration value="OPTERR"/>
///                         <xs:enumeration value="BADLENGTH"/>
///                         <xs:enumeration value="NOROUTE"/>
///                         <xs:enumeration value="COMMPROHIBV6"/>
///                         <xs:enumeration value="BYNDSRCADDR"/>
///                         <xs:enumeration value="ADDRUNREACH"/>
///                         <xs:enumeration value="PORTUNREACH"/>
///                         <xs:enumeration value="SRCADDRPLCY"/>
///                         <xs:enumeration value="REJECTDST"/>
///                         <xs:enumeration value="HOPLMTEXCD"/>
///                         <xs:enumeration value="FRAGTIME"/>
///                         <xs:enumeration value="ERRHDRFIELD"/>
///                         <xs:enumeration value="NXTHDRERR"/>
///                         <xs:enumeration value="IPV6OPTERR"/>
///                         <xs:enumeration value="SEQNUMRST"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="src"     type="xs:string"/>
///             <xs:attribute name="dst"     type="xs:string"/>
///             <xs:attribute name="state">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="LISTEN"/>
///                         <xs:enumeration value="SYN_SENT"/>
///                         <xs:enumeration value="SYN_RCVD"/>
///                         <xs:enumeration value="ESTABLISHED"/>
///                         <xs:enumeration value="FIN_WAIT_1"/>
///                         <xs:enumeration value="FIN_WAIT_2"/>
///                         <xs:enumeration value="CLOSE_WAIT"/>
///                         <xs:enumeration value="LAST_ACK"/>
///                         <xs:enumeration value="TIME_WAIT"/>
///                         <xs:enumeration value="CLOSED"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="mtu"     type="xs:unsignedInt"/>
///             <xs:attribute name="acknum"  type="xs:unsignedInt"/>
///             <xs:attribute name="version" type="xs:string"/>
///             <xs:attribute name="nh">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="LISTEN"/>
///                         <xs:enumeration value="HOPOPT"/>
///                         <xs:enumeration value="ICMP"/>
///                         <xs:enumeration value="IGMP"/>
///                         <xs:enumeration value="GGP"/>
///                         <xs:enumeration value="IPV4"/>
///                         <xs:enumeration value="ST"/>
///                         <xs:enumeration value="TCP"/>
///                         <xs:enumeration value="CBT"/>
///                         <xs:enumeration value="EGP"/>
///                         <xs:enumeration value="IGP"/>
///                         <xs:enumeration value="BBN_RCC_MON"/>
///                         <xs:enumeration value="NVP_II"/>
///                         <xs:enumeration value="PUP"/>
///                         <xs:enumeration value="ARGUS"/>
///                         <xs:enumeration value="EMCON"/>
///                         <xs:enumeration value="XNET"/>
///                         <xs:enumeration value="CHAOS"/>
///                         <xs:enumeration value="UDP"/>
///                         <xs:enumeration value="MUX"/>
///                         <xs:enumeration value="DCN_MEAS"/>
///                         <xs:enumeration value="HMP"/>
///                         <xs:enumeration value="PRM"/>
///                         <xs:enumeration value="XNS_IDP"/>
///                         <xs:enumeration value="TRUNK_1"/>
///                         <xs:enumeration value="TRUNK_2"/>
///                         <xs:enumeration value="LEAF_1"/>
///                         <xs:enumeration value="LEAF_2"/>
///                         <xs:enumeration value="RDP"/>
///                         <xs:enumeration value="IRTP"/>
///                         <xs:enumeration value="ISO_TP4"/>
///                         <xs:enumeration value="NETBLT"/>
///                         <xs:enumeration value="MFE_NSP"/>
///                         <xs:enumeration value="MERIT_INP"/>
///                         <xs:enumeration value="DCCP"/>
///                         <xs:enumeration value="THREE_PC"/>
///                         <xs:enumeration value="IDPR"/>
///                         <xs:enumeration value="XTP"/>
///                         <xs:enumeration value="DDP"/>
///                         <xs:enumeration value="IDPR_CMTP"/>
///                         <xs:enumeration value="TP_PLUS"/>
///                         <xs:enumeration value="IL"/>
///                         <xs:enumeration value="IPV6"/>
///                         <xs:enumeration value="SDRP"/>
///                         <xs:enumeration value="IPV6_ROUTE"/>
///                         <xs:enumeration value="IPV6_FRAG"/>
///                         <xs:enumeration value="IDRP"/>
///                         <xs:enumeration value="RSVP"/>
///                         <xs:enumeration value="GRE"/>
///                         <xs:enumeration value="DSR"/>
///                         <xs:enumeration value="BNA"/>
///                         <xs:enumeration value="ESP"/>
///                         <xs:enumeration value="AH"/>
///                         <xs:enumeration value="I_NLSP"/>
///                         <xs:enumeration value="SWIPE"/>
///                         <xs:enumeration value="NARP"/>
///                         <xs:enumeration value="MOBILE"/>
///                         <xs:enumeration value="TLSP"/>
///                         <xs:enumeration value="SKIP"/>
///                         <xs:enumeration value="ICMPV6"/>
///                         <xs:enumeration value="IPV6_NONXT"/>
///                         <xs:enumeration value="IPV6_OPTS"/>
///                         <xs:enumeration value="HOST_INT_PROT"/>
///                         <xs:enumeration value="CFTP"/>
///                         <xs:enumeration value="LOCAL_NET"/>
///                         <xs:enumeration value="SAT_EXPAK"/>
///                         <xs:enumeration value="KRYPTOLAN"/>
///                         <xs:enumeration value="RVD"/>
///                         <xs:enumeration value="IPPC"/>
///                         <xs:enumeration value="DFS"/>
///                         <xs:enumeration value="SAT_MON"/>
///                         <xs:enumeration value="VISA"/>
///                         <xs:enumeration value="IPCV"/>
///                         <xs:enumeration value="CPNX"/>
///                         <xs:enumeration value="CPHB"/>
///                         <xs:enumeration value="WSN"/>
///                         <xs:enumeration value="PVP"/>
///                         <xs:enumeration value="BR_SAT_MON"/>
///                         <xs:enumeration value="SUN_ND"/>
///                         <xs:enumeration value="WB_MON"/>
///                         <xs:enumeration value="WB_EXPAK"/>
///                         <xs:enumeration value="ISO_IP"/>
///                         <xs:enumeration value="VMTP"/>
///                         <xs:enumeration value="SECURE_VMTP"/>
///                         <xs:enumeration value="VINES"/>
///                         <xs:enumeration value="TTP"/>
///                         <xs:enumeration value="IPTM"/>
///                         <xs:enumeration value="NSFNET_IGP"/>
///                         <xs:enumeration value="DGP"/>
///                         <xs:enumeration value="TCF"/>
///                         <xs:enumeration value="EIGRP"/>
///                         <xs:enumeration value="OSPFIGP"/>
///                         <xs:enumeration value="SPRITE_RPC"/>
///                         <xs:enumeration value="LARP"/>
///                         <xs:enumeration value="MTP"/>
///                         <xs:enumeration value="AX_25"/>
///                         <xs:enumeration value="MICP"/>
///                         <xs:enumeration value="SCC_SP"/>
///                         <xs:enumeration value="ETHERIP"/>
///                         <xs:enumeration value="IENCAP"/>
///                         <xs:enumeration value="PRIV_ENCRYPT"/>
///                         <xs:enumeration value="GMTP"/>
///                         <xs:enumeration value="IFMP"/>
///                         <xs:enumeration value="PNNI"/>
///                         <xs:enumeration value="PIM"/>
///                         <xs:enumeration value="ARIS"/>
///                         <xs:enumeration value="SCPS"/>
///                         <xs:enumeration value="QNX"/>
///                         <xs:enumeration value="A_N"/>
///                         <xs:enumeration value="IPCOMP"/>
///                         <xs:enumeration value="SNP"/>
///                         <xs:enumeration value="COMPAQ_PEER"/>
///                         <xs:enumeration value="IPX_IN_IP"/>
///                         <xs:enumeration value="VRRP"/>
///                         <xs:enumeration value="PGM"/>
///                         <xs:enumeration value="ZERO_HOP_PROT"/>
///                         <xs:enumeration value="L2TP"/>
///                         <xs:enumeration value="DDX"/>
///                         <xs:enumeration value="IATP"/>
///                         <xs:enumeration value="STP"/>
///                         <xs:enumeration value="SRP"/>
///                         <xs:enumeration value="UTI"/>
///                         <xs:enumeration value="SMP"/>
///                         <xs:enumeration value="SM"/>
///                         <xs:enumeration value="PTP"/>
///                         <xs:enumeration value="ISIS_OVER_IPV4"/>
///                         <xs:enumeration value="FIRE"/>
///                         <xs:enumeration value="CRTP"/>
///                         <xs:enumeration value="CRUDP"/>
///                         <xs:enumeration value="SSCOPMCE"/>
///                         <xs:enumeration value="IPLT"/>
///                         <xs:enumeration value="SPS"/>
///                         <xs:enumeration value="PIPE"/>
///                         <xs:enumeration value="SCTP"/>
///                         <xs:enumeration value="FC"/>
///                         <xs:enumeration value="RSVP_E2E_IGNORE"/>
///                         <xs:enumeration value="MOBILITY_HEADER"/>
///                         <xs:enumeration value="UDPLITE"/>
///                         <xs:enumeration value="MPLS_IN_IP"/>
///                         <xs:enumeration value="MANET"/>
///                         <xs:enumeration value="HIP"/>
///                         <xs:enumeration value="SHIM6"/>
///                         <xs:enumeration value="WESP"/>
///                         <xs:enumeration value="ROHC"/>
///                         <xs:enumeration value="JUMBOGRAM"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="dsecn"      type="xs:unsignedByte"/>
///             <xs:attribute name="flags"      type="xs:unsignedByte"/>
///             <xs:attribute name="doffset"    type="xs:unsignedByte"/>
///             <xs:attribute name="window"     type="xs:unsignedShort"/>
///             <xs:attribute name="urgpointer" type="xs:unsignedShort"/>
///             <xs:attribute name="timeout"    type="xs:unsignedInt"/>
///             <xs:attribute name="ttl">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedByte">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="255"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="wimaxmode">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="OFDM"/>
///                         <xs:enumeration value="OFDMA"/>
///                         <xs:enumeration value="AGMH_OFDM"/>
///                         <xs:enumeration value="AGMH_OFDMA"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="macsecmode">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="AES_GCM_128"/>
///                         <xs:enumeration value="AES_GCM_256"/>
///                         <xs:enumeration value="AES_GCM_XPN_128"/>
///                         <xs:enumeration value="AES_GCM_XPN_256"/>
///                         <xs:enumeration value="NULL_MACSEC"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="srtpcipher">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="NULL_SRTP"/>
///                         <xs:enumeration value="AES_CTR_SHA1"/>
///                         <xs:enumeration value="AEAD_AES_128_GCM"/>
///                         <xs:enumeration value="AEAD_AES_256_GCM"/>
///                         <xs:enumeration value="AEAD_AES_128_GCM_8"/>
///                         <xs:enumeration value="AEAD_AES_256_GCM_8"/>
///                         <xs:enumeration value="AEAD_AES_128_GCM_12"/>
///                         <xs:enumeration value="AEAD_AES_256_GCM_12"/>
///                         <xs:enumeration value="AEAD_AES_128_CCM"/>
///                         <xs:enumeration value="AEAD_AES_256_CCM"/>
///                         <xs:enumeration value="AEAD_AES_128_CCM_8"/>
///                         <xs:enumeration value="AEAD_AES_256_CCM_8"/>
///                         <xs:enumeration value="AEAD_AES_128_CCM_12"/>
///                         <xs:enumeration value="AEAD_AES_256_CCM_12"/>
///                         <xs:enumeration value="ARIA_128_CTR_HMAC_SHA1_80"/>
///                         <xs:enumeration value="ARIA_128_CTR_HMAC_SHA1_32"/>
///                         <xs:enumeration value="ARIA_192_CTR_HMAC_SHA1_80"/>
///                         <xs:enumeration value="ARIA_192_CTR_HMAC_SHA1_32"/>
///                         <xs:enumeration value="ARIA_256_CTR_HMAC_SHA1_80"/>
///                         <xs:enumeration value="ARIA_256_CTR_HMAC_SHA1_32"/>
///                         <xs:enumeration value="AEAD_ARIA_128_GCM"/>
///                         <xs:enumeration value="AEAD_ARIA_256_GCM"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="id"      type="xs:unsignedShort"/>
///             <xs:attribute name="label"   type="xs:unsignedInt"/>
///             <xs:attribute name="mode"    type="xs:string"/>
///             <xs:attribute name="spi"     type="xs:unsignedInt"/>
///             <xs:attribute name="bytecnt" type="xs:unsignedLong"/>
///             <xs:attribute name="lifetime" type="xs:unsignedLong"/>
///             <xs:attribute name="seqnumovrflw">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="statefulfrag">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="bypassdf">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="bypassdscp">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="nat">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="nchk">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="natsrc">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedShort">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="65535"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="natdst">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedShort">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="65535"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="fragoff" type="xs:unsignedShort"/>
///             <xs:attribute name="hdrlen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="4096"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="tfclen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="512"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="randiv">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="audit">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="auditlog" type="xs:string"/>
///             <xs:attribute name="sci"     type="xs:unsignedLong"/>
///             <xs:attribute name="pn"      type="xs:unsignedInt"/>
///             <xs:attribute name="xpn"     type="xs:unsignedInt"/>
///             <xs:attribute name="ethtype" type="xs:unsignedShort"/>
///             <xs:attribute name="tcian"   type="xs:unsignedByte"/>
///             <xs:attribute name="sl"      type="xs:unsignedByte"/>
///             <xs:attribute name="roc"     type="xs:unsignedInt"/>
///             <xs:attribute name="ssrc"    type="xs:unsignedInt"/>
///             <xs:attribute name="ver"     type="xs:unsignedInt"/>
///             <xs:attribute name="type"    type="xs:unsignedInt"/>
///             <xs:attribute name="pad">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ext">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="marker">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="mki">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="mkilen"  type="xs:unsignedInt"/>
///             <xs:attribute name="saltlen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedInt">
///                         <xs:minInclusive value="3"/>
///                         <xs:maxInclusive value="4"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="salt"    type="xs:string"/>
///             <xs:attribute name="mkidata" type="xs:string"/>
///             <xs:attribute name="csrc"    type="xs:string"/>
///             <xs:attribute name="ctlext">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="SSW"/>
///                         <xs:enumeration value="GRANT"/>
///                         <xs:enumeration value="POLL"/>
///                         <xs:enumeration value="SSWACK"/>
///                         <xs:enumeration value="DMGDTS"/>
///                         <xs:enumeration value="SSWFDBCK"/>
///                         <xs:enumeration value="DMGCTS"/>
///                         <xs:enumeration value="SPR"/>
///                         <xs:enumeration value="GRANTACK"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="sppcap">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="tlsver">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="SSL30"/>
///                         <xs:enumeration value="TLS10"/>
///                         <xs:enumeration value="TLS11"/>
///                         <xs:enumeration value="TLS12"/>
///                         <xs:enumeration value="DTLS"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="tlstype">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="CHG_CIPHER_SPEC"/>
///                         <xs:enumeration value="ALERT"/>
///                         <xs:enumeration value="HANDSHAKE"/>
///                         <xs:enumeration value="APPLICATION"/>
///                         <xs:enumeration value="HEARTBEAT"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ciphersuite">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="TLS_NULL_WITH_NULL_NULL"/>
///                         <xs:enumeration value="TLS_RSA_WITH_NULL_MD5"/>
///                         <xs:enumeration value="TLS_RSA_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_RSA_EXPORT_WITH_RC4_40_MD5"/>
///                         <xs:enumeration value="TLS_RSA_WITH_RC4_128_MD5"/>
///                         <xs:enumeration value="TLS_RSA_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_RSA_EXPORT_WITH_DES40_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_EXPORT_WITH_RC4_40_MD5"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_RC4_128_MD5"/>
///                         <xs:enumeration value="TLS_DH_ANON_EXPORT_WITH_DES40_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_KRB5_WITH_DES_CBC_SHA"/>
///                         <xs:enumeration value="TLS_KRB5_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_KRB5_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_KRB5_WITH_DES_CBC_MD5"/>
///                         <xs:enumeration value="TLS_KRB5_WITH_3DES_EDE_CBC_MD5"/>
///                         <xs:enumeration value="TLS_KRB5_WITH_RC4_128_MD5"/>
///                         <xs:enumeration value="TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA"/>
///                         <xs:enumeration value="TLS_KRB5_EXPORT_WITH_RC4_40_SHA"/>
///                         <xs:enumeration value="TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5"/>
///                         <xs:enumeration value="TLS_KRB5_EXPORT_WITH_RC4_40_MD5"/>
///                         <xs:enumeration value="TLS_PSK_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_NULL_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_CAMELLIA_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_AES_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_AES_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_AES_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_AES_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_CAMELLIA_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_PSK_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_PSK_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_SEED_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_SEED_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_SEED_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_SEED_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_SEED_CBC_SHA"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_SEED_CBC_SHA"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_NULL_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_NULL_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_NULL_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_NULL_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_NULL_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_NULL_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_CAMELLIA_256_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ANON_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ANON_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ANON_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ANON_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDH_ANON_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_RC4_128_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_NULL_SHA"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_NULL_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_NULL_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DH_ANON_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384"/>
///                         <xs:enumeration value="TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_128_CCM"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_256_CCM"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_128_CCM"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_256_CCM"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_128_CCM_8"/>
///                         <xs:enumeration value="TLS_RSA_WITH_AES_256_CCM_8"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_128_CCM_8"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_AES_256_CCM_8"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_128_CCM"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_256_CCM"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_128_CCM"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_AES_256_CCM"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_128_CCM_8"/>
///                         <xs:enumeration value="TLS_PSK_WITH_AES_256_CCM_8"/>
///                         <xs:enumeration value="TLS_PSK_DHE_WITH_AES_128_CCM_8"/>
///                         <xs:enumeration value="TLS_PSK_DHE_WITH_AES_256_CCM_8"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_128_CCM"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_256_CCM"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8"/>
///                         <xs:enumeration value="TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256"/>
///                         <xs:enumeration value="TLS_PSK_WITH_CHACHA20_POLY1305_SHA256"/>
///                         <xs:enumeration value="TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256"/>
///                         <xs:enumeration value="TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256"/>
///                         <xs:enumeration value="TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="epoch"   type="xs:unsignedShort"/>
///             <xs:attribute name="ivex">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="encthenmac">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="addr1"   type="xs:unsignedLong"/>
///             <xs:attribute name="addr2"   type="xs:unsignedLong"/>
///             <xs:attribute name="addr3"   type="xs:unsignedLong"/>
///             <xs:attribute name="addr4"   type="xs:unsignedLong"/>
///             <xs:attribute name="framctl" type="xs:unsignedShort"/>
///             <xs:attribute name="seqctl"  type="xs:unsignedShort"/>
///             <xs:attribute name="qosctl"  type="xs:unsignedShort"/>
///             <xs:attribute name="htctl"   type="xs:unsignedInt"/>
///             <xs:attribute name="keyid"   type="xs:unsignedByte"/>
///             <xs:attribute name="extiv">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="fcs">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="eks"     type="xs:unsignedByte"/>
///             <xs:attribute name="fid"     type="xs:unsignedByte"/>
///             <xs:attribute name="cid"     type="xs:unsignedShort"/>
///             <xs:attribute name="eh">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ht">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ec">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="esf">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ci">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="datctrl">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="pdutype"   type="xs:unsignedByte"/>
///             <xs:attribute name="poll">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="rsn">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="snlen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:integer">
///                         <xs:pattern value="5|7|12|15|16|18"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="hdrext"    type="xs:unsignedByte"/>
///             <xs:attribute name="lenind"    type="xs:unsignedShort"/>
///             <xs:attribute name="hfni"      type="xs:unsignedInt"/>
///             <xs:attribute name="sufi"      type="xs:unsignedInt"/>
///             <xs:attribute name="fms"       type="xs:unsignedInt"/>
///             <xs:attribute name="pgkindex"  type="xs:unsignedByte"/>
///             <xs:attribute name="ptkident"  type="xs:unsignedShort"/>
///             <xs:attribute name="sdutype"   type="xs:unsignedByte"/>
///             <xs:attribute name="kdid"      type="xs:unsignedShort"/>
///             <xs:attribute name="nmp"       type="xs:unsignedInt"/>
///             <xs:attribute name="hrw"       type="xs:unsignedInt"/>
///             <xs:attribute name="bearer"    type="xs:unsignedByte"/>
///             <xs:attribute name="fresh"     type="xs:unsignedInt"/>
///             <xs:attribute name="bitmaplen" type="xs:unsignedInt"/>
///             <xs:attribute name="bitmap"    type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="input">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="data"     type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="name"   type="xs:string"/>
///             <xs:attribute name="stream" type="xs:string"/>
///             <xs:attribute name="prev"   type="xs:string"/>
///             <xs:attribute name="write"  type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="output">
///         <xs:complexType>
///             <xs:attribute name="name"   type="xs:string"/>
///             <xs:attribute name="stream" type="xs:string"/>
///             <xs:attribute name="len"    type="xs:integer"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="expect">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="data"     type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="name"   type="xs:string"/>
///             <xs:attribute name="stream" type="xs:string"/>
///             <xs:attribute name="read"   type="xs:string"/>
///             <xs:attribute name="status" type="xs:unsignedInt"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="data">
///         <xs:complexType>
///             <xs:attribute name="width" type="xs:integer"/>
///             <xs:attribute name="len"   type="xs:integer"/>
///         </xs:complexType>
///     </xs:element>
/// </xs:schema>
///\endcode
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jdata
/// @see ProtocolPP::jpacket
/// @see ProtocolPP::jstream
/// @see ProtocolPP::jprotocolpp
/// @see ProtocolPP::wasp
/// @see tinyxml2::XMLPrinter
/// @see tinyxml2::XMLVisitor
///
/// <B>For Additional Documentation:</B>
/// @see jdata
/// @see jpacket
/// @see jstream
/// @see jprotocolpp
/// @see wasp
/// @see tinyxml2::XMLPrinter
/// @see tinyxml2::XMLVisitor
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#define DEBUG_PROTPP
#include <ctime>
#include <sys/types.h>
#if defined(_MSC_VER)
#include <io.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#endif
#include <exception>
#include "oids.h"
#include "jlogger.h"
#include "jrand.h"
#include "tinyxml2.h"
#include "jdata.h"
#include "jpacket.h"
#include "jstream.h"
#include "jtestcfg.h"
#include "jprotocolpp.h"

namespace ProtocolPP {

class wasp : public tinyxml2::XMLPrinter, public std::exception {

public:

    //////////////////////////////////////////////////////////////////////
    /// W.A.S.P is an interface to Protocol++&reg; that allows the generation
    /// of random descriptors and the ability to drive them into a
    /// testbench
    ///
    /// @param input  - XML data represented in a character string
    /// @param out    - Filename to write XML output to.  If not provided
    ///                 data is written to memory
    /// @param seed   - default seed for random data (set to time, pass in hardware seed)
    //////////////////////////////////////////////////////////////////////
    explicit wasp(const char* input,
                  const char* out=nullptr,
                  unsigned long seed=static_cast<unsigned long>(time(nullptr)));

    //////////////////////////////////////////////////////////////////////
    /// W.A.S.P is an interface to Protocol++&reg; that allows the generation
    /// of random descriptors and the ability to drive them into a
    /// testbench
    ///
    /// @param input  - Filename of an XML data file to load
    /// @param out    - Filename to write XML output to.  If not provided
    ///                 data is written to memory
    /// @param seed   - default seed for random data (set to time, pass in hardware seed)
    //////////////////////////////////////////////////////////////////////
    explicit wasp(std::string& input,
                  const char* out=nullptr,
                  unsigned long seed=static_cast<unsigned long>(time(nullptr)));

    //////////////////////////////////////////////////////////////////////
    /// W.A.S.P is an interface to Protocol++&reg; that allows the generation
    /// of random descriptors and the ability to drive them into a
    /// testbench
    ///
    /// @param input  - XML document to load
    /// @param out    - Filename to write XML output to.  If not provided
    ///                 data is written to memory
    /// @param seed   - default seed for random data (set to time, pass in hardware seed)
    /// @see tinyxml2
    //////////////////////////////////////////////////////////////////////
    explicit wasp(std::shared_ptr<tinyxml2::XMLDocument>& input,
                  const char* out=nullptr,
                  unsigned long seed=static_cast<unsigned long>(time(nullptr)));

    //////////////////////////////////////////////////////////////////////
    /// W.A.S.P standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~wasp() {}

    //////////////////////////////////////////////////////////////////////
    /// @return - shared pointer to JDATA object
    //////////////////////////////////////////////////////////////////////
    void get(std::shared_ptr<jdata>& data);

private:

    // don't use these
    wasp() = delete;
    wasp(wasp& rhs) = delete;
    wasp(const wasp& rhs) = delete;

    // state of operation for W.A.S.P
    enum mode_t {
        GENOUT,
        RANDOM,
        READ,
    };

    // initialize routine
    void init();

    // create the protocol engine
    void engine(const tinyxml2::XMLElement* prot, const tinyxml2::XMLElement* elem);
    
    // generate descriptors
    void gen();

    /// Visit an element
    bool VisitEnter(const tinyxml2::XMLElement& element, const tinyxml2::XMLAttribute* attribute);
   
    /// Exit the element
    bool VisitExit(const tinyxml2::XMLElement& element);

    /// Visit the XMLText
    bool Visit(const tinyxml2::XMLText& text);

    // uppercase the input string
    std::string upper(const char* input);

    // member variables
    mode_t m_mode;
    uint32_t m_status;
    std::string m_packets;
    unsigned int m_total_packets;
    unsigned int m_errors;
    unsigned long m_seed;
    unsigned int m_ptr;
    unsigned int m_sgt;
    InterfacePP::jlogger::asciicolor m_debugclr;
    InterfacePP::jlogger::asciicolor m_infoclr;
    InterfacePP::jlogger::asciicolor m_warnclr;
    InterfacePP::jlogger::asciicolor m_errclr;
    InterfacePP::jlogger::asciicolor m_fatalclr;
    InterfacePP::jlogger::asciicolor m_passclr;
    std::string m_stream;
    std::string m_flowcnt;
    std::string m_datalen;
    tinyxml2::XMLError m_err;
    std::shared_ptr<jrand> m_rand;
    std::map<std::string, std::shared_ptr<jstream>> m_flows;
    std::map<std::string, std::list<std::shared_ptr<jpacket>>> m_pkts;
    std::shared_ptr<tinyxml2::XMLDocument> m_doc;
};

}

#endif /* WASP_H_ */
