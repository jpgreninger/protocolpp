#ifndef JLICENSE_H
#define JLICENSE_H

#include <mutex>
#include <iostream>
#include "LexStatusCodes.h"
#include "LexActivator.h"
#include "StdCapture.h"

// Uncomment following for Windows static build
/*
#if _WIN32
#define LEXACTIVATOR_STATIC
#pragma comment(lib, "winhttp")
#if _WIN64
#pragma comment(lib, "x64/libcurl_MD")
#pragma comment(lib, "x64/LexActivator")
#else
#pragma comment(lib, "x86/libcurl_MD")
#pragma comment(lib, "x86/LexActivator")
#endif
#endif
*/

#if _WIN32
#if _WIN64
#pragma comment(lib, "x64/LexActivator")
#else
#pragma comment(lib, "x86/LexActivator")
#endif
#endif

namespace ProtocolPP {

class jlicense {

public:

    // check the license
    bool static chkLicense();

    // deactivate the license
    void static deactivateLicense();

private:

    // don't allow these
    jlicense() = delete;
    jlicense(jlicense& rhs) = delete;
    jlicense(const jlicense& rhs) = delete;

    // initialize
    bool static init();

    // License callback is invoked when IsLicenseGenuine() completes a server sync
    void static LA_CC LicenseCallback(uint32_t status);

    // Software release update callback is invoked when CheckForReleaseUpdate() gets a response from the server
    void static LA_CC SoftwareReleaseUpdateCallback(uint32_t status);

    // Ideally on a button click inside a dialog
    bool static activate();

    // Ideally on a button click inside a dialog
    bool static activateTrial();
};

} 

#endif // JLICENSE_H
