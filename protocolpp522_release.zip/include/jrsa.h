#ifndef JRSA_H_
#define JRSA_H_

///
///\class jrsa jrsa.h "include/jrsa.h"
///
///\section MRSA RSA CyptoSystem
///
/// see https://en.wikipedia.org/wiki/RSA_(cryptosystem)
/// 
/// RSA (Rivest–Shamir–Adleman) is one of the first public-key cryptosystems and is widely used for
/// secure data transmission. In such a cryptosystem, the encryption key is public and it is different
/// from the decryption key which is kept secret (private). In RSA, this asymmetry is based on the
/// practical difficulty of the factorization of the product of two large prime numbers, the "factoring
/// problem". The acronym RSA is made of the initial letters of the surnames of Ron Rivest, Adi Shamir,
/// and Leonard Adleman, who first publicly described the algorithm in 1978. Clifford Cocks, an English
/// mathematician working for the British intelligence agency Government Communications Headquarters
/// (GCHQ), had developed an equivalent system in 1973, but this was not declassified until 1997 
///
/// A user of RSA creates and then publishes a public key based on two large prime numbers, along with
/// an auxiliary value. The prime numbers must be kept secret. Anyone can use the public key to encrypt
/// a message, but with currently published methods, and if the public key is large enough, only someone
/// with knowledge of the prime numbers can decode the message feasibly.[2] Breaking RSA encryption is
/// known as the RSA problem. Whether it is as difficult as the factoring problem remains an open question. 
/// RSA is a relatively slow algorithm, and because of this, it is less commonly used to directly encrypt
/// user data. More often, RSA passes encrypted shared keys for symmetric key cryptography which in turn
/// can perform bulk encryption-decryption operations at much higher speed 
/// 
/// The idea of an asymmetric public-private key cryptosystem is attributed to Whitfield Diffie and
/// Martin Hellman, who published this concept in 1976. They also introduced digital signatures and
/// attempted to apply number theory. Their formulation used a shared-secret-key created from exponentiation
/// of some number, modulo a prime number. However, they left open the problem of realizing a one-way function,
/// possibly because the difficulty of factoring was not well-studied at the time 
///
/// Ron Rivest, Adi Shamir, and Leonard Adleman at the Massachusetts Institute of Technology made several
/// attempts, over the course of a year, to create a one-way function that was hard to invert. Rivest and
/// Shamir, as computer scientists, proposed many potential functions, while Adleman, as a mathematician,
/// was responsible for finding their weaknesses. They tried many approaches including "knapsack-based" and
/// "permutation polynomials". For a time, they thought what they wanted to achieve was impossible due to
/// contradictory requirements.[4] In April 1977, they spent Passover at the house of a student and drank a
/// good deal of Manischewitz wine before returning to their homes at around midnight. Rivest, unable to
/// sleep, lay on the couch with a math textbook and started thinking about their one-way function. He spent
/// the rest of the night formalizing his idea, and he had much of the paper ready by daybreak. The algorithm
/// is now known as RSA – the initials of their surnames in same order as their paper 
///
/// Clifford Cocks, an English mathematician working for the British intelligence agency Government Communications
/// Headquarters (GCHQ), described an equivalent system in an internal document in 1973. However, given the
/// relatively expensive computers needed to implement it at the time, RSA was considered to be mostly a curiosity
/// and, as far as is publicly known, was never deployed. His discovery, however, was not revealed until 1997 due
/// to its top-secret classification. 
///
/// <B>Operation</B>
///
/// The RSA algorithm involves four steps: key generation, key distribution, encryption and decryption 
///
/// A basic principle behind RSA is the observation that it is practical to find three very large positive
/// integers \f$ e\f$, \f$ d\f$ and \f$ n\f$ such that with modular exponentiation for all integers
/// \f$ m\f$ (with \f$ 0 \leq m < n\f$): 
///
/// \f$ {({m}^{e})}^{d} \equiv m (mod n)\f$ 
/// 
/// and that even knowing \f$ e\f$ and \f$ n\f$ or even \f$ m\f$ it can be extremely difficult to find \f$ d\f$ 
///
/// In addition, for some operations it is convenient that the order of the two exponentiations can be
/// changed and that this relation also implies: 
///
/// \f$ {({m}^{d})}^{e} \equiv m ( mod n )\f$
/// 
/// RSA involves a public key and a private key. The public key can be known by everyone, and it is used for
/// encrypting messages. The intention is that messages encrypted with the public key can only be decrypted in
/// a reasonable amount of time by using the private key. The public key is represented by the integers \f$ n\f$
/// and \f$ e\f$; and, the private key, by the integer \f$ d\f$ (although \f$ n\f$ is also used during the
/// decryption process. Thus, it might be considered to be a part of the private key, too). \f$ m\f$ represents
/// the message (previously prepared with a certain technique explained below) 
///
/// <B>Key generation</B>
///
/// The keys for the RSA algorithm are generated the following way: 
///
/// * Choose two distinct prime numbers p and q
///
///   * For security purposes, the integers p and q should be chosen at random, and should be similar in
///     magnitude but differ in length by a few digits to make factoring harder Prime integers can be
///     efficiently found using a primality test
/// 
/// * Compute \f$ n = pq\f$
///
///   * n is used as the modulus for both the public and private keys. Its length, usually expressed
///     in bits, is the key length
/// 
/// * Compute \f$ \lambda(n) = lcm(\lambda(p), \lambda(q)) = lcm(p−1, q−1)\f$, where \f$ \lambda\f$ is Carmichael's totient function. This value is kept private
///
/// * Choose an integer \f$ e\f$ such that \f$ 1 < e < \lambda(n)\f$ and \f$ gcd(e, \lambda(n)) = 1\f$; i.e.,
///   \f$ e\f$ and \f$ \lambda(n)\f$ are coprime
///
/// * Determine \f$ d\f$ as \f$ d \equiv {e}^{−1} (mod \lambda(n))\f$; i.e., \f$ d\f$ is the modular multiplicative
///   inverse of \f$ e mod \lambda(n)\f$
///
///   * This means: solve for \f$ d\f$ the equation \f$ d \cdot e \equiv 1 (mod \lambda(n))\f$
///
///   * \f$ e\f$ having a short bit-length and small Hamming weight results in more efficient encryption – most
///     commonly \f$ e = {2}^{16} + 1 = 65,537\f$. However, much smaller values of \f$ e\f$ (such as 3) have been
///     shown to be less secure in some settings
///
///   * \f$ e\f$ is released as the public key exponent
///
///   * \f$ d\f$ is kept as the private key exponent
///
/// The public key consists of the modulus \f$ n\f$ and the public (or encryption) exponent \f$ e\f$. The private
/// key consists of the private (or decryption) exponent \f$ d\f$, which must be kept secret. \f$ p, q\f$, and
/// \f$ \lambda(n)\f$ must also be kept secret because they can be used to calculate \f$ d\f$ 
///
/// In the original RSA paper, the Euler totient function \f$ \phi(n) = (p − 1)(q − 1)\f$ is used instead of
/// \f$ \lambda(n)\f$ for calculating the private exponent \f$ d\f$. Since \f$ \phi(n)\f$ is always divisible by
/// \f$ \lambda(n)\f$ the algorithm works as well
///
/// <B>Key distribution</B>
///
/// Suppose that Bob wants to send information to Alice. If they decide to use RSA, Bob must know Alice's
/// public key to encrypt the message and Alice must use her private key to decrypt the message. To enable
/// Bob to send his encrypted messages, Alice transmits her public key \f$ (n, e)\f$ to Bob via a reliable,
/// but not necessarily secret, route. Alice's private key (\f$ d\f$) is never distributed 
///
/// <B>Encryption</B>
///
/// After Bob obtains Alice's public key, he can send a message \f$ M\f$ to Alice. To do it, he first turns \f$ M\f$
/// (strictly speaking, the un-padded plaintext) into an integer \f$ m\f$ (strictly speaking, the padded plaintext),
/// such that \f$ 0 ≤ m < n\f$ by using an agreed-upon reversible protocol known as a padding scheme. He then computes
/// the ciphertext \f$ c\f$, using Alice's public key \f$ e\f$, corresponding to \f$ c \equiv {m}^{e} (mod n)\f$ 
/// 
/// This can be done reasonably quickly, even for 500-bit numbers, using modular exponentiation. Bob then transmits
/// \f$ c\f$ to Alice 
///
/// <B>Decryption</B>
///
/// Alice can recover \f$ m\f$ from \f$ c\f$ by using her private key exponent \f$ d\f$ by computing
///
/// \f$ {c}^{d} \equiv {({m}^{e})}^{d} \equiv m (mod n)\f$
/// 
/// Given \f$ m\f$, she can recover the original message \f$ M\f$ by reversing the padding scheme 
/// 
/// <B>Signing messages</B>
///
/// Suppose Alice uses Bob's public key to send him an encrypted message. In the message, she can claim to
/// be Alice but Bob has no way of verifying that the message was actually from Alice since anyone can use
/// Bob's public key to send him encrypted messages. In order to verify the origin of a message, RSA can also
/// be used to sign a message 
///
/// Suppose Alice wishes to send a signed message to Bob. She can use her own private key to do so. She produces
/// a hash value of the message, raises it to the power of \f$ d (mod n)\f$ (as she does when decrypting a
/// message), and attaches it as a "signature" to the message. When Bob receives the signed message, he uses
/// the same hash algorithm in conjunction with Alice's public key. He raises the signature to the power of
/// \f$ e (mod n)\f$ (as he does when encrypting a message), and compares the resulting hash value with the
/// message's actual hash value. If the two agree, he knows that the author of the message was in possession
/// of Alice's private key, and that the message has not been tampered with since 
///
/// <B>Padding schemes</B>
///
/// To avoid these problems, practical RSA implementations typically embed some form of structured, randomized padding
/// into the value m before encrypting it. This padding ensures that m does not fall into the range of insecure
/// plaintexts, and that a given message, once padded, will encrypt to one of a large number of different possible
/// ciphertexts 
///
/// Standards such as PKCS#1 have been carefully designed to securely pad messages prior to RSA encryption. Because
/// these schemes pad the plaintext m with some number of additional bits, the size of the un-padded message
/// \f$ M\f$ must be somewhat smaller. RSA padding schemes must be carefully designed so as to prevent sophisticated
/// attacks which may be facilitated by a predictable message structure. Early versions of the PKCS#1 standard
/// (up to version 1.5) used a construction that appears to make RSA semantically secure
/// 
/// Secure padding schemes such as RSA-PSS are as essential for the security of message signing as they are for
/// message encryption
///
/// <B>Security</B>
///
/// The security of the RSA cryptosystem is based on two mathematical problems: the problem of factoring large
/// numbers and the RSA problem. Full decryption of an RSA ciphertext is thought to be infeasible on the
/// assumption that both of these problems are hard, i.e., no efficient algorithm exists for solving them.
/// Providing security against partial decryption may require the addition of a secure padding scheme 
///
/// <B>Importance of strong random number generation</B>
///
/// A cryptographically strong random number generator, which has been properly seeded with adequate entropy, must
/// be used to generate the primes \f$ p\f$ and \f$ q\f$
///
/// Strong random number generation is important throughout every phase of public key cryptography. For instance,
/// if a weak generator is used for the symmetric keys that are being distributed by RSA, then an eavesdropper
/// could bypass RSA and guess the symmetric keys directly 
///
/// <B>For API information:</B>
///
/// @see ProtocolPP::jrsa
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
///
/// @see jrsa
/// @see jrand
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#include <sys/types.h>
//#include <unistd.h>
//#include <netdb.h>
//#include <crypt.h>
#include <cstring>
#include <memory>
#include "jlogger.h"
#include "jenum.h"
#include "jarray.h"
#include "jrand.h"
#include "jprotocol.h"
#include "jrsasa.h"

#include "nbtheory.h"
using CryptoPP::ModularExponentiation;

#include "osrng.h"
using CryptoPP::AutoSeededRandomPool;

#include "sha.h"
using CryptoPP::SHA1;
using CryptoPP::SHA256;

#include "aes.h"
using CryptoPP::AES;

#include "rsa.h"

#include "pssr.h"

#include "secblock.h"
using CryptoPP::SecByteBlock;

#include "oids.h"
using CryptoPP::OID;

#include "asn.h"
using namespace CryptoPP::ASN1;

#include "integer.h"
using CryptoPP::Integer;

namespace ProtocolPP {

class jrsa : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor with default values
    /// bitsize=3072
    /// padding=PKCS1_5
    /// @param logger - logging object
    //////////////////////////////////////////////////////////////////////
    explicit jrsa(std::shared_ptr<InterfacePP::jlogger>& logger);

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor
    /// @param bitsize - size of the private key
    /// @param padding - padding types (PKCS1_5 and PSS)
    /// @param logger - logging object
    //////////////////////////////////////////////////////////////////////
    jrsa(int bitsize,
         rsapadtype_t padding,
         std::shared_ptr<InterfacePP::jlogger>& logger);

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor
    /// @param bitsize - size of the private key
    /// @param padding - padding types (PKCS1_5 and PSS)
    /// @param PRVKey - RSA private key
    /// @param PUBKey - RSA public key
    /// @param logger - logging object
    //////////////////////////////////////////////////////////////////////
    jrsa(int bitsize,
         rsapadtype_t padding,
         CryptoPP::RSA::PrivateKey& PRVKey,
         CryptoPP::RSA::PublicKey& PUBKey,
         std::shared_ptr<InterfacePP::jlogger>& logger);

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor
    /// @param security - security association for RSA
    //////////////////////////////////////////////////////////////////////
    explicit jrsa(std::shared_ptr<jrsasa>& security);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    ~jrsa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field RSA object
    ///
    /// <table>
    /// <caption id="RSA Set Fields">RSA Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>rsapadtype_t<td>RSAPAD<td>set_field<rsapadtype_t>(field_t::RSAPAD, rsapadtype_t::PKCS15)
    /// <tr><td>int<td>BITSIZE<td>set_field<int>(field_t::BITSIZE, bitsize)
    /// </table>
    ///
    /// @param field - field to update the IP security association
    /// @param fieldval - value to update the IP security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field RSA object
    ///
    /// <table>
    /// <caption id="RSA Get Fields">RSA Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>rsapadtype_t<td>RSAPAD<td>rsapadtype_t rsapad = get_field<rsapadtype_t>(field_t::RSAPAD)
    /// <tr><td>int<td>BITSIZE<td>int bitsize = get_field<int>(field_t::BITSIZE)
    /// <tr><td>CryptoPP::RSA::PrivateKey <td>PRVKEY<td>CryptoPP::RSA::PrivateKey prvkey = get_field<CryptoPP::RSA::PrivateKey>(field_t::PRVKEY)
    /// <tr><td>CryptoPP::RSA::PublicKey <td>PUBKEY<td>CryptoPP::RSA::PublicKey pubkey = get_field<CryptoPP::RSA::PublicKey>(field_t::PUBKEY)
    /// <tr><td>std::pair<CryptoPP::RSA::PrivateKey, CryptoPP::RSA::PublicKey> <td>KEYPAIR<td>shared_ptr<std::pair<CryptoPP::RSA::PrivateKey, CryptoPP::RSA::PublicKey> keypair = get_field<std::pair<CryptoPP::RSA::PrivateKey, CryptoPP::RSA::PublicKey>>(field_t::KEYPAIR)
    /// </table>
    ///
    /// @param field - field to retrieve from the IP security association
    /// @return field of the IP security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Generate key pair
    //////////////////////////////////////////////////////////////////////
    void gen_keypair();

    //////////////////////////////////////////////////////////////////////
    /// Encrypt the data
    /// @param data - data to encrypt
    /// @param ciphertext - encrypted data
    //////////////////////////////////////////////////////////////////////
    void encrypt(std::shared_ptr<jarray<uint8_t>>& data,
                 std::shared_ptr<jarray<uint8_t>>& ciphertext);

    //////////////////////////////////////////////////////////////////////
    /// Decrypt the data
    /// @param ciphertext - encrypted data
    /// @param data - decrypted data
    //////////////////////////////////////////////////////////////////////
    void decrypt(std::shared_ptr<jarray<uint8_t>>& ciphertext,
                 std::shared_ptr<jarray<uint8_t>>& data);

    //////////////////////////////////////////////////////////////////////
    /// Sign the data
    /// @param data - Data to sign using the pad type
    /// @param signature - Generated signature
    //////////////////////////////////////////////////////////////////////
    void sign(std::shared_ptr<jarray<uint8_t>>& data,
              std::shared_ptr<jarray<uint8_t>>& signature);

    //////////////////////////////////////////////////////////////////////
    /// Verify the data
    /// @param signature - Signature to verify using the pad type
    /// @return result of the verification 
    //////////////////////////////////////////////////////////////////////
    void verify(std::shared_ptr<jarray<uint8_t>>& signature);

    /////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    /////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jrsasa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param hdr - header of the packet
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param field - field to update
    /// @param value - new value for the field
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @return empty array
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr(); 

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @return 0
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param input - data to encapsulate
    /// @param output - encapsulated packet
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param input - encapsulated packet
    /// @param output - decapsulated packet
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input, std::shared_ptr<jarray<uint8_t>>& output);

private:

    // don't use these
    jrsa(jrsa& jrsa) = delete;
    jrsa(const jrsa& jrsa) = delete;

    // member variables
    int m_bitsize;
    std::shared_ptr<jrsasa> m_sec;
    std::shared_ptr<InterfacePP::jlogger> m_logger;

    // Sign with the RSA Private Key
    CryptoPP::AutoSeededRandomPool m_rng;
};

}

#endif /* JRSA_H_ */

