#ifndef JTLSA_H_
#define JTLSA_H_

///
///\class jtlsa jtlsa.h "include/jtlsa.h"
///
///\section TLSA_ClassSA Transport Layer Security Association (TLSA)
///
/// For additional information see http://en.wikipedia.org/wiki/Transport_Layer_Security
///
/// The TLS protocol exchanges records—which encapsulate the data to be exchanged
/// in a specific format (see below). Each record can be compressed, padded, appended
/// with a message authentication code (MAC), or encrypted, all depending on the state
/// of the connection. Each record has a content type field that designates the type
/// of data encapsulated, a length field and a TLS version field. The data encapsulated
/// may be control or procedural messages of the TLS itself, or simply the application
/// data needed to be transferred by TLS. The specifications (cipher suite, keys etc.)
/// required to exchange application data by TLS, are agreed upon in the "TLS handshake"
/// between the client requesting the data and the server responding to requests. The
/// protocol therefore defines both the structure of payloads transferred in TLS and the
/// procedure to establish and monitor the transfer
///
/// <B>TLS Records</B>
/// 
/// This is the general format for all TLS records (packets) [1]
///
///\image html TLS_Message.png "General Format for TLS Records (Packets)"
///\image latex TLS_Message.eps "General Format for TLS Records (Packets)" width=15cm
///
/// <B>Content Type</B>
///
/// This field identifies the Record Layer Protocol Type contained in this Record
///
/// <table>
/// <caption id="tlsactypes">TLS Content Types</caption>
/// <tr><th>Hex<th>Dec<th>Type
/// <tr><td>0x14<td>20<td>ChangeCipherSpec
/// <tr><td>0x15<td>21<td>Alert
/// <tr><td>0x16<td>22<td>Handshake
/// <tr><td>0x17<td>23<td>Application
/// <tr><td>0x18<td>24<td>Heartbeat
/// </table>
///
/// <B>Version</B>
///
/// This field identifies the major and minor version of TLS for the contained message. For a ClientHello message, this
/// need not be the highest version supported by the client
///
/// <table>
/// <caption id="tlsaversions">TLS Versions</caption>
/// <tr><th>Major Version<th>Minor Version<th>Version Type
/// <tr><td>0x03<td>0x00<td>SSL3.0
/// <tr><td>0x03<td>0x01<td>TLS1.0
/// <tr><td>0x03<td>0x02<td>TLS1.1
/// <tr><td>0x03<td>0x03<td>TLS1.2
/// <tr><td>0xFF<td>0xFE<td>DTLS
/// </table>
///
/// <B>Length</B> 
///
/// The length of Protocol message(s), MAC and Padding, not to exceed \f${2}^{14}\f$ bytes (16KB)
///
///
/// <B>Protocol Message(s)</B>
///
/// One or more messages identified by the Protocol field. Note that this field may be encrypted depending
/// on the state of the connection
///
///
/// <B>MAC and Padding</B>
///
/// A message authentication code computed over the Protocol message, with additional key material included
/// Note that this field may be encrypted, or not included entirely, depending on the state of the connection
/// No MAC or Padding can be present at end of TLS records before all cipher algorithms and parameters have
/// been negotiated and handshaked and then confirmed by sending a CipherStateChange record (see below) for
/// signaling that these parameters will take effect in all further records sent by the same peer
///
///
/// <B>Handshake protocol</B>
///
/// Most messages exchanged during the setup of the TLS session are based on this record, unless an
/// error or warning occurs and needs to be signaled by an Alert protocol record (see below), or the
/// encryption mode of the session is modified by another record (see ChangeCipherSpec protocol below)
///
/// <table>
/// <caption id="tlsahandshake">TLS Handshake Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x16</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5..8<td>Message Type<td colspan="3"><center>Handshake Message Data Length</center>
/// <tr><td>Byte 9-(n-1)<td colspan="4"><center>Handshake Message Data</center>
/// <tr><td><center><b>. . .</b></center><td colspan="4"><center><b>. . .</b></center>
/// </table>
///
///
/// <B>Message type</B> 
///
/// This field identifies the handshake message type
///
/// <table>
/// <caption id="tlsamsgtype">TLS Message Types</caption>
/// <tr><th>Code<th>Description
/// <tr><td>0<td>HelloRequest
/// <tr><td>1<td>ClientHello
/// <tr><td>2<td>ServerHello
/// <tr><td>4<td>NewSessionTicket
/// <tr><td>11<td>Certificate
/// <tr><td>12<td>ServerKeyExchange
/// <tr><td>13<td>CertificateRequest
/// <tr><td>14<td>ServerHelloDone
/// <tr><td>15<td>CertificateVerify
/// <tr><td>16<td>ClientExchange
/// <tr><td>20<td>Finished
/// </table>
///
/// <B>Handshake message data length</B>
///
/// This is a 3-byte field indicating the length of the handshake data, not including the header
/// Note that multiple handshake messages may be combined within one record
///
/// <B>Alert protocol</B>
///
/// This record should normally not be sent during normal handshaking or application exchanges.  However,
/// this message can be sent at any time during the handshake and up to the closure of the session. If
/// this is used to signal a fatal error, the session will be closed immediately after sending this
/// record, so this record is used to give a reason for this closure.  If the alert level is flagged
/// as a warning, the remote can decide to close the session if it decides that the session is not 
/// reliable enough for its needs (before doing so, the remote may also send its own signal)
///
/// <table>
/// <caption id="tlsaalert">TLS Alert Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x15</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5..6<td><center>Level</center><td><center>Description</center><td colspan="2">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 7-(n-1)<td colspan="4"><center>MAC (optional)</center>
/// <tr><td>Byte p-(q-1)<td colspan="4"><center>Padding (block ciphers only)</center>
/// </table>
///
/// <B>Level</B>
///  
/// This field identifies the level of alert. If the level is fatal, the sender should close the session
/// immediately. Otherwise, the recipient may decide to terminate the session itself, by sending its own
/// fatal alert and closing the session itself immediately after sending it. The use of Alert records is
/// optional, however if it is missing before the session closure, the session may be resumed automatically
/// (with its handshakes)
///
/// Normal closure of a session after termination of the transported application should preferably be
/// alerted with at least the Close notify Alert type (with a simple warning level) to prevent such
/// automatic resume of a new session. Signaling explicitly the normal closure of a secure session before
/// effectively closing its transport layer is useful to prevent or detect attacks (like attempts to 
/// truncate the securely transported data, if it intrinsically does not have a predetermined length or
/// duration that the recipient of the secured data may expect)
///
/// 
/// <B>ChangeCipherSpec protocol</B>
///
/// <table>
/// <caption id="tlsacipherchange">TLS ChangeCipherSpec Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x14</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5<td><center>CCS Prot Type</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// </table>
///
/// <B>CCS protocol type</B>
///
/// Currently only 1
///
///
/// <B>Application protocol</B>
///
/// <table>
/// <caption id="tlsaapp">TLS Application Protocol</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x17</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 5-(m-1)<td colspan="4"><center>Application Data</center>
/// <tr><td>Byte m-(p-1)<td colspan="4"><center>MAC (optional)</center>
/// <tr><td>Byte p-(q-1)<td colspan="4"><center>Padding (block ciphers only)</center>
/// </table>
///
/// <table>
/// <caption id="tlsadtls">DTLS Datagram</caption>
/// <tr><th>+<th>Byte0<th>Byte1<th>Byte2<th>Byte3
/// <tr><td>Byte 0<td><center>0x17</center><td colspan="3">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/// <tr><td>Byte 1-4<td colspan="2"><center>Version</center><td colspan="2"><center>Epoch</center>
/// <tr><td>Byte 5-8<td colspan="4"><center>Seqnum</center>
/// <tr><td>Byte 9-12<td colspan="2"><center>Seqnum</center><td colspan="2"><center>Length</center>
/// <tr><td>Byte 13-(m-1)<td colspan="4"><center>Seqnum</center>
/// <tr><td>Byte m-(p-1)<td colspan="4"><center>MAC (optional)</center>
/// <tr><td>Byte p-(q-1)<td colspan="4"><center>Padding (block ciphers only)</center>
/// </table>
///
/// <B>Length</B>
///
/// Length of the application data (excluding the protocol header and including the MAC and padding trailers)
///
///
/// <B>MAC</B>
///
/// 20 bytes for the SHA1 based HMAC, 16 bytes for the MD5 based HMAC
///
///
/// <B>Padding</B>
/// 
/// Variable length; last byte contains the padding length
///
/// [1] http://orm-chimera-prod.s3.amazonaws.com/1230000000545/ch04.html
///
/// [2] https://tools.ietf.org/html/rfc7366
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jtlsa
/// @see ProtocolPP::jtls
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jtlsa
/// @see jtls
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Redistribution and use in source and binary forms, with or without modification, are
/// permitted provided that the following conditions are met:
///
/// * Redistributions of source code must retain the above copyright notice, this list of
///   conditions and the following disclaimer
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use requires a fee-based license obtainable at www.protocolpp.com
///
/// * Academic use requires written and notarized permission from John Peter and Sheila
///   Rocha Greninger
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The names of its contributors may not be used to endorse or promote products derived
/// from this software without specific prior written permission
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///
 
#include <regex>
#include "jsecass.h"

namespace ProtocolPP {

class jtlsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard Constructor with defaults
    ///
    /// <table>
    /// <caption id="TLS Defaults">TLS Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::ENCAP
    /// <tr><td>ciphersuite<td>tls_ciphersuite_t::TLS_DH_DSS_WITH_AES_128_CBC_SHA
    /// <tr><td>ver<td>tlsver_t::TLS10
    /// <tr><td>type<td>tlstype_t::APPLICATION
    /// <tr><td>icvlen<td>20
    /// <tr><td>epoch<td>0
    /// <tr><td>seqnum<td>0
    /// <tr><td>ivlen<td>16
    /// <tr><td>ckeylen<td>16
    /// <tr><td>akeylen<td>20
    /// <tr><td>saltlen<td>0
    /// <tr><td>arlen<td>0
    /// <tr><td>arwin<td>0
    /// <tr><td>mtu<td>0
    /// <tr><td>randiv<td>false
    /// <tr><td>ivex<td>true
    /// <tr><td>encthenmac<td>false
    /// <tr><td>authkey<td>0
    /// <tr><td>cipherkey<td>0
    /// <tr><td>iv<td>0
    /// <tr><td>salt<td>0
    /// </table>
    //////////////////////////////////////////////////////////////////////
    jtlsa();

    //////////////////////////////////////////////////////////////////////
    /// Security Association for TLS
    ///
    /// @param dir - Direction of processing (ENCAP or DECAP)
    /// @param ciphersuite - Ciphersuite to use with TLS/SSL
    /// @param ver - Version of TLS/SSL to use
    /// @param icvlen - Length of the ICV tag
    /// @param mtu - Maximum transmition unit
    /// @param type - Default type of packet to send (usually Application)
    /// @param epoch - Initial Epoch for DTLS
    /// @param seqnum - Initial sequence number
    /// @param ivlen - Length of the initialization vector (IV)
    /// @param iv - Initialization Vector (IV)
    /// @param ckeylen - Length of the cipher key
    /// @param cipherkey - Key for the encryption algorithm
    /// @param akeylen - Length of the authentication key
    /// @param authkey - Key for the authentication algorithm
    /// @param saltlen - Length of the salt
    /// @param salt - salt for CTR, CCM, GCM, and CHACHA20 ciphers
    /// @param arlen - Number og packets to track in the replay window
    /// @param arwin - Anti-replay window for tracking packets
    /// @param randiv - use random IV instead of IV passed in
    /// @param ivex - IV is sent in the clear instead of encrypted if asserted
    /// @param encthenmac - Encrypt then MAC flag set by negogiated features
    //////////////////////////////////////////////////////////////////////
    jtlsa(direction_t dir,
          tls_ciphersuite_t ciphersuite,
          tlsver_t ver,
          tlstype_t type,
          uint16_t epoch,
          uint64_t seqnum,
          unsigned int icvlen,
          unsigned int ivlen,
          std::shared_ptr<jarray<uint8_t>> iv,
          unsigned int ckeylen,
          std::shared_ptr<jarray<uint8_t>> cipherkey,
          unsigned int akeylen,
          std::shared_ptr<jarray<uint8_t>> authkey,
          unsigned int saltlen,
          std::shared_ptr<jarray<uint8_t>> salt,
          unsigned int arlen,
          jarray<uint8_t> arwin,
          unsigned int mtu,
          bool randiv,
          bool ivex,
          bool encthenmac);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for TLS Security Association
    /// @param rhs - Security association (SA) for this TLS flow
    //////////////////////////////////////////////////////////////////////
    jtlsa(jtlsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for TLS Security Association
    /// @param rhs - Security association (SA) for this TLS flow
    //////////////////////////////////////////////////////////////////////
    explicit jtlsa(std::shared_ptr<jtlsa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jtlsa() {
        if (!m_iv.empty()) {
            m_iv.serase();
        }
        if (!m_cipherkey.empty()) {
            m_cipherkey.serase();
        }
        if (!m_authkey.empty()) {
            m_authkey.serase();
        }
        if (!m_salt.empty()) {
            m_salt.serase();
        }
    }

    //////////////////////////////////////////////////////////////////////
    /// Update the field in the TLS security association
    ///
    /// <table>
    /// <caption id="TLS Set Fields">TLS Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::DECAP)
    /// <tr><td>tls_ciphersuite_t<td>CIPHERSUITE<td>set_field<tls_ciphersuite_t>(field_t::CIPHERSUITE, tls_ciphersuite::TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA)
    /// <tr><td>tlsver_t<td>VERSION<td>set_field<tlsver_t>(field_t::VERSION, tlsver_t::DTLS)
    /// <tr><td>tlstype_t<td>TYPE<td>set_field<tlstype_t>(field_t::TYPE, tlstype_t::APPLICATION)
    /// <tr><td>bool<td>RANDIV<td>set_field<bool>(field_t::RANDIV, true);
    /// <tr><td><td>IVEX<td>set_field<bool>(field_t::IVEX, true);
    /// <tr><td><td>ENCTHENMAC<td>set_field<bool>(field_t::ENCTHENMAC, true);
    /// <tr><td>uint16_t<td>EPOCH<td>set_field<uint16_t>(field_t::EPOCH, 0);
    /// <tr><td>uint32_t<td>ICVLEN<td>set_field<uint32_t>(field_t::ICVLEN, 0);
    /// <tr><td><td>IVLEN<td>set_field<uint32_t>(field_t::IVLEN, 0);
    /// <tr><td><td>CKEYLEN<td>set_field<uint32_t>(field_t::CKEYLEN, 0);
    /// <tr><td><td>AKEYLEN<td>set_field<uint32_t>(field_t::AKEYLEN, 0);
    /// <tr><td><td>SALTLEN<td>set_field<uint32_t>(field_t::SALTLEN, 0);
    /// <tr><td><td>ARLEN<td>set_field<uint32_t>(field_t::ARLEN, 0);
    /// <tr><td><td>MTU<td>set_field<uint32_t>(field_t::MTU, 0);
    /// <tr><td>uint64_t<td>SEQNUM<td>set_field<uint64_t>(field_t::SEQNUM, 0);
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>set_field<jarray<uint8_t>>(field_t::ARWIN, jarray<uint8_t>("000000000000001"))
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>IV<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::IV, std::make_shared<rotocolPP::jarray<uint8_t>>("000000000000001"))
    /// <tr><td><td>CIPHERKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, std::make_shared<rotocolPP::jarray<uint8_t>>("000000000000001"))
    /// <tr><td><td>AUTHKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY, std::make_shared<rotocolPP::jarray<uint8_t>>("000000000000001"))
    /// <tr><td><td>SALT<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT, std::make_shared<rotocolPP::jarray<uint8_t>>("000000000000001"))
    /// </table>
    ///
    /// @param field - TLS field to update
    /// @param fieldval - new value for the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the field from the TLS security association
    ///
    /// <table>
    /// <caption id="TLS Get Fields">TLS Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>tls_ciphersuite_t<td>CIPHERSUITE<td>tls_ciphersuite_t mycsuite = get_field<tls_ciphersuite_t>(field_t::CIPHERSUITE)
    /// <tr><td>tlsver_t<td>VERSION<td>tlsver_t myver = get_field<tlsver_t>(field_t::VERSION)
    /// <tr><td>tlstype_t<td>TYPE<td>tlstype_t mytype = get_field<tlstype_t>(field_t::TYPE)
    /// <tr><td>bool<td>RANDIV<td>bool myrandiv = get_field<bool>(field_t::RANDIV);
    /// <tr><td><td>IVEX<td>bool myivex = get_field<bool>(field_t::IVEX);
    /// <tr><td><td>ENCTHENMAC<td>bool myethm = get_field<bool>(field_t::ENCTHENMAC);
    /// <tr><td>uint16_t<td>EPOCH<td>uint16_t myepoch = get_field<uint16_t>(field_t::EPOCH);
    /// <tr><td>uint32_t<td>ICVLEN<td>uint32_t myicvlen = get_field<uint32_t>(field_t::ICVLEN);
    /// <tr><td><td>IVLEN<td>uint32_t myivlen = get_field<uint32_t>(field_t::IVLEN);
    /// <tr><td><td>CKEYLEN<td>uint32_t myckeylen = get_field<uint32_t>(field_t::CKEYLEN);
    /// <tr><td><td>AKEYLEN<td>uint32_t myakeylen = get_field<uint32_t>(field_t::AKEYLEN);
    /// <tr><td><td>SALTLEN<td>uint32_t mysaltlen = get_field<uint32_t>(field_t::SALTLEN);
    /// <tr><td><td>ARLEN<td>uint32_t myarlen = get_field<uint32_t>(field_t::ARLEN);
    /// <tr><td><td>MTU<td>uint32_t mymtu = get_field<uint32_t>(field_t::MTU);
    /// <tr><td>uint64_t<td>SEQNUM<td>uint64_t myseqnum = get_field<uint64_t>(field_t::SEQNUM);
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>jarray<uint8_t> myarwin = get_field<jarray<uint8_t>>(field_t::ARWIN)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>IV<td>std::shared_ptr<jarray<uint8_t>> myarwin = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::IV)
    /// <tr><td><td>CIPHERKEY<td>std::shared_ptr<jarray<uint8_t>> myarwin = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY)
    /// <tr><td><td>AUTHKEY<td>std::shared_ptr<jarray<uint8_t>> myarwin = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::AUTHKEY)
    /// <tr><td><td>SALT<td>std::shared_ptr<jarray<uint8_t>> myarwin = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT)
    /// </table>
    ///
    /// @param field - field to retrieve
    /// @return value of the field 
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Print the protocol and security objects to XML
    ///
    /// @param myxml - XMLPrinter object
    /// @param direction - facilitator for random descriptor generation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jtlsa(const jtlsa& rhs) = delete;

    // member variables
    direction_t m_dir;
    tls_ciphersuite_t m_ciphersuite;
    tlsver_t m_ver;
    tlstype_t m_type;
    uint16_t m_epoch;
    uint64_t m_seqnum;
    unsigned int m_icvlen;
    unsigned int m_ivlen;
    jarray<uint8_t> m_iv;
    unsigned int m_ckeylen;
    jarray<uint8_t> m_cipherkey;
    unsigned int m_akeylen;
    jarray<uint8_t> m_authkey;
    unsigned int m_saltlen;
    jarray<uint8_t> m_salt;
    unsigned int m_arlen;
    jarray<uint8_t> m_arwin;
    unsigned int m_mtu;
    bool m_randiv;
    bool m_ivex;
    bool m_encthenmac;
};

}

#endif // JTLSA_H_
