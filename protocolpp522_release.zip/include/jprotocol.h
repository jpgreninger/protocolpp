#ifndef JPROTOCOL_H_
#define JPROTOCOL_H_

///
///\class jprotocol jprotocol.h "include/jprotocol.h"
///
///\section JPROTOCOLC Protocol Base Class for Protocol++&reg; (ProtocolPP&reg;)
///
/// This class is the base class for all other protocols. Many of the methods are
/// pure virtual and must be implemented in the inherited class. In addition, the
/// class comtains helper functions for use in the various protocols
///
/// Constructors are provided for differnt kinds of protocols. Some protocols may
/// be opening a file, some may need a random data generator, some protocols may
/// require a file input and a random number generator
///
/// Two different types of encap and decap virtual functions are provided. For
/// protocols that have a file input, encapsulation only requires a pointer to
/// the output data. Input data will be retrieved from the input file, in chunks
/// the size of the current MTU untill the EOF is reached. For decapsulation with
/// a file output will write the data into the file in append mode until the
/// last packet is processed
///
/// For the typical type, and input pointer and output pointer must be provided
/// to process the plaintext and ciphertext
///
/// Set and get functions must be implemented in the protocols. Various fields can
/// be retrieved as well as the whole header for the protocol
///
/// Following the virtual functions, there are several helper functions for use by
/// the protocols. The function currentDateTime() returns a string representation
/// of the date and time useful for the AUDIT fuction in IPsec. It can be used any
/// time the date or time is needed
/// 
/// The functions has_file() provides a convenient method to check if the file is
/// present and it's open for reading or writing
///
/// The next two functions provide methods to retrieve the status get_status()
/// which returns an encoded status that contains the protocols generating the
/// status, the error type, and the line number in the code where the error
/// occurred. For printing purposes, the function str_status(status) returns
/// a printable string describing the protocol
///
/// to_xml() prints the security association as XML output to the XMLPrint object. For example,
/// the to_xml() function for the IP protocol passes the following information
/// to the XMLPrint object as the security tag
///\code
///
/// void jipsa::to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction) {
///    // convert enums to strings
///    m_dir = direction;
///    std::string dir(EnumString<direction_t>::From(m_dir));
///    std::string ver(EnumString<iana_t>::From(m_ver));
///    std::string nh(EnumString<iana_t>::From(m_nh));
///
///    // print XML
///    myxml.OpenElement("security");
///    myxml.PushAttribute("name", "ipsa");
///    myxml.PushAttribute("ver", ver.c_str());
///    myxml.PushAttribute("dir", dir.c_str());
///    myxml.PushAttribute("nh", nh.c_str());
///    myxml.PushAttribute("dsecn", m_dsecn);
///    myxml.PushAttribute("mtu", m_mtu);
///    myxml.PushAttribute("ttl", m_ttl);
///    myxml.PushAttribute("jumbogram", m_jumbogram);
///    myxml.PushAttribute("src", m_src.to_string(false,0,false).c_str());
///    myxml.PushAttribute("dst", m_dst.to_string(false,0,false).c_str());
///    if (m_exthdr.get_size() == 0) {
///        myxml.PushAttribute("exthdr", "");
///    }
///    else {
///        myxml.PushAttribute("exthdr", m_exthdr.to_string(false,0,false).c_str());
///    }
///    myxml.PushAttribute("flags", m_flags);
///    myxml.PushAttribute("fragoff", m_fragoff);
///    myxml.PushAttribute("id", m_id);
///    myxml.PushAttribute("label", m_label);
///    myxml.CloseElement();
/// }
///\endcode
/// To help in converting data from unsigned types to arrays and back with
/// the correct endianess, the following helper functions are provided:
///\code
///
/// jarray<uint8_t> static to_array(uint8_t input);
///
/// jarray<uint8_t> static to_array(uint16_t input);
///
/// jarray<uint8_t> static to_array(uint32_t input);
///
/// jarray<uint8_t> static to_array(uint64_t input);
///
/// uint8_t static to_u8(jarray<uint8_t> src_array);
///
/// uint16_t static to_u16(jarray<uint8_t> src_array);
///
/// uint32_t static to_u32(jarray<uint8_t> src_array);
///
/// uint64_t static to_u64(jarray<uint8_t> src_array);
///\endcode
///
/// The final two functions provide common functionality that is used across multiple
/// protocols so are provided in the base class. The checksum() function calculates
/// the IPsec checksum calculation also used in TCP and UDP. Input data is padded to
/// two byte length. The checksum field for the protocol is set to zero, and the 
/// checksum is calculated across the data two bytes at a time. The calculated checksum
/// is returned as a two-byte array ready for insertion into the packet. If the checksum is
/// being validated (DECAP direction), the checksum is calculated without setting
/// the checksum field to zero. If the calculated checksum results in a value of
/// zero, the checksum is correct
///\code
///
/// jarray<uint8_t> checksum(iana_t prot,
///                          direction_t dir,
///                          jarray<uint8_t>& check,
///                          unsigned int offset=0);
///\endcode
/// pad(pad_t padtype, unsigned int len) generates padding material to be appended to
/// the packet if needed. Supports either ZERO, INCREMENTING, SIZE, or RANDOM padding
/// to support the different protocol formats
///\code
///
/// jarray<uint8_t> pad(pad_t padtype,
///                     unsigned int len);
///\endcode
/// There are several protected helper functions for use by the protocols during or
/// after construction of the protocol object. This includes functions to setup the
/// anti-replay window from the security association, the ability to update the status,
/// functions to read and write the input and output files, and function to roundup()
/// values
///
/// <B>For API Documentation:</B>
/// @see tinyxml2::tinyxml2
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jreplay
/// @see ProtocolPP::ciphers
/// @see ProtocolPP::jprotocol
///
/// <B>For Additional Documentation:</B>
/// @see tinyxml2
/// @see jarray
/// @see jrand
/// @see jreplay
/// @see ciphers
/// @see jprotocol
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <mutex>
#include <random>
#include <cstddef>
#include <sys/types.h>
#include <exception>
#include <ratio>
#include <chrono>

#include <memory>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#if defined(_MSC_VER)
#include <io.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#endif
#include <netinet/in.h>
#include <cassert>
#include "EnumString.h"
#include "jenum.h"
#include "jarray.h"
#include "jrand.h"
#include "jreplay.h"
#include "ciphers.h"
#include "tinyxml2.h"

namespace ProtocolPP {

class jprotocol {

public:
    //////////////////////////////////////////////////////////////////////
    /// Constructor for base class of protocols which accepts the
    /// maximum transmission unit (MTU)
    ///
    /// @param dir - direction of processing either ENCAP or DECAP
    //////////////////////////////////////////////////////////////////////
    explicit jprotocol(direction_t dir);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for base class of protocols which accepts the
    /// maximum transmission unit (MTU) and a path to a file which
    /// contains the data to transmit
    ///
    /// @param dir - direction of processing either ENCAP or DECAP
    /// @param file - input file that contains data to transmit
    //////////////////////////////////////////////////////////////////////
    jprotocol(direction_t dir,
              std::string& file);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for base class of protocols which accepts the
    /// maximum transmission unit (MTU), an anti-replay structure, and
    /// a pointer to a random number generator for cryptographic purposes
    ///
    /// @param dir - direction of processing either ENCAP or DECAP
    /// @param rand - pointer to random number generator for cryptographic
    ///               functionality such as padding
    //////////////////////////////////////////////////////////////////////
    jprotocol(direction_t dir,
              std::shared_ptr<jrand>& rand);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for base class of protocols which accepts the
    /// maximum transmission unit (MTU), an anti-replay structure, and
    /// a pointer to a random number generator for cryptographic purposes
    ///
    /// @param dir - direction of processing either ENCAP or DECAP
    /// @param file - input file that contains data to transmit
    /// @param rand - pointer to random number generator for cryptographic
    ///               functionality such as padding
    //////////////////////////////////////////////////////////////////////
    jprotocol(direction_t dir,
              std::shared_ptr<jrand>& rand,
              std::string& file);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    ~jprotocol();

    //////////////////////////////////////////////////////////////////////
    /// packet processing functions for use with protocols that access
    /// files (TCP, UDP, IP). Encap generates packets from the file
    /// given in the constructor with each packet containing MTU worth
    /// of data in the packet
    ///
    /// @param output - shared pointer to generated output packet
    //////////////////////////////////////////////////////////////////////
    virtual void encap_packet(std::shared_ptr<jarray<uint8_t>>& output) {}

    //////////////////////////////////////////////////////////////////////
    /// packet processing functions for use with protocols that access
    /// files (TCP, UDP, IP). Decap takes packets from the system
    /// decapsulates the packet, and writes the resulting payload to the
    /// file given in the constructor with each packet containing MTU
    /// worth of data in the packet
    ///
    /// @param input - shared pointer to received packet whose payload
    ///                will be written to the file passed to the
    ///                constructor
    //////////////////////////////////////////////////////////////////////
    virtual void decap_packet(std::shared_ptr<jarray<uint8_t>>& input) {}

    //////////////////////////////////////////////////////////////////////
    /// packet processing functions for use with all protocols. Encap
    /// takes a payload or packet generated by a lower-level protocol
    /// encapsulates the packet according to the protocol selected, and
    /// returns the resulting packet. Both the input and output packets
    /// are shared pointers to arrays containing payloads and packets
    /// respectively
    //////////////////////////////////////////////////////////////////////
    virtual void encap_packet(std::shared_ptr<jarray<uint8_t>>& input,
                              std::shared_ptr<jarray<uint8_t>>& output) = 0;

    //////////////////////////////////////////////////////////////////////
    /// packet processing functions for use with all protocols. Decap
    /// takes a packet from an upper-layer protocol and decapsulates
    /// the packet and returns the payload. Both the input and output
    /// packets are shared pointers to arrays containing payloads and
    /// packets respectively
    //////////////////////////////////////////////////////////////////////
    virtual void decap_packet(std::shared_ptr<jarray<uint8_t>>& input,
                              std::shared_ptr<jarray<uint8_t>>& output) = 0;

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the header for the packet
    /// @return the full header
    //////////////////////////////////////////////////////////////////////
    virtual jarray<uint8_t> get_hdr() = 0;

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the value of the field
    /// @param field - field to retrieve
    /// @return current value of the field
    //////////////////////////////////////////////////////////////////////
    virtual uint64_t get_field(field_t field) { return 0; }

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the value of the field
    /// @param field - field to retrieve
    /// @param hdr - header to retrieve the field from
    /// @return current value of the field
    //////////////////////////////////////////////////////////////////////
    virtual uint64_t get_field(field_t field, jarray<uint8_t>& hdr) = 0;

    //////////////////////////////////////////////////////////////////////
    /// Set the header to the current value
    /// @param hdr - new header value
    //////////////////////////////////////////////////////////////////////
    virtual void set_hdr(jarray<uint8_t>& hdr) = 0;

    //////////////////////////////////////////////////////////////////////
    /// Set the specified field with a new value
    /// @param field - field to set
    /// @param value - new value for the field
    //////////////////////////////////////////////////////////////////////
    virtual void set_field(field_t field, uint64_t value) = 0;

    //////////////////////////////////////////////////////////////////////
    /// Get current date/time, format is YYYY-MM-DD.HH:mm:ss
    /// @return data/time formatted as string
    //////////////////////////////////////////////////////////////////////
    const std::string static currentDateTime();

    //////////////////////////////////////////////////////////////////////
    /// check for file input/output
    /// @return - file is present or not
    //////////////////////////////////////////////////////////////////////
    bool hasfile();

    //////////////////////////////////////////////////////////////////////
    /// return the status for the packet with the following format
    ///\code
    /// --------------------------------------------------------------
    /// | Protocol (8-bits) | Error (8-bits) | Line Number (16-bits) |
    /// --------------------------------------------------------------
    ///\endcode
    ///
    /// * Protocol codes in STATUS:
    ///   * NO_ERROR - No errors (value of 0)
    ///   * PROTOCOL - JProtocol base class (value of 1)
    ///   * MACSEC - Macsec protocol (value of 2)
    ///   * WIFI - Wifi protocol (value of 3)
    ///   * WIGIG - WiGig protocol (value of 4)
    ///   * WIMAX - WiMax protocol (value of 5)
    ///   * LTE - Long Term Evolution (LTE/3GPP) protocol (value of 6)
    ///   * RLC - Radio Link Control (value of 7)
    ///   * TLS - Transport Layer Security (TLS/SSL) protocol (value of 8)
    ///   * SRTP - Secure RTP protocol (value of 9)
    ///   * UDP - User Datagram Protocol (UDP) (value of 10)
    ///   * TCP - Transport Control Protocol (TCP) (value of 11)
    ///   * ICMP - Internet Control Message Protocol (ICMP) (value of 12)
    ///   * IP - Internet Protocol (IP) (value of 13)
    ///   * IPSEC - Encapsulating Security Protocol (ESP) (value of 14)
    ///   * XMLPARSER - TinyXML2 parser (value of 15)
    ///   * RINGDRIVER - Ring driver (value of 16)
    ///   * DIRECTDRIVER - Direct driver (value of 17)
    ///   * DRIVER - Driver (value of 18)
    ///   * LOOPBACK - Ethernet Loopback mode (value of 19)
    ///   * ETHERNET - Ethernet protocol (value of 20)
    ///   * RSA - RSA Signature and Encryption Scheme (value of 21)
    ///   * DSA - Digital Signature Algorithm (value of 22)
    ///   * ECDSAFp- Elliptic Curve Digital Signature Algorithm Fp (value 23)
    ///   * ECDSAF2M - Elliptic Curve Digital Signature Algorithm F2M (value 24)
    ///   * ECDSAEd - Edwards Curve Digital Signature Algorithm (value 25)
    ///   * IKEV2 - Internet Key Exchange v2 (value of 26)
    ///   * INTEGRITY - Standalone integrity algorithms in testbench (value of 27)
    ///   * CONFIDENT - Standalone confidentialy algorithms in testbench (value of 28)
    ///   * BLOB - Memory blobs (value of 29)
    ///   * XMSS - XMSS Signature Scheme (value of 30)
    ///   * LMS - LMS Signature Scheme (value of 31)
    ///   * TLS13 - Version 1.3 of the TLS protocol (value of 32)
    ///   * NOPROTO - Version 1.3 of the TLS protocol (value of 33)
    ///
    /// * Error Codes in STATUS:
    ///   * ERR_NONE - No error (value of 0) 
    ///   * ERR_LATE - Anti-replay late packet error found (value of 1) 
    ///   * ERR_REPLAY - Anti-replay error found (value of 2)
    ///   * ERR_ROLLOVER - Packet number rollover error (value of 3)
    ///   * ERR_ROLLUNDER - Packet number rollunder error (value of 4)
    ///   * ERR_PROGRAM - Programming error (value of 5)
    ///   * ERR_ICV - ICV check failure (value of 6)
    ///   * ERR_CRC - CRC check failure (value of 7)
    ///   * ERR_READ_ENDOFILE - Read end of file (value of 8)
    ///   * ERR_READ_FAILFILE - Read failed in input file (value of 9)
    ///   * ERR_READ_BADFILE - Read of missing file (value of 10)
    ///   * ERR_WRITE_FAILFILE - Write to missing file (value of 11)
    ///   * ERR_WRITE_BADFILE - Write error to output file (value of 12)
    ///   * ERR_CHECKSUM - Checksum error (value of 13)
    ///   * ERR_LISTEN - TCP server received packet while listening without SYN=1 (value of 14)
    ///   * ERR_ACKNUM - TCP ACKNUM is incorrect (value of 15)
    ///   * ERR_CLOSED - TCP session CLOSED during TX/RX (value of 16)
    ///   * ERR_BITS - TCP header reserved bits error (value of 17)
    ///   * ERR_TTL - TTL field of packet is zero (value of 18)
    ///   * ERR_JUMBOGRAM_FORMAT - IPv6 JUMBOGRAM formatting error (value of 19)
    ///   * WARN_DUMMY - Dummy packet received warning (value of 20)
    ///   * WARN_IPV6_ROUTE - IPv6 Route header but not for this destination (value of 21)
    ///   * WARN_ZERO_DATA - Zero length payload warning (value of 22)
    ///   * ERR_ICMP_HDR_EXT_LEN - Header extension length is ODD for ROUTE header (value of 23)
    ///   * ERR_ICMP_SEGMENTS_LEFT - In ROUTE header, Segments left is larger than N (value of 24)
    ///   * ERR_MULTICAST_EXT_HDR - In ROUTE header, Multicast address present (value of 25)
    ///   * ERR_UNKNOWN_ROUTE_TYPE - In ROUTE header, Unknown route type (only type 0 is supported, value of 26
    ///   * ERR_CIPHER_KEY_SIZE - For the cipher requested, the key size is incorrect (value of 27)
    ///   * ERR_AUTH_KEY_SIZE - For the authentication requested, the key size is incorrect (value of 28)
    ///   * ERR_IV_SIZE - For the initialization vector requested, the size is incorrect (value of 29)
    ///   * ERR_SALT_SIZE - For the cipher salt requested, the size is incorrect (value of 30)
    ///   * ERR_ICV_SIZE - For the authentication requested, the ICV size is incorrect (value of 31)
    ///   * ERR_UNKNOWN_NXTHDR - For the IP packet, unknown NH value (value of 32)
    ///   * ERR_FORMAT_ERROR - Malformed packet (value of 33)
    ///   * WARN_INPUT_QUEUE_FULL - Send queue is full (value of 34)
    ///   * WARN_OUTPUT_QUEUE_EMPTY - Receive queue is empty (value of 35)
    ///   * ERR_SA_NOT_FOUND - Security Association not found (value of 36)
    ///   * ERR_KEY_NOKEY - The key specified is invalid or not found (value of 37)
    ///   * ERR_KEY_EXPIRED - The key specified has expired (value of 38)
    ///   * ERR_KEY_REVOKED - The key specified has been revoked (value of 39)
    ///   * ERR_KEY_ACCESS - The key exists but is not readable by the calling process or cant be modified by the user (value of 40)
    ///   * ERR_KEY_NOT_SUPP - The key type does not support reading of the payload data (value of 41)
    ///   * ERR_KEY_QUOTA - The key quota for this user would be exceeded by creating this key (value of 42)
    ///   * ERR_KEY_INVALID - The payload data was invalid (value of 43)
    ///   * ERR_KEY_REJECTED - The attempt to generate a new key was rejected (value of 44)
    ///   * ERR_KEY_NOMEM - Insufficient memory to create a key (value of 45)
    ///   * ERR_KEY_INTR - The request was interrupted by a signal (value of 46)
    ///   * ERR_RSA_INVALID_CODING - Coding of RSA decrypted data was incorrect (value of 47)
    ///   * ERR_RSA_MESSAGE_LENGTH - Decrypted RSA message length was incorrect (value of 48)
    ///   * ERR_INVALID_SIGNATURE - Signature verification failed (value of 49)
    ///   * WARN_NO_VLAN - VLAN tags did not match (value of 50)
    ///   * ERR_UNKNOWN - Unknown error (value of 51)
    ///
    /// * Line number in code where the error occurred
    ///
    //////////////////////////////////////////////////////////////////////
    uint32_t get_status();

    //////////////////////////////////////////////////////////////////////
    /// Interpret the status word and return as a printable string
    /// @param status - Status word to interpret
    /// @return Printable string representation of the status word
    //////////////////////////////////////////////////////////////////////
    std::string static str_status(uint32_t status);

    //////////////////////////////////////////////////////////////////////
    /// print the protocol and security objects as XML
    /// @param myxml - object to print to
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    virtual void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction) = 0;

    //////////////////////////////////////////////////////////////////////
    /// Convert uint8_t into a byte array
    /// @param input - uint8_t to convert
    /// @return byte array in current endian format
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> static to_array(uint8_t input);

    //////////////////////////////////////////////////////////////////////
    /// Convert uint16_t into a byte array
    /// @param input - uint16_t to convert
    /// @return byte array in current endian format
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> static to_array(uint16_t input);

    //////////////////////////////////////////////////////////////////////
    /// Convert uint32_t into a byte array
    /// @param input - uint32_t to convert
    /// @return byte array in current endian format
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> static to_array(uint32_t input);

    //////////////////////////////////////////////////////////////////////
    /// Convert uint64_t into a byte array
    /// @param input - uint64_t to convert
    /// @return byte array in current endian format
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> static to_array(uint64_t input);

    //////////////////////////////////////////////////////////////////////
    /// Convert a byte array into a uint8_t
    /// @param src_array - jarray to convert, must be 1 byte
    /// @return uint8_t in current endian format
    //////////////////////////////////////////////////////////////////////
    uint8_t static to_u8(jarray<uint8_t> src_array);

    //////////////////////////////////////////////////////////////////////
    /// Convert a byte array into a uint16_t
    /// @param src_array - jarray to convert, must be 2 or fewer bytes
    /// @return uint16_t in current endian format
    //////////////////////////////////////////////////////////////////////
    uint16_t static to_u16(jarray<uint8_t> src_array);

    //////////////////////////////////////////////////////////////////////
    /// Convert a byte array into a uint32_t
    /// @param src_array - jarray to convert, must be 4 or fewer bytes
    /// @return uint32_t in current endian format
    //////////////////////////////////////////////////////////////////////
    uint32_t static to_u32(jarray<uint8_t> src_array);

    //////////////////////////////////////////////////////////////////////
    /// Convert a byte array into a uint64_t
    /// @param src_array - jarray to convert, must be 8 or fewer bytes
    /// @return uint64_t in current endian format
    //////////////////////////////////////////////////////////////////////
    uint64_t static to_u64(jarray<uint8_t> src_array);

    //////////////////////////////////////////////////////////////////////
    /// helper functions for use with all protocols that need them
    /// Checksum calculates a 1's complement running sum across all
    /// 16-bit values in the input data. Algorithm is based on the
    /// protocol requested
    ///
    /// @param prot - protocol to calculate the checksum for
    /// @param dir - direction of the data flow
    /// @param check - data to checksum
    /// @param offset - offset into the data to clear checksum field
    /// @return array containing calculated checkum
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> checksum(iana_t prot,
                             direction_t dir,
                             jarray<uint8_t>& check,
                             unsigned int offset=0);

    //////////////////////////////////////////////////////////////////////
    /// helper functions for use with all protocols that need them
    /// Pad generates padding material to be appended to the packet if
    /// needed. Supports either ZERO, INCREMENTING, SIZE, or RANDOM padding
    ///
    /// @param padtype - Type of padding to generate (ZERO, INCREMENT, SIZE, RANDOM)
    /// @param len - the amount of padding to generate
    /// @return array containing padding requested
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> pad(pad_t padtype, unsigned int len);

protected:

    //////////////////////////////////////////////////////////////////////
    /// helper functions for use with all protocols that need them
    /// Update_replay returns a shared_ptr pointing at a new jreplay()
    /// object for anti-replay functionality
    ///
    /// @param prot   - protocol to use anti-replay
    /// @param seqnum - initial sequence number
    /// @param extseq - initial extended sequence number
    /// @param usext  - extended sequence number is used for anti-replay
    /// @param size   - number of packets to track
    /// @return shared_ptr to the anti-replay object
    //////////////////////////////////////////////////////////////////////
    template <typename T, typename TE>
    std::shared_ptr<jreplay<T,TE>> update_replay(protocol_t prot,
                                                 T& seqnum,
                                                 TE& extseq,
                                                 bool usext,
                                                 unsigned int size) {
        std::shared_ptr<jreplay<T,TE>> result = std::make_shared<jreplay<T,TE>>(m_rand, prot, seqnum, extseq, usext, size);
        return result;
    };

    //////////////////////////////////////////////////////////////////////
    /// helper functions for use with all protocols that need them
    /// Update_replay returns a shared_ptr pointing at a new jreplay()
    /// object for anti-replay functionality
    ///
    /// @param prot   - protocol to use anti-replay
    /// @param seqnum - initial sequence number
    /// @param extseq - initial extended sequence number
    /// @param usext  - extended sequence number is used for anti-replay
    /// @param size   - number of packets to track
    /// @param window - initial anti-replay window
    /// @return shared_ptr to the anti-replay object
    //////////////////////////////////////////////////////////////////////
    template <typename T, typename TE>
    std::shared_ptr<jreplay<T,TE>> update_replay(protocol_t prot,
                                                 T& seqnum,
                                                 TE& extseq,
                                                 bool usext,
                                                 unsigned int size,
                                                 jarray<uint8_t>& window) {
        std::shared_ptr<jreplay<T,TE>> result = std::make_shared<jreplay<T,TE>>(m_rand, prot, seqnum, extseq, usext, size, window);
        return result;
    };

    //////////////////////////////////////////////////////////////////////
    /// accessor functions for the status
    /// Updates the status with the new value
    ///
    /// @param stat - new value for the status
    //////////////////////////////////////////////////////////////////////
    void update_status(uint32_t stat);

    //////////////////////////////////////////////////////////////////////
    /// accessor functions for file I/O
    /// Get data accesses the file and retrieves MTU length of data from it
    /// @param data - array filled with data from the file
    /// @return returns true until EOF is reached then returns FALSE
    ///         when last packet is returned with FALSE set, the array
    ///         will be properly trimmed to the size of the remaining data
    //////////////////////////////////////////////////////////////////////
    void get_data(std::shared_ptr<jarray<uint8_t>>& data);

    //////////////////////////////////////////////////////////////////////
    /// accessor functions for file I/O
    /// Put data accesses the file and writes the payload to the file
    ///
    /// @param wdata - an array of data to write to the file
    //////////////////////////////////////////////////////////////////////
    void put_data(std::shared_ptr<jarray<uint8_t>>& wdata);

    //////////////////////////////////////////////////////////////////////
    /// Encrypt data (key, context, etc)
    /// If information needed for the protocol contains key material
    /// encrypt the data before writing to memory
    ///
    /// @param red - plaintext data to encrypt
    /// @param black - encrypted data to write to memory
    //////////////////////////////////////////////////////////////////////
    void encryptdat(std::shared_ptr<jarray<uint8_t>>& red,
                    std::shared_ptr<jarray<uint8_t>>& black);

    //////////////////////////////////////////////////////////////////////
    /// Decrypt data (key, context, etc)
    /// If information needed for the protocol has key material in it
    /// decrypt the data after reading from memory
    ///
    /// @param black - encrypted data to decrypt
    /// @param red - decrypted plaintext
    //////////////////////////////////////////////////////////////////////
    void decryptdat(std::shared_ptr<jarray<uint8_t>>& black,
                    std::shared_ptr<jarray<uint8_t>>& red);

    //////////////////////////////////////////////////////////////////////
    /// roundup the value
    /// @param value - Value to round up
    /// @param mult - Next multiple of value to round to
    /// @return value rounded up to next multiple of mult
    //////////////////////////////////////////////////////////////////////
    unsigned int roundup(unsigned int value, unsigned int mult);

    //////////////////////////////////////////////////////////////////////
    /// direction of processing
    //////////////////////////////////////////////////////////////////////
    direction_t m_dir;

    //////////////////////////////////////////////////////////////////////
    /// Status value for packet processing with format
    ///\code
    /// --------------------------------------------------------------
    /// | Protocol (8-bits) | Error (8-bits) | Line Number (16-bits) |
    /// --------------------------------------------------------------
    ///\endcode
    //////////////////////////////////////////////////////////////////////
    uint32_t m_status;

    //////////////////////////////////////////////////////////////////////
    /// random data generator passed into constructor
    //////////////////////////////////////////////////////////////////////
    std::shared_ptr<jrand> m_rand;

    //////////////////////////////////////////////////////////////////////
    /// file input string for this protocol
    //////////////////////////////////////////////////////////////////////
    std::string m_filename;
    std::fstream m_file;

    //////////////////////////////////////////////////////////////////////
    /// endianess string for this protocol
    //////////////////////////////////////////////////////////////////////
    endian_t m_endian;

private:

    // don't use these
    jprotocol() = delete;
    jprotocol(jprotocol& jprotocol) = delete;
    jprotocol(const jprotocol& jprotocol) = delete;

    bool init();
    bool activate();
    bool activateTrial();
    bool chkLicense();
};

}

#endif /* JPROTOCOL_H_ */
