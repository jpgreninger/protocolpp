#ifndef JIPSA_H_
#define JIPSA_H_

///
///\class jipsa jipsa.h "include/jipsa.h"
///
///\section IPSA_ClassSA Internet Protocol (IP) Security Association
///
/// See https://en.wikipedia.org/wiki/Internet_Protocol
///
/// The Internet Protocol (IP) is the principal communications protocol
/// in the Internet protocol suite for relaying datagrams across network
/// boundaries. Its routing function enables internetworking, and
/// essentially establishes the Internet.
///
/// IP has the task of delivering packets from the source host to the
/// destination host solely based on the IP addresses in the packet headers.
/// For this purpose, IP defines packet structures that encapsulate the data
/// to be delivered. It also defines addressing methods that are used to label
/// the datagram with source and destination information.
///
/// Historically, IP was the connectionless datagram service in the original
/// Transmission Control Program introduced by Vint Cerf and Bob Kahn in 1974;
/// the other being the connection-oriented Transmission Control Protocol (TCP).
/// The Internet protocol suite is therefore often referred to as TCP/IP.
///
/// The first major version of IP, Internet Protocol Version 4 (IPv4), is the
/// dominant protocol of the Internet. Its successor is Internet Protocol V6
///
/// The header for IPv4 is configured as follows (See RFC 791) [1]
///
///\image html IP_version4_hdr2.png "IP Version 4 Header"
///\image latex IP_version4_hdr2.eps "IP Version 4 Header" width=15cm
///
///
/// * Version:  4 bits
///
///    The Version field indicates the format of the internet header
///
/// * IHL:  4 bits
///
///    Internet Header Length is the length of the internet header in 32
///    bit words, and thus points to the beginning of the data.  Note that
///    the minimum value for a correct header is 5.
///
/// * Type of Service:  8 bits
///    
///    The Type of Service provides an indication of the abstract
///    parameters of the quality of service desired. These parameters are
///    to be used to guide the selection of the actual service parameters
///    when transmitting a datagram through a particular network.  Several
///    networks offer service precedence, which somehow treats high
///    precedence traffic as more important than other traffic (generally
///    by accepting only traffic above a certain precedence at time of high
///    load).  The major choice is a three way tradeoff between low-delay,
///    high-reliability, and high-throughput.
///
///\code
///    Bits 0-2:  Precedence
///    Bit    3:  0 = Normal Delay, 1 = Low Delay
///    Bit    4:  0 = Normal Throughput, 1 = High Throughput
///    Bit    5:  0 = Normal Relibility, 1 = High Relibility
///    Bits 6-7:  Reserved for Future Use.
///
///       0     1     2     3     4     5     6     7
///    +-----+-----+-----+-----+-----+-----+-----+-----+
///    |                 |     |     |     |     |     |
///    |   PRECEDENCE    |  D  |  T  |  R  |  0  |  0  |
///    |                 |     |     |     |     |     |
///    +-----+-----+-----+-----+-----+-----+-----+-----+
///
///    Precedence
///    
///      111 - Network Control
///      110 - Internetwork Control
///      101 - CRITIC/ECP
///      100 - Flash Override
///      011 - Flash
///      010 - Immediate
///      001 - Priority
///      000 - Routine
///\endcode
///
///   The use of the Delay, Throughput, and Reliability indications may
///   increase the cost (in some sense) of the service.  In many networks
///   better performance for one of these parameters is coupled with worse
///   performance on another.  Except for very unusual cases at most two
///   of these three indications should be set.
///
///   The type of service is used to specify the treatment of the datagram
///   during its transmission through the internet system.  Example mappings
///   of the internet type of service to the actual service provided on
///   networks such as AUTODIN II, ARPANET, SATNET, and PRNET is given in
///   "Service Mappings"
///
///   The Network Control precedence designation is intended to be used
///   within a network only.  The actual use and control of that
///   designation is up to each network. The Internetwork Control
///   designation is intended for use by gateway control originators only.
///   If the actual use of these precedence designations is of concern to
///   a particular network, it is the responsibility of that network to
///   control the access to, and use of, those precedence designations.
///
/// * Total Length:  16 bits
///
///   Total Length is the length of the datagram, measured in octets,
///   including internet header and data.  This field allows the length of
///   a datagram to be up to 65,535 octets.  Such long datagrams are
///   impractical for most hosts and networks.  All hosts must be prepared
///   to accept datagrams of up to 576 octets (whether they arrive whole
///   or in fragments).  It is recommended that hosts only send datagrams
///   larger than 576 octets if they have assurance that the destination
///   is prepared to accept the larger datagrams.
///
///   The number 576 is selected to allow a reasonable sized data block to
///   be transmitted in addition to the required header information.  For
///   example, this size allows a data block of 512 octets plus 64 header
///   octets to fit in a datagram.  The maximal internet header is 60
///   octets, and a typical internet header is 20 octets, allowing a
///   margin for headers of higher level protocols.
///
/// * Identification:  16 bits
///
///   An identifying value assigned by the sender to aid in assembling the
///   fragments of a datagram.
///
/// * Flags:  3 bits
///
///   Various Control Flags
///     Bit 0: reserved, must be zero
///     Bit 1: (DF) 0 = May Fragment, 1 = Don’t Fragment
///     Bit 2: (MF) 0 = Last Fragment, 1 = More Fragments
///
///\code
///        0   1   2 
///      +---+---+---+
///      |   | D | M |
///      | 0 | F | F |
///      +---+---+---+
///\endcode
///
/// * Fragment Offset:  13 bits
///
///   This field indicates where in the datagram this fragment belongs
///   The fragment offset is measured in units of 8 octets (64 bits).  The
///   first fragment has offset zero.
///
/// * Time to Live:  8 bits
///
///   This field indicates the maximum time the datagram is allowed to
///   remain in the internet system.  If this field contains the value
///   zero, then the datagram must be destroyed.  This field is modified
///   in internet header processing.  The time is measured in units of
///   seconds, but since every module that processes a datagram must
///   decrease the TTL by at least one even if it process the datagram in
///   less than a second, the TTL must be thought of only as an upper
///   bound on the time a datagram may exist.  The intention is to cause
///   undeliverable datagrams to be discarded, and to bound the maximum
///   datagram lifetime.
///
/// * Protocol:  8 bits
///
///   This field indicates the next level protocol used in the data
///   portion of the internet datagram.  The values for various protocols
///   are specified in "Assigned Numbers"
///
/// * Header Checksum:  16 bits
///
///   A checksum on the header only.  Since some header fields change
///   (e.g., time to live), this is recomputed and verified at each point
///   that the internet header is processed.  The checksum algorithm is:
///
///   The checksum field is the 16 bit one’s complement of the one’s
///   complement sum of all 16 bit words in the header.  For purposes of
///   computing the checksum, the value of the checksum field is zero.
///
///   This is a simple to compute checksum and experimental evidence
///   indicates it is adequate, but it is provisional and may be replaced
///   by a CRC procedure, depending on further experience.
///
/// * Source Address:  32 bits
///
///   The source address.  See section 3.2.
///      
/// * Destination Address:  32 bits
///
///   The destination address.  See section 3.2.
///
///
/// The header for IPv6 is configured as follows (see RFC 2460) [2]
///
///\image html ipv6-header.jpg "IP Version 6 Header"
///\image latex ipv6-header.eps "IP Version 6 Header" width=15cm
///
///
/// * Version:              
///
///    4-bit Internet Protocol version number = 6.
///
/// * Traffic Class:
///
///    8-bit traffic class field.  See section 7.
///
/// * Flow Label:
///
///    20-bit flow label.  See section 6.
///
/// * Payload Length:
///    
///   16-bit unsigned integer.  Length of the IPv6
///   payload, i.e., the rest of the packet following
///   this IPv6 header, in octets.  (Note that any
///   extension headers present are considered part
///   of the payload, i.e., included in the length count.)
///
/// * Next Header:
///
///   8-bit selector.  Identifies the type of header
///   immediately following the IPv6 header.  Uses the
///   same values as the IPv4 Protocol field [RFC-1700 et seq.]
///
/// * Hop Limit:
///
///   8-bit unsigned integer.  Decremented by 1 by each node
///   that forwards the packet. The packet is discarded if
///   Hop Limit is decremented to zero.
///
/// * Source Address:
///
///   128-bit address of the originator of the packet
///
/// * Destination Address:
///
///   128-bit address of the intended recipient of the packet
///   (possibly not the ultimate recipient, if a Routing header is present)
///
///
/// <B>IPv4 vs IPv6 Header Comparison [3]</B>
///
///\image html IP_hdr_comp.png "Comparison of IPv4 and IPv6 Header Fields"
///\image latex IP_hdr_comp.eps "Comparison of IPv4 and IPv6 Header Fields" width=15cm
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jip
/// @see ProtocolPP::jipsa
/// @see ProtocolPP::jicmp
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
/// @see jsecass
/// @see jprotocol
/// @see jip
/// @see jipsa
/// @see jicmp
/// @see jarray
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class jipsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor with defaults
    ///
    /// <table>
    /// <caption id="IP Defaults">IP Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::ENCAP
    /// <tr><td>ver<td>iana_t::IPV4
    /// <tr><td>nh<td>iana_t::TCP
    /// <tr><td>src<td>0xAAAAAAAA
    /// <tr><td>dst<td>0xDDDDDDDD
    /// <tr><td>exthdr<td>0
    /// <tr><td>dsecn<td>0
    /// <tr><td>ttl<td>0xFF
    /// <tr><td>flags<td>0
    /// <tr><td>fragoff<td>0
    /// <tr><td>id<td>0
    /// <tr><td>label<td>0
    /// <tr><td>jumbogram<td>true
    /// <tr><td>mtu<td>1500
    /// </table>
    ///
    ///\code
    /// jipsa snd;
    ///
    /// snd.set_field<iana_t>(field_t::NH, iana_t::UDP);
    /// snd.set_field<uint32_t>(field_t::MTU, 390);
    /// snd.set_field<bool>(field_t::JUMBOGRAM, false);
    ///\endcode
    //////////////////////////////////////////////////////////////////////
    jipsa();
    
    //////////////////////////////////////////////////////////////////////
    /// Security Association for IP
    ///
    /// Required fields for IP
    ///
    /// @param dir - Direction of data flow
    /// @param version - Version of IP to use (IPv4, IPv6)
    /// @param nh - Next header of the extension header or payload
    /// @param src - Source address (4 bytes for IPv4, 16 bytes for IPv6)
    /// @param dst - Destination address (4 bytes for IPv4, 16 bytes for IPv6)
    /// @param exthdr - Extension header to add to standard header
    /// @param dsecn - Differentiated services and Congestion bits
    /// @param ttl - Time-To-Live / Hop Limit
    /// @param jumbogram - Nodal support for IPv6 JUMBOGRAMs
    /// @param mtu - if using a file for input data, size of the payload
    ///
    /// Required IPv4 fields
    ///
    /// @param flags - Flags for the IPv4 header
    /// @param fragoff - Fragment offset
    /// @param id - ID field for IPv4 header
    ///
    /// Required IPv6 fields
    ///
    /// @param label - Label field 
    //////////////////////////////////////////////////////////////////////
    jipsa(direction_t dir,
          iana_t version,
          iana_t nh,
          jarray<uint8_t> src,
          jarray<uint8_t> dst,
          jarray<uint8_t> exthdr,
          uint8_t dsecn,
          uint8_t ttl,
          uint8_t flags,
          uint16_t fragoff,
          uint16_t id,
          uint32_t label,
          bool jumbogram,
          unsigned int mtu);

    //////////////////////////////////////////////////////////////////////
    /// standard copy constructor
    //////////////////////////////////////////////////////////////////////
    jipsa(jipsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// standard copy constructor from shared pointer
    //////////////////////////////////////////////////////////////////////
    explicit jipsa(std::shared_ptr<jipsa>& rhs);
     
    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jipsa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the IP security association
    ///
    /// <table>
    /// <caption id="IP Set Fields">IP Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::DECAP)
    /// <tr><td>iana_t<td>VERSION<td>set_field<iana_t>(field_t::VERSION, iana_t::IPV4)
    /// <tr><td><td>NH<td>set_field<iana_t>(field_t::NH, iana_t::UDP)
    /// <tr><td>jarray<uint8_t><td>SOURCE<td>set_field<jarray<uint8_t>>(field_t::SOURCE, jarray<uint8_t>("CCEE1144"))
    /// <tr><td><td>DESTINATION<td>set_field<jarray<uint8_t>>(field_t::DESTINATION, jarray<uint8_t>("4433AABB"))
    /// <tr><td><td>EXTHDR<td>set_field<jarray<uint8_t>>(field_t::EXTHDR, jarray<uint8_t>("50000104"))
    /// <tr><td>uint8_t<td>DSECN<td>set_field<uint8_t>(field_t::DSECN, 0x11)
    /// <tr><td><td>TTLHOP<td>set_field<uint8_t>(field_t::TTLHOP, 0xFF)
    /// <tr><td><td>FLAGS<td>set_field<uint8_t>(field_t::FLAGS, 0x01)
    /// <tr><td>uint16_t<td>FRAGOFFSET<td>set_field<uint16_t>(field_t::FRAGOFFSET, 0x0010)
    /// <tr><td><td>ID<td>set_field<uint16_t>(field_t::ID, 0xFFEE)
    /// <tr><td>uint32_t<td>LABEL<td>set_field<uint32_t>(field_t::LABEL, 0xAABB1155)
    /// <tr><td><td>MTU<td>set_field<uint32_t>(field_t::MTU, 0x00000040)
    /// <tr><td>bool<td>MODEJUMBO<td>set_field<uint32_t>(field_t::MODEJUMBO, true)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in jip
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    ///
    /// @param field - field to update the IP security association
    /// @param value - value to update the IP security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T value);

    //////////////////////////////////////////////////////////////////////
    /// Returns the version field of the IP security association
    ///
    /// <table>
    /// <caption id="IP Get Fields">IP Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>iana_t<td>VERSION<td>iana_t myver = get_field<iana_t>(field_t::VERSION)
    /// <tr><td><td>NH<td>iana_t mynh = get_field<iana_t>(field_t::NH)
    /// <tr><td>jarray<uint8_t><td>SOURCE<td>jarray<uint8_t> mysrc = get_field<jarray<uint8_t>>(field_t::SOURCE)
    /// <tr><td><td>DESTINATION<td>jarray<uint8_t> mydst = get_field<jarray<uint8_t>>(field_t::DESTINATION)
    /// <tr><td><td>EXTHDR<td>jarray<uint8_t> myexthdr = get_field<jarray<uint8_t>>(field_t::EXTHDR)
    /// <tr><td>uint8_t<td>DSECN<td>uint8_t mydsecn = get_field<uint8_t>(field_t::DSECN)
    /// <tr><td><td>TTLHOP<td>uint8_t myttl = get_field<uint8_t>(field_t::TTLHOP)
    /// <tr><td><td>FLAGS<td>uint8_t myflags = get_field<uint8_t>(field_t::FLAGS)
    /// <tr><td>uint16_t<td>FRAGOFFSET<td>uint16_t myoffset = get_field<uint16_t>(field_t::FRAGOFFSET)
    /// <tr><td><td>ID<td>uint16_t myid = get_field<uint16_t>(field_t::ID)
    /// <tr><td>uint32_t<td>LABEL<td>uint32_t mylabel = get_field<uint32_t>(field_t::LABEL)
    /// <tr><td><td>MTU<td>uint32_t mymtu = get_field<uint32_t>(field_t::MTU)
    /// <tr><td>bool<td>MODEJUMBO<td>bool myjumbo = get_field<uint32_t>(field_t::MODEJUMBO)
    /// </table>
    ///
    /// Due to their dynamic nature, some fields are only available in jip
    /// which include the following fields
    ///
    /// * LENGTH
    /// * CHECKSUM
    ///
    /// @param field - field to retrieve from the IP security association
    /// @return field of the IP security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol object in XML
    /// @param myxml - XMLPrinter object to print to
    /// @param direction - randomzation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jipsa(const jipsa& jip) = delete;
    
    // member variables
    direction_t m_dir;
    iana_t m_ver;
    iana_t m_nh;
    jarray<uint8_t> m_src;
    jarray<uint8_t> m_dst;
    jarray<uint8_t> m_exthdr;
    uint8_t m_dsecn;
    uint8_t m_ttl;
    uint8_t m_flags;
    uint16_t m_fragoff;
    uint16_t m_id;
    uint32_t m_label;
    bool m_jumbogram;
    unsigned int m_mtu;
    jarray<uint8_t> m_iphdr;
    unsigned int m_hdrlen;
};

}

#endif // JIPSA_H_
