#ifndef JPROTOCOL_JRAND_H_
#define JPROTOCOL_JRAND_H_

///
///\class jrand jrand.h "include/jrand.h"
///
///\section JRANDC Randomization Class for Protocol++&reg; (ProtocolPP&reg;)
///
/// This class is the randomization class for all of ProtocolPP&reg; (Protocol++&reg;) and
/// supports generating random char, bytes, words, longs, strings, and integers
///
/// The core of the randomizer is the Merseene-Twister. The randomizer object
/// can be created with one of three constructors. The default constructor 
/// creates a randomizer that is seeded with the default seed of 1234567890
///\code
///
/// // Standard constructor for the jrand
/// jrand();
///\endcode
/// To improve the entropy of the randomizer, it can also be created using
/// a long integer or by using an array of long integers
///\code
///
/// // Constructor for jrand that accepts an unsigned int for the seed
/// jrand(unsigned long myseed);
///\endcode
/// Additional entropy may be added by using the seed() methods to reseed
/// the object
///\code
///    
/// // Constructor for jrand that accepts an unsigned int for the seed
/// jrand(const unsigned long *newseed, int size);
///\endcode
/// The getname() and getstring() functions allow the user to obtain a randomly
/// generated name or to choose a string from a list of colon separated values
/// Names are generated from a-zA-Z0-9, no special characters are used
///\code
///
/// // generates random name of 12 characters
/// std::string newname = getname(12);
///
/// // selects on from the list of strings
/// std::string newstr = getstring("missy:david:mary:tomtom");
///\endcode 
/// The functions that return an array of values can be called in two different
/// ways, either by asking for an amount of random data or by asking for a range
/// of data. For example to ask for 200 bytes of the random data, the user would
/// try
///\code
///
/// jarray<uint8_t> newdata = myrand.getbyte(200);
///\endcode
/// To obtain a random amount of data from 500 to 1000 bytes, the user would call
///\code
///
/// jarray<uint8_t> newdata = myrand.getbyte("500..1000");
///\endcode
/// This second call would first randomly select the length of bytes between 500
/// and 1000, they it would generate and return the bytes for that length as an
/// array
///
/// The randomization class also allows the user to ask for a single object of the
/// the type requested. To obtain a uint64_t the call would be
///\code
///
/// uint64_t newdata = myrand.get_u64();
///\endcode
/// To generate cryptographically secure keys and data, jrand provides access to the
/// hardware random number generator on the device being use. The can be accomplished
/// by use the function
///\code
///
/// // return 16 bytes from the hardware random generator
/// jarray<uint8_t> crypto = myrand.get_crypto(16);
///\endcode
/// Finally, a tokenizer is provided with a static interface to allow the user to
/// parse strings and obtain the delimited result. In jrand this is mainly used to
/// parse ranges but can be used for any string. Use is
///\code
///
/// std::vector<std::string> split = jrand::tokenizer("Olympia:Boise:Medford", ":");
///\endcode
/// This randomizer also supports a special mode that allows a large number of SIMD
/// generated data to be obtained from the process. It requires that this class be
/// compiled with the define SMFT_MODE
///
/// SMFT_MODE periodically generates a large pool of random data from the processor
/// that can be used by the random object. If the next request depletes the current
/// store of random data, the random object will ask the process to refill it's
/// "well". The randomization object will get a "bucket" from the "well" to fill it's
/// array. Data in these large amounts are generated with SIMD commands
///
/// See the header file \ref SFMT.h for additional information
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jarray
///
/// <B>For Additional Documentation:</B>
/// @see jarray
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <cstring>
#include "jarray.h"
#include <random>
#include <cstdio>
#include <climits>
#include <ctime>
#include <cstring>
#include <cstdlib>
#include "SFMT.h"
#include <netinet/in.h>

//#define SFMT_MODE

namespace ProtocolPP {

class jrand {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor for the jrand
    /// class. Seeded with 0x5489UL
    //////////////////////////////////////////////////////////////////////
    jrand();
    
    //////////////////////////////////////////////////////////////////////
    /// Constructor for jrand that accepts an unsigned int for the seed
    /// @param myseed - seed to initialize psuedo-random number generator
    //////////////////////////////////////////////////////////////////////
    explicit jrand(unsigned long myseed);
    
    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jrand() {}
    
    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a random boolean from the random number
    /// generator
    /// @return randomly choosen True or False
    //////////////////////////////////////////////////////////////////////
    bool getbool();
    
    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a random name from the random number
    /// generator
    /// @param length - length of random string to generate
    /// @return randomly generated name
    //////////////////////////////////////////////////////////////////////
    std::string getname(unsigned int length);
    
    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a random string from the random number
    /// generator
    /// @param input - string of colon separated strings to choose from
    /// @return randomly selected string from the input
    //////////////////////////////////////////////////////////////////////
    std::string getstr(const char* input);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of bytes from the random number
    /// generator
    /// @param amount - number of bytes to generate
    /// @return Array of random bytes
    //////////////////////////////////////////////////////////////////////
    jarray<char> getchar(unsigned int amount);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of bytes from the random number
    /// generator
    /// @param amount - number of bytes to generate
    /// @return Array of random bytes
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> getbyte(unsigned int amount);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of bytes from the random number
    /// generator
    /// @param range - String representing a range of sizes ex., "1..256"
    /// @param mult - Round the length of the byte array up to the next multiple
    /// @return Array of random bytes
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> getbyte(const char* range, unsigned int mult=0);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of uint16_t from the random number
    /// generator
    /// @param amount - number of uint16_t to generate
    /// @return Array of random uint16_t
    //////////////////////////////////////////////////////////////////////
    jarray<uint16_t> getu16(unsigned int amount);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of shorts from the random number
    /// generator
    /// @param range - String representing a range of sizes ex., "1..256"
    /// @return Array of random shorts 
    //////////////////////////////////////////////////////////////////////
    jarray<uint16_t> getu16(const char* range);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of uint32_t from the random number
    /// generator
    /// @param amount - number of uint32_t to generate
    /// @return Array of random uint32_t
    //////////////////////////////////////////////////////////////////////
    jarray<uint32_t> getword(unsigned int amount);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of words from the random number
    /// generator
    /// @param range - String representing a range of sizes ex., "1..256"
    /// @return Array of random words
    //////////////////////////////////////////////////////////////////////
    jarray<uint32_t> getword(const char* range);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of uint64_t from the random number
    /// generator
    /// @param amount - number of uint64_t to generate
    /// @return Array of random uint64_t
    //////////////////////////////////////////////////////////////////////
    jarray<uint64_t> getdouble(unsigned int amount);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain an array of double words from the random number
    /// generator
    /// @param range - String representing a range of sizes ex., "1..256"
    /// @return Array of random double words
    //////////////////////////////////////////////////////////////////////
    jarray<uint64_t> getdouble(const char* range);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random integer from the random number
    /// generator
    /// @return integer
    //////////////////////////////////////////////////////////////////////
    int get_int();

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random integer from the random number
    /// generator
    /// @param range Range of integers to randomize over. Can either be
    ///              of the form "1..32" or "16:32:64"
    /// @return integer
    //////////////////////////////////////////////////////////////////////
    int get_int(const char* range);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random unsigned integer from the random number
    /// generator
    /// @param range Range of integers to randomize over. Can either be
    ///              of the form "1..32" or "16:32:64"
    /// @return integer
    //////////////////////////////////////////////////////////////////////
    unsigned int get_uint(const char* range);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random byte from the random number
    /// generator
    /// @return uint8_t
    //////////////////////////////////////////////////////////////////////
    uint8_t get_u8();

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random uint16_t from the random number
    /// generator
    /// @return uint16_t
    //////////////////////////////////////////////////////////////////////
    uint16_t get_u16();

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random uint32_t from the random number
    /// generator
    /// @return uint32_t
    //////////////////////////////////////////////////////////////////////
    uint32_t get_u32();

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain a single random uint64_t from the random number
    /// generator
    /// @return uint64_t
    //////////////////////////////////////////////////////////////////////
    uint64_t get_u64();

    //////////////////////////////////////////////////////////////////////
    /// Method to reseed generator with unsigned long
    /// @param myseed - new seed for random number generator
    //////////////////////////////////////////////////////////////////////
    void seed(unsigned long myseed);

    //////////////////////////////////////////////////////////////////////
    /// Method to obtain cryptographic random data to be used for keys,
    /// salt, IV
    /// @param size - length of cryptographic data
    /// @return array filled with hardware generated random numbers
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_crypto(unsigned int size);

    //////////////////////////////////////////////////////////////////////
    /// tokenize the string 
    /// @param input - String to tokenize
    /// @param delimiters - Delimiters to split the string (with no spaces e.g., "-,.|")
    /// @return vector containing tokens
    //////////////////////////////////////////////////////////////////////
    static std::vector<std::string> tokenizer(const char* input, const char* delimiters);

private:

    // don't use these
    jrand(jrand& rhs) = delete;
    jrand(const jrand& rhs) = delete;

#ifdef SFMT_MODE
    // get data from well
    jarray<uint8_t> get_well(unsigned int amount);
    unsigned int empty_well(unsigned int amount);
    uint8_t* get_bucket();
    bool get_init() { return m_init; }
    void init() { m_init = true; }
#endif

    // get data
    jarray<uint8_t> get_data(unsigned int amount);

    // Merseene Twister random number generator
    std::mt19937 m_rand;

#ifdef SFMT_MODE
    // variables for SIMD data generation
    sfmt m_sfmt;
    unsigned int m_idx;
    jarray<uint8_t> m_well;
    bool m_init;
#endif

    // alphabet for random numbers
    std::vector<char> m_letters;

    // hardware generated random numbers
    std::random_device m_randp;
};

}

#endif // JPROTOCOL_JRAND_H_
