#ifndef JPROTOCOL_JPACKET_H_
#define JPROTOCOL_JPACKET_H_

///
///\class jpacket jpacket.h "include/jpacket.h"
///
///\section PKT Packet class for Protocol++&reg; (ProtocolPP&reg;)
///
/// This class is the packet object for Protocol++&reg;. Each packet has certain elements that are required to allow
/// simulations to work correctly. Each packet needs to know what stream it's associated with, where it's input
/// data, output memory location, and expected data are, what packet preceeds this one (if it's the first packet
/// in the stream, prev=begin). It also will contain the status of the packet after it has run. Length of the
/// output buffer is also included so that the DUT or responder will not overwrite the buffer
///
/// A packet can be created with each of the constructors. If expected data and output is unknown at time of
/// construction, the first constructor can be used as
///\code
///
/// jpacket pkt1(std::string("stream1"),
///              std::string("pkt1"),
///              std::string("pkt0"),
///              inputdata,
///              0);
///\endcode
/// Output, length, and expected can be added later when known with the accessor functions
///\code
///
/// set_field<uint64_t>(field_t::OUTADDR, pkt1outaddr);
///
/// set_field<unsigned int>(field_t::OUTLEN, pkt1outlen);
///\endcode
/// Expected values are passed as an array wrapped in a shared pointer using
///\code
///
/// set_expected(pkt1exp);
///\endcode
/// After a packet has finished, it's status can be updated with
///\code
///
/// set_field<uint32_t>(field_t::STATUS, pkt1status);
///\endcode
///
/// If everything but the output address is available at the time of construction, the second constructor
/// can be used as follows:
///\code
///
/// jpacket(std::string("stream2"),
///         std::string("pkt2"),
///         std::string("pkt1"),
///         inputdata2,
///         expectdata2,
///         1500,
///         0);
///\endcode
///
/// If all items are are available at the time of construction, the third constuctor can be used as
/// follows:
///\code
///
/// jpacket(std::string("stream3"),
///         std::string("pkt3"),
///         std::string("pkt2"),
///         inputdata3,
///         expectdata3,
///         0x00001FAB00112233,
///         390,
///         0);
///\endcode
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jpacket
/// @see ProtocolPP::jstream
/// @see ProtocolPP::jdata
///
/// <B>For Additional Documentation:</B>
/// @see jarray
/// @see jpacket
/// @see jstream
/// @see jdata
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <memory>
#include <string>
#include "jarray.h"

namespace ProtocolPP {

class jpacket {

public :

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jpacket
    /// @param stream - name of the stream this packet belongs to
    /// @param name - unique name of the packet
    /// @param prev - name of the previous packet (may be 'start')
    /// @param input - shared pointer to input data
    /// @param status - expected status of the packet
    //////////////////////////////////////////////////////////////////////
    jpacket(std::string stream,
            std::string name,
            std::string prev,
            std::shared_ptr<jarray<uint8_t>>& input,
            uint32_t status=0);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jpacket
    /// @param stream - name of the stream this packet belongs to
    /// @param name - unique name of the packet
    /// @param prev - name of the previous packet (may be 'start')
    /// @param input - shared pointer to input data
    /// @param expect - shared pointer to expected data
    /// @param outlen - length of the output data
    /// @param status - expected status of the packet
    //////////////////////////////////////////////////////////////////////
    jpacket(std::string stream,
            std::string name,
            std::string prev,
            std::shared_ptr<jarray<uint8_t>>& input,
            std::shared_ptr<jarray<uint8_t>>& expect,
            unsigned int outlen=0,
            uint32_t status=0);

    //////////////////////////////////////////////////////////////////////
    /// Constructor for jpacket
    /// @param stream - name of the stream this packet belongs to
    /// @param name - unique name of the packet
    /// @param prev - name of the previous packet (may be 'start')
    /// @param input - shared pointer to input data
    /// @param expect - shared pointer to expected data
    /// @param outaddr - Address of the output memory location
    /// @param outlen - length of the output data
    /// @param status - expected status of the packet
    //////////////////////////////////////////////////////////////////////
    jpacket(std::string stream,
            std::string name,
            std::string prev,
            std::shared_ptr<jarray<uint8_t>>& input,
            std::shared_ptr<jarray<uint8_t>>& expect,
            uint64_t outaddr,
            unsigned int outlen=0,
            uint32_t status=0);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jpacket() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field in JPACKET
    ///
    /// <table>
    /// <caption id="packet_set">JPACKET Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>std::string <td>STREAM<td>set_field<std::string>(field_t::STREAM, std::string("ALIBABA"))
    /// <tr><td>std::string <td>NAME<td>set_field<std::string>(field_t::NAME, std::string("ALIBABA"))
    /// <tr><td>std::string <td>PREVIOUS<td>set_field<std::string>(field_t::PREVIOUS, std::string("ALIBABA"))
    /// <tr><td>uint64_t <td>OUTADDR<td>set_field<uint64_t>(field_t::OUTADDR, 0xAAFFDDEEFF112233)
    /// <tr><td>unsigned int <td>OUTLEN<td>set_field<uint32_t>(field_t::OUTLEN, 1500)
    /// <tr><td>uint32_t <td>STATUS<td>set_field<uint32_t>(field_t::STATUS, 0x03100123)
    /// </table>
    ///
    /// @param field - field to update
    /// @param fieldval - value to update the field with
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Set the input data for this packet
    ///\code
    /// std::shared_ptr<jarray<uint8_t>> mydata = std::make_shared<jarray<uint8_t>>(50, 0xAA);
    /// set_data(field_t::INPUT, mydata);
    /// set_data(field_t::OUTPUT, mydata);
    /// set_data(field_t::EXPECT, mydata);
    ///\endcode
    /// @param field - Data field to set
    /// @param data - Array to place the data in
    //////////////////////////////////////////////////////////////////////
    void set_data(field_t field, std::shared_ptr<jarray<uint8_t>>& data);

    //////////////////////////////////////////////////////////////////////
    /// Returns the field in JPACKET
    ///
    /// <table>
    /// <caption id="packet_get">JPACKET Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>std::string <td>STREAM<td>std::string myname = get_field<std::string>(field_t::STREAM)
    /// <tr><td>std::string <td>NAME<td>std::string myname = get_field<std::string>(field_t::NAME)
    /// <tr><td>std::string <td>PREVIOUS<td>std::string myname = get_field<std::string>(field_t::PREVIOUS)
    /// <tr><td>uint64_t <td>OUTADDR<td>uint64_t myoutaddr = get_field<uint64_t>(field_t::OUTADDR)
    /// <tr><td>uint32_t <td>OUTLEN<td>unsigned int myinlen = get_field<uint32_t>(field_t::OUTLEN)
    /// <tr><td>uint32_t <td>INLEN<td>unsigned int myinlen = get_field<uint32_t>(field_t::INLEN)
    /// <tr><td>uint32_t <td>OUTPUTLEN<td>unsigned int myinlen = get_field<uint32_t>(field_t::OUTPUTLEN)
    /// <tr><td>uint32_t <td>EXPLEN<td>unsigned int myinlen = get_field<uint32_t>(field_t::EXPLEN)
    /// <tr><td>uint32_t <td>STATUS<td>uint32_t mystatus = get_field<uint32_t>(field_t::STATUS)
    /// </table>
    ///
    /// @param field - field to retrieve from the IP header
    /// @return value of the field in the security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Get the data for this packet
    ///\code
    /// std::shared_ptr<jarray<uint8_t>> mydata = std::shared_ptr<jarray<uint8_t>>(50,0);
    /// get_data(field_t::INPUT, mydata);
    /// get_data(field_t::OUTPUT, mydata);
    /// get_data(field_t::EXPECT, mydata);
    ///\endcode
    /// @param field - Data field to set
    /// @param data - Array to place the data in
    //////////////////////////////////////////////////////////////////////
    void get_data(field_t field, std::shared_ptr<jarray<uint8_t>>& data);

private:

    // don't use these
    jpacket() = delete;
    jpacket(jpacket& rhs) = delete;
    jpacket(const jpacket& rhs) = delete;

    // member variables
    std::string m_stream;
    std::string m_name;
    std::string m_prev;
    std::shared_ptr<jarray<uint8_t>> m_in;
    std::shared_ptr<jarray<uint8_t>> m_out;
    std::shared_ptr<jarray<uint8_t>> m_exp; 
    uint64_t m_outaddr;
    unsigned int m_outlen;
    uint32_t m_status;
};

}

#endif // JPROTOCOL_JPACKET_H_
