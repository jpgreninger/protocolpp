#ifndef JWIMAXSA_H_
#define JWIMAXSA_H_

///
///\class jwimaxsa jwimaxsa.h "include/jwimaxsa.h"
///
///\section WiMax_ClassSASA WiMax Protocol Security Association (WiMax SA)
///
/// See IEEE802.16e-2005 and IEEE802.16-2004 for the following
///
/// <B>WiMAX MAC PDUS (See Joint Source-Channel Decoding Appendix Z)</B>
///
/// As seen in Section Z.2, in DL subframes, several MAC PDUs are aggregated in bursts.
/// Section 8.3, page 232, presents techniques for performing a reliable burst segmentation
/// in the presence of noise. The content of each MAC PDU is introduced below.
///
/// Each MAC PDU begins with a ﬁxed-size header, followed by a variable length payload 
/// and an optional CRC.There are two types of MAC PDU headers
///
/// * The generic MAC header (GMH) is the header of MAC frames containing either MAC
///   management messages or CS data.The CS data may be user data or other higher layer
///   management data. The generic MAC header frame is the only one used in downlink
///
/// * The bandwidth request header (BRH) is not followed by any MAC PDU payload or CRC. This
///   frame name has been introduced by the 802.16e amendment. Previously, in 802.16-2004,
///   the BRH was deﬁned to request additional bandwidths. The content of these headers is
///   presented in what follows.
///
///
/// <B>Generic MAC Header (IEEE802.16-2004)</B>
/// 
/// As we are considering only the downlink case, where the connection is already established
/// and MAC PDUs inside the BS contain only CS data, so only the
///
///\image html WiMax_GMH.png "Generic MAC Header (GMH) for WiMax Packets"
///\image latex WiMax_GMH.eps "Generic MAC Header (GMH) for WiMax Packets" width=15cm
///
/// GMH is possible inside BB. Format of GMH as speciﬁed in IEEE 802.16-2004 (IEEE, 2004) is illustrated
/// in Figure Z.2. The various ﬁelds of a GMH are as follows
///
/// * The Header Type (HT) consists of a single bit set to 0 for GMH
/// 
/// * The Encryption Control(EC) ﬁeld speciﬁes whether the payload is encrypted or not and is set to 0
///   when the payload is not encrypted and to 1 when it is encrypted
///
/// * The Type ﬁeld indicates the subheaders and special payload types present in the message payload
///   (ﬁve possible subheader types)
/// 
/// * The Reserved (Rsv) ﬁeld is of one bit and is set to 0
/// 
/// * The CRC Indicator (CI) ﬁeld is a single bit set to 1 if a CRC is included and is set to 0 if no
///   CRC is included
/// 
/// * The Encryption Key Sequence (EKS) ﬁeld is two bits. It is the index of the Trafﬁc Encryption Key
///   (TEK) and initialization vector used to encrypt the payload. Obviously, this ﬁeld is only meaningful
///   if the EC ﬁeld is set to 1
///
/// * The Reserved (Rsv) ﬁeld is of one bit and is set to 0
///
/// * The Length (LEN) ﬁeld is 11 bits long. It speciﬁes the length in bytes of the MAC PDU including the
///   MAC header and the CRC, if present
/// 
/// * The Connection IDentiﬁer (CID) ﬁeld is 16 bits long and represents the connection identiﬁer of the user
/// 
/// * The Header Check Sequence (HCS) ﬁeld is 8 bits long and is used to detect errors in the header.
///
///
/// <B>Generic MAC Header (IEEE802.16e-2005 with ESF bit)</B>
/// 
/// As we are considering only the downlink case, where the connection is already established
/// and MAC PDUs inside the BS contain only CS data, so only the
///
///\image html WiMax_GMH_ESF.png "ESF Bit Usage and Formatting in WiMax Packets"
///\image latex WiMax_GMH_ESF.eps "ESF Bit Usage and Formatting in WiMax Packets" width=15cm
///
/// GMH is possible inside BB. Format of GMH as speciﬁed in IEEE 802.16-2004 (IEEE, 2004) is illustrated
/// in Figure Z.2. The various ﬁelds of a GMH are as follows
///
/// * The Header Type (HT) consists of a single bit set to 0 for GMH
/// 
/// * The Encryption Control(EC) ﬁeld speciﬁes whether the payload is encrypted or not and is set to 0
///   when the payload is not encrypted and to 1 when it is encrypted
///
/// * The Type ﬁeld indicates the subheaders and special payload types present in the message payload
///   (ﬁve possible subheader types)
/// 
/// * The Extended Subheader Field(ESF) ﬁeld consists of a single bit set to 1 if the extended subheader
///   is present and follows the GMH immediately (applicable in both the downlink and uplink)
///
/// * The CRC Indicator (CI) ﬁeld is a single bit set to 1 if a CRC is included and is set to 0 if no
///   CRC is included
/// 
/// * The Encryption Key Sequence (EKS) ﬁeld is two bits. It is the index of the Trafﬁc Encryption Key
///   (TEK) and initialization vector used to encrypt the payload. Obviously, this ﬁeld is only meaningful
///   if the EC ﬁeld is set to 1
///
/// * The Reserved (Rsv) ﬁeld is one bit and is set to 0
///
/// * The Length (LEN) ﬁeld is 11 bits long. It speciﬁes the length in bytes of the MAC PDU including the
///   MAC header and the CRC, if present
/// 
/// * The Connection IDentiﬁer (CID) ﬁeld is 16 bits long and represents the connection identiﬁer of the user
/// 
/// * The Header Check Sequence (HCS) ﬁeld is 8 bits long and is used to detect errors in the header.
///
///
/// <B>MAC header formats</B>
///
/// There are three defined MAC header formats: the advanced generic MAC header, the Short-Packet
/// MAC header, and the MAC signaling header. At any connection, only one of the following formats
/// shall be used: advanced generic MAC header, short-packet MAC header, and MAC signaling header
///
///
/// <B>Advanced generic MAC header (AGMH)</B>
///
/// The AGMH format is defined in Table 6-2. For E-MBS services, the FID shall be ignored by the
/// receiver. For multicast service, the multicast-specific FID associated with Multicast Group ID
/// shall be used in the FID field of AGMH 
///
///\image html WiMax_AGMH.png "Advanced Generic MAC (AGMH) Header for WiMax Packets"
///\image latex WiMax_AGMH.eps "Advanced Generic MAC (AGMH) Header for WiMax Packets" width=15cm
///
/// <B>Short-packet MAC header (SPMH)</B>
///
/// The SPMH is defined to support applications, such as Voice over IP (VoIP), that utilize small
/// data packets and non-ARQ connections. The extended header group may be piggybacked on the SPMH,
/// if allowed by its length field. The SPMH is identified by the specific FID that is provisioned
/// statically, or created dynamically via AAI-DSA-REQ/RSP
///
///\image html WiMax_SPMH.png "Formatting for Short-Packet MAC Header (SPMH) in WiMax Packets"
///\image latex WiMax_SPMH.eps "Formatting for Short-Packet MAC Header (SPMH) in WiMax Packets" width=15cm
///
/// <B>MAC signaling header</B>
///
/// The signaling header shall be sent standalone or concatenated with other MAC PDUs in either DL
/// or UL. One FID is reserved for the MAC signaling header. The value of FID for the MAC signaling
/// header is 0010
///
/// All MAC signaling header formats follow the layout defined in Table 6-4.
///
///\image html WiMax_SIG.png "Formatting for MAC Signaling Header in WiMax Packets"
///\image latex WiMax_SIG.eps "Formatting for MAC Signaling Header in WiMax Packets" width=15cm
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jwimaxsa
/// @see ProtocolPP::jwimax
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jsecass
/// @see jmodes
/// @see jwimaxsa
/// @see jwimax
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///
    
#include "jsecass.h"

namespace ProtocolPP {

class jwimaxsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard Constructor
    ///
    /// <table>
    /// <caption id="WIMAX Defaults">WIMAX Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::ENCAP
    /// <tr><td>mode<td>wimaxmode_t::OFDM
    /// <tr><td>cipher<td>cipher_t::AES_CCM
    /// <tr><td>auth<td>auth_t::SHA256
    /// <tr><td>type<td>0
    /// <tr><td>eks<td>0
    /// <tr><td>fid<td>0
    /// <tr><td>cid<td>0
    /// <tr><td>pn<td>0
    /// <tr><td>ckeylen<td>16
    /// <tr><td>cipherkey<td>0
    /// <tr><td>arlen<td>0
    /// <tr><td>arwin<td>0
    /// <tr><td>eh<td>false
    /// <tr><td>ht<td>false
    /// <tr><td>ec<td>true
    /// <tr><td>esf<td>false
    /// <tr><td>ci<td>true
    /// </table>
    //////////////////////////////////////////////////////////////////////
    jwimaxsa();

    //////////////////////////////////////////////////////////////////////
    /// Security Association for Wimax 
    ///
    /// @param dir - Direction of processing (ENCAP or DECAP)
    /// @param mode - Mode of operation (OFDM, OFDMA, AGHM_OFDM, AGHM_OFDMA)
    /// @param cipher - Encryption (AES_CCM, SM4_CCM, NULL_CIPHER)
    /// @param type - types and subheaders in payload
    /// @param eks - Encryption key sequence
    /// @param cid - Connection Identifier
    /// @param fid - Flow Identifier (AGHM header only)
    /// @param pn - Packet number (for counter modes PN=ROC[7:0]|PN[23:0])
    /// @param ckeylen - Length of the key
    /// @param cipherkey - Key for the encryption algorithm
    /// @param arlen - Number of packets to track in replay window
    /// @param arwin - Anti-replay window for tracking packets
    /// @param eh - Extended header group presence identifier (AGHM header only)
    /// @param ht - Header type
    /// @param ec - Encryption control
    /// @param esf - Extended subheader present
    /// @param ci - CRC Indicator
    //////////////////////////////////////////////////////////////////////
    jwimaxsa(direction_t dir,
             wimaxmode_t mode,
             cipher_t cipher,
             uint8_t  type,
             uint8_t  eks,
             uint8_t  fid,
             uint16_t cid,
             uint32_t pn,
             unsigned int ckeylen,
             std::shared_ptr<jarray<uint8_t>> cipherkey,
             unsigned int arlen,
             jarray<uint8_t> arwin,
             bool eh,
             bool ht,
             bool ec,
             bool esf,
             bool ci);

    //////////////////////////////////////////////////////////////////////
    /// Copy constructor for wimax security association 
    /// @param rhs - Security association (SA) for this wimax flow
    //////////////////////////////////////////////////////////////////////
    jwimaxsa(jwimaxsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Copy constructor for wimax security association from shared pointer 
    /// @param rhs - Security association (SA) for this wimax flow
    //////////////////////////////////////////////////////////////////////
    explicit jwimaxsa(std::shared_ptr<jwimaxsa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jwimaxsa() {
        m_cipherkey.serase();
    }

    //////////////////////////////////////////////////////////////////////
    /// Update WIMAX field with the new value
    ///
    /// <table>
    /// <caption id="WIMAX Set Fields">WIMAX Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP)
    /// <tr><td>wimaxmode_t<td>MODE<td>set_field<wimaxmode_t>(field_t::MODE, wimaxmode_t::OFDMA)
    /// <tr><td>cipher_t<td>CIPHER<td>set_field<cipher_t>(field_t::CIPHER, cipher_t::AES_CCM)
    /// <tr><td>bool<td>EH<td>set_field<bool>(field_t::EH, true)
    /// <tr><td><td>HT<td>set_field<bool>(field_t::HT, false)
    /// <tr><td><td>EC<td>set_field<bool>(field_t::EC, true)
    /// <tr><td><td>ESF<td>set_field<bool>(field_t::ESF, false)
    /// <tr><td><td>CI<td>set_field<bool>(field_t::CI, true)
    /// <tr><td>uint8_t<td>TYPE<td>set_field<uint8_t>(field_t::TYPE, 0)
    /// <tr><td><td>EKS<td>set_field<uint8_t>(field_t::EKS, 0)
    /// <tr><td><td>FID<td>set_field<uint8_t>(field_t::FID, 0)
    /// <tr><td>uint16_t<td>CID<td>set_field<uint16_t>(field_t::CID, 0)
    /// <tr><td>uint32_t<td>PN<td>set_field<uint32_t>(field_t::PN, 1)
    /// <tr><td><td>CKEYLEN<td>set_field<uint32_t>(field_t::CKEYLEN, 1)
    /// <tr><td><td>ARLEN<td>set_field<uint32_t>(field_t::ARLEN, 1)
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>set_field<jarray<uint8_t>>(field_t::ARWIN, jarray<uint8_t>("000000000000000001")
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, std::shared_ptr<jarray<uint8_t>>("000000000000000001"))
    /// </table>
    ///
    /// @param field - field to update
    /// @param fieldval - new value for the field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the field from the wimax header
    ///
    /// <table>
    /// <caption id="WIMAX Get Fields">WIMAX Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>wimaxmode_t<td>MODE<td>wimaxmode_t mymode = get_field<wimaxmode_t>(field_t::MODE)
    /// <tr><td>cipher_t<td>CIPHER<td>cipher_t mycipher = get_field<cipher_t>(field_t::CIPHER)
    /// <tr><td>bool<td>EH<td>bool myeh = get_field<bool>(field_t::EH)
    /// <tr><td><td>HT<td>bool myht = get_field<bool>(field_t::HT)
    /// <tr><td><td>EC<td>bool myec = get_field<bool>(field_t::EC)
    /// <tr><td><td>ESF<td>bool myesf = get_field<bool>(field_t::ESF)
    /// <tr><td><td>CI<td>bool myci = get_field<bool>(field_t::CI)
    /// <tr><td>uint8_t<td>TYPE<td>uint8_t mytype = get_field<uint8_t>(field_t::TYPE)
    /// <tr><td><td>EKS<td>uint8_t myeks = get_field<uint8_t>(field_t::EKS)
    /// <tr><td><td>FID<td>uint8_t myfid = get_field<uint8_t>(field_t::FID)
    /// <tr><td>uint16_t<td>CID<td>uint16_t mycid = get_field<uint16_t>(field_t::CID)
    /// <tr><td>uint32_t<td>PN<td>uint32_t mypn = get_field<uint32_t>(field_t::PN)
    /// <tr><td><td>CKEYLEN<td>uint32_t myckeylen = get_field<uint32_t>(field_t::CKEYLEN)
    /// <tr><td><td>ARLEN<td>uint32_t myarlen = get_field<uint32_t>(field_t::ARLEN)
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>jarray<uint8_t> myarwin = get_field<jarray<uint8_t>>(field_t::ARWIN)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>CIPHERKEY<td>std::shared_ptr<jarray<uint8_t>> myckey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY)
    /// </table>
    ///
    /// @param field - field to retrieve
    /// @return field value
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Print the protocol and security objects to XML
    /// @param myxml - XMLPrinter object for printing
    /// @param direction - facilitator for random generation
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jwimaxsa(const jwimaxsa& rhs) = delete;

    // member variables
    direction_t m_dir;
    wimaxmode_t m_mode;
    cipher_t m_cipher;
    uint8_t m_type;
    uint8_t m_eks;
    uint8_t m_fid;
    uint16_t m_cid;
    uint32_t m_pn;
    unsigned int m_ckeylen;
    jarray<uint8_t> m_cipherkey;
    unsigned int m_arlen;
    jarray<uint8_t> m_arwin;
    bool m_eh;
    bool m_ht;
    bool m_ec;
    bool m_esf;
    bool m_ci;
};

}

#endif // JWIMAXSA_H_
