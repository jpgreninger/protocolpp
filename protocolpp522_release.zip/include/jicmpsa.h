#ifndef JICMPSA_H_
#define JICMPSA_H_

///
///\class jicmpsa jicmpsa.h "include/jicmpsa.h"
///
///\section ICMPSA_ClassSA Internet Control Message Protocol Security Association (ICMPSA)
///
/// See https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol
///
/// The Internet Control Message Protocol (ICMP) is one of the main protocols of the internet protocol
/// suite. It is used by network devices, like routers, to send error messages indicating, for example,
/// that a requested service is not available or that a host or router could not be reached. ICMP can
/// also be used to relay query messages.[1] It is assigned protocol number 1.[2] ICMP[3] differs from
/// transport protocols such as TCP and UDP in that it is not typically used to exchange data between
/// systems, nor is it regularly employed by end-user network applications (with the exception of some
/// diagnostic tools like ping and traceroute)
///
/// <B>ICMP_STRUCT ICMP datagram structure</B>
///
/// <B>Header</B>
///
/// The ICMP header starts after the IPv4 header and is identified by IP protocol number '1'. All ICMP
/// packets have an 8-byte header and variable-sized data section. The first 4 bytes of the header
/// have fixed format, while the last 4 bytes depend on the type/code of that ICMP packet
///
///\image html ICMP_Header.png "ICMP Version 4 Header [1]"
///\image latex ICMP_Header.eps "ICMP Version 4 Header [1]" width=15cm
///
/// <B>Type</B> 
///
/// ICMP type, see Control messages
///
/// <B>Code</B> 
///
/// ICMP subtype, see Control messages
///
/// <B>Checksum</B> 
///
/// Error checking data, calculated from the ICMP header and data, with value 0 substituted for this
/// field. The Internet Checksum is used, specified in RFC 1071
///
/// <B>Rest of Header</B> 
///
/// Four-bytes field, contents vary based on the ICMP type and code
///
/// <B>Data</B>
///
/// ICMP error messages contain a data section that includes the entire IPv4 header, plus the first
/// eight bytes of data from the IPv4 packet that caused the error message. The ICMP packet is then
/// encapsulated in a new IPv4 packet.[1] This data is used by the host to match the message to the
/// appropriate process. If a higher level protocol uses port numbers, they are assumed to be in the
/// first 64 data bits of the original datagram's data
///
/// The variable size of the ICMP packet data section has been exploited. In the "Ping of death",
/// large or fragmented ping packets are used for denial-of-service attacks. ICMP can also be used
/// to create covert channels for communication. These channels are known as ICMP tunnels
///
/// <B>Control Messages</B>
///
///\image html ICMP_Message1.png
///\image latex ICMP_Message1.eps "" width=15cm
///
///\image html ICMP_Message2.png "ICMP Control Message Values [2]"
///\image latex ICMP_Message2.eps "ICMP Control Message Values [2]" width=15cm
///
///
///\subsection ICMPSAv6SA Internet Control Message Protocol version 6
///
/// See https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol_version_6
///
/// Internet Control Message Protocol version 6 (ICMPv6) is the implementation of the Internet
/// Control Message Protocol (ICMP) for Internet Protocol version 6 (IPv6). ICMPv6 is defined in
/// RFC 4443.[1] ICMPv6 is an integral part of IPv6 and performs error reporting and diagnostic
/// functions (e.g., ping), and has a framework for extensions to implement future changes
///
/// Several extensions have been published, defining new ICMPv6 message types as well as new options
/// for existing ICMPv6 message types. Neighbor Discovery Protocol (NDP) is a node discovery protocol
/// in IPv6 which replaces and enhances functions of ARP.[2] Secure Neighbor Discovery (SEND) is an
/// extension of NDP with extra security. Multicast Router Discovery (MRD) allows discovery of multicast 
/// routers
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
/// @see jprotocol
/// @see jarray
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include "jsecass.h"

namespace ProtocolPP {

class jicmpsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard Constructor with defaults
    ///
    /// <table>
    /// <caption id="icmpsa_default">ICMP SA Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::DECAP
    /// <tr><td>ver<td>iana_t::ICMP
    /// <tr><td>msg<td>icmpmsg_t::TIMEXCEED
    /// <tr><td>code<td>icmpcode_t::TTLEXPIRE
    /// <tr><td>dsecn<td>0
    /// <tr><td>ttl<td>0xFF
    /// <tr><td>flags<td>0
    /// <tr><td>fragoff<td>0
    /// <tr><td>id<td>0xFFFF
    /// <tr><td>label<td>0xFFFFFFFF
    /// <tr><td>src<td>0xBBBBBBBB
    /// <tr><td>dst<td>0xEEEEEEEE
    /// </table>
    ///
    /// Generate the security association for ENCAP and new source and
    /// destination addresses do the following:
    ///\code
    /// jicmpsa snd;
    ///
    /// snd.set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP);
    /// snd.set_field<jarray<uint8_t>>(field_t::SOURCE, jarray<uint8_t>("00112233"));
    /// snd.set_field<jarray<uint8_t>>(field_t::DESTINATION, jarray<uint8_t>("33221100"));
    ///\endcode
    //////////////////////////////////////////////////////////////////////
    jicmpsa();

    //////////////////////////////////////////////////////////////////////
    /// ICMP security association
    /// @param dir - Direction of data flow (usually opposite the IP/IPsec flow)
    /// @param ver - Version of ICMP (ICMP or ICMPv6)
    /// @param msg - Message to be sent to SENDER
    /// @param code - Code to be sent to SENDER
    /// @param dsecn - DS/ECN from sender
    /// @param ttl - Time-to-Live/HOP Limit
    /// @param flags - IPv4 flags from sender
    /// @param fragoff - IPv4 fragmentation offset from sender
    /// @param id - IPv4 identification field from sender
    /// @param label - IPv6 label from the sender
    /// @param src - Address of RECEIVER
    /// @param dst - Address of SENDER
    //////////////////////////////////////////////////////////////////////
    jicmpsa(direction_t dir,
            iana_t ver,
            icmpmsg_t msg,
            icmpcode_t code,
            uint8_t dsecn,
            uint8_t ttl,
            uint8_t flags,
            uint16_t fragoff,
            uint16_t id,
            uint32_t label,
            jarray<uint8_t> src,
            jarray<uint8_t> dst);

    //////////////////////////////////////////////////////////////////////
    /// constructor for ICMP and ICMPv6 
    /// @param security - Parameters necessary to setup ICMP flow such
    ///                   as DIRECTION, VERSION, MSG, CODE, SRC, DST
    //////////////////////////////////////////////////////////////////////
    jicmpsa(jicmpsa& security);

    //////////////////////////////////////////////////////////////////////
    /// constructor for ICMP and ICMPv6 
    /// @param security - Parameters necessary to setup ICMP flow such
    ///                   as DIRECTION, VERSION, MSG, CODE, SRC, DST
    //////////////////////////////////////////////////////////////////////
    explicit jicmpsa(std::shared_ptr<jicmpsa>& security);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jicmpsa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the field of the IP header
    ///
    /// <table>
    /// <caption id="icmpsa_set">ICMP SA Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP)
    /// <tr><td>iana_t<td>VERSION<td>set_field<iana_t>(field_t::VERSION, iana_t::ICMPV6)
    /// <tr><td>icmpmsg_t<td>MESSAGE<td>set_field<icmpmsg_t>(field_t::MESSAGE, icmpmsg_t::TIMEXCEED)
    /// <tr><td>icmpcode_t<td>CODE<td>set_field<icmpcode_t>(field_t::CODE, icmpcode_t::TTLEXPIRE)
    /// <tr><td>uint8_t<td>DSECN<td>set_field<uint8_t>(field_t::DSECN, 0xFF)
    /// <tr><td><td>TTLHOP<td>set_field<uint8_t>(field_t::TTLHOP, 0xAA)
    /// <tr><td><td>FLAGS<td>set_field<uint8_t>(field_t::FLAGS, 0xCC)
    /// <tr><td>uint16_t<td>FRAGOFFSET<td>set_field<uint16_t>(field_t::FRAGOFFSET, 0x001E)
    /// <tr><td><td>ID<td>set_field<uint16_t>(field_t::ID, 0x01CC)
    /// <tr><td><td>LABEL<td>set_field<uint32_t>(field_t::LABEL, 0xA1CC)
    /// <tr><td>jarray<uint8_t><td>SOURCE<td>set_field<jarray<uint8_t>>(field_t::SOURCE, jarray<uint8_t>("0xAABBCCDD"))
    /// <tr><td><td>DESTINATION<td>set_field<jarray<uint8_t>>(field_t::DESTINATION, jarray<uint8_t>("0xEE11AABB"))
    /// </table>
    ///
    /// Some fields may only be available in the jicmp protocol due to
    /// their dynamic nature as fields in the ICMP header or packet
    /// and are not stored in the security association. For ICMP they include
    ///
    /// * CHECKSUM
    /// * POINTER
    /// * TYPE
    /// * SEQNUM
    /// * GATEWAY
    /// * ORIGTIMESTAMP
    /// * RXTIMESTAMP
    /// * TXTIMESTAMP
    ///
    /// @param field - field to update the IP header with
    /// @param fieldval - value to update the IP header with
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the field in ICMPSA
    ///
    /// <table>
    /// <caption id="icmpsa_get">ICMP SA Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>iana_t<td>VERSION<td>iana_t myver = get_field<iana_t>(field_t::VERSION)
    /// <tr><td>icmpmsg_t<td>MESSAGE<td>icmpmsg_t mymsg = get_field<icmpmsg_t>(field_t::MESSAGE)
    /// <tr><td>icmpcode_t<td>CODE<td>icmpcode_t mycode = get_field<icmpcode_t>(field_t::CODE)
    /// <tr><td>uint8_t<td>DSECN<td>uint8_t mydsecn = get_field<uint8_t>(field_t::DSECN)
    /// <tr><td><td>TTLHOP<td>uint8_t myttl = get_field<uint8_t>(field_t::TTLHOP)
    /// <tr><td><td>FLAGS<td>uint8_t myflags = get_field<uint8_t>(field_t::FLAGS)
    /// <tr><td>uint16_t<td>FRAGOFFSET<td>uint16_t myfragoff = get_field<uint16_t>(field_t::FRAGOFFSET)
    /// <tr><td><td>ID<td>uint16_t myid = get_field<uint16_t>(field_t::ID)
    /// <tr><td><td>LABEL<td>uint32_t mylabel = get_field<uint32_t>(field_t::LABEL)
    /// <tr><td>jarray<uint8_t><td>SOURCE<td>jarray<uint8_t> mysrc = get_field<jarray<uint8_t>>(field_t::SOURCE)
    /// <tr><td><td>DESTINATION<td>jarray<uint8_t> mydst = get_field<jarray<uint8_t>>(field_t::DESTINATION)
    /// </table>
    ///
    /// Some fields may only be available in the jicmp protocol due to
    /// their dynamic nature as fields in the ICMP header or packet
    /// and are not stored in the security association. For ICMP they include
    ///
    /// * CHECKSUM
    /// * POINTER
    /// * TYPE
    /// * SEQNUM
    /// * GATEWAY
    /// * ORIGTIMESTAMP
    /// * RXTIMESTAMP
    /// * TXTIMESTAMP
    ///
    /// @param field - field to retrieve from the IP header
    /// @return value of the field in the security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol as an XML object
    /// @param myxml - XMLPrinter object to print with
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jicmpsa(const jicmpsa& rhs) = delete;

    // member variables
    direction_t m_dir;
    iana_t m_ver;
    icmpmsg_t m_msg;
    icmpcode_t m_code;
    uint8_t m_dsecn;
    uint8_t m_ttl;
    uint8_t m_flags;
    uint16_t m_fragoff;
    uint16_t m_id;
    uint32_t m_label;
    jarray<uint8_t> m_src;
    jarray<uint8_t> m_dst;
};

}

#endif /* JICMPSA_H_ */
