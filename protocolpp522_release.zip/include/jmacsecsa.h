#ifndef JMACSECSA_H
#define JMACSECSA_H

///
///\class jmacsecsa jmacsecsa.h "include/jmacsecsa.h"
///
///\section MacSecSASA MACsec Security Association
///
/// Information provided by IEEE https://standards.ieee.org/getieee802/download/802.1AE-2006.pdf
///
/// <B>Encoding of MACsec protocol data units</B>
///
/// This clause specifies the structure and encoding of the MACsec Protocol Data Units (MPDUs) exchanged
/// between MAC Security Entities (SecYs). It
///
/// * Specifies rules for the representation and encoding of protocol fields
///
/// * Specifies the major components of each MPDU, and the fields they comprise
///
/// * Reviews the purpose of each field, and the functionality provided
///
/// * Specifies validation of the MPDU on reception
///
/// * Documents the allocation of an EtherType value, the MACsec EtherType, to identify MPDUs
///
///
/// NOTE—The MPDU validation checks specified in this clause are deliberately limited to ensuring successful
/// decoding, and do not overlap with the specification of SecY operation (Clause 10). 
///
///
/// <B>Structure, representation, and encoding</B>
///
/// All MPDUs shall contain an integral number of octets. The octets in a MPDU are numbered starting from 1
/// and increasing in the order they are put into the MAC Service Data Unit (MSDU) that accompanies a request
/// to or indication from the instance of the MAC Internal Sublayer Service (ISS) used by a SecY. The bits in
/// an octet are numbered from 1 to 8 in order of increasing bit significance, where 1 is the least significant
/// bit in the octet. Where octets and bits within a MPDU are represented using a diagram, octets shown higher
/// on the page than subsequent octets and octets shown to the left of subsequent octets at the same height on
/// the page are lower numbered, bits shown to the left of other bits within the same octet are higher numbered.
/// Where two or more consecutive octets are represented as hexadecimal values, lower numbered octet(s) are shown
/// to the left and each octet following the first is preceded by a hyphen, e.g., 01-80-C2-00-00-00.
///
/// When consecutive octets are used to encode a binary number, the lower octet number has the more significant
/// value. When consecutive bits within an octet are used to encode a binary number, the higher bit number has
/// the most significant value. When bits within consecutive octets are used to encode a binary number, the lower
/// octet number composes the more significant bits of the number. A flag is encoded as a single bit, and is set
/// (True) if the bit takes the value 1, and clear (False) otherwise. The remaining bits within the octet can be
/// used to encode other protocol fields.
///
///\image html MacSec_Packet.png "Macsec Packet Structure"
///\image latex MacSec_Packet.eps "Macsec Packet Structure" width=15cm
///
///
/// <B>Major components</B>
///
/// Each MPDU comprises
///
/// * A Security TAG (SecTAG)
///
/// * Secure Data (9.10) c) An Integrity Check Value (ICV)
///
///
/// Each of these components comprises an integral number of octets and is encoded in successive octets of the
/// MPDU as illustrated in Figure 9-1
///
/// NOTE—The MPDU does not include the source and destination MAC addresses, as these are separate parameters
/// of the service requests and indications to and from the insecure service that supports MACsec
///
///\image html MacSec_MPDU.png "Packet Data Unit (PDU) For Macsec"
///\image latex MacSec_MPDU.eps "Packet Data Unit (PDU) For Macsec" width=15cm
///
/// <B>Security TAG</B>
///
/// The Security TAG (SecTAG) is identified by the MACsec EtherType, and conveys the
///
/// * TAG Control Information (TCI, 9.5)
///
/// * Association Number (AN, 9.6)
///
/// * Short Length (SL, 9.7)
///
/// * Packet Number (PN, 9.8)
///
/// * Optionally encoded Secure Channel Identifier (SCI, 9.9).
///
///
/// The format of the SecTAG is illustrated in Figure 9-2
///
///\image html MacSec_SECTAG.png "Security TAG For Macsec"
///\image latex MacSec_SECTAG.eps "Security TAG For Macsec" width=15cm
///
///
/// <B>MACsec EtherType</B>
///
/// The MACsec EtherType comprises octet 1 and octet 2 of the SecTAG. It is included to allow
///
/// * Coexistence of MACsec capable systems in the same environment as other systems
///
/// * Incremental deployment of MACsec capable systems
///
/// * Peer SecYs to communicate using the same media as other communicating entities
///
/// * Concurrent operation of Key Agreement protocols that are independent of the MACsec protocol and the Current Cipher Suite
///
/// * Operation of other protocols and entities that make use of the service provided by the SecY’s Uncontrolled Port to
///   communicate independently of the Key Agreement state 
///
///\image html MacSec_ETHER.png "Ethernet Type of the Macsec Packet"
///\image latex MacSec_ETHER.eps "Ethernet Type of the Macsec Packet" width=15cm
///
///
/// The encoding of the MACsec EtherType in the MPDU is illustrated in the next figure 
///
///\image html MacSec_ETHER_ENCODE.png "Position of the EtherType Field in the Macsec Packet"
///\image latex MacSec_ETHER_ENCODE.eps "Position of the EtherType Field in the Macsec Packet" width=15cm
///
///
/// <B>TAG Control Information (TCI)</B>
///
/// The TCI field comprises bits 8 through 3 of octet 3 (Figure 9-4) of the SecTAG. These bits facilitate
///
/// * Version numbering of the MACsec protocol without changing the MACsec EtherType
///
/// * Optional use of the MAC Source Address parameter to convey the SCI
///
/// * Optional inclusion of an explicitly encoded SCI (7.1.2, Figure 7-7)
///
/// * Use of the EPON (Clause 12) Single Copy Broadcast capability, without requiring an explicit SCI
///   to distinguish the SCB Secure Channel
///
/// * Extraction of the User Data from MPDUs by systems that do not possess the SAK (8.1.2, 8.1.4) when
///   confidentiality is not being provided
///
/// * Determination of whether confidentiality or integrity alone are in use
///
/// The encoding of the MACsec TCI in the MPDU is illustrated in Figure 9-4. 
///
///\image html MacSec_TCIAN.png "TAG Control Information for the Macsec Packet"
///\image latex MacSec_TCIAN.eps "TAG Control Information for the Macsec Packet" width=15cm
///
/// TCIAN bit encoding is as follows:
/// 
/// * The version number shall be 0 and is encoded in bit 8. NOTE—Future versions of the MACsec protocol may
///   use additional bits of the TCI to encode the version number. The fields and format of the remainder of
///   the MPDU may change if the version number changes
///
/// * If the MPDU is transmitted by an end station and the first 6 octets of the SCI are equal to the value
///   of the octets of MAC Source Address parameter of the ISS request in canonical format order, bit 7
///   [the End Station (ES) bit] of the TCI may be set
///
/// * If the ES bit is set, bit 6 (the SC bit) shall not be set and an SCI shall not be explicitly encoded
///   in the SecTAG. The ES bit is clear if the Source Address is not used to determine the SCI. If an SCI
///   (9.9, 7.1.2) is explicitly encoded in the SecTAG, bit 6 (the SC bit) of the TCI shall be set. The SC
///   bit shall be clear if an SCI is not present in the SecTAG
/// 
/// * If and only if the MPDU is associated with the Secure Channel that supports the EPON Single Copy
///   Broadcast capability, bit 5 (the SCB bit) of the TCI may be set
///
/// * If the SCB is set, bit 6 (the SC bit) shall not be set and an SCI shall not be explicitly included
///   in the SecTAG. If the ES bit is set and the SCB is not set, the SCI comprises a Port Identifier (7.1.2)
///   component of 00-01. If the SCB bit is set, the Port Identifier (7.1.2) component has the reserved SCB
///   value of 00-00
///
/// * If the Encryption (E) bit is set and the Changed Text (C) bit is clear, the frame is not processed
///   by the SecY (10.6) but is reserved for use by the KaY. Otherwise, the E bit is set if and only if
///   confidentiality is being provided and is clear if integrity only is being provided
///
/// * The C bit is clear if and only if the Secure Data is exactly the same as the User Data and the ICV
///   is 16 octets long. When the Default Cipher Suite (14.5) is used for integrity protection only, the
///   Secure Data is the unmodified User Data, and a 16 octet ICV is used. Both the E bit and the C bit
///   are therefore clear, and the data conveyed by MACsec is available to applications, such as network
///   management, that need to see the data but are not trusted with the SAK that would permit its modification.
///   Other Cipher Suites may also integrity protect data without modifying it, and use a 16 octet ICV,
///   enabling read access to the data by other applications. The E and C bits are also clear for such
///   Cipher Suites when integrity only is provided
///
/// * Some cryptographic algorithms modify or add to the data even when integrity only is being provided, or
///   use an ICV that is not 16 octets long. The C bit is never clear for such an algorithm, even if the E bit
///   is clear to indicate that confidentiality is not provided. Recovery of the data from a MACsec frame with
///   the E bit clear and the C bit set requires knowledge of the Cipher Suite at a minimum. That information is
///   not provided in the MACsec frame. If both the C bit and E bit are set, confidentiality of the original User
///   Data is being provided.
///
/// <B>Association Number (AN)</B>
///
/// The AN is encoded as an integer in bits 1 and 2 of octet 3 of the SecTAG (Figure 9-4) and identifies up to
/// four different SAs within the context of an SC. NOTE—Although each receiving SecY only needs to maintain two
/// SAs per SC, the use of a 2-bit AN simplifies the design of protocols that update values associated with each
/// of the SAs.
///
///
/// <B>Short Length (SL)</B>
///
/// SL is an integer encoded in bits 1 through 6 of octet 4 of the SecTAG and is set to the number of octets in
/// the Secure Data (9.10) field, i.e., the number of octets between the last octet of the SecTAG and the first
/// octet of the ICV, if that number is less than 48. Otherwise, SL is set to zero. If the number is zero then
/// the frame is deemed not to have been short. The Secure Data field always comprises at least one octet. Bits
/// 7 and 8 of octet 4 shall be zero.
///
///
/// <B>Packet Number (PN)</B>
///
/// The PN is encoded in octets 5 through 8 of the SecTAG to 
///
/// * Provide a unique IV PDU for all MPDUs transmitted using the same SA
///
/// * Support replay protection
///
///
/// NOTE—As specified in this clause, the IV used by the default Cipher Suite (GCM-AES-128) comprises the
/// SCI (even if the SCI is not transmitted in the SecTAG) and the PN. Subject to proper unique MAC Address
/// allocation procedures, the SCI is a globally unique identifier for a SecY. To satisfy the IV uniqueness
/// requirements of CTR mode of operation, a fresh key is used before PN values are reused.
///
///
/// <B>Secure Channel Identifier (SCI)</B>
///
/// If the SC bit in the TCI is set, the SCI (7.1.2, 8.2.1) is encoded in octets 9 through 16 of the SecTAG,
/// and facilitates
///
/// * Identification of the SA where the CA comprises three or more peers
///
/// * Network management identification of the SecY that has transmitted the frame Octets 9 through 14 of
///   the SecTAG encode the System Identifier component of the SCI. This comprises the six octets of a
///   globally unique MAC address uniquely associated with the transmitting SecY. The octet values and
///   their sequence conform to the Canonical Format specified by IEEE Std 802. Octets 15 and 16 of the
///   SecTAG encode the Port Identifier component of the SCI, as an integer.
///
/// NOTE —The 64-bit value FF-FF-FF-FF-FF-FF is never used as an SCI and is reserved for use by implementations
/// to indicate the absence of an SC or an SCI in contexts where an SC can be present.
///
/// An explicitly encoded SCI field in the SecTAG is not required on point-to-point links, which are
/// identified by the operPointToPointMAC status parameter of the service provider. In the point-to-point case,
/// the secure association created by the SecY for the peer SecYs, together with the direction of transmission
/// of the secured MPDU, can be used to identify the transmitting SecY and therefore an explicitly encoded SCI
/// is unnecessary. Although the SCI does not have to be repeated in each frame when only two SecYs participate
/// in a CA (see Clause 8, Clause9, and Clause10), the SCI still forms part of the cryptographic computation.
///
/// <B>802.1Q VLAN Tagging</B>
///
/// Tagging a frame with a VLAN tag
///
/// a. Allows a VID to be conveyed, facilitating consistent VLAN classification of the frame throughout
///    the network and enabling segregation of frames assigned to different VIDs
///
/// b. Allows priority (IEEE Std 802.1AC, 6.8) to be conveyed with the frame when using IEEE 802 LAN
///    media access control methods that provide no inherent capability to signal priority
///
/// <B>Tag Format</B>
///
/// Each tag comprises the following sequential information elements:
///
/// a. A Tag Protocol Identifier (TPID)
///
/// b. Tag Control Information (TCI) that is dependent on the tag type
///
/// c. Additional information, if and as required by the tag type and TCI
///
///\image html VLAN802.1QTag.png "VLAN Tag Format"
///\image latex VLAN802.1QTag.eps "VLAN Tag Format" width=5cm
///
/// The tag encoding function supports each EISS (6.8) instance by using an instance of the ISS to transmit and
/// receive frames and encodes the above information in the first and subsequent octets of the MSDU that will
/// accompany an ISS M_UNITDATA.request, immediately prior to encoding the sequence of octets that constitute
/// the corresponding EISS M_UNITDATA.request’s MSDU. On reception the tag decoding function is selected by the
/// TPID and decodes the TCI and additional information octets (if present) prior to issuing an EISS
/// M_UNITDATA.indication with an MSDU that comprises the subsequent octets
///
/// The following types of tags are specified:
///
/// a. A C-TAG, for general use by C-VLAN Bridges and C-VLAN components of Provider Edge Bridges
///
/// b. An S-TAG, reserved for use by S-VLAN Bridges, the S-VLAN component of Provider Edge Bridges
///    and BEBs, and C-VLAN Bridges signaling priority to a PBN or a PBBN
///
/// c. An I-TAG, reserved for use by BEBs
///
/// NOTE—The S-TAG is identical to the B-TAG
///
/// A distinct EtherType has been allocated (see table below) for use in the TPID field of each tag type so they
/// can be distinguished from each other, and from other protocols
///
/// <center>
/// <table>
/// <caption id="vlantagsQ">IEEE 802.1Q Ethertype allocations</caption>
/// <tr><th>Tag Type<th>Name<th>Value
/// <tr><td>Customer VLAN Tag<td>IEEE 802.1Q Tag Protocol EtherType (802.1QTagType)<td>81-00
/// <tr><td>Service or Backbone VLAN Tag<td>IEEE 802.1Q Tag Protocol EtherType (802.1QSTagType)<td>88-A8
/// <tr><td>Backbone Service Instance Tag<td>IEEE 802.1Q Backbone Service Instance Tag EtherType (802.1QITagType)<td>88-E7
/// </table>
/// </center>
///
/// <B>VLAN Tag Control Information (TCI)</B>
///
/// The VLAN TCI field is two octets in length and encodes the vlan_identifier, drop eligible, and priority
/// parameters of the corresponding EISS M_UNITDATA.request as unsigned binary numbers
///
///\image html VLAN_TCI_Format.png "VLAN TCI Format SA"
///\image latex VLAN_TCI_Format.eps "VLAN TCI Format SA" width=5cm
///
/// The VID is encoded in a 12-bit field. A VLAN Bride may not support the full range of VID values but
/// shall support the use of all VID values in the range 0 through a maximum N, less than or equal to
/// 4094 and specified for that implementation. The following table identifies VID values that have
/// specific meanings or uses
/// 
///\image html VLAN_Reserved_VID_values.png "Reserved VID values SA"
///\image latex VLAN_Reserved_VID_values.eps "Reserved VID values SA" width=5cm
///
/// NOTE 1 - There is a distinction between the range of VIDs that an implementation can support and the
/// maximum number of active VIDs supported at any one time. An implementation supports only 16 active
/// VIDs, for example, may use VIDs chosen from anywhere in the identifier space, or from a limited range.
/// The latter can result in difficulties where different Bridges in the same network support different
/// maximums. It is recommended that new implementations of this standard support the full range of VIDs,
/// even if the number of active VIDs is limited
///
/// The priority and drop eligible parameters are conveyed in the 3-bit PCP field and the DEI field
///
/// NOTE 2 - Previous versions of this standard used bit 5 of octet 1 of the TCI in C-TAGs as a Canonical
/// Format Indicator (CFI). Bridges conformant to this version of the standard will not interoperate
/// with Bridges that set the CFI as a result of inserting C-TAGs in frames received from an IEEE 802.5
/// Token Ring LAN. Bridges conformant to this version of the standard will interoperate with Bridges
/// that forward bit 5 of octet 1 as a CFI but do not 802.5 Token Ring interfaces
///
/// <B>Support for double tags</B>
///
/// When using a single VLAN tag, the tag in the security association name VLANTAG1 will be used. If
/// a second tag is used, the tag in the security association named VLANTAG2 will be inserted
/// between VLANTAG1 and the EthType of the packet as shown below
///
///\image html VLAN_802.1ad_DoubleTag75.png "VLAN Double Tag Formatting SA"
///\image latex VLAN_802.1ad_DoubleTag.eps "VLAN Double Tag Formatting SA" width=5cm
///
/// <B>For API Documentation:</B>
/// @see ProtocolPP::jmacsec
/// @see ProtocolPP::jmacsecsa
/// @see ProtocolPP::jprotocol
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jarray
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
/// @see jmacsec
/// @see jmacsecsa
/// @see jprotocol
/// @see jmodes
/// @see jarray
/// @see jrand
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///
    
#include "jsecass.h"

namespace ProtocolPP {

class jmacsecsa : public jsecass {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard Constructor with defaults
    ///
    /// <table>
    /// <caption id="MACSEC Defaults">MACSEC Defaults</caption>
    /// <tr><th>field<th>Default Value
    /// <tr><td>dir<td>direction_t::ENCAP
    /// <tr><td>mode<td>macsecmode_t::AES_GCM_128
    /// <tr><td>usext<td>false
    /// <tr><td>enreceive<td>false
    /// <tr><td>entransmit<td>false
    /// <tr><td>protectframes<td>true
    /// <tr><td>tcian<td>0
    /// <tr><td>sl<td>0
    /// <tr><td>ethtype<td>0x88E5
    /// <tr><td>vlantag1<td>0
    /// <tr><td>vlantag2<td>0
    /// <tr><td>pn<td>0
    /// <tr><td>xpn<td>0
    /// <tr><td>ssci<td>0
    /// <tr><td>icvlen<td>16
    /// <tr><td>keylen<td>16
    /// <tr><td>src<td>0
    /// <tr><td>dst<td>0
    /// <tr><td>sci<td>0
    /// <tr><td>arlen<td>0
    /// <tr><td>arwin<td>0
    /// </table>
    ///
    ///\code
    /// std::shared_ptr<jmacsecsa> snd = std::make_shared<jmacsecsa>();
    ///
    /// snd->set_field<uint32_t>(field_t::PN, 0x00000001);
    /// snd->set_field<uint8_t>(field_t::TCIAN, 0xEE);
    /// snd->set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::CIPHERKEY, std::make_shared<jarray<uint8_t>>>(m_rand->getbyte(16)));
    ///\endcode
    //////////////////////////////////////////////////////////////////////
    jmacsecsa();
    
    //////////////////////////////////////////////////////////////////////
    /// Security Association for MacSec
    ///
    /// @param dir - Direction for processing (ENCAP or DECAP)
    /// @param mode - Mode for MACSEC (AES-GCM with 128-bit or 256-bit key with or without extended packet number)
    /// @param usext - use extended sequence number
    /// @param enreceive - SA receiving frames
    /// @param entransmit - SA transmitting frames
    /// @param protectframes - SA protecting frames
    /// @param tcian - TAG control information
    /// @param sl - short length parameter
    /// @param ethtype - ethernet type
    /// @param vlantag1 - customer virtual LAN tag (CVLAN), service virtual LAN tag (SVLAN), or service instance virtual LAN tag (IVLAN)
    /// @param vlantag2 - customer virtual LAN tag (CVLAN), service virtual LAN tag (SVLAN), or service instance virtual LAN tag (IVLAN)
    /// @param pn - packet number this Phy is generating/receiving
    /// @param xpn - if extended packet numbers are used, upper half of the PN
    /// @param ssci - short security control index (for extended packet number)
    /// @param arlen - Number of packets to track in the replay window
    /// @param icvlen - length of the ICV. Default is 16
    /// @param keylen - length of the key (either 16 or 32 bytes)
    /// @param src - source address for the stream
    /// @param dst - destination address for the stream
    /// @param sci - security control index (64-bits)
    /// @param arwin - Anti-replay window to track packets
    /// @param sakey - AES-GCM key for integrity of user data
    /// @param salt - salt to XOR with SSCI, XPN, and PN when using extended packet numbers
    //////////////////////////////////////////////////////////////////////
    jmacsecsa(direction_t dir,
              macsecmode_t mode,
              bool usext,
              bool enreceive,
              bool entransmit,
              bool protectframes,
              uint8_t tcian,
              uint8_t sl,
              uint16_t ethtype,
              uint32_t vlantag1,
              uint32_t vlantag2,
              uint32_t pn,
              uint32_t xpn,
              uint32_t ssci,
              unsigned int arlen,
              unsigned int icvlen,
              unsigned int keylen,
              uint64_t src,
              uint64_t dst,
              uint64_t sci,
              jarray<uint8_t> arwin,
              std::shared_ptr<jarray<uint8_t>> sakey,
              std::shared_ptr<jarray<uint8_t>> salt);

    //////////////////////////////////////////////////////////////////////
    /// Create an instance of the macsec protocol. Use update_sec to
    /// create the security association
    ///
    /// @param rhs - security association for this flow
    //////////////////////////////////////////////////////////////////////
    jmacsecsa(jmacsecsa& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Create an instance of the macsec protocol. Use update_sec to
    /// create the security association
    ///
    /// @param rhs - security association for this flow
    //////////////////////////////////////////////////////////////////////
    explicit jmacsecsa(std::shared_ptr<jmacsecsa>& rhs);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    ~jmacsecsa() {
        if (!m_sakey.empty()) {
            m_sakey.serase();
        }
        if (!m_salt.empty()) {
            m_salt.serase();
        }
    }

    //////////////////////////////////////////////////////////////////////
    /// Update MACSEC field
    ///
    /// <table>
    /// <caption id="MACSEC Set Fields">MACSEC Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>set_field<direction_t>(field_t::DIRECTION, direction_t::ENCAP)
    /// <tr><td>macsecmode_t<td>MODE<td>set_field<macsecmode_t>(field_t::MODE, macsecmode_t::AES_256_GCM)
    /// <tr><td>bool<td>USEXT<td>set_field<bool>(field_t::USEXT, true)
    /// <tr><td>uint8_t<td>TCIAN<td>set_field<uint8_t>(field_t::TCIAN, 0x88)
    /// <tr><td><td>SL<td>set_field<uint8_t>(field_t::SL, 0x88)
    /// <tr><td>uint16_t<td>ETHERTYPE<td>set_field<uint16_t>(field_t::ETHERTYPE, 0x88FF)
    /// <tr><td>uint32_t<td>VLANTAG1<td>set_field<uint32_t>(field_t::VLANTAG1, 0x810000FE)
    /// <tr><td>uint32_t<td>VLANTAG2<td>set_field<uint32_t>(field_t::VLANTAG2, 0x88A800FE)
    /// <tr><td>uint32_t<td>PN<td>set_field<uint32_t>(field_t::PN, 0x000088FF)
    /// <tr><td><td>XPN<td>set_field<uint32_t>(field_t::XPN, 0x088FF0AA)
    /// <tr><td><td>SSCI<td>set_field<uint32_t>(field_t::SSCI, 0x8FF0AACC)
    /// <tr><td><td>ARLEN<td>set_field<uint32_t>(field_t::ARLEN, 128)
    /// <tr><td><td>ICVLEN<td>set_field<uint32_t>(field_t::ICVLEN, 8)
    /// <tr><td><td>KEYLEN<td>set_field<uint32_t>(field_t::KEYLEN, 32)
    /// <tr><td>uint64_t<td>SOURCE<td>set_field<uint64_t>(field_t::SOURCE, 0xAABBCCDD11223344)
    /// <tr><td><td>DESTINATION<td>set_field<uint64_t>(field_t::DESTINATION, 0x1122334455667788)
    /// <tr><td>jarray<uint8_t><td>ARWIN<td>set_field<jarray<uint8_t>>(field_t::ARWIN, jarray<uint8_t>("00000000000000000000000000000001")
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>SAKEY<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SAKEY, std::make_shared<jarray<uint8_t>("AAAABBECEDEDEDED"))
    /// <tr><td><td>SALT<td>set_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT, std::make_shared<jarray<uint8_t>("AAAABBEC"))
    /// </table>
    ///
    /// @param field - MACSEC field to update
    /// @param fieldval - new value for the MACSEC field
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Return the macsec field
    ///
    /// <table>
    /// <caption id="MACSEC Get Fields">MACSEC Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>direction_t mydir = get_field<direction_t>(field_t::DIRECTION)
    /// <tr><td>macsecmode_t<td>MODE<td>macsecmode_t mymode = get_field<macsecmode_t>(field_t::MODE)
    /// <tr><td>bool<td>USEXT<td>bool myusext = get_field<bool>(field_t::USEXT)
    /// <tr><td>uint8_t<td>TCIAN<td>uint8_t mytcian = get_field<uint8_t>(field_t::TCIAN)
    /// <tr><td><td>SL<td>uint8_t mysl = get_field<uint8_t>(field_t::SL)
    /// <tr><td>uint16_t<td>ETHERTYPE<td>uint16_t myethtype = get_field<uint16_t>(field_t::ETHERTYPE)
    /// <tr><td>uint32_t<td>VLANTAG1<td>uint32_t cvlantag = get_field<uint32_t>(field_t::VLANTAG1)
    /// <tr><td>uint32_t<td>VLANTAG2<td>uint32_t svlantag = get_field<uint32_t>(field_t::VLANTAG2)
    /// <tr><td>uint32_t<td>PN<td>uint32_t mypn = get_field<uint32_t>(field_t::PN)
    /// <tr><td><td>XPN<td>uint32_t myxpn = get_field<uint32_t>(field_t::XPN)
    /// <tr><td><td>SSCI<td>uint32_t myssci = get_field<uint32_t>(field_t::SSCI)
    /// <tr><td><td>ARLEN<td>uint32_t myarlen = get_field<uint32_t>(field_t::ARLEN)
    /// <tr><td><td>ICVLEN<td>uint32_t myicvlen = get_field<uint32_t>(field_t::ICVLEN)
    /// <tr><td><td>KEYLEN<td>uint32_t mykeylen = get_field<uint32_t>(field_t::KEYLEN)
    /// <tr><td>uint64_t<td>SOURCE<td>uint64_t mysrc = get_field<uint64_t>(field_t::SOURCE)
    /// <tr><td><td>DESTINATION<td>uint64_t mydst = get_field<uint64_t>(field_t::DESTINATION)
    /// <tr><td>jarray<uint8_t<td>ARWIN<td>jarray<uint8_t> myarwin = get_field<jarray<uint8_t>>(field_t::ARWIN)
    /// <tr><td>std::shared_ptr<jarray<uint8_t>><td>SAKEY<td>std::shared_ptr<jarray<uint8_t>> mysakey = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SAKEY)
    /// <tr><td><td>SALT<td>std::shared_ptr<jarray<uint8_t>> mysalt = get_field<std::shared_ptr<jarray<uint8_t>>>(field_t::SALT)
    /// </table>
    ///
    /// @param field - MACSEC field to retrieve
    /// @return MACSEC field value
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Write the protocol and security objects as XML
    /// @param myxml - XMLPrinter object to print with
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jmacsecsa(const jmacsecsa& rhs) = delete;

    // member variables
    direction_t m_dir;
    macsecmode_t m_mode;
    std::string m_createdTime;
    std::string m_startedTime;
    std::string m_stoppedTime;
    bool m_usext;
    bool m_inuse;
    bool m_enreceive;
    bool m_entransmit;
    bool m_protectframes;
    uint8_t m_tcian;
    uint8_t m_sl;
    uint16_t m_ethtype;
    uint32_t m_vlantag1;
    uint32_t m_vlantag2;
    uint32_t m_pn;
    uint32_t m_xpn;
    uint32_t m_ssci;
    unsigned int m_arlen;
    unsigned int m_icvlen;
    unsigned int m_keylen;
    uint64_t m_src;
    uint64_t m_dst;
    uint64_t m_sci;
    jarray<uint8_t> m_arwin;
    jarray<uint8_t> m_sakey;
    jarray<uint8_t> m_salt;
};

}

#endif //JMACSECSA_H
