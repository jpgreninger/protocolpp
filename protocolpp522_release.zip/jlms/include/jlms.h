#ifndef JLMS_H
#define JLMS_H

///
///\class jlms jlms.h "include/jlms.h"
///
/// <B>Leighton-Micali Signatures</B>
///
/// The Leighton-Micali Signature (LMS) method can sign a potentially large but fixed number of messages
/// An LMS system uses two cryptographic components: a one-time signature method and a hash function. Each
/// LMS public/private key pair is associated with a perfect binary tree, each node of which contains
/// an m-byte value, where m is the output length of the hash function. Each leaf of the tree contains the
/// value of the public key of an LM-OTS public/private key pair. The value contained by the root of the
/// tree is the LMS key pair. The value contained by the root fo teh tree is the LMS key pair. Each
/// interior node is computed by applying the hash function to the concatenation of the values of its
/// children nodes
///
/// Each node of the tree is associated with a node number, an unsigned integer that is denoted as node_num
/// in the algorithms below, which is computed as follows. The root node has node number 1; for each node
/// with node number \f$ N lt {2}^{h} \f$ (where h is the height of the tree), its left child has node
/// number \f$ 2*N \f$, while its right child has node number
///
/// \f$ {2}^{h}, ({2}^{h} + 1), ({2}^{h} + 2), ..., ({2}^{h})+({2}^{h})-1 \f$
///
/// In general, the j-th node at level i hash node \f$ {2}^{i} + j \f$. The node number can conveniently
/// be computed when it is needed in the LMS algorithms, as described in those algorithms
///
/// <B>LMS Parameters</B>
///
/// An LMS system has the following parameters:
///
/// * h - the height of the tree
///
/// * m - the number of bytes associated with each node
///
/// * H - a second-preimage-resistant cryptographic hash function that accepts byte strings of any length
///       and returns an m-byte string
///
/// <table>
/// <caption id="LMSP">LMS Parameters</caption>
/// <tr><th>Name<th>H<th>m<th>h<th>type value
/// <tr><td>LMOTS_SHA256_M32_H5<td>SHA256<td>32<td>5<td>0x00000005
/// <tr><td>LMOTS_SHA256_M32_H10<td>SHA256<td>32<td>10<td>0x00000006
/// <tr><td>LMOTS_SHA256_M32_H15<td>SHA256<td>32<td>15<td>0x00000007
/// <tr><td>LMOTS_SHA256_M32_H20<td>SHA256<td>32<td>20<td>0x00000008
/// <tr><td>LMOTS_SHA256_M32_H25<td>SHA256<td>32<td>20<td>0x00000009
/// </table>
///
/// <B>LMS Private Key</B>
///
/// The format of the LMS private key is an internal matter to the implementation, and this
/// document does not attempt to define it. One possibility is that it may consist of an array
/// OTS_PRIV[] of 2^h LM-OTS private keys and the leaf number q of the next LM-OTS private key
/// that has not yet been used. The q-th element of OTS_PRIV[] is generated using Algorithm 0
/// with the identifiers I, q. The leaf number q is initialized to zero when the LMS private
/// key is created. The format of the LMS Private Key consists of
///\code
///
/// ------------------------------------------------
/// | LMOTSQ+1 | LMOTS_SK[0] | ... | LMOTS_SK[H-1] |
/// ------------------------------------------------
///\endcode
///
/// <B>LMS Public Key</B>
///
/// An LMS public key is defined as follows, where we denote the public key final hash value
/// (namely, the K value computed in Algorithm 1) associated with the i-th LM-OTS private key as
/// OTS_PUB_HASH[i], with i ranging from 0 to (2^h)-1. Each instance of an LMS public/private key
/// pair is associated with a balanced binary tree, and the nodes of that tree are indexed from 1
/// to 2^(h+1)-1. Each node is associated with an m-byte string. The string for the r-th node is
/// denoted as T[r]. The format of the LMS Public Key consists of
///\code
///
/// ------------------------------------------
/// | LMS_TYPE | LMOTS_TYPE | I | LMOTS_T[1] |
/// ------------------------------------------
///\endcode
///
/// <B>LMS Signature</B>
///
/// An LMS signature consists of
///
/// * the number q of the leaf associated with the LM-OTS signature, as a four-byte unsigned
///   integer in network byte order, an LM-OTS signature
///
/// * a typecode indicating the particular LMS algorithm
///
/// * an array of h m-byte values that is associated with the path through the tree from the
///   leaf associated with the LM-OTS signature to the root
///
/// The format for the LMS Signature consists of
///\code
///
/// -------------------------------------------------------------------
/// | LMOTSQ | LMOTS_SIGNATURE | LMS_TYPE | PATH[0] | ... | PATH[H-1] |
/// -------------------------------------------------------------------
///\endcode
///
/// To compute the LMS signature of a message with an LMS private key, the signer first computes
/// the LM-OTS signature of the message using the leaf number of the next unused LM-OTS private
/// key. The leaf number q in the signature is set to the leaf number of the LMS private key that
/// was used in the signature. Before releasing the signature, the leaf number q in the LMS private
/// key MUST be incremented to prevent the LM-OTS private key from being used again. If the LMS
/// private key is maintained in nonvolatile memory, then the implementation MUST ensure that the
/// incremented value has been stored before releasing the signature. The issue this tries to
/// prevent is a scenario where
///
/// a) we generate a signature using one LM-OTS private key and release it to the application
///
/// b) before we update the nonvolatile memory, we crash, and
///
/// c) we reboot and generate a second signature using the same LM-OTS private key. With two different
///    signatures using the same LM-OTS private key, an attacker could potentially generate a forged
///    signature of a third message
///
///\image html LMSTree.png "LMS Tree"
///\image latex LMSTree.eps "LMS Tree" width=10cm
///
/// <B>LMS Signature Verification</B>
///
/// An LMS signature is verified by first using the LM-OTS signature verification algorithm
/// (Algorithm 4b) to compute the LM-OTS public key from the LM-OTS signature and the message. The
/// value of that public key is then assigned to the associated leaf of the LMS tree, and then the
/// root of the tree is computed from the leaf value and the array path[] as described in Algorithm 6
/// If the root value matches the public key, then the signature is valid; otherwise, the signature
/// verification fails
///
/// <B>Comparison with Other Work</B>
///
/// The eXtended Merkle Signature Scheme (XMSS) is similar to HSS in several ways. Both are stateful
/// hash-based signature schemes, and both use a hierarchical approach, with a Merkle tree at each
/// level of the hierarchy. XMSS signatures are slightly shorter than HSS signatures, for equivalent
/// security and an equal number of signatures
///
/// HSS has several advantages over XMSS. HSS operations are roughly four times faster than the comparable
/// XMSS ones, when SHA256 is used as the underlying hash. This occurs because the hash operation done as
/// a part of the Winternitz iterations dominates performance, and XMSS performs four compression-function
/// invocations (two for the PRF, two for the F function) where HSS only needs to perform one. Additionally,
/// HSS is somewhat simpler (as each hash invocation is just a prefix followed by the data being hashed)
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include "jenum.h"
#include "jarray.h"
#include "jprotocol.h"
#include "jlmsa.h"
#include "jlmots.h"

namespace ProtocolPP {

class jlms : public jprotocol {

public:

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor
    /// @param rand - pseudorandom with uniform distribution
    //////////////////////////////////////////////////////////////////////
    explicit jlms(std::shared_ptr<jrand>& rand);

    //////////////////////////////////////////////////////////////////////
    /// Standard constructor with XMSS type
    /// @param rand - pseudorandom with uniform distribution
    /// @param alg - LMS algorithm type
    /// @param otsalg - LMSOTS algorithm type
    //////////////////////////////////////////////////////////////////////
    jlms(std::shared_ptr<jrand>& rand,
         lms_algorithm_t alg,
         lmots_algorithm_t otsalg);

    //////////////////////////////////////////////////////////////////////
    /// Constructor with jlmsa security association
    /// @param rand - pseudorandom with uniform distribution
    /// @param security - LMS security association
    //////////////////////////////////////////////////////////////////////
    jlms(std::shared_ptr<jrand>& rand,
         std::shared_ptr<jlmsa>& security);

    //////////////////////////////////////////////////////////////////////
    /// Generate a LMS key pair and place in security association
    //////////////////////////////////////////////////////////////////////
    void gen_keypair();
   
    //////////////////////////////////////////////////////////////////////
    /// Generate a LMS signature and update LMS private key
    /// @param message - Message to sign with LMS
    /// @param lms_sig - LMS Signature
    //////////////////////////////////////////////////////////////////////
    void sign(std::shared_ptr<jarray<uint8_t>>& message,
              std::shared_ptr<jarray<uint8_t>>& lms_sig);

    //////////////////////////////////////////////////////////////////////
    /// Verify the LMS signature
    /// @param data - Message and Signature used to generate the signature concatenated as message || signature
    //////////////////////////////////////////////////////////////////////
    void verify(std::shared_ptr<jarray<uint8_t>>& data);

    //////////////////////////////////////////////////////////////////////
    /// get_security
    /// @param sec - Shared pointer to hold the security association
    //////////////////////////////////////////////////////////////////////
    void get_security(std::shared_ptr<jlmsa>& sec);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol as an XML object
    /// @param myxml - XMLPrinter object to print with
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param hdr - header of the packet
    //////////////////////////////////////////////////////////////////////
    void set_hdr(jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @param field - field to update
    /// @param value - new value of the field
    //////////////////////////////////////////////////////////////////////
    void set_field(field_t field, uint64_t value);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @return empty array
    //////////////////////////////////////////////////////////////////////
    jarray<uint8_t> get_hdr(); 

    //////////////////////////////////////////////////////////////////////
    /// Retrieve the field from the LMS
    /// @param field - field to return
    /// @return field
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    /// @return 0
    //////////////////////////////////////////////////////////////////////
    uint64_t get_field(field_t field, jarray<uint8_t>& hdr);

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    //////////////////////////////////////////////////////////////////////
    void encap_packet(std::shared_ptr<jarray<uint8_t>>& input,
                      std::shared_ptr<jarray<uint8_t>>& output) {}

    //////////////////////////////////////////////////////////////////////
    /// Not used in this protocol
    //////////////////////////////////////////////////////////////////////
    void decap_packet(std::shared_ptr<jarray<uint8_t>>& input,
                      std::shared_ptr<jarray<uint8_t>>& output) {}

private:

    // member variables
    std::shared_ptr<jlmsa> m_sec;
    jarray<uint8_t> m_increment;
};
    
}
    
#endif
    
