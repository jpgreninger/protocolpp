#ifndef JIKEPRF_H_
#define JIKEPRF_H_

///
///\class jikeprf jikeprf.h "include/jikeprf.h"
///
///\section IKEPRF IKE PRF and PRF+ functions
///
/// Provides the PRF and PRF+ functions for IKEv2
///
/// <B>Generating Keying Material</B>
///
/// <p>In the context of the IKE_SA, four cryptographic algorithms are negotiated: an encryption algorithm,
/// an integrity protection algorithm, a Diffie-Hellman group, and a pseudo-random function (prf).
/// The pseudo-random function is used for the construction of keying material for all of the
/// cryptographic algorithms used in both the IKE_SA and the CHILD_SAs</p>
///
/// <p>We assume that each encryption algorithm and integrity protection algorithm uses a fixed-size
/// key and that any randomly chosen value of that fixed size can serve as an appropriate key. For
/// algorithms that accept a variable length key, a fixed key size MUST be specified as part of the
/// cryptographic transform negotiated. For algorithms for which not all values are valid keys (such
/// as DES or 3DES with key parity), the algorithm by which keys are derived from arbitrary values
/// MUST be specified by the cryptographic transform. For integrity protection functions based on
/// Hashed Message Authentication Code (HMAC), the fixed key size is the size of the output of the
/// underlying hash function. When the prf function takes a variable length key, variable length
/// data, and produces a fixed-length output (e.g., when using HMAC), the formulas in this document
/// apply. When the key for the prf function has fixed length, the data provided as a key is
/// truncated or padded with zeros as necessary unless exceptional processing is explained
/// following the formula</p>
/// 
/// <p>Keying material will always be derived as the output of the negotiated prf algorithm. Since
/// the amount of keying material needed may be greater than the size of the output of the prf
/// algorithm, we will use the prf iteratively. We will use the terminology prf+ to describe
/// the function that outputs a pseudo-random stream based on the inputs to a prf as follows:
/// (where | indicates concatenation)</p>
///
/// \f$ prf+ (K,S) = T1\;|\;T2\;|\;T3\;|\;T4\;|\;...\f$
///
/// where:
/// 
/// * \f$ T1 = prf (K,\;S\;|\;0x01)\f$
/// * \f$ T2 = prf (K,\;T1\;|\;S\;|\;0x01)\f$
/// * \f$ T3 = prf (K,\;T2\;|\;S\;|\;0x01)\f$
/// * \f$ T4 = prf (K,\;T3\;|\;S\;|\;0x01)\f$
///
/// <p>continuing as needed to compute all required keys. The keys are taken from the output
/// string without regard to boundaries (e.g., if the required keys are a 256-bit Advanced
/// Encryption Standard (AES) key and a 160-bit HMAC key, and the prf function generates
/// 160 bits, the AES key will come from T1 and the beginning of T2, while the HMAC key
/// will come from the rest of T2 and the beginning of T3). The constant concatenated to
/// the end of each string feeding the prf is a single octet. prf+ in this document is not
/// defined beyond 255 times the size of the prf output</p>
///
/// <B>Generating Keying Material for CHILD_SAs</B>
///
/// The shared keys are computed as follows. A quantity called \f$ SKEYSEED\f$ is calculated from
/// the nonces exchanged during the IKE_SA_INIT exchange and the Diffie-Hellman shared secret
/// established during that exchange. \f$ SKEYSEED\f$ is used to calculate seven other secrets:
/// 
/// * \f$ SK_d\f$ - used for deriving new keys for the CHILD_SAs established with this IKE_SA
/// * \f$SK_ai \; and \; SK_ar\f$ - used as a key to the integrity protection algorithm for authenticating
///   the component messages of subsequent exchanges
/// * \f$ SK_ei \; and \; SK_er\f$ - used for encrypting (and of course decrypting) all subsequent exchanges
/// * \f$ SK_pi \; and \; SK_pr\f$ - which are used when generating an AUTH payload
///
/// \f$ SKEYSEED\f$ and its derivatives are computed as follows:
///
/// \f$ SKEYSEED = prf(Ni\;|\;Nr,\;g^ir)\f$
///
/// \f$ {SK_d\;|\;SK_ai\;|\;SK_ar\;|\;SK_ei\;|\;SK_er\;|\;SK_pi\;|\;SK_pr\;} = prf+ (SKEYSEED,\;Ni\;|\;Nr\;|\;SPIi\;|\;SPIr)\f$
///
/// (indicating that the quantities \f$ SK_d,\;SK_ai,\;SK_ar,\;SK_ei,\;SK_er,\;SK_pi,\;and\;SK_pr\f$ are
/// taken in order from the generated bits of the prf+). g^ir is the shared secret from the
/// ephemeral Diffie-Hellman exchange. g^ir is represented as a string of octets in big endian
/// order padded with zeros if necessary to make it the length of the modulus. Ni and Nr are
/// the nonces, stripped of any headers. If the negotiated prf takes a fixed-length key and
/// the lengths of Ni and Nr do not add up to that length, half the bits must come from Ni and
/// half from Nr, taking the first bits of each
///
/// The two directions of traffic flow use different keys. The keys used to protect messages
/// from the original initiator are SK_ai and SK_ei. The keys used to protect messages in the
/// other direction are SK_ar and SK_er. Each algorithm takes a fixed number of bits of keying
/// material, which is specified as part of the algorithm. For integrity algorithms based on
/// a keyed hash, the key size is always equal to the length of the output of the underlying
/// hash function
///
/// A single CHILD_SA is created by the IKE_AUTH exchange, and additional CHILD_SAs can optionally
/// be created in CREATE_CHILD_SA exchanges. Keying material for them is generated as follows:
/// 
/// \f$ KEYMAT = prf+(SK_d,\;Ni\;|\;Nr) \f$
///
/// Where Ni and Nr are the nonces from the IKE_SA_INIT exchange if this request is the first CHILD_SA
/// created or the fresh Ni and Nr from the CREATE_CHILD_SA exchange if this is a subsequent creation.
///
/// For CREATE_CHILD_SA exchanges including an optional Diffie-Hellman exchange, the keying material
/// is defined as:
///
/// \f$ KEYMAT = prf+(SK_d,\;g^ir\;(new) |\;Ni\;|\;Nr) \f$
///
/// where g^ir (new) is the shared secret from the ephemeral Diffie-Hellman exchange of this
/// CREATE_CHILD_SA exchange (represented as an octet string in big endian order padded with zeros in
/// the high-order bits if necessary to make it the length of the modulus). A single CHILD_SA negotiation
/// may result in multiple security associations. ESP and AH SAs exist in pairs (one in each direction),
/// and four SAs could be created in a single CHILD_SA negotiation if a combination of ESP and AH is
/// being negotiated. Keying material MUST be taken from the expanded KEYMAT in the following order:
///
/// * All keys for SAs carrying data from the initiator to the responder
///   are taken before SAs going in the reverse direction
///
/// * If multiple IPsec protocols are negotiated, keying material is
///   taken in the order in which the protocol headers will appear in
///   the encapsulated packet
///
/// * If a single protocol has both encryption and authentication keys,
///   the encryption key is taken from the first octets of KEYMAT and
///   the authentication key is taken from the next octets
///
/// Each cryptographic algorithm takes a fixed number of bits of keying material specified as part
/// of the algorithm
///
/// <B>For API information:</B>
///
/// @see ProtocolPP::jmodes
/// @see ProtocolPP::jikev2
/// @see ProtocolPP::jrand
/// @see ProtocolPP::jenum
/// @see ProtocolPP::jsecass
/// @see ProtocolPP::jikev2sa
/// @see ProtocolPP::jipsecsa
/// @see ProtocolPP::jikeprf
///
/// <B>For Additional Documentation:</B>
///
/// @see jmodes
/// @see jikev2
/// @see jrand
/// @see jenum
/// @see jsecass
/// @see jikev2sa
/// @see jipsecsa
/// @see jikeprf
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <string>
#include "ciphers.h"

namespace ProtocolPP {

class jikeprf {

public:

  	//////////////////////////////////////////////////////////////////////
    /// Standard constructor
  	//////////////////////////////////////////////////////////////////////
    jikeprf();

  	//////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
  	//////////////////////////////////////////////////////////////////////
    ~jikeprf() {}

	//////////////////////////////////////////////////////////////////////
    /// Computes the hash result for PRF for IKEPRFv1 and IKEPRFv2
	/// @param prf - PRF function to use (MD5, SHA, SHA256, SHA384, SHA512, AES_XCBC_MAC, AES_CMAC depending on IKEPRF version)
	/// @param key - key for the PRF function
	/// @param data - data to hash
	/// @param output - pointer to hold SKEYSEED the size of the HASH output
	//////////////////////////////////////////////////////////////////////
    void get_prf(prf_id_t prf,
                 jarray<uint8_t>& key,
                 jarray<uint8_t>& data,
                 std::shared_ptr<jarray<uint8_t>>& output);

	//////////////////////////////////////////////////////////////////////
    /// Computes the keying material for IKEPRFv1 and IKEPRFv2
	/// @param prf - PRF function to use (MD5, SHA, SHA256, SHA384, SHA512, AES_XCBC_MAC, AES_CMAC depending on IKEPRF version)
	/// @param key - Child SA key generated from the SKEYSEED (SKd) or the generated SKEYSEED if generating IKEV2 key material
	/// @param data - Security Parameter Indexes (SPI) SPIi and SPIr (may include seconDGRAMd ephemeral secret SECRET2|SPIi|SPIr)
    ///               or for IKEV2 key material, NONCES and SPIs (Ni|Nr|SPIi|SPIr) to generate IKE connection keys
	/// @param output - pointer to hold generated data
	/// @param length - length of the desired output data
	//////////////////////////////////////////////////////////////////////
    void get_prfplus(prf_id_t prf,
                     jarray<uint8_t>& key,
                     jarray<uint8_t>& data,
                     std::shared_ptr<jarray<uint8_t>>& output,
                     unsigned int length);
private:

    // don't use these
    jikeprf(jikeprf& jikeprf) = delete;
    jikeprf(const jikeprf& jikeprf) = delete;
};

}

#endif // JIKEPRF_H_

