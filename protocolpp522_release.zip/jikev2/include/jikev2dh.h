#ifndef JIKEV2DH_H_
#define JIKEV2DH_H_

///
///\class jikev2dh jikev2dh.h "include/jikev2dh.h"
///
///\section IKEV2DH Diffie-Hellman Support for IKEv2
///
/// (See RFC7296 for complete details)
///
/// IKE performs mutual authentication between two parties and establishes an IKE security
/// association (SA) that includes shared secret information that can be used to efficiently
/// establish SAs for Encapsulating Security Payload (ESP) [RFC4303] and/or Authentication
/// Header (AH) [RFC4302] and a set of cryptographic algorithms to be used by the SAs to
/// protect the traffic that they carry. In this document, the term "suite" or "cryptographic
/// suite" refers to a complete set of algorithms used to protect an SA. An initiator
/// proposes one or more suites by listing supported algorithms that can be combined into
/// suites in a mix-and-match fashion. IKE can also negotiate use of IP Compression (IPComp)
/// [IPCOMP] in connection with an ESP and/or AH SA. We call the IKE SA an "IKE_SA". The SAs for
/// ESP and/or AH that get set up through that IKE_SA we call "CHILD_SAs"
///
/// All IKE communications consist of pairs of messages: a request and a response. The pair
/// is called an "exchange". We call the first messages establishing an IKE_SA IKE_SA_INIT
/// and IKE_AUTH exchanges and subsequent IKE exchanges CREATE_CHILD_SA or INFORMATIONAL
/// exchanges. In the common case, there is a single IKE_SA_INIT exchange and a single
/// IKE_AUTH exchange (a total of four messages) to establish the IKE_SA and the first
/// CHILD_SA. In exceptional cases, there may be more than one of each of these exchanges. In
/// all cases, all IKE_SA_INIT exchanges MUST complete before any other exchange type, then
/// all IKE_AUTH exchanges MUST complete, and following that any number of CREATE_CHILD_SA
/// and INFORMATIONAL exchanges may occur in any order. In some scenarios, only a single
/// CHILD_SA is needed between the IPsec endpoints, and therefore there would be no additional
/// exchanges. Subsequent exchanges MAY be used to establish additional CHILD_SAs between the
/// same authenticated pair of endpoints and to perform housekeeping functions
///
/// IKE message flow always consists of a request followed by a response.  It is the
/// responsibility of the requester to ensure reliability. If the response is not received
/// within a timeout interval, the requester needs to retransmit the request (or abandon the
/// connection)
///
/// The first request/response of an IKE session (IKE_SA_INIT) negotiates security parameters
/// for the IKE_SA, sends nonces, and sends Diffie-Hellman values.  The second request/response
/// (IKE_AUTH) transmits identities, proves knowledge of the secrets corresponding to the two
/// identities, and sets up an SA for the first (and often only) AH and/or ESP CHILD_SA. The
/// types of subsequent exchanges are CREATE_CHILD_SA (which creates a CHILD_SA) and INFORMATIONAL
/// (which deletes an SA, reports error conditions, or does other housekeeping). Every request
/// requires a response. An INFORMATIONAL request with no payloads (other than the empty Encrypted
/// payload required by the syntax) is commonly used as a check for liveness. These subsequent
/// exchanges cannot be used until the initial exchanges have completed
///
/// <B>For API information:</B>
///
/// @see ProtocolPP::jikev2dh
/// @see ProtocolPP::jikev2
/// @see ProtocolPP::jikev2sa
/// @see ProtocolPP::jikeparse
/// @see ProtocolPP::jenum
///
/// <B>For Additional Documentation:</B>
///
/// @see jikev2dh
/// @see jikev2
/// @see jikev2sa
/// @see jikeparse
/// @see jenum
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

//#include <sys/types.h>
//#include <unistd.h>
//#include <crypt.h>
#include <cstring>
#include <memory>
#include "jlogger.h"
#include "jenum.h"
#include "jarray.h"

#include "xed25519.h"
#include "hex.h"

#include "nbtheory.h"
using CryptoPP::ModularExponentiation;

#include "osrng.h"
using CryptoPP::AutoSeededRandomPool;
using CryptoPP::AutoSeededX917RNG;

#include "aes.h"
using CryptoPP::AES;

#include "dh.h"
using CryptoPP::DH;

#include "eccrypto.h"
using CryptoPP::ECDH;
using CryptoPP::ECP;
using CryptoPP::EC2N;

#include "secblock.h"
using CryptoPP::SecByteBlock;

#include "oids.h"
using CryptoPP::OID;

#include "asn.h"
using namespace CryptoPP::ASN1;

#include "integer.h"
using CryptoPP::Integer;

namespace ProtocolPP {

class jikev2dh {

public:

  	//////////////////////////////////////////////////////////////////////
    /// Standard constructor
  	//////////////////////////////////////////////////////////////////////
    explicit jikev2dh(std::shared_ptr<InterfacePP::jlogger>& logger);

  	//////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
  	//////////////////////////////////////////////////////////////////////
    ~jikev2dh() {}

  	//////////////////////////////////////////////////////////////////////
    /// Generate a public key pair
    /// @param diffiehellman - Diffie-Hellman curve or field to use
    /// @param pubkey - array containing public key
    /// @param prvKey - Generated private key from key pair
    /// @return - True if found and calculated, false otherwise
  	//////////////////////////////////////////////////////////////////////
    bool get_pubkey(dh_id_t diffiehellman,
                    std::shared_ptr<jarray<uint8_t>>& pubkey,
                    std::shared_ptr<CryptoPP::SecByteBlock>& prvKey);

  	//////////////////////////////////////////////////////////////////////
    /// Verify the Diffie-Hellman computation and generate shared secret
    /// @param diffiehellman - Diffie-Hellman curve or field to use
    /// @param rcvPubKey - the received public key
    /// @param prvKey - Generated private key from key pair
    /// @param sharedSecret - the generated shared secret if verification is successful
    /// @return Public key verified
  	//////////////////////////////////////////////////////////////////////
    bool verify(dh_id_t diffiehellman,
                std::shared_ptr<jarray<uint8_t>>& rcvPubKey,
                std::shared_ptr<CryptoPP::SecByteBlock>& prvKey,
                std::shared_ptr<jarray<uint8_t>>& sharedSecret);

private:

    // don't use these
    jikev2dh(jikev2dh& jikev2dh) = delete;
    jikev2dh(const jikev2dh& jikev2dh) = delete;

    // member variables
    std::shared_ptr<InterfacePP::jlogger> m_logger;

    // Diffie-Hellman MODP and ECDH engines
    CryptoPP::DH m_dh;
    CryptoPP::ECDH<ECP>::Domain m_ecp;
    CryptoPP::ECDH<EC2N>::Domain m_ec2n;
    CryptoPP::x25519 m_xed;

    // public key container
    CryptoPP::SecByteBlock pubKey;
};

}

#endif /* JIKEV2DH_H_ */

