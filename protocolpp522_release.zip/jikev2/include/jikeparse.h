#ifndef JIKEPARSE_H_
#define JIKEPARSE_H_

///
///\class jikeparse jikeparse.h "include/jikeparse.h"
///
///\section JIKEP IkeParse XML Parser for IKEv2 Configuration files 
///
/// Parser class for Internet Key Exchange (IKEv2) configuration files. Supports the following
/// schema also found in ikev2
///\verbatim
///
/// <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
///     <xs:element name="ikev2">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="logging"        type="xs:string"/>
///                 <xs:element name="general"        type="xs:string"/>
///                 <xs:element name="policies"       type="xs:string"/>
///                 <xs:element name="policy"         type="xs:string"/>
///                 <xs:element name="peer"           type="xs:string"/>
///                 <xs:element name="ike"            type="xs:string"/>
///                 <xs:element name="ipsec"          type="xs:string"/>
///                 <xs:element name="remote"         type="xs:string"/>
///                 <xs:element name="local_id"       type="xs:string"/>
///                 <xs:element name="peer_id"        type="xs:string"/>
///                 <xs:element name="proposal"       type="xs:string"/>
///                 <xs:element name="address_config" type="xs:string"/>
///                 <xs:element name="server"         type="xs:string"/>
///                 <xs:element name="client"         type="xs:string"/>
///                 <xs:element name="esp_proposal"   type="xs:string"/>
///                 <xs:element name="ah_proposal"    type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="ver"        type="xs:float"/>
///             <xs:attribute name="connection" type="xs:string"/>
///             <xs:attribute name="format"     type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="logging">
///         <xs:complexType>
///             <xs:attribute name="loglevel">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="error|warn|info|debug"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="show_mask">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="hide_mask">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="debugclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="infoclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="warnclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="fatalclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="passclr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="BLACK"/>
///                         <xs:enumeration value="RED"/>
///                         <xs:enumeration value="GREEN"/>
///                         <xs:enumeration value="YELLOW"/>
///                         <xs:enumeration value="BLUE"/>
///                         <xs:enumeration value="MAGENTA"/>
///                         <xs:enumeration value="CYAN"/>
///                         <xs:enumeration value="WHITE"/>
///                         <xs:enumeration value="BRIGHTBLACK"/>
///                         <xs:enumeration value="BRIGHTRED"/>
///                         <xs:enumeration value="BRIGHTGREEN"/>
///                         <xs:enumeration value="BRIGHTYELLOW"/>
///                         <xs:enumeration value="BRIGHTBLUE"/>
///                         <xs:enumeration value="BRIGHTMAGENTA"/>
///                         <xs:enumeration value="BRIGHTCYAN"/>
///                         <xs:enumeration value="BRIGHTWHITE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="general">
///         <xs:complexType>
///             <xs:attribute name="max_ike_negotiation" type="xs:unsignedInt"/>
///             <xs:attribute name="cookies_lifetime"    type="xs:unsignedInt"/>
///             <xs:attribute name="cookies_threshold"   type="xs:unsignedInt"/>
///             <xs:attribute name="vendor_id"           type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="policies">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="policy" type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="flush_before">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="generate_allow_policies">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="policy">
///         <xs:complexType>
///             <xs:attribute name="src_selector">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                         <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="src_port">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="255"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="dst_selector">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                         <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="dst_port">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="255"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ip_proto">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="tcp|udp"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="dir">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="DIR_IN"/>
///                         <xs:enumeration value="DIR_OUT"/>
///                         <xs:enumeration value="DIR_ALL"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="ipsec_proto">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="esp"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="mode">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="TRANSPORT_MODE"/>
///                         <xs:enumeration value="TUNNEL_MODE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="src_tunnel">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                         <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             <xs:attribute name="dst_tunnel">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                         <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             <xs:attribute name="priority"     type="xs:unsignedint"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="peer">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="ike"            type="xs:string"/>
///                 <xs:element name="proposal"       type="xs:string"/>
///                 <xs:element name="ipsec"          type="xs:string"/>
///                 <xs:element name="esp_proposal"   type="xs:string"/>
///                 <xs:element name="ah_proposal"    type="xs:string"/>
///                 <xs:element name="address_config" type="xs:string"/>
///                 <xs:element name="local_id"       type="xs:string"/>
///                 <xs:element name="peer_id"        type="xs:string"/>
///                 <xs:element name="server"         type="xs:string"/>
///                 <xs:element name="client"         type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="role">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:enumeration value="ROLE_INITIATOR"/>
///                         <xs:enumeration value="ROLE_RESPONDER"/>
///                         <xs:enumeration value="ROLE_ANY"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             <xs:attribute name="peer_addr">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                         <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="ike">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="remote"         type="xs:string"/>
///                 <xs:element name="local_id"       type="xs:string"/>
///                 <xs:element name="peer_id"        type="xs:string"/>
///                 <xs:element name="proposal"       type="xs:string"/>
///                 <xs:element name="address_config" type="xs:string"/>
///                 <xs:element name="server"         type="xs:string"/>
///                 <xs:element name="client"         type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="retransmit_time">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="5"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="retransmit_factor">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="4"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="max_retries"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="10"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="rekey_time"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="30"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="max_idle_time"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="30"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="reauth_time"/>
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="600"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="use_uname">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="auth_generator">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:string">
///                         <xs:enumeration value="AUTH_RSA"/>
///                         <xs:enumeration value="AUTH_PSK"/>
///                         <xs:enumeration value="AUTH_DSS"/>
///                         <xs:enumeration value="AUTH_ECDSA_P256"/>
///                         <xs:enumeration value="AUTH_ECDSA_P384"/>
///                         <xs:enumeration value="AUTH_ECDSA_P512"/>
///                         <xs:enumeration value="AUTH_DIGITAL_SIGNATURE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="auth_verifiers">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:string">
///                         <xs:enumeration value="AUTH_RSA"/>
///                         <xs:enumeration value="AUTH_PSK"/>
///                         <xs:enumeration value="AUTH_DSS"/>
///                         <xs:enumeration value="AUTH_ECDSA_P256"/>
///                         <xs:enumeration value="AUTH_ECDSA_P384"/>
///                         <xs:enumeration value="AUTH_ECDSA_P512"/>
///                         <xs:enumeration value="AUTH_DIGITAL_SIGNATURE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="preshared_key"                type="xs:string"/>
///             <xs:attribute name="peer_preshared_key"           type="xs:string"/>
///             <xs:attribute name="certificates"                 type="xs:string"/>
///             <xs:attribute name="ca_certificates"              type="xs:string"/>
///             <xs:attribute name="send_cert_payload">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="peer_ca_certificates"         type="xs:string"/>
///             <xs:attribute name="cert_white_list"              type="xs:string"/>
///             <xs:attribute name="cert_black_list"              type="xs:string"/>
///             <xs:attribute name="hash_url_support">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="send_cert_req_payload">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="eap_clients"                  type="xs:string"/>
///             <xs:attribute name="eap_md5_password"             type="xs:string"/>
///             <xs:attribute name="eap_tls_client_cert"          type="xs:string"/>
///             <xs:attribute name="eap_tls_private_key"          type="xs:string"/>
///             <xs:attribute name="eap_tls_private_key_password" type="xs:string"/>
///             <xs:attribute name="eap_tls_ca_cert"              type="xs:string"/>
///             <xs:attribute name="eap_server"                   type="xs:string"/>
///             <xs:attribute name="eap_md5_user_db"              type="xs:string"/>
///             <xs:attribute name="radius_server">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="radius_port">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="65535"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="radius_secret"                type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="ipsec">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="esp_proposal" type="xs:string"/>
///                 <xs:element name="ah_proposal"  type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="lifetime_soft"  type="xs:unsignedlong"/>
///             <xs:attribute name="lifetime_hard"  type="xs:unsignedlong"/>
///             <xs:attribute name="max_bytes_soft" type="xs:unsignedlong"/>
///             <xs:attribute name="max_bytes_hard" type="xs:unsignedlong"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="proposal">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="encr"  type="xs:string"/>
///                 <xs:element name="integ" type="xs:string"/>
///                 <xs:element name="prf"   type="xs:string"/>
///                 <xs:element name="dh"    type="xs:string"/>
///             </xs:sequence>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="esp_proposal">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="encr"     type="xs:string"/>
///                 <xs:element name="integ"    type="xs:string"/>
///                 <xs:element name="dh"       type="xs:string"/>
///             </xs:sequence>
///             <xs:attribute name="mode">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:string">
///                         <xs:enumeration value="TRANSPORT_MODE"/>
///                         <xs:enumeration value="TUNNEL_MODE"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="use_esn">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:string">
///                         <xs:enumeration value="ESN_NO"/>
///                         <xs:enumeration value="ESN_YES"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             </xs:attribute>
///             <xs:attribute name="bypassdf">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="bypassdscp">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="randiv">
///                 <xs:simpleType>
///                     <xs:restriction type="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="tfclen">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="512"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="arwindow">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="2048"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="ah_proposal">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="integ"    type="xs:string"/>
///             </xs:sequence>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="encr">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:enumeration value="ENCR_DES"/>
///                 <xs:enumeration value="ENCR_3DES"/>
///                 <xs:enumeration value="ENCR_NULL"/>
///                 <xs:enumeration value="ENCR_AES_CBC"/>
///                 <xs:enumeration value="ENCR_AES_CTR"/>
///                 <xs:enumeration value="ENCR_AES_CCM_8"/>
///                 <xs:enumeration value="ENCR_AES_CCM_12"/>
///                 <xs:enumeration value="ENCR_AES_CCM_16"/>
///                 <xs:enumeration value="ENCR_AES_GCM_8"/>
///                 <xs:enumeration value="ENCR_AES_GCM_12"/>
///                 <xs:enumeration value="ENCR_AES_GCM_16"/>
///                 <xs:enumeration value="ENCR_CAMELLIA_CBC"/>
///                 <xs:enumeration value="ENCR_CAMELLIA_CTR"/>
///                 <xs:enumeration value="ENCR_CAMELLIA_CCM_8"/>
///                 <xs:enumeration value="ENCR_CAMELLIA_CCM_12"/>
///                 <xs:enumeration value="ENCR_CAMELLIA_CCM_16"/>
///                 <xs:enumeration value="ENCR_CHACHA20_POLY1305"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="integ">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:enumeration value="AUTH_NONE"/>
///                 <xs:enumeration value="AUTH_HMAC_MD5_96"/>
///                 <xs:enumeration value="AUTH_HMAC_SHA1_96"/>
///                 <xs:enumeration value="AUTH_AES_XCBC_96"/>
///                 <xs:enumeration value="AUTH_HMAC_MD5_128"/>
///                 <xs:enumeration value="AUTH_HMAC_SHA1_160"/>
///                 <xs:enumeration value="AUTH_AES_CMAC_96"/>
///                 <xs:enumeration value="AUTH_AES_128_GMAC"/>
///                 <xs:enumeration value="AUTH_AES_192_GMAC"/>
///                 <xs:enumeration value="AUTH_AES_256_GMAC"/>
///                 <xs:enumeration value="AUTH_HMAC_SHA2_256_128"/>
///                 <xs:enumeration value="AUTH_HMAC_SHA2_384_192"/>
///                 <xs:enumeration value="AUTH_HMAC_SHA2_512_256"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="prf">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:enumeration value="PRF_HMAC_MD5"/>
///                 <xs:enumeration value="PRF_HMAC_SHA1"/>
///                 <xs:enumeration value="PRF_AES128_XCBC"/>
///                 <xs:enumeration value="PRF_HMAC_SHA2_256"/>
///                 <xs:enumeration value="PRF_HMAC_SHA2_384"/>
///                 <xs:enumeration value="PRF_HMAC_SHA2_512"/>
///                 <xs:enumeration value="PRF_AES128_CMAC"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="dh">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:enumeration value="DH_MODP_768"/>
///                 <xs:enumeration value="DH_MODP_1024"/>
///                 <xs:enumeration value="DH_MODP_1536"/>
///                 <xs:enumeration value="DH_MODP_2048"/>
///                 <xs:enumeration value="DH_MODP_3072"/>
///                 <xs:enumeration value="DH_MODP_4096"/>
///                 <xs:enumeration value="DH_MODP_6144"/>
///                 <xs:enumeration value="DH_MODP_8192"/>
///                 <xs:enumeration value="DH_ECP_256"/>
///                 <xs:enumeration value="DH_ECP_384"/>
///                 <xs:enumeration value="DH_ECP_521"/>
///                 <xs:enumeration value="DH_MODP_1024_160"/>
///                 <xs:enumeration value="DH_MODP_2048_224"/>
///                 <xs:enumeration value="DH_MODP_2048_256"/>
///                 <xs:enumeration value="DH_ECP_192_RANDOM"/>
///                 <xs:enumeration value="DH_ECP_224_RANDOM"/>
///                 <xs:enumeration value="DH_BRAINPOOL_P224R1"/>
///                 <xs:enumeration value="DH_BRAINPOOL_P256R1"/>
///                 <xs:enumeration value="DH_BRAINPOOL_P384R1"/>
///                 <xs:enumeration value="DH_BRAINPOOL_P512R1"/>
///                 <xs:enumeration value="DH_CURVE_25519"/>
///                 <xs:enumeration value="DH_CURVE_448"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="remote">
///         <xs:complexType>
///             <xs:attribute name="host">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:string">
///                         <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+"/>
///                         <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="port">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="255"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="hop">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:boolean">
///                         <xs:pattern value="true|false"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///             <xs:attribute name="hop_time">
///                 <xs:simpleType>
///                     <xs:restriction base="xs:unsignedint">
///                         <xs:minInclusive value="0"/>
///                         <xs:maxInclusive value="4294967295"/>
///                     </xs:restriction>
///                 </xs:simpleType>
///             </xs:attribute>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="local_id">
///         <xs:complexType>
///             <xs:attribute name="type" type="xs:string"/>
///             <xs:attribute name="id"   type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="peer_id">
///         <xs:complexType>
///             <xs:attribute name="type" type="xs:string"/>
///             <xs:attribute name="id"   type="xs:string"/>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="addr_config">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="server" type="xs:string"/>
///                 <xs:element name="client" type="xs:string"/>
///             </xs:sequence>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="server">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="method"/>
///                 <xs:element name="protected_ipv4_subnet"/>
///                 <xs:element name="protected_ipv6_subnet"/>
///                 <xs:element name="fixed_ipv4_prefix"/>
///                 <xs:element name="fixed_ipv6_prefix"/>
///                 <xs:element name="dhcp_interface"/>
///                 <xs:element name="dhcp_server_ip"/>
///                 <xs:element name="dhcp_timeout"/>
///                 <xs:element name="dhcp_retries"/>
///             </xs:sequence>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="client">
///         <xs:complexType>
///             <xs:sequence>
///                 <xs:element name="request_configuration"/>
///                 <xs:element name="request_ipv6_suffix"/>
///             </xs:sequence>
///         </xs:complexType>
///     </xs:element>
///     <xs:element name="method">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="none|fixed|dhcp"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="protected_ipv4_subnet">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="protected_ipv6_subnet">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="fixed_ipv4_prefix">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="fixed_ipv6_prefix">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="dhcp_interface" type="xs:string"/>
///     <xs:element name="dhcp_server_ip">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="\\d+\\.\\d+\\.\\d+\\.\\d+/\\d+"/>
///                 <xs:pattern value="\\d*\\:\\d*\\:\\d*\\:\\d*/\\d+"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="dhcp_timeout">
///         <xs:simpleType>
///             <xs:restriction base="xs:unsignedint">
///                 <xs:minInclusive value="0"/>
///                 <xs:maxInclusive value="30"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="dhcp_retries">
///         <xs:simpleType>
///             <xs:restriction base="xs:unsignedint">
///                 <xs:minInclusive value="0"/>
///                 <xs:maxInclusive value="5"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="request_configuration">
///         <xs:simpleType>
///             <xs:restriction base="xs:boolean">
///                 <xs:pattern value="true|false"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
///     <xs:element name="request_ipv6_suffix">
///         <xs:simpleType>
///             <xs:restriction base="xs:string">
///                 <xs:pattern value="\\d*\:\\d*\:\\d*\:\\d*/\\d+"/>
///             </xs:restriction>
///         </xs:simpleType>
///     </xs:element>
/// </xs:schema>
///\endverbatim
///
/// <B>For API Documentation:</B>
/// @see tinyxml2::XMLPrinter
/// @see tinyxml2::XMLVisitor
/// @see ProtocolPP::ikev2
/// @see ProtocolPP::jikeparse
///
/// <B>For Additional Documentation:</B>
/// @see tinyxml2::XMLPrinter
/// @see tinyxml2::XMLVisitor
/// @see ikev2
/// @see jikeparse
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///

#include <ctime>
#include <sys/types.h>
#if defined(_MSC_VER)
#include <io.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#endif
#include <exception>
#include <unordered_map>
#include "jrand.h"
#include "tinyxml2.h"
#include "jdata.h"
#include "jpacket.h"
#include "jstream.h"
#include "jprotocolpp.h"

namespace ProtocolPP {

class jikeparse : public tinyxml2::XMLPrinter, public std::exception {

public :

    struct jikepolicy {
        jarray<uint8_t> src_selector;
        jarray<uint8_t> src_selector_mask;
        jarray<uint8_t> dst_selector;
        jarray<uint8_t> dst_selector_mask;
        uint16_t src_port;
        uint16_t dst_port;
        iana_t ip_proto;
        direction_t dir;
        iana_t ipsec_proto;
        ipmode_t mode;
        jarray<uint8_t> src_tunnel;
        jarray<uint8_t> dst_tunnel;
        unsigned int priority;

        jikepolicy() : src_selector(jarray<uint8_t>(4,0)),
                       src_selector_mask(jarray<uint8_t>(4,0)),
                       dst_selector(jarray<uint8_t>(4,0)),
                       dst_selector_mask(jarray<uint8_t>(4,0)),
                       src_port(0),
                       dst_port(0),
                       ip_proto(iana_t::UDP),
                       dir(direction_t::ENCAP),
                       ipsec_proto(iana_t::ESP),
                       mode(ipmode_t::TUNNEL),
                       src_tunnel(jarray<uint8_t>(4,0)),
                       dst_tunnel(jarray<uint8_t>(4,0)),
                       priority(0)
        {}
    };

    struct jikecfg {
        std::string connection;
        std::string format;
        unsigned int max_ike_negotiation;
        unsigned int cookies_lifetime;
        unsigned int cookies_threshold;
        std::string vendor_id;
        unsigned long seed;
        bool show_extra_info;
        std::string show_mask;
        std::string hide_mask;
        std::string debugclr;
        std::string infoclr;
        std::string warnclr;
        std::string errclr;
        std::string fatalclr;
        std::string passclr;
        bool flush_before;
        bool generate_allow_policies;
        std::string role;
        std::string peer_addr;
        unsigned int retransmition_time;
        unsigned int retransmition_factor;
        unsigned int max_retries;
        unsigned int rekey_time;
        unsigned int max_idle_time;
        unsigned int reauth_time;
        bool use_uname;
        std::string auth_generator;
        std::string auth_verifiers;
        std::string preshared_key;
        std::string peer_preshared_key;
        std::string certificates;
        std::string ca_certificates;
        std::string send_cert_payload;
        std::string peer_ca_certificates;
        std::string cert_white_list;
        std::string cert_black_list;
        bool hash_url_support;
        bool send_cert_req_payload;
        bool hop;
        unsigned int hop_time;
        std::string eap_clients;
        std::string eap_md5_password;
        std::string eap_tls_client_cert;
        std::string eap_tls_private_key;
        std::string eap_tls_private_key_password;
        std::string eap_tls_ca_cert;
        std::string eap_server;
        std::string eap_md5_user_db;
        std::string radius_server;
        unsigned int radius_port;
        std::string radius_secret;
        std::string local_type;
        std::string local_id;
        std::string peerid_type;
        std::string peerid_id;
        std::string ike_encr;
        std::string ike_integ;
        std::string ike_prf;
        std::string ike_dh;
        std::string remote_port;
        std::string remote_host;
        std::string method;
        std::string espmode;
        jarray<uint8_t> protected_ipv4_subnet;
        jarray<uint8_t> protected_ipv4_subnet_mask;
        jarray<uint8_t> protected_ipv6_subnet;
        jarray<uint8_t> protected_ipv6_subnet_mask;
        jarray<uint8_t> fixed_ipv4_prefix;
        jarray<uint8_t> fixed_ipv4_prefix_mask;
        jarray<uint8_t> fixed_ipv6_prefix;
        jarray<uint8_t> fixed_ipv6_prefix_mask;
        std::string dhcp_interface;
        std::string dhcp_server_ip;
        unsigned int dhcp_timeout;
        unsigned int dhcp_retries;
        bool request_configuration;
        std::string request_ipv6_suffix;
        unsigned int lifetime_soft;
        unsigned int lifetime_hard;
        unsigned int max_bytes_soft;
        unsigned int max_bytes_hard;
        std::string esp_encr;
        std::string esp_integ;
        std::string esp_dh;
        bool use_esn;
        bool bypassdf;
        bool bypassdscp;
        bool randiv;
        unsigned int tfclen;
        unsigned int arwindow;
        std::string ah_integ;
        jarray<uint8_t> nonceInitiator;
        jarray<uint8_t> nonceResponder;
        std::unordered_map<std::string,jikepolicy> ikepolicies;

        jikecfg() : connection("IKEv2_Connection"),
                    format("BIG"),
                    max_ike_negotiation(30),
                    cookies_lifetime(20),
                    cookies_threshold(5),
                    vendor_id("IKEv2_Vendor_ID"),
                    seed(1234567890),
                    show_extra_info(true),
                    show_mask("all"),
                    hide_mask("none"),
                    debugclr("MAGENTA"),
                    infoclr("BLACK"),
                    warnclr("YELLOW"),
                    errclr("RED"),
                    fatalclr("RED"),
                    passclr("GREEN"),
                    flush_before(true),
                    generate_allow_policies(true),
                    role("initiator"),
                    peer_addr("192.168.1.1"),
                    retransmition_time(5),
                    retransmition_factor(2),
                    max_retries(10),
                    rekey_time(60),
                    max_idle_time(60),
                    reauth_time(600),
                    use_uname(false),
                    auth_generator("AUTH_PSK"),
                    auth_verifiers("AUTH_PSK, cert"),
                    preshared_key("UNKNWN"),
                    peer_preshared_key("UNKNWN"),
                    certificates("UNKNWN"),
                    ca_certificates("UNKNWN"),
                    send_cert_payload("UNKNWN"),
                    peer_ca_certificates("UNKNWN"),
                    cert_white_list("cert1"),
                    cert_black_list("cert2"),
                    hash_url_support(false),
                    send_cert_req_payload(false),
                    eap_clients("UNKNWN"),
                    eap_md5_password("UNKNWN"),
                    eap_tls_client_cert("UNKNWN"),
                    eap_tls_private_key("UNKNWN"),
                    eap_tls_private_key_password("UNKNWN"),
                    eap_tls_ca_cert("UNKNWN"),
                    eap_server("UNKNWN"),
                    eap_md5_user_db("UNKNWN"),
                    radius_server("UNKNWN"),
                    radius_port(0),
                    radius_secret("UNKNWN"),
                    local_type("ID_IPV4_ADDR"),
                    local_id("youremail@gmail.com"),
                    peerid_type("ID_IPV4_ADDR"),
                    peerid_id("youremail@gmail.com"),
                    ike_encr("ENCR_AES_CBC"),
                    ike_integ("AUTH_HMAC_SHA2_256"),
                    ike_prf("PRF_HMAC_SHA2_256"),
                    ike_dh("DH_MODP_2048"),
                    remote_port("500"),
                    remote_host("UNKNWN"),
                    method("dhcp"),
                    espmode("tunnel"),
                    protected_ipv4_subnet(jarray<uint8_t>(4,0)),
                    protected_ipv4_subnet_mask(jarray<uint8_t>(4,0xFF)),
                    protected_ipv6_subnet(jarray<uint8_t>(16,0)),
                    protected_ipv6_subnet_mask(jarray<uint8_t>(16,0xFF)),
                    fixed_ipv4_prefix(jarray<uint8_t>(4,0)),
                    fixed_ipv4_prefix_mask(jarray<uint8_t>(4,0xFF)),
                    fixed_ipv6_prefix(jarray<uint8_t>(16,0)),
                    fixed_ipv6_prefix_mask(jarray<uint8_t>(16,0xFF)),
                    dhcp_interface("eth0"),
                    dhcp_server_ip("192.168.1.1"),
                    dhcp_timeout(3),
                    dhcp_retries(3),
                    request_configuration(false),
                    request_ipv6_suffix("::100/16"),
                    lifetime_soft(500),
                    lifetime_hard(800),
                    max_bytes_soft(1000000),
                    max_bytes_hard(1200000),
                    esp_encr("ENCR_AES_CBC"),
                    esp_integ("AUTH_HMAC_SHA2_256"),
                    esp_dh("PRF_HMAC_SHA2_256"),
                    use_esn(true),
                    bypassdf(false),
                    bypassdscp(false),
                    randiv(true),
                    tfclen(0),
                    arwindow(0),
                    ah_integ("AUTH_HMAC_SHA2_256"),
                    nonceInitiator(jarray<uint8_t>(8,0)),
                    nonceResponder(jarray<uint8_t>(8,0)),
                    ikepolicies()
        {}
    };

    //////////////////////////////////////////////////////////////////////
    /// JIKEPARSE - Parse IKEv2 configuration files
    ///
    /// @param input - XML data represented in a character string
    /// @param out - output file to write to (if desired)
    //////////////////////////////////////////////////////////////////////
    jikeparse(const char* input,
              const char* out=0);

    //////////////////////////////////////////////////////////////////////
    /// JIKEPARSE - Parse IKEv2 configuration files
    ///
    /// @param input - Filename of an XML data file to load
    /// @param out - output file to write to (if desired)
    //////////////////////////////////////////////////////////////////////
    jikeparse(std::string& input,
              const char* out=0);

    //////////////////////////////////////////////////////////////////////
    /// JIKEPARSE - Parse IKEv2 configuration files
    ///
    /// @param input - XMLDocument to load
    /// @param out - output file to write to (if desired)
    //////////////////////////////////////////////////////////////////////
    jikeparse(std::shared_ptr<tinyxml2::XMLDocument>& input,
              const char* out=0);

    //////////////////////////////////////////////////////////////////////
    /// JIKEPARSE standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jikeparse() {}

    //////////////////////////////////////////////////////////////////////
    /// @return - shared pointer to JIKECFG object
    //////////////////////////////////////////////////////////////////////
    void get(std::shared_ptr<jikecfg>& cfg);

private :

    // don't use these
    jikeparse() = delete;
    jikeparse(jikeparse& rhs) = delete;
    jikeparse(const jikeparse& rhs) = delete;

    /// Visit an element
    bool VisitEnter(const tinyxml2::XMLElement& element, const tinyxml2::XMLAttribute* attribute);
   
    /// Exit the element
    bool VisitExit(const tinyxml2::XMLElement& element);

    /// Visit the XMLText
    bool Visit(const tinyxml2::XMLText& text);

    // uppercase the input string
    std::string upper(const char* input);

    // member variables
    bool m_status;
    tinyxml2::XMLError m_err;
    std::shared_ptr<tinyxml2::XMLDocument> m_doc;
    std::shared_ptr<jikecfg> m_ikecfg;
};

}

#endif /* JIKEPARSE_H_ */
