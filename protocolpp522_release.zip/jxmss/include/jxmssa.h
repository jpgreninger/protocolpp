#ifndef JXMSSA_H
#define JXMSSA_H

////////////////////////////////////////////////////////////////////////////
///\class jxmssa jxmssa.h "include/jxmssa.h"
///
/// The eXtended Merkel Signature Scheme (XMSS), a hash-bashed digital signature scheme that
/// is based on existing descriptions in scientific literature. There are three types of
/// signatures specified for Winternitz One-Time Signature Plus (WOTS+), a one-time signature
/// scheme; XMSS, a single-tree scheme; and XMSS^MT, a multi-tree variant of XMSS. Both XMSS
/// and XMSS^MT use WOTS+ as a main bulding block. XMSS provides cryptographic digital
/// signatures without relying on the conjectured hardness of mathematical problems. Instead,
/// it is proven that it only relies on the properties of cryptographic hash functions. XMSS
/// provides strong security guarantees and is even secure when the collison resistance of
/// the underlying hash function is broken. Its is suitable for compact implementations, is
/// relatively simple to implement, and naturally resists side-channel attacks. Unlike most
/// other signature systems, hash-based signatures can so far withstand known attacks using
/// quantum computers
///
/// The xmss_algorithm_t used to create the security association is sufficient to determine
/// all other initial parameters for the desired XMSS signatures
///
///\image html quantumresist.jpg "QuantumResist"
///\image latex quantumresist.eps "QuantumResist" width=10cm
///
///\image html xmss_tree.png "XMSS Tree"
///\image latex xmss_tree.eps "XMSS Tree" width=10cm
///
/// <center>Protocol++&reg; (ProtocolPP&reg;) written by : John Peter Greninger &bull; &copy; John Peter Greninger 2015-2022 &bull; All Rights Reserved</center>
/// <center><sub>All copyrights and trademarks are the property of their respective owners</sub></center>
///
/// The source code contained or described herein and all documents related to the source code 
/// (herein called "Material") are owned by John Peter Greninger and Sheila Rocha Greninger. Title
/// to the Material remains with John Peter Greninger and Sheila Rocha Greninger. The Material contains
/// trade secrets and proprietary and confidential information of John Peter Greninger and Sheila Rocha
/// Greninger. The Material is protected by worldwide copyright and trade secret laws and treaty
/// provisions. No part of the Material may be used, copied, reproduced, modified, published, uploaded,
/// posted, transmitted, distributed, or disclosed in any way without prior express written consent of
/// John Peter Greninger and Sheila Rocha Greninger (both are required)
/// 
/// No license under any patent, copyright, trade secret, or other intellectual property right is granted
/// to or conferred upon you by disclosure or delivery of the Materials, either expressly, by implication,
/// inducement, estoppel, or otherwise. Any license under such intellectual property rights must be express
/// and approved by John Peter Greninger and Sheila Rocha Greninger in writing
///
/// Licensing information can be found at <B>www.protocolpp.com/license</B> with use of the binary forms
/// permitted provided that the following conditions are met:
///
/// * Redistributions in binary form must reproduce the above copyright notice, this list
///   of conditions and the following disclaimer in the documentation and/or other materials
///   provided with the distribution
///
/// * Any and all modifications must be returned to John Peter Greninger at GitHub.com
///   https://github.com/jpgreninger/protocolpp for evaluation. Inclusion of modifications
///   in the source code shall be determined solely by John Peter Greninger. Failure to
///   provide modifications shall render this license NULL and VOID and revoke any rights
///   to use of Protocol++&reg;
///
/// * Commercial use (incidental or not) requires a fee-based license obtainable at <B>www.protocolpp.com/shop</B>
///
/// * Academic or research use requires prior written and notarized permission from John Peter
///   and Sheila Rocha Greninger
///
/// Use of the source code requires purchase of the source code. Source code can be purchased
/// at <B>www.protocolpp.com/shop</B>
///
/// * <B>US Copyrights at https://www.copyright.gov/</B>
///   * <B>TXu002059872 (Version 1.0.0)</B>
///   * <B>TXu002066632 (Version 1.2.7)</B>
///   * <B>TXu002082674 (Version 1.4.0)</B>
///   * <B>TXu002097880 (Version 2.0.0)</B>
///   * <B>TXu002169236 (Version 3.0.1)</B>
///   * <B>TXu002182417 (Version 4.0.0)</B>
///   * <B>TXu002219402 (Version 5.0.0)</B>
///   * <B>TXu002272076 (Version 5.2.1)</B>
///
/// The name of its contributor may not be used to endorse or promote products derived
/// from this software without specific prior written permission and licensing
///
/// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTOR "AS IS" AND ANY
/// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
/// OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
/// SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
/// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
/// OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
/// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
/// TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
/// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
///
////////////////////////////////////////////////////////////////////////////

#include "jsecass.h"

namespace ProtocolPP {

class jxmssa : public jsecass {
 
public:

    //////////////////////////////////////////////////////////////////////
    /// XMSS security association with default values
    //////////////////////////////////////////////////////////////////////
    jxmssa();
    
    //////////////////////////////////////////////////////////////////////
    /// XMSS Generate an XMSS key pair
    /// @param mode - Mode of operation (GENKEYPAIR, PKISIGN, PKIVERIFY)
    /// @param algorithm - XMSS algorith to use for signing
    //////////////////////////////////////////////////////////////////////
    jxmssa(keymode_t mode,
           xmss_algorithm_t algorithm);

    //////////////////////////////////////////////////////////////////////
    /// XMSS Generate an XMSS key pair
    /// @param mode - Mode of operation (GENKEYPAIR, PKISIGN, PKIVERIFY)
    /// @param algorithm - XMSS algorith to use for signing
    /// @param prvkey - Private XMSS key
    /// @param pubkey - Public XMSS key
    //////////////////////////////////////////////////////////////////////
    jxmssa(keymode_t mode,
           xmss_algorithm_t algorithm,
           std::shared_ptr<jarray<uint8_t>>& prvkey,
           std::shared_ptr<jarray<uint8_t>>& pubkey);
   
    //////////////////////////////////////////////////////////////////////
    /// treeSig - Generate a XMSS signature and update XMSS private key
    /// @param security - XMSS security association
    //////////////////////////////////////////////////////////////////////
    jxmssa(jxmssa& security);

    //////////////////////////////////////////////////////////////////////
    /// treeSig - Generate a XMSS signature and update XMSS private key
    /// @param security - XMSS security association
    //////////////////////////////////////////////////////////////////////
    explicit jxmssa(std::shared_ptr<jxmssa>& security);

    //////////////////////////////////////////////////////////////////////
    /// Standard deconstructor
    //////////////////////////////////////////////////////////////////////
    virtual ~jxmssa() {}

    //////////////////////////////////////////////////////////////////////
    /// Allows the user to update the fields of XMSS security association
    ///
    /// <table>
    /// <caption id="xmssa_set">XMSS SA Set Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>xmss_algorithm_t<td>AUTH<td>set_field<ProtocolPP::xmss_algorithm_t>(ProtocolPP::field_t::XMSSALG, ProtocolPP::XMSS_SHA2_10_256)
    /// <tr><td>uint32_t<td>TREEHEIGHT<td>set_field<uint32_t>(ProtocolPP::field_t::TREEHEIGHT, 0x0000000A)
    /// <tr><td>uint32_t<td>LENGTH<td>set_field<uint32_t>(ProtocolPP::field_t::LENGTH, 0x00000020)
    /// <tr><td>uint32_t<td>WINTZ<td>set_field<uint32_t>(ProtocolPP::field_t::WINTZ, 0x00000010)
    /// <tr><td>jarray<uint8_t><td>STACKPUSH<td>set_field<jarray<uint8_t>>(ProtocolPP::field_t::STACKPUSH, jarray<uint8_t>("0xAABBCCDD"))
    /// </table>
    ///
    /// @param field - field to update the security association with
    /// @param fieldval - value to update the security association with
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    void set_field(field_t field, T fieldval);

    //////////////////////////////////////////////////////////////////////
    /// Returns the field in XMSSA
    ///
    /// <table>
    /// <caption id="xmssa_get">XMSS SA Get Fields</caption>
    /// <tr><th>field type<th>field name<th>Example
    /// <tr><td>direction_t<td>DIRECTION<td>ProtocolPP::direction_t mydir = get_field<ProtocolPP::direction_t>(ProtocolPP::field_t::DIRECTION)
    /// <tr><td>xmss_algorithm_t<td>XMSSALG<td>ProtocolPP::xmss_algorithm_t myalg = get_field<ProtocolPP::xmss_algorithm_t>(ProtocolPP::field_t::XMSSALG)
    /// <tr><td>uint32_t<td>TREEHEIGHT<td>uint32_t treeheight = get_field<uint32_t>(ProtocolPP::field_t::TREEHEIGHT)
    /// <tr><td>uint32_t<td>LENGTH<td>uint32_t mylen = get_field<uint32_t>(ProtocolPP::field_t::LENGTH)
    /// <tr><td>uint32_t<td>WINTZ<td>uint32_t myw = get_field<uint32_t>(ProtocolPP::field_t::WINTZ)
    /// <tr><td>uint32_t<td>STACKLEN<td>uint32_t myw = get_field<uint32_t>(ProtocolPP::field_t::STACKLEN)
    /// <tr><td>jarray<uint8_t><td>STACKPOP<td>jarray<uint8_t> mypop = get_field<jarray<uint8_t>>(ProtocolPP::field_t::STACKPOP)
    /// <tr><td>jarray<uint8_t><td>STACKTOP<td>jarray<uint8_t> mypop = get_field<jarray<uint8_t>>(ProtocolPP::field_t::STACKTOP)
    /// <tr><td>std::stack<jarray<uint8_t>><td>STACK<td>std::stack<jarray<uint8_t>> mypop = get_field<std::stack<jarray<uint8_t>>>(ProtocolPP::field_t::STACK)
    /// </table>
    ///
    /// @param field - field to retrieve from the security association
    /// @return value of the field in the security association
    //////////////////////////////////////////////////////////////////////
    template <typename T>
    T get_field(field_t field);

    //////////////////////////////////////////////////////////////////////
    /// Prints the protocol as an XML object
    /// @param myxml - XMLPrinter object to print with
    /// @param direction - randomization
    //////////////////////////////////////////////////////////////////////
    void to_xml(tinyxml2::XMLPrinter& myxml, direction_t direction);

private:

    // don't use these
    jxmssa(const jxmssa& rhs) = delete;

    // member variables
    direction_t m_dir;
    keymode_t m_mode;
    xmss_algorithm_t m_auth;
    unsigned int m_height;
    unsigned int m_xmsslen;
    unsigned int m_xmssw;
    jarray<uint8_t> m_prvkey;
    jarray<uint8_t> m_pubkey;
    std::vector<jarray<uint8_t>> m_stack;
};
    
}
    
#endif
    
