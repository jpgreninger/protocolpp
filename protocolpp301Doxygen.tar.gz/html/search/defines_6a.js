var searchData=
[
  ['jpoly1305_5f32bit',['JPOLY1305_32BIT',['../jpoly1305_8h.html#aed801d3051a0e2bb336cad3e53dfe721',1,'jpoly1305.h']]],
  ['jpoly1305_5fblock_5fsize',['jpoly1305_block_size',['../poly1305-16_8h.html#a02560c77261dc16b7fbfab12f3c18b92',1,'jpoly1305_block_size():&#160;poly1305-16.h'],['../poly1305-32_8h.html#a02560c77261dc16b7fbfab12f3c18b92',1,'jpoly1305_block_size():&#160;poly1305-32.h'],['../poly1305-64_8h.html#a02560c77261dc16b7fbfab12f3c18b92',1,'jpoly1305_block_size():&#160;poly1305-64.h'],['../poly1305-8_8h.html#a02560c77261dc16b7fbfab12f3c18b92',1,'jpoly1305_block_size():&#160;poly1305-8.h']]],
  ['jpoly1305_5fnoinline',['JPOLY1305_NOINLINE',['../poly1305-16_8h.html#a1f5ba538f39902d7465f17c214f1ea24',1,'JPOLY1305_NOINLINE():&#160;poly1305-16.h'],['../poly1305-32_8h.html#a1f5ba538f39902d7465f17c214f1ea24',1,'JPOLY1305_NOINLINE():&#160;poly1305-32.h'],['../poly1305-8_8h.html#a1f5ba538f39902d7465f17c214f1ea24',1,'JPOLY1305_NOINLINE():&#160;poly1305-8.h']]]
];
