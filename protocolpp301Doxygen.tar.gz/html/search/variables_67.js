var searchData=
[
  ['generate_5fallow_5fpolicies',['generate_allow_policies',['../structProtocolPP_1_1jikeparse_1_1jikecfg.html#aa04440590ad301d23f69c034d40ce08f',1,'ProtocolPP::jikeparse::jikecfg']]]
];
