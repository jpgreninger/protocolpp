var searchData=
[
  ['gzip_5fos_5fcode',['GZIP_OS_CODE',['../config_8h.html#af28128118c3579150e041ede1256e929',1,'config.h']]]
];
