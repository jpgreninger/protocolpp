var searchData=
[
  ['leftover',['leftover',['../structProtocolPP_1_1jpoly1305__state__internal__t.html#a16d315bfc0635c6b359eee0adbf8a2ce',1,'ProtocolPP::jpoly1305_state_internal_t']]],
  ['length',['length',['../classPlatformPP_1_1jsgt.html#a087355a2c8afc35b6c4857484948fa02',1,'PlatformPP::jsgt::length()'],['../jsgt_8h.html#ac8d42bcd4a44e078047ccd7291059238',1,'length():&#160;jsgt.h']]],
  ['lifetime_5fhard',['lifetime_hard',['../structProtocolPP_1_1jikeparse_1_1jikecfg.html#af66fe8979196d3b816a629dcdadebd41',1,'ProtocolPP::jikeparse::jikecfg']]],
  ['lifetime_5fsoft',['lifetime_soft',['../structProtocolPP_1_1jikeparse_1_1jikecfg.html#a0d64ea5ba82514eadcf2f4e5be35e44b',1,'ProtocolPP::jikeparse::jikecfg']]],
  ['local_5fid',['local_id',['../structProtocolPP_1_1jikeparse_1_1jikecfg.html#a099c266ab6cf0fe1f0f95f2e83a6fe8e',1,'ProtocolPP::jikeparse::jikecfg']]],
  ['local_5ftype',['local_type',['../structProtocolPP_1_1jikeparse_1_1jikecfg.html#a85573f099f170456d15020fa1f177963',1,'ProtocolPP::jikeparse::jikecfg']]],
  ['longopt',['longopt',['../structoption_1_1Descriptor.html#a470c449dfa894c9bfda2dae026142b4b',1,'option::Descriptor']]],
  ['lword_5fmax',['LWORD_MAX',['../config_8h.html#a2e8f5e8729bf2ba8a903917e639ec16a',1,'config.h']]]
];
