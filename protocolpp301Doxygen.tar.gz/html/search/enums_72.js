var searchData=
[
  ['replay_5ft',['replay_t',['../namespaceProtocolPP.html#a0160929af40c2a496fe7386216cc2c2f',1,'ProtocolPP']]],
  ['rohc_5fattr_5ft',['rohc_attr_t',['../namespaceProtocolPP.html#a768a931e65e8cade586b7ab455e2f63b',1,'ProtocolPP']]],
  ['role_5fid_5ft',['role_id_t',['../namespaceProtocolPP.html#a058e2e1577bb1285945f31d67717428b',1,'ProtocolPP']]],
  ['rsapadtype_5ft',['rsapadtype_t',['../namespaceProtocolPP.html#ad62ec36e4436383ce51a70c3f1417b60',1,'ProtocolPP']]]
];
