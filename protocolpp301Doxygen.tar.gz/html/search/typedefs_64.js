var searchData=
[
  ['dword',['dword',['../config_8h.html#a15256cb19835a1685641655efb8fdc60',1,'config.h']]]
];
