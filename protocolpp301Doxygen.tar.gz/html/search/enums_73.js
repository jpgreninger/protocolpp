var searchData=
[
  ['severity_5ftype',['severity_type',['../classInterfacePP_1_1jlogger.html#a956fca3db5251c3c9db9c8cea636d445',1,'InterfacePP::jlogger']]],
  ['srtpcipher_5ft',['srtpcipher_t',['../namespaceProtocolPP.html#af9de89d351f27b280c94bd76e19ba48a',1,'ProtocolPP']]]
];
