var searchData=
[
  ['rot',['ROT',['../jzuc_8h.html#a52ada004164db2f64d2547616cb854aa',1,'jzuc.h']]],
  ['rotate_5fbytes',['rotate_bytes',['../SFMT-neon_8h.html#a019988f2ffb34f9b9c4ae71087a50bf1',1,'SFMT-neon.h']]]
];
