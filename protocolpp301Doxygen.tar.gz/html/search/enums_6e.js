var searchData=
[
  ['notify_5ferr_5ft',['notify_err_t',['../namespaceProtocolPP.html#ab59a43ba85522b3c0aade2539eafd12c',1,'ProtocolPP']]],
  ['notify_5fstatus_5ft',['notify_status_t',['../namespaceProtocolPP.html#a29bea4a4fafb9611e3ee2be488fa1cc7',1,'ProtocolPP']]]
];
