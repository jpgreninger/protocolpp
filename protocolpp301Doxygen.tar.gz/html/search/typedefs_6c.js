var searchData=
[
  ['lword',['lword',['../config_8h.html#af483e021877846e97888686e55db93c1',1,'config.h']]]
];
