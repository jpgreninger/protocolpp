var searchData=
[
  ['has_5fgcc_5f4_5f4_5f64bit',['HAS_GCC_4_4_64BIT',['../jpoly1305_8h.html#adb1ce1b2de7d12db1ebf9e3021cd7b64',1,'HAS_GCC_4_4_64BIT():&#160;jpoly1305.h'],['../tinyxml2_8h.html#adb1ce1b2de7d12db1ebf9e3021cd7b64',1,'HAS_GCC_4_4_64BIT():&#160;tinyxml2.h']]],
  ['has_5fmsvc_5f64bit',['HAS_MSVC_64BIT',['../jpoly1305_8h.html#ac130801bff856c479ceb0523173b50d7',1,'HAS_MSVC_64BIT():&#160;jpoly1305.h'],['../tinyxml2_8h.html#ac130801bff856c479ceb0523173b50d7',1,'HAS_MSVC_64BIT():&#160;tinyxml2.h']]],
  ['has_5fsizeof_5fint128_5f64bit',['HAS_SIZEOF_INT128_64BIT',['../jpoly1305_8h.html#a7db220fb5c6d6f68cc589d1ef3b7d94e',1,'HAS_SIZEOF_INT128_64BIT():&#160;jpoly1305.h'],['../tinyxml2_8h.html#a7db220fb5c6d6f68cc589d1ef3b7d94e',1,'HAS_SIZEOF_INT128_64BIT():&#160;tinyxml2.h']]],
  ['hex',['HEX',['../jenum_8h.html#a708c7e27c25676e160facfe16e534d58',1,'jenum.h']]],
  ['hexlog',['HEXLOG',['../jenum_8h.html#a62b656fd8b00f5faba63f1b2530f78a6',1,'jenum.h']]]
];
