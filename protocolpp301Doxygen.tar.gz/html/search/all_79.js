var searchData=
[
  ['yellow',['YELLOW',['../classInterfacePP_1_1jlogger.html#a1ec7adeb3e0960926db5f44276dcc7d6aa349d58894ff2b064b30a309ebc8d2b8',1,'InterfacePP::jlogger']]]
];
