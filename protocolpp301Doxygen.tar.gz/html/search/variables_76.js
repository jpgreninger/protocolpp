var searchData=
[
  ['vendor_5fid',['vendor_id',['../structProtocolPP_1_1jikeparse_1_1jikecfg.html#a7f87c831a9ec03e219d35154e7d649b2',1,'ProtocolPP::jikeparse::jikecfg']]]
];
