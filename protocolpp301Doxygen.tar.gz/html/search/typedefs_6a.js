var searchData=
[
  ['jpoly1305_5fstate_5finternal_5ft',['jpoly1305_state_internal_t',['../namespaceProtocolPP.html#a88f1286f96324cf36a14682523aa4793',1,'ProtocolPP']]]
];
