var searchData=
[
  ['namespace_5fbegin',['NAMESPACE_BEGIN',['../config_8h.html#ad149ead4031d3962c87e84a3e12f4866',1,'config.h']]],
  ['namespace_5fend',['NAMESPACE_END',['../config_8h.html#a552036593282adfb00999ab4152fc0ac',1,'config.h']]],
  ['no_5fos_5fdependence',['NO_OS_DEPENDENCE',['../config_8h.html#a819055b58208e6db92ae55a5f6443281',1,'config.h']]]
];
