var searchData=
[
  ['hasbom',['HasBOM',['../classtinyxml2_1_1XMLDocument.html#a530649e9de7e5aa8df9c37f66197fcb6',1,'tinyxml2::XMLDocument']]],
  ['hasfile',['hasfile',['../classProtocolPP_1_1jprotocol.html#abb853e85c122eca0a47b0ad3ffdfff19',1,'ProtocolPP::jprotocol']]]
];
