var searchData=
[
  ['byte',['byte',['../config_8h.html#a0c8186d9b9b7880309c27230bbb5e69d',1,'byte():&#160;config.h'],['../jmodes_8h.html#ae3a497195d617519e5353ea7b417940f',1,'Byte():&#160;jmodes.h']]]
];
