var searchData=
[
  ['temporarywriter',['TemporaryWriter',['../structoption_1_1PrintUsageImplementation_1_1TemporaryWriter.html',1,'option::PrintUsageImplementation']]]
];
